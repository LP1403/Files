(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["main"],{

/***/ 50492:
/*!************************************************!*\
  !*** ./src/app/MyMissingTranslationHandler.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MyMissingTranslationHandler": () => (/* binding */ MyMissingTranslationHandler)
/* harmony export */ });
class MyMissingTranslationHandler {
  handle(params) {
    console.log('missing translation: ' + params.key);
    return params.key;
  }
}

/***/ }),

/***/ 23966:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 82454);



const routes = [{
  path: '',
  redirectTo: 'landing',
  pathMatch: 'full'
}, {
  path: 'landing',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_shared_module_ts"), __webpack_require__.e("src_app_shared_pages_landing_landing_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./shared/pages/landing/landing.module */ 74206)).then(m => m.LandingPageModule)
}, {
  path: 'onboarding',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_shared_module_ts"), __webpack_require__.e("common"), __webpack_require__.e("src_app_onboarding_onboarding_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./onboarding/onboarding.module */ 68207)).then(m => m.OnboardingModule)
}, {
  path: 'access',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_shared_module_ts"), __webpack_require__.e("default-src_app_invite_invite_module_ts"), __webpack_require__.e("default-src_app_access_pages_access-point-wizard_new-access-point_business_ts-src_app_shared_-cd58b1"), __webpack_require__.e("src_app_access_access_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./access/access.module */ 85356)).then(m => m.AccessModule)
}, {
  path: 'sites',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_shared_module_ts"), __webpack_require__.e("default-src_app_invite_invite_module_ts"), __webpack_require__.e("default-src_app_access_pages_access-point-wizard_new-access-point_business_ts-src_app_shared_-cd58b1"), __webpack_require__.e("src_app_sites_sites_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./sites/sites.module */ 68090)).then(m => m.SitesModule)
}, {
  path: 'invite',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_shared_module_ts"), __webpack_require__.e("default-src_app_invite_invite_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./invite/invite.module */ 26723)).then(m => m.InviteModule)
}, {
  path: 'scan',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_shared_module_ts"), __webpack_require__.e("src_app_scan_scan_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./scan/scan.module */ 85809)).then(m => m.ScanModule)
}, {
  path: 'credential',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_shared_module_ts"), __webpack_require__.e("src_app_credential_credential_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./credential/credential.module */ 2702)).then(m => m.CredentialPageModule)
}, {
  path: 'notifications',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_shared_module_ts"), __webpack_require__.e("src_app_notification_notification_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./notification/notification.module */ 84858)).then(m => m.NotificationModule)
}, {
  path: 'profile',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_shared_module_ts"), __webpack_require__.e("common"), __webpack_require__.e("src_app_profile_profile_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./profile/profile.module */ 96239)).then(m => m.ProfilePageModule)
}, {
  path: 'faq',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_shared_module_ts"), __webpack_require__.e("src_app_faq_faq_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./faq/faq.module */ 92763)).then(m => m.FaqPageModule)
}, {
  path: 'error',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_shared_module_ts"), __webpack_require__.e("src_app_shared_pages_error_error_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./shared/pages/error/error.module */ 67282)).then(m => m.ErrorPageModule)
}, {
  path: 'landing',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_shared_module_ts"), __webpack_require__.e("src_app_shared_pages_landing_landing_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./shared/pages/landing/landing.module */ 74206)).then(m => m.LandingPageModule)
}, {
  path: 'pricing',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_shared_module_ts"), __webpack_require__.e("src_app_shared_pages_pricing_pricing_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./shared/pages/pricing/pricing.module */ 89177)).then(m => m.PricingPageModule)
}];
let AppRoutingModule = class AppRoutingModule {};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgModule)({
  imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule.forRoot(routes, {
    preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__.PreloadAllModules
  })],
  exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule]
})], AppRoutingModule);


/***/ }),

/***/ 66401:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app.component.html?ngResource */ 33383);
/* harmony import */ var _app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app.component.scss?ngResource */ 79595);
/* harmony import */ var _app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var _shared_services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./shared/services/user.service */ 31880);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capacitor/core */ 39734);
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! firebase/app */ 4105);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/environments/environment */ 20553);
/* harmony import */ var _capacitor_firebase_analytics__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @capacitor-firebase/analytics */ 66081);
/* harmony import */ var _shared_plugins_FirebaseInstallationPlugin__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./shared/plugins/FirebaseInstallationPlugin */ 74743);
/* harmony import */ var firebase_installations__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! firebase/installations */ 32761);
/* harmony import */ var _capacitor_status_bar__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @capacitor/status-bar */ 50512);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _shared_pages_error_error_page__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./shared/pages/error/error.page */ 95885);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 85439);
/* harmony import */ var capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! capacitor-native-biometric */ 51685);


var _class;
var AppComponent_1;

















let AppComponent = AppComponent_1 = (_class = class AppComponent {
  constructor(translate, userService, navController) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "firebaseApp", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "incompatible$", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "window", window);
    this.translate = translate;
    this.userService = userService;
    this.navController = navController;
    this.incompatible$ = new rxjs__WEBPACK_IMPORTED_MODULE_14__.ReplaySubject(0);
    AppComponent_1.isIncompatible = this.incompatible$.asObservable();
    if (screen.orientation?.lock) {
      screen.orientation.lock('portrait').then(success => {}, fail => {});
    }
  }
  ngOnInit() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.configureStatusBar();
      yield _this.checkIncompatibleDevice();
      _this.initializeFirebase();
      _this.translate.setDefaultLang('es');
      _this.translate.use('es');
      const language = window.navigator.language;
      console.log(language);
      yield _capacitor_firebase_analytics__WEBPACK_IMPORTED_MODULE_8__.FirebaseAnalytics.logEvent({
        name: 'InitApp'
      });
      if (!_capacitor_core__WEBPACK_IMPORTED_MODULE_5__.Capacitor.isNativePlatform()) {
        yield _this.userService.getInitialPage();
      }
      const preloader = document.getElementById('preloader');
      if (preloader) {
        preloader.classList.add('preloader-hide');
      }
    })();
  }
  initializeFirebase() {
    var _this2 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_capacitor_core__WEBPACK_IMPORTED_MODULE_5__.Capacitor.isNativePlatform()) {
        AppComponent_1.installationID = (yield _shared_plugins_FirebaseInstallationPlugin__WEBPACK_IMPORTED_MODULE_9__["default"].installationID({
          value: 'installationID'
        }))?.value ?? 'Error';
      } else {
        _this2.firebaseApp = (0,firebase_app__WEBPACK_IMPORTED_MODULE_6__.initializeApp)(src_environments_environment__WEBPACK_IMPORTED_MODULE_7__.environment.firebase);
        const installations = (0,firebase_installations__WEBPACK_IMPORTED_MODULE_10__.getInstallations)(_this2.firebaseApp);
        AppComponent_1.installationID = yield (0,firebase_installations__WEBPACK_IMPORTED_MODULE_10__.getId)(installations);
      }
      console.log('InstallationID ' + AppComponent_1.installationID);
    })();
  }
  configureStatusBar() {
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_capacitor_core__WEBPACK_IMPORTED_MODULE_5__.Capacitor.isPluginAvailable('StatusBar')) {
        yield _capacitor_status_bar__WEBPACK_IMPORTED_MODULE_11__.StatusBar.setStyle({
          style: _capacitor_status_bar__WEBPACK_IMPORTED_MODULE_11__.Style.Dark
        });
        if (_capacitor_core__WEBPACK_IMPORTED_MODULE_5__.Capacitor.getPlatform() === 'android') yield _capacitor_status_bar__WEBPACK_IMPORTED_MODULE_11__.StatusBar.setBackgroundColor({
          color: '#0078d7'
        });
      }
    })();
  }
  checkIncompatibleDevice() {
    var _this3 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_capacitor_core__WEBPACK_IMPORTED_MODULE_5__.Capacitor.isNativePlatform()) {
        _this3.window.IRoot.isRooted( /*#__PURE__*/function () {
          var _ref = (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (res) {
            if (res) {
              const msg = new _shared_pages_error_error_page__WEBPACK_IMPORTED_MODULE_12__.ErrorMessage();
              msg.hidePanel = true;
              msg.title = _this3.translate.instant('error.rootedTitle');
              msg.message = _this3.translate.instant('error.rootedMessage');
              _this3.userService.errorMessage = msg;
              _this3.incompatible$.next(true);
            } else {
              const result = yield capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_13__.NativeBiometric.isAvailable();
              if (result.isAvailable === false) {
                const msg = new _shared_pages_error_error_page__WEBPACK_IMPORTED_MODULE_12__.ErrorMessage();
                msg.hidePanel = true;
                msg.title = _this3.translate.instant('error.biometricTitle');
                msg.message = _this3.translate.instant('error.biometricMessage');
                _this3.userService.errorMessage = msg;
              }
              _this3.incompatible$.next(result.isAvailable === false);
            }
          });
          return function (_x) {
            return _ref.apply(this, arguments);
          };
        }(), err => {
          console.log('cdvRootBeer Error', err);
        });
      } else {
        _this3.incompatible$.next(false);
      }
    })();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "installationID", ''), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "isIncompatible", void 0), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_15__.TranslateService
}, {
  type: _shared_services_user_service__WEBPACK_IMPORTED_MODULE_4__.UserService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_16__.NavController
}]), _class);
AppComponent = AppComponent_1 = (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_18__.Component)({
  selector: 'app-root',
  template: _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_2__,
  styles: [(_app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_3___default())]
})], AppComponent);


/***/ }),

/***/ 78629:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule),
/* harmony export */   "createTranslateLoader": () => (/* binding */ createTranslateLoader)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/platform-browser */ 23380);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-routing.module */ 23966);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app.component */ 66401);
/* harmony import */ var _angular_service_worker__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/service-worker */ 20649);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../environments/environment */ 20553);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common/http */ 74048);
/* harmony import */ var _fake_fakebackend__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./fake/fakebackend */ 22642);
/* harmony import */ var ngx_skeleton_loader__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ngx-skeleton-loader */ 12413);
/* harmony import */ var _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @fortawesome/angular-fontawesome */ 30708);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @fortawesome/free-solid-svg-icons */ 99977);
/* harmony import */ var _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @fortawesome/free-regular-svg-icons */ 65920);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @ngx-translate/http-loader */ 32615);
/* harmony import */ var _MyMissingTranslationHandler__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./MyMissingTranslationHandler */ 50492);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/platform-browser/animations */ 65364);
/* harmony import */ var _angular_common_locales_es__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/locales/es */ 53696);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 89650);
/* harmony import */ var ngx_timeago__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ngx-timeago */ 14899);
/* harmony import */ var _auth_auth_interceptor__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./auth/auth.interceptor */ 31048);
/* harmony import */ var _interceptors_common_interceptor__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./interceptors/common.interceptor */ 65015);

var _class;
























(0,_angular_common__WEBPACK_IMPORTED_MODULE_8__.registerLocaleData)(_angular_common_locales_es__WEBPACK_IMPORTED_MODULE_9__["default"], 'es');
let AppModule = (_class = class AppModule {
  constructor(library) {
    library.addIconPacks(_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_10__.fas, _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_11__.far);
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_12__.FaIconLibrary
}]), _class);
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.NgModule)({
  declarations: [_app_component__WEBPACK_IMPORTED_MODULE_2__.AppComponent],
  imports: [_angular_common_http__WEBPACK_IMPORTED_MODULE_15__.HttpClientModule, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_16__.BrowserModule, ngx_timeago__WEBPACK_IMPORTED_MODULE_17__.TimeagoModule.forRoot({
    formatter: {
      provide: ngx_timeago__WEBPACK_IMPORTED_MODULE_17__.TimeagoFormatter,
      useClass: ngx_timeago__WEBPACK_IMPORTED_MODULE_17__.TimeagoCustomFormatter
    }
  }), _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_18__.BrowserAnimationsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonicModule.forRoot({
    animated: false
  }), _app_routing_module__WEBPACK_IMPORTED_MODULE_1__.AppRoutingModule, _angular_service_worker__WEBPACK_IMPORTED_MODULE_20__.ServiceWorkerModule.register('ngsw-worker.js', {
    enabled: _environments_environment__WEBPACK_IMPORTED_MODULE_3__.environment.production,
    // Register the ServiceWorker as soon as the application is stable
    // or after 30 seconds (whichever comes first).
    registrationStrategy: 'registerWhenStable:30000'
  }), ngx_skeleton_loader__WEBPACK_IMPORTED_MODULE_21__.NgxSkeletonLoaderModule, _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_12__.FontAwesomeModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_22__.TranslateModule.forRoot({
    loader: {
      provide: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_22__.TranslateLoader,
      useFactory: createTranslateLoader,
      deps: [_angular_common_http__WEBPACK_IMPORTED_MODULE_15__.HttpClient]
    },
    missingTranslationHandler: {
      provide: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_22__.MissingTranslationHandler,
      useClass: _MyMissingTranslationHandler__WEBPACK_IMPORTED_MODULE_5__.MyMissingTranslationHandler
    },
    useDefaultLang: false
  })],
  providers: [{
    provide: _angular_router__WEBPACK_IMPORTED_MODULE_23__.RouteReuseStrategy,
    useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonicRouteStrategy
  }, {
    provide: _angular_core__WEBPACK_IMPORTED_MODULE_14__.LOCALE_ID,
    useValue: 'es'
  }, _fake_fakebackend__WEBPACK_IMPORTED_MODULE_4__.fakeBackendProvider, ngx_timeago__WEBPACK_IMPORTED_MODULE_17__.TimeagoIntl, _auth_auth_interceptor__WEBPACK_IMPORTED_MODULE_6__.authInterceptorProviders, _interceptors_common_interceptor__WEBPACK_IMPORTED_MODULE_7__.commonHttpInterceptorProvider],
  bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_2__.AppComponent]
})], AppModule);

function createTranslateLoader(http) {
  return new _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_24__.TranslateHttpLoader(http, './assets/i18n/', '.json');
}

/***/ }),

/***/ 31048:
/*!******************************************!*\
  !*** ./src/app/auth/auth.interceptor.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthInterceptor": () => (/* binding */ AuthInterceptor),
/* harmony export */   "authInterceptorProviders": () => (/* binding */ authInterceptorProviders)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 74048);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 47530);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 40803);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 70672);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 56997);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 75162);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 37574);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 74110);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./auth.service */ 75148);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _shared_models_SessionTokenViewModel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../shared/models/SessionTokenViewModel */ 93490);

var _class;









const TOKEN_HEADER_KEY = 'Authorization'; // for Spring Boot back-end
//const TOKEN_HEADER_KEY = 'x-access-token';    // for Node.js Express back-end
let AuthInterceptor = (_class = class AuthInterceptor {
  constructor(authService, navController, route) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "authService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "route", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "isRefreshing", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "refreshTokenSubject", new rxjs__WEBPACK_IMPORTED_MODULE_3__.BehaviorSubject(null));
    this.authService = authService;
    this.navController = navController;
    this.route = route;
  }
  intercept(req, next) {
    //req = req.clone({ headers: req.headers.set('Content-Type', 'application/json') });
    let authReq = req;
    const token = this.authService.getToken();
    if (token != null) {
      authReq = this.addTokenHeader(req, token);
    }
    return next.handle(authReq).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.catchError)(error => {
      if (error instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpErrorResponse && error.status === 401) {
        if (this.authService.hasUserDataSnapshot()) {
          return this.handle401Error(authReq, next);
        } else {
          this.signOut(); //Fuerzo el logout para que el usuario termine en el login nuevamente
          return new rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable();
        }
      } else {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.throwError)(error);
      }
    }));
  }
  signOut() {
    this.authService.clearUserData();
    this.navController.navigateRoot('onboarding/splash');
  }
  handle401Error(request, next) {
    if (!this.isRefreshing) {
      this.isRefreshing = true;
      this.refreshTokenSubject.next(null);
      const refreshToken = this.authService.getRefreshToken();
      const userToken = this.authService.getToken();
      if (userToken && refreshToken) {
        const vm = new _shared_models_SessionTokenViewModel__WEBPACK_IMPORTED_MODULE_2__.SessionTokenViewModel();
        vm.refreshToken = refreshToken;
        vm.token = userToken;
        return this.authService.refreshToken(vm).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.switchMap)(ret => {
          this.isRefreshing = false;
          this.authService.saveToken(ret.data.token);
          this.authService.saveRefreshToken(ret.data.refreshToken);
          this.refreshTokenSubject.next(ret.data.token);
          return next.handle(this.addTokenHeader(request, ret.data.token));
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.catchError)(err => {
          this.isRefreshing = false;
          this.authService.clearUserData();
          this.signOut();
          return (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.throwError)(err);
        }));
      }
    }
    return this.refreshTokenSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.filter)(token => token !== null), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.switchMap)(token => next.handle(this.addTokenHeader(request, token))));
  }
  addTokenHeader(request, token) {
    /* for Spring Boot back-end */
    return request.clone({
      headers: request.headers.set(TOKEN_HEADER_KEY, 'Bearer ' + token)
    });
    /* for Node.js Express back-end */
    //return request.clone({ headers: request.headers.set(TOKEN_HEADER_KEY, token) });
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _auth_service__WEBPACK_IMPORTED_MODULE_1__.AuthService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.NavController
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.ActivatedRoute
}]), _class);
AuthInterceptor = (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.Injectable)()], AuthInterceptor);

const authInterceptorProviders = [{
  provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HTTP_INTERCEPTORS,
  useClass: AuthInterceptor,
  multi: true
}];

/***/ }),

/***/ 75148:
/*!**************************************!*\
  !*** ./src/app/auth/auth.service.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 74048);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 85439);
/* harmony import */ var _shared_services_base_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../shared/services/base.service */ 15127);

var _class;





const TOKEN_KEY = 'auth-token';
const TOKEN_ANOM_KEY = 'anom-token';
const REFRESHTOKEN_KEY = 'auth-refreshtoken';
const LOGIN_DATA_KEY = 'loginData';
let AuthService = (_class = class AuthService {
  constructor(http) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "http", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "hasUserData", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "userData$", void 0);
    this.http = http;
    this.userData$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__.ReplaySubject(0);
    this.hasUserData = this.userData$.asObservable();
    this.userData$.next(this.hasUserDataSnapshot());
  }
  hasUserDataSnapshot() {
    return localStorage.getItem(TOKEN_KEY) !== null;
  }
  getToken() {
    return localStorage.getItem(TOKEN_KEY);
  }
  saveRefreshToken(token) {
    localStorage.removeItem(REFRESHTOKEN_KEY);
    localStorage.setItem(REFRESHTOKEN_KEY, token);
  }
  getRefreshToken() {
    return localStorage.getItem(REFRESHTOKEN_KEY);
  }
  getAnomToken() {
    return this.http.get(_shared_services_base_service__WEBPACK_IMPORTED_MODULE_1__.BaseService.apiUrl + 'Session/GetAnomToken');
  }
  refreshToken(model) {
    return this.http.post(_shared_services_base_service__WEBPACK_IMPORTED_MODULE_1__.BaseService.apiUrl + 'Session/RefreshToken', model, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  saveToken(token) {
    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(TOKEN_ANOM_KEY, '0');
    this.userData$.next(token != null);
  }
  saveAnomToken(token) {
    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(TOKEN_ANOM_KEY, '1');
  }
  getAnomTokenStorage() {
    return localStorage.getItem(TOKEN_ANOM_KEY) === '1';
  }
  clearUserData() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(REFRESHTOKEN_KEY);
    localStorage.removeItem(LOGIN_DATA_KEY);
    this.userData$.next(false);
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient
}]), _class);
AuthService = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
  providedIn: 'root'
})], AuthService);


/***/ }),

/***/ 22642:
/*!*************************************!*\
  !*** ./src/app/fake/fakebackend.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FakeBackendHttpInterceptor": () => (/* binding */ FakeBackendHttpInterceptor),
/* harmony export */   "fakeBackendProvider": () => (/* binding */ fakeBackendProvider)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 74048);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 52449);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 83693);
/* harmony import */ var _shared_models_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../shared/models/api */ 38551);





const DELAY = 150;
//https://github.com/coderkan/angular-examples/tree/master/http-interceptor-fakebackend
let FakeBackendHttpInterceptor = class FakeBackendHttpInterceptor {
  intercept(req, next) {
    return this.handleRequests(req, next);
  }
  /**
   * Handle request's and support with mock data.
   *
   * @param req
   * @param next
   */
  handleRequests(req, next) {
    const {
      url,
      method
    } = req;
    if (url.endsWith('/Access/Get') && method === 'GET') {
      req = req.clone({
        url: 'assets/fake/AccessGet.json'
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    /*
    if (url.endsWith('/Access/GetInvitations') && method === 'GET') {
      req = req.clone({
        url: 'assets/fake/AccessGetInvitation.json',
      });
      return next.handle(req).pipe(delay(DELAY));
    }
    */
    if (url.endsWith('/Site/GetInvitationsById') && method === 'GET') {
      const pos = url.search('/Site/GetInvitationsById');
      let jsonURL = url.slice(pos);
      jsonURL = jsonURL.replace(/\//g, '');
      jsonURL = jsonURL.concat(`${req.params.get('id')}`, `.json`);
      req = req.clone({
        url: `assets/fake/` + jsonURL
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.endsWith('/Access/GetCategories') && method === 'GET') {
      req = req.clone({
        url: 'assets/fake/AccessGetCategories.json'
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.endsWith('/Site/Get') && method === 'GET') {
      req = req.clone({
        url: 'assets/fake/SiteGet.json'
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/Site/GetById') && method === 'GET') {
      const pos = url.search('/Site/GetById');
      let jsonURL = url.slice(pos);
      jsonURL = jsonURL.replace(/\//g, '');
      jsonURL = jsonURL.concat(`${req.params.get('id')}`, `.json`);
      req = req.clone({
        url: `assets/fake/` + jsonURL
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    /*
    if (url.endsWith('/Site/GetCategories') && method === 'GET') {
      req = req.clone({
        url: 'assets/fake/SiteGetCategories.json',
      });
      return next.handle(req).pipe(delay(DELAY));
    }
    */
    if (url.endsWith('/Site/GetListItem') && method === 'GET') {
      req = req.clone({
        url: 'assets/fake/SiteGetListItem.json'
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/Access/GetById') && method === 'GET') {
      const pos = url.search('/Access/GetById');
      let jsonURL = url.slice(pos);
      jsonURL = jsonURL.replace(/\//g, '');
      jsonURL = jsonURL.concat(`${req.params.get('id')}`, `.json`);
      req = req.clone({
        url: `assets/fake/` + jsonURL
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/Access/GetInvitationEditFirstStep') && method === 'GET') {
      const pos = url.search('/Access/GetInvitationEditFirstStep');
      let jsonURL = url.slice(pos);
      jsonURL = jsonURL.replace(/\//g, '');
      jsonURL = jsonURL.concat(`${req.params.get('id')}`, `.json`);
      req = req.clone({
        url: `assets/fake/` + jsonURL
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/Access/GetInvitationEditSecondStep') && method === 'GET') {
      const pos = url.search('/Access/GetInvitationEditSecondStep');
      let jsonURL = url.slice(pos);
      jsonURL = jsonURL.replace(/\//g, '');
      jsonURL = jsonURL.concat(`${req.params.get('id')}`, `.json`);
      req = req.clone({
        url: `assets/fake/` + jsonURL
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/Access/GetInvitationEditThirdStep') && method === 'GET') {
      const pos = url.search('/Access/GetInvitationEditThirdStep');
      let jsonURL = url.slice(pos);
      jsonURL = jsonURL.replace(/\//g, '');
      jsonURL = jsonURL.concat(`${req.params.get('id')}`, `.json`);
      req = req.clone({
        url: `assets/fake/` + jsonURL
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    /*
    if (url.includes('/Access/GetInvitationById') && method === 'GET') {
      const pos = url.search('/Access/GetInvitationById');
      let jsonURL = url.slice(pos);
      jsonURL = jsonURL.replace(/\//g, '');
      jsonURL = jsonURL.concat(`${req.params.get('id')}`, `.json`);
      req = req.clone({
        url: `assets/fake/` + jsonURL,
      });
            return next.handle(req).pipe(delay(DELAY));
    }
    */
    if (url.includes('/Access/GetInvitationAccessPoints') && method === 'GET') {
      const pos = url.search('/Access/GetInvitationAccessPoints');
      let jsonURL = url.slice(pos);
      jsonURL = jsonURL.replace(/\//g, '');
      jsonURL = jsonURL.concat(`${req.params.get('id')}`, `.json`);
      req = req.clone({
        url: `assets/fake/` + jsonURL
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/Access/GetAccessPointById') && method === 'GET') {
      const pos = url.search('/Access/GetAccessPointById');
      let jsonURL = url.slice(pos);
      jsonURL = jsonURL.replace(/\//g, '');
      jsonURL = jsonURL.concat(`${req.params.get('id')}`, `.json`);
      req = req.clone({
        url: `assets/fake/` + jsonURL
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.endsWith('/Terms/Get') && method === 'GET') {
      req = req.clone({
        url: 'assets/fake/TermsGet.json'
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.endsWith('/employes') && method === 'POST') {
      const {
        body
      } = req.clone();
      // assign a new uuid to new employee
      //body.id = uuidv4();
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.of)(new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpResponse({
        status: 200,
        body
      })).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.match(/\/employes\/.*/) && method === 'DELETE') {
      const empId = this.getEmployeeId(url);
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.of)(new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpResponse({
        status: 200,
        body: empId
      })).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/Contact/GetByInvitationId') && method === 'GET') {
      const pos = url.search('/Contact/GetByInvitationId');
      let jsonURL = url.slice(pos);
      jsonURL = jsonURL.replace(/\//g, '');
      jsonURL = jsonURL.concat(`${req.params.get('id')}`, `.json`);
      req = req.clone({
        url: `assets/fake/` + jsonURL
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/Contact/GetBySite') && method === 'POST') {
      const list = req.body;
      const pos = url.search('/Contact/GetBySite');
      let jsonURL = url.slice(pos);
      jsonURL = jsonURL.replace(/\//g, '');
      jsonURL = jsonURL.concat(`${list.role}`, `.json`);
      req = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpRequest('GET', `assets/fake/` + jsonURL);
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/Access/GetAccessRegisterById') && method === 'GET') {
      const pos = url.search('/Access/GetAccessRegisterById');
      let jsonURL = url.slice(pos);
      jsonURL = jsonURL.replace(/\//g, '');
      jsonURL = jsonURL.concat(`${req.params.get('id')}`, `.json`);
      req = req.clone({
        url: `assets/fake/` + jsonURL
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/Access/GetGuestById') && method === 'GET') {
      const pos = url.search('/Access/GetGuestById');
      let jsonURL = url.slice(pos);
      jsonURL = jsonURL.replace(/\//g, '');
      jsonURL = jsonURL.concat(`${req.params.get('id')}`, `.json`);
      req = req.clone({
        url: `assets/fake/` + jsonURL
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/Contact/GetNotInvited') && method === 'GET') {
      req = req.clone({
        url: 'assets/fake/ContactGetNotInvited.json'
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/Contact/GetList') && method === 'GET') {
      req = req.clone({
        url: 'assets/fake/ContactGetList.json'
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/Contact/GetNonMembers') && method === 'POST') {
      const list = req.body;
      const pos = url.search('/Contact/GetNonMembers');
      let jsonURL = url.slice(pos);
      jsonURL = jsonURL.replace(/\//g, '');
      jsonURL = jsonURL.concat(`${list.role}`, `.json`);
      req = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpRequest('GET', `assets/fake/` + jsonURL);
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/Scan/GetResult') && method === 'GET') {
      let jsonURL;
      const params = req.params.get('result');
      if (params === 'notauthorized') jsonURL = 'assets/fake/ScanGetResultNotAuthorized.json';else if (params === 'denied') {
        jsonURL = 'assets/fake/ScanGetResultDenied.json';
      } else jsonURL = 'assets/fake/ScanGetResultAuthorized.json';
      req = req.clone({
        url: jsonURL
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/User/GetProfile') && method === 'GET') {
      const pos = url.search('/User/GetProfile');
      let jsonURL = url.slice(pos);
      jsonURL = jsonURL.replace(/\//g, '');
      jsonURL = jsonURL.concat(`.json`);
      req = req.clone({
        url: `assets/fake/` + jsonURL
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    // if (url.includes('/User/GetNotifications') && method === 'GET') {
    //   req = req.clone({
    //     url: 'assets/fake/notification/UserGetNotification.json',
    //   });
    //   return next.handle(req).pipe(delay(DELAY));
    // }
    // if (url.includes('/User/GetNotificationById') && method === 'GET') {
    //   const jsonURL = `assets/fake/notification/notification${req.params.get('id')}.json`;
    //   req = req.clone({
    //     url: jsonURL,
    //   });
    //   return next.handle(req).pipe(delay(DELAY));
    // }
    if (url.includes('/Access/GetAccessPointInvitationsById') && method === 'GET') {
      const pos = url.search('/Access/GetAccessPointInvitationsById');
      let jsonURL = url.slice(pos);
      jsonURL = jsonURL.replace(/\//g, '');
      jsonURL = jsonURL.concat(`${req.params.get('id')}`, `.json`);
      req = req.clone({
        url: `assets/fake/` + jsonURL
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/Site/PostNewSite') && method === 'POST') {
      const {
        body
      } = req.clone();
      body.id = 'site3';
      const result = new _shared_models_api__WEBPACK_IMPORTED_MODULE_0__.ApiResult();
      result.data = body;
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.of)(new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpResponse({
        status: 200,
        body: result
      })).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/Site/PostNewAccessPoint') && method === 'POST') {
      const {
        body
      } = req.clone();
      body.id = 'ap5';
      const result = new _shared_models_api__WEBPACK_IMPORTED_MODULE_0__.ApiResult();
      result.data = body;
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.of)(new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpResponse({
        status: 200,
        body: result
      })).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/Access/PostNewInvitation') && method === 'POST') {
      const {
        body
      } = req.clone();
      body.id = 'inv3';
      const result = new _shared_models_api__WEBPACK_IMPORTED_MODULE_0__.ApiResult();
      result.data = body;
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.of)(new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpResponse({
        status: 200,
        body: result
      })).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/Site/GetWizardFirstStepById') && method === 'GET') {
      const pos = url.search('/Site/GetWizardFirstStepById');
      let jsonURL = url.slice(pos);
      jsonURL = jsonURL.replace(/\//g, '');
      jsonURL = jsonURL.concat(`${req.params.get('id')}`, `.json`);
      req = req.clone({
        url: `assets/fake/` + jsonURL
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/Access/PostInputByAccessId') && method === 'POST') {
      const {
        body
      } = req.clone();
      body.id = 'ap3';
      const result = new _shared_models_api__WEBPACK_IMPORTED_MODULE_0__.ApiResult();
      result.data = body;
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.of)(new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpResponse({
        status: 200,
        body: result
      })).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/User/PostProfile') && method === 'POST') {
      const {
        body
      } = req.clone();
      body.userId = 'user1';
      const result = new _shared_models_api__WEBPACK_IMPORTED_MODULE_0__.ApiResult();
      result.data = body;
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.of)(new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpResponse({
        status: 200,
        body: result
      })).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/Access/GetAccessPointFirstStep') && method === 'GET') {
      const pos = url.search('/Access/GetAccessPointFirstStep');
      let jsonURL = url.slice(pos);
      jsonURL = jsonURL.replace(/\//g, '');
      jsonURL = jsonURL.concat(`${req.params.get('id')}`, `.json`);
      req = req.clone({
        url: `assets/fake/` + jsonURL
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/Access/GetAccessPointSecondStep') && method === 'GET') {
      const pos = url.search('/Access/GetAccessPointSecondStep');
      let jsonURL = url.slice(pos);
      jsonURL = jsonURL.replace(/\//g, '');
      jsonURL = jsonURL.concat(`${req.params.get('id')}`, `.json`);
      req = req.clone({
        url: `assets/fake/` + jsonURL
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/Access/GetAccessPointThirdStep') && method === 'GET') {
      const pos = url.search('/Access/GetAccessPointThirdStep');
      let jsonURL = url.slice(pos);
      jsonURL = jsonURL.replace(/\//g, '');
      jsonURL = jsonURL.concat(`${req.params.get('id')}`, `.json`);
      req = req.clone({
        url: `assets/fake/` + jsonURL
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    if (url.includes('/Access/GetAccessPointFourthStep') && method === 'GET') {
      const pos = url.search('/Access/GetAccessPointFourthStep');
      let jsonURL = url.slice(pos);
      jsonURL = jsonURL.replace(/\//g, '');
      jsonURL = jsonURL.concat(`${req.params.get('id')}`, `.json`);
      req = req.clone({
        url: `assets/fake/` + jsonURL
      });
      return next.handle(req).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.delay)(DELAY));
    }
    // if there is not any matches return default request.
    return next.handle(req);
  }
  /**
   * Get Employee unique uuid from url.
   *
   * @param url
   */
  getEmployeeId(url) {
    const urlValues = url.split('/');
    return urlValues[urlValues.length - 1];
  }
};
FakeBackendHttpInterceptor = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)()], FakeBackendHttpInterceptor);

/**
 * Mock backend provider definition for app.module.ts provider.
 */
const fakeBackendProvider = {
  provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HTTP_INTERCEPTORS,
  useClass: FakeBackendHttpInterceptor,
  multi: true
};

/***/ }),

/***/ 65015:
/*!****************************************************!*\
  !*** ./src/app/interceptors/common.interceptor.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommonInterceptor": () => (/* binding */ CommonInterceptor),
/* harmony export */   "commonHttpInterceptorProvider": () => (/* binding */ commonHttpInterceptorProvider)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 74048);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 98645);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 51547);
/* harmony import */ var _capacitor_device__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/device */ 1793);


var _class;





let CommonInterceptor = (_class = class CommonInterceptor {
  constructor() {}
  intercept(req, next) {
    return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.from)(this.handle(req, next));
  }
  //https://stackoverflow.com/questions/45345354/how-use-async-service-into-angular-httpclient-interceptor
  handle(req, next) {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const info = yield _capacitor_device__WEBPACK_IMPORTED_MODULE_2__.Device.getInfo();
      const infoReq = req.clone({
        setHeaders: {
          DeviceFingerprint: yield _this.parseDeviceInfo(info)
        }
      });
      return yield (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.lastValueFrom)(next.handle(infoReq));
    })();
  }
  parseDeviceInfo(info) {
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const infoToSave = {
        androidSdk: info.androidSDKVersion,
        isVirtual: info.isVirtual,
        manufacturer: info.manufacturer,
        model: info.model,
        name: info.name,
        os: info.operatingSystem,
        osVersion: info.osVersion,
        platform: info.platform
      };
      const jsonInfo = JSON.stringify(infoToSave);
      const encryptedInfo = yield crypto.subtle.digest('SHA-256', new TextEncoder().encode(jsonInfo));
      const hashArray = Array.from(new Uint8Array(encryptedInfo)); // convert buffer to byte array
      const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join(''); // convert bytes to hex string
      return hashHex;
    })();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => []), _class);
CommonInterceptor = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Injectable)()], CommonInterceptor);

const commonHttpInterceptorProvider = [{
  provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HTTP_INTERCEPTORS,
  useClass: CommonInterceptor,
  multi: true
}];

/***/ }),

/***/ 93490:
/*!********************************************************!*\
  !*** ./src/app/shared/models/SessionTokenViewModel.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SessionTokenViewModel": () => (/* binding */ SessionTokenViewModel)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);

class SessionTokenViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "token", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "refreshToken", void 0);
  }
}

/***/ }),

/***/ 38551:
/*!**************************************!*\
  !*** ./src/app/shared/models/api.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApiError": () => (/* binding */ ApiError),
/* harmony export */   "ApiResult": () => (/* binding */ ApiResult),
/* harmony export */   "FieldError": () => (/* binding */ FieldError),
/* harmony export */   "PaginatedApiResult": () => (/* binding */ PaginatedApiResult)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);

class ApiResult {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "data", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "message", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "error", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "code", void 0);
    this.data = {};
    this.error = new ApiError();
    this.message = '';
    this.code = 0;
  }
}
class PaginatedApiResult extends ApiResult {
  constructor() {
    super();
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "totalRecords", void 0);
    this.totalRecords = 0;
  }
}
class ApiError {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "generalMessage", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "fieldErrors", void 0);
    this.generalMessage = '';
    this.fieldErrors = [];
  }
}
class FieldError {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "field", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "error", void 0);
    this.field = '';
    this.error = '';
  }
}

/***/ }),

/***/ 95885:
/*!**************************************************!*\
  !*** ./src/app/shared/pages/error/error.page.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ErrorMessage": () => (/* binding */ ErrorMessage),
/* harmony export */   "ErrorPage": () => (/* binding */ ErrorPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _error_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./error.page.html?ngResource */ 15472);
/* harmony import */ var _error_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./error.page.scss?ngResource */ 8196);
/* harmony import */ var _error_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_error_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 67690);

var _class;






let ErrorPage = (_class = class ErrorPage {
  constructor(router, translate) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "router", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "errorTitle", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "errorMessage", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "hidePanel", false);
    this.router = router;
    this.translate = translate;
    this.errorTitle = this.translate.instant('common.errorTitle');
    this.errorMessage = this.translate.instant('common.errorMessage');
    this.getNavigation();
  }
  getNavigation() {
    const current = this.router.getCurrentNavigation();
    if (current?.extras.state !== undefined) {
      const msg = JSON.parse(current?.extras.state?.error);
      if (msg) {
        this.errorTitle = msg.title;
        this.errorMessage = msg.message;
        this.hidePanel = msg.hidePanel;
      }
    }
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router
}, {
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslateService
}]), _class);
ErrorPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
  selector: 'app-error',
  template: _error_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_error_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], ErrorPage);

class ErrorMessage {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "title", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "message", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "hidePanel", void 0);
  }
}

/***/ }),

/***/ 74743:
/*!**************************************************************!*\
  !*** ./src/app/shared/plugins/FirebaseInstallationPlugin.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 39734);

const FirebaseInstallation = (0,_capacitor_core__WEBPACK_IMPORTED_MODULE_0__.registerPlugin)('FirebaseInstallation');
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FirebaseInstallation);

/***/ }),

/***/ 15127:
/*!*************************************************!*\
  !*** ./src/app/shared/services/base.service.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BaseService": () => (/* binding */ BaseService)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 83693);
/* harmony import */ var _models_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../models/api */ 38551);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var ionicons_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ionicons/icons */ 64047);


var _class;







let BaseService = (_class = class BaseService {
  constructor(toast, navController, translateService) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "toast", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "translateService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "isOnline", true);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "offlineMessage", '¡Parece que no hay internet! Igualmente podés seguir usando tu credencial.');
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "button", {
      role: 'cancel',
      icon: ionicons_icons__WEBPACK_IMPORTED_MODULE_3__.closeOutline,
      handler: () => {
        console.log('Dismiss clicked');
      }
    });
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "offlineToast", void 0);
    this.toast = toast;
    this.navController = navController;
    this.translateService = translateService;
  }
  showErrorOffline() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (!_this.offlineMessage) _this.offlineMessage = _this.translateService?.instant('common.offlineMessage');
      _this.offlineToast = yield _this.toast.create({
        message: _this.offlineMessage,
        buttons: [_this.button],
        duration: 30000,
        icon: ionicons_icons__WEBPACK_IMPORTED_MODULE_3__.alertCircleOutline,
        color: 'danger',
        cssClass: 'offline-toast'
      });
      if (_this.offlineToast.isOpen === false) yield _this.offlineToast.present();
    })();
  }
  showError(error) {
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {})();
  } // if (environment.production) return;
  // const toast = await this.toast.create({
  //   message: error,
  //   duration: 5000,
  //   icon: 'alert-outline',
  // });
  // await toast.present();

  checkResult(x) {
    if (x?.code >= 800) {
      //si devuelvo un codigo de error mayor a 800, lo voy a manejar desde el llamado
      return x;
    }
    if (x?.error?.generalMessage) {
      this.showError(x.error.generalMessage);
    } else if (x?.error?.fieldErrors?.length > 0) {
      x.error.fieldErrors.forEach(fieldErr => {
        this.showError('<b>' + fieldErr.field + ':<br> ' + fieldErr.error);
      });
    } else if (x.data && typeof x.data === 'string') {
      //   if (this.toastr.currentlyActive == 0)//Evito duplicar mensajes exitosos, que muestre uno solo si esta todo ok.
      //     this.toastr.success(x.data, "Operation Completed");
    }
    return x;
  }
  checkResultPaginated(x) {
    if (x?.code >= 800) {
      //si devuelvo un codigo de error mayor a 800, lo voy a manejar desde el llamado
      return x;
    }
    if (x?.error?.generalMessage) {
      console.error(x.error.generalMessage);
      this.showError(x.error.generalMessage);
    } else if (x?.error?.fieldErrors?.length > 0) {
      x.error.fieldErrors.forEach(fieldErr => {
        console.error(fieldErr.field + ': ' + fieldErr.error);
        this.showError('<b>' + fieldErr.field + ':<br> ' + fieldErr.error);
      });
    } else if (x.data && typeof x.data === 'string') {
      //this.toastr.success(x.data, "Operation Completed");
    }
    return x;
  }
  handleError(error) {
    let inner;
    const result = new _models_api__WEBPACK_IMPORTED_MODULE_2__.ApiResult();
    try {
      if (error?.url) {
        if (error.url.includes('/Identity/Account/Login')) {
          this.navController.navigateForward('/');
          result.error = new _models_api__WEBPACK_IMPORTED_MODULE_2__.ApiError();
          return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)(result);
        }
      }
      if (error.error.code >= 800) {
        result.error = new _models_api__WEBPACK_IMPORTED_MODULE_2__.ApiError();
        if (error?.error?.Message) {
          result.error.generalMessage = error.error.Message;
        }
        result.code = error.error.code;
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)(result);
      }
      if (error.status === 0) {
        this.isOnline = false;
        this.showErrorOffline();
        this.navController.navigateForward('/credential');
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)(result);
      }
      inner = JSON.stringify(error.error);
    } catch (er) {
      inner = error.error;
    }
    const errorDesc = `<b>URL:</b> ${error.url} ` + `<b>Http Code:</b> ${error.status}<br/>` + `<b>Mensaje:</b> ${error.message}<br/>` + `<b>Contenido:</b> ${inner}`;
    try {
      console.error('Custom Error: ' + JSON.stringify(error));
    } catch (er) {
      console.error('Custom Error: ' + errorDesc);
    }
    this.showError(errorDesc);
    result.error = new _models_api__WEBPACK_IMPORTED_MODULE_2__.ApiError();
    result.error.generalMessage = errorDesc;
    return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)(result);
  }
  handleErrorPaginated(error) {
    let inner;
    const result = new _models_api__WEBPACK_IMPORTED_MODULE_2__.PaginatedApiResult();
    try {
      if (error?.url) {
        if (error.url.includes('/Identity/Account/Login')) {
          this.navController.navigateForward('/');
          result.error = new _models_api__WEBPACK_IMPORTED_MODULE_2__.ApiError();
          return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)(result);
        }
      }
      if (error.error.Code >= 800) {
        result.error = new _models_api__WEBPACK_IMPORTED_MODULE_2__.ApiError();
        if (error?.error?.Message) {
          result.error.generalMessage = error.error.Message;
        }
        result.code = error.error.Code;
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)(result);
      }
      if (error.status === 0) {
        this.showErrorOffline();
        this.navController.navigateForward('/credential');
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)(result);
      }
      inner = JSON.stringify(error.error);
    } catch (er) {
      inner = error.error;
    }
    const errorDesc = `<b>URL:</b> ${error.url} ` + `<b>Http Code:</b> ${error.status}<br/>` + `<b>Mensaje:</b> ${error.message}<br/>` + `<b>Contenido:</b> ${inner}`;
    try {
      console.error('Custom Error: ' + JSON.stringify(error));
    } catch (er) {
      console.error('Custom Error: ' + errorDesc);
    }
    this.showError(errorDesc);
    result.error = new _models_api__WEBPACK_IMPORTED_MODULE_2__.ApiError();
    result.error.generalMessage = errorDesc;
    return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)(result);
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "apiUrl", void 0), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "appVersion", '1.0'), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "appBuild", void 0), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "appUpdateUrl", 'https://storage.googleapis.com/identifast-static/'), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ToastController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController
}, {
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateService
}]), _class);
BaseService = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Injectable)({
  providedIn: 'root'
})], BaseService);


/***/ }),

/***/ 11750:
/*!*****************************************************!*\
  !*** ./src/app/shared/services/firebase.service.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FirebaseService": () => (/* binding */ FirebaseService)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _capacitor_firebase_remote_config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor-firebase/remote-config */ 19857);
/* harmony import */ var src_app_shared_services_base_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/services/base.service */ 15127);


var _class;




let FirebaseService = (_class = class FirebaseService {
  constructor() {}
  initializeConfig() {
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      //Levanto la configuracion del remote config
      //Esto es para ios y android
      console.log('Retrieve remote config');
      yield _capacitor_firebase_remote_config__WEBPACK_IMPORTED_MODULE_2__.FirebaseRemoteConfig.fetchConfig({
        minimumFetchIntervalInSeconds: 3600
      });
      //Este es para web
      _capacitor_firebase_remote_config__WEBPACK_IMPORTED_MODULE_2__.FirebaseRemoteConfig.setMinimumFetchInterval({
        minimumFetchIntervalInSeconds: 3600
      });
      yield _capacitor_firebase_remote_config__WEBPACK_IMPORTED_MODULE_2__.FirebaseRemoteConfig.fetchAndActivate();
      //Configuro apiurl
      src_app_shared_services_base_service__WEBPACK_IMPORTED_MODULE_3__.BaseService.apiUrl = yield _capacitor_firebase_remote_config__WEBPACK_IMPORTED_MODULE_2__.FirebaseRemoteConfig.getString({
        key: 'url_api'
      }).then(x => {
        return x.value;
      });
      src_app_shared_services_base_service__WEBPACK_IMPORTED_MODULE_3__.BaseService.appBuild = yield _capacitor_firebase_remote_config__WEBPACK_IMPORTED_MODULE_2__.FirebaseRemoteConfig.getString({
        key: 'app_build'
      }).then(x => {
        return x.value;
      });
      src_app_shared_services_base_service__WEBPACK_IMPORTED_MODULE_3__.BaseService.appVersion = yield _capacitor_firebase_remote_config__WEBPACK_IMPORTED_MODULE_2__.FirebaseRemoteConfig.getString({
        key: 'app_version'
      }).then(x => {
        return x.value;
      });
      src_app_shared_services_base_service__WEBPACK_IMPORTED_MODULE_3__.BaseService.appUpdateUrl = yield _capacitor_firebase_remote_config__WEBPACK_IMPORTED_MODULE_2__.FirebaseRemoteConfig.getString({
        key: 'app_update_url'
      }).then(x => {
        return x.value;
      });
    })();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => []), _class);
FirebaseService = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
  providedIn: 'root'
})], FirebaseService);


/***/ }),

/***/ 9101:
/*!*****************************************************!*\
  !*** ./src/app/shared/services/template.service.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TemplateService": () => (/* binding */ TemplateService)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 40803);
/* harmony import */ var _splidejs_splide__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @splidejs/splide */ 82026);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 45667);

var _class;





let TemplateService = (_class = class TemplateService {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "isLight$", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "prefDark", window.matchMedia('(prefers-color-scheme: dark)'));
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "isLight", true);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "isPlatformMobile", () => (0,_ionic_angular__WEBPACK_IMPORTED_MODULE_2__.isPlatform)('capacitor'));
    this.prefDark.addEventListener('change', e => {
      this.isLight = e.matches;
      this.updateTheme();
      this.isLight$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__.Observable(obs => {
        obs.next(!e.matches);
      });
    });
  }
  updateTheme() {
    if (!this.isLight) {
      this.activateLightMode();
      this.isLight = true;
    } else {
      this.activateDarkMode();
      this.isLight = false;
    }
    this.isLight$?.pipe();
  }
  singleSlider(options) {
    const splide = document.getElementsByClassName('splide');
    if (splide.length) {
      const singleSlider = document.querySelectorAll('.single-slider');
      if (singleSlider.length) {
        singleSlider.forEach(e => {
          const single = new _splidejs_splide__WEBPACK_IMPORTED_MODULE_1__.Splide('#' + e.id, options).mount();
          const sliderNext = document.querySelectorAll('.slider-next');
          const sliderPrev = document.querySelectorAll('.slider-prev');
          sliderNext.forEach(el => el.addEventListener('click', ele => {
            single.go('>');
          }));
          sliderPrev.forEach(el => el.addEventListener('click', ele => {
            single.go('<');
          }));
          if (options?.onMove) {
            single.on('move', newIndex => {
              options.onMove?.(newIndex);
            });
          }
        });
      }
    }
  }
  destroySlider() {
    const splide = document.getElementsByClassName('splide');
    if (splide.length) {
      const singleSlider = document.querySelectorAll('.single-slider');
      if (singleSlider.length) {
        singleSlider.forEach(e => {
          const single = new _splidejs_splide__WEBPACK_IMPORTED_MODULE_1__.Splide('#' + e.id).mount();
          single.destroy();
        });
      }
    }
  }
  cardExtender() {
    const cards = Array.from(document.getElementsByClassName('card'));
    let headerHeight;
    let footerHeight;
    const headerOnPage = document.querySelectorAll('.header:not(.header-transparent)')[0];
    const footerOnPage = document.querySelectorAll('#footer-bar')[0];
    if (headerOnPage) {
      headerHeight = document.querySelectorAll('.header')[0].offsetHeight;
    } else {
      headerHeight = 0;
    }
    if (footerOnPage) {
      footerHeight = document.querySelectorAll('#footer-bar')[0].offsetHeight;
    } else {
      footerHeight = 0;
    }
    // for (let i = 0; i < cards.length; i++)
    for (const card of cards) {
      let windowHeight = 0;
      let coverHeight = '';
      if (card.getAttribute('data-card-height') === 'cover') {
        if (window.matchMedia('(display-mode: fullscreen)').matches) {
          windowHeight = window.outerHeight;
        }
        if (!window.matchMedia('(display-mode: fullscreen)').matches) {
          windowHeight = window.innerHeight;
        }
        //Fix for iOS 15 pages with data-height="cover"
        coverHeight = windowHeight + 'px';
        // - Remove this for iOS 14 issues - var coverHeight = windowHeight - headerHeight - footerHeight + 'px';
      }

      if (card.hasAttribute('data-card-height')) {
        const getHeight = card.getAttribute('data-card-height');
        card.style.height = getHeight + 'px';
        if (getHeight === 'cover') {
          const totalHeight = getHeight;
          card.style.height = coverHeight;
        }
      }
    }
  }
  // ///Function implementada solo para detectar problemas en el maquetado a causa del template. Usar solo para debug.
  // initTemplate() {
  //   console.warn('NO SE DEBE USAR EL METODO INITTEMPLATE');
  //   init_template();
  // }
  activateDarkMode() {
    document.body.classList.add('theme-dark');
    document.body.classList.remove('theme-light', 'detect-theme');
    localStorage.setItem('theme', 'dark');
  }
  activateLightMode() {
    document.body.classList.add('theme-light');
    document.body.classList.remove('theme-dark', 'detect-theme');
    localStorage.setItem('theme', 'light');
  }
  activateAutoMode() {
    document.body.classList.add('theme-light');
    document.body.classList.remove('theme-dark', 'detect-theme');
    localStorage.setItem('theme', 'auto');
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => []), _class);
TemplateService = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
  providedIn: 'root'
})], TemplateService);

class SliderOptions {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "type", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "autoplay", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "interval", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "perPage", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "onMove", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "classes", void 0);
    this.type = 'slide';
    this.autoplay = false;
    this.interval = 5000;
    this.perPage = 1;
  }
}

/***/ }),

/***/ 31880:
/*!*************************************************!*\
  !*** ./src/app/shared/services/user.service.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserService": () => (/* binding */ UserService)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 13045);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 56997);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 74048);
/* harmony import */ var _base_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./base.service */ 15127);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _template_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./template.service */ 9101);
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/auth/auth.service */ 75148);
/* harmony import */ var _firebase_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./firebase.service */ 11750);
/* harmony import */ var _capacitor_network__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @capacitor/network */ 97642);


var _class;










let UserService = (_class = class UserService extends _base_service__WEBPACK_IMPORTED_MODULE_2__.BaseService {
  constructor(http, toast, navController, templateService, authService, firebaseService) {
    super(toast, navController);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "http", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "templateService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "authService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "firebaseService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userData", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "initializing", true);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "subscriptions", []);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "errorMessage", void 0);
    this.http = http;
    this.templateService = templateService;
    this.authService = authService;
    this.firebaseService = firebaseService;
    const theme = localStorage.getItem('theme');
    if (theme === 'dark') {
      this.templateService.activateDarkMode();
    } else {
      this.templateService.activateLightMode();
    }
    _capacitor_network__WEBPACK_IMPORTED_MODULE_6__.Network.addListener('networkStatusChange', status => {
      console.log('Network status changed', status);
      this.isOnline = status.connected;
    });
  }
  ngOnDestroy() {
    this.subscriptions.forEach(subscription => subscription.unsubscribe());
  }
  getInitialPage() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this.authService.hasUserDataSnapshot() && !_this.authService.getAnomTokenStorage() && _this.getLoginData() !== undefined) {
        yield _this.firebaseService.initializeConfig();
        _this.getLoginData();
        _this.navController.navigateRoot(['/credential']);
      } else {
        _this.navController.navigateRoot(['/onboarding/splash']);
      }
    })();
  }
  getLoginData() {
    if (localStorage.getItem('loginData') === null) return undefined;
    this.userData = JSON.parse(localStorage.getItem('loginData') ?? '');
    this.userData.initialBanner = localStorage.getItem('initialBanner') === '1';
    this.userData.nightMode = localStorage.getItem('theme') === 'dark';
    return this.userData;
  }
  logout() {
    this.userData = undefined;
    this.deletePhoneInfo();
    this.authService.clearUserData();
    this.navController.navigateRoot(['/onboarding/splash'], {
      replaceUrl: true
    });
  }
  closeBanner() {
    localStorage.setItem('initialBanner', '0');
    this.userData.initialBanner = false;
  }
  setUserLoggedIn(model, newUser = true) {
    localStorage.setItem('initialBanner', newUser ? '1' : '0');
    localStorage.setItem('loggedIn', '1');
    localStorage.setItem('loginData', JSON.stringify(model));
    this.getLoginData();
    this.initializing = false;
  }
  savePhoneInfo(phone) {
    localStorage.setItem('countryCode', phone.countryCode);
  }
  deletePhoneInfo() {
    localStorage.removeItem('countryCode');
  }
  getPhoneCode(phone) {
    const queryParams = new _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpParams().append('phone', phone);
    return this.http.get(`${_base_service__WEBPACK_IMPORTED_MODULE_2__.BaseService.apiUrl}Onboarding/GetPhoneCode`, {
      params: queryParams
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.catchError)(error => this.handleError(error)));
  }
  postPhoneValidate(phone) {
    return this.http.post(`${_base_service__WEBPACK_IMPORTED_MODULE_2__.BaseService.apiUrl}Onboarding/ValidatePhone`, phone).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.catchError)(error => this.handleError(error)));
  }
  saveUser(user) {
    return this.http.post(`${_base_service__WEBPACK_IMPORTED_MODULE_2__.BaseService.apiUrl}Onboarding/SaveUser`, user).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.catchError)(error => this.handleError(error)));
  }
  deleteImage() {
    return this.http.delete(`${_base_service__WEBPACK_IMPORTED_MODULE_2__.BaseService.apiUrl}User/DeleteImage`);
  }
  getServerCurrentTime() {
    return this.http.get(`${_base_service__WEBPACK_IMPORTED_MODULE_2__.BaseService.apiUrl}AccessPoint/GetServerCurrentTime`).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.catchError)(error => this.handleError(error)));
  }
  getTerm() {
    return this.http.get(`${_base_service__WEBPACK_IMPORTED_MODULE_2__.BaseService.apiUrl}Onboarding/GetTerm`).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.catchError)(error => this.handleError(error)));
  }
  getProfile() {
    return this.http.get(`${_base_service__WEBPACK_IMPORTED_MODULE_2__.BaseService.apiUrl}User/GetUser`).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.catchError)(error => this.handleError(error)));
  }
  getUser() {
    return this.http.get(`${_base_service__WEBPACK_IMPORTED_MODULE_2__.BaseService.apiUrl}User/GetUser`).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.catchError)(error => this.handleError(error)));
  }
  getNotifications() {
    return this.http.get(`${_base_service__WEBPACK_IMPORTED_MODULE_2__.BaseService.apiUrl}User/GetNotifications`).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.catchError)(error => this.handleError(error)));
  }
  getNonReadCount() {
    return this.http.get(`${_base_service__WEBPACK_IMPORTED_MODULE_2__.BaseService.apiUrl}User/GetNonReadCount`).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.catchError)(error => this.handleError(error)));
  }
  getNotificationById(id) {
    const queryParams = new _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpParams().append('notificationId', id);
    return this.http.get(`${_base_service__WEBPACK_IMPORTED_MODULE_2__.BaseService.apiUrl}User/GetNotificationById`, {
      params: queryParams
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.catchError)(error => this.handleError(error)));
  }
  update(user) {
    return this.http.post(`${_base_service__WEBPACK_IMPORTED_MODULE_2__.BaseService.apiUrl}User/Update`, user).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.catchError)(error => this.handleError(error)));
  }
  notificationMarkAsRead(id) {
    const queryParams = new _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpParams().append('notificationId', id);
    return this.http.post(`${_base_service__WEBPACK_IMPORTED_MODULE_2__.BaseService.apiUrl}User/NotificationMarkAsRead`, null, {
      params: queryParams
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.catchError)(error => this.handleError(error)));
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClient
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.ToastController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.NavController
}, {
  type: _template_service__WEBPACK_IMPORTED_MODULE_3__.TemplateService
}, {
  type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__.AuthService
}, {
  type: _firebase_service__WEBPACK_IMPORTED_MODULE_5__.FirebaseService
}]), _class);
UserService = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Injectable)({
  providedIn: 'root'
})], UserService);


/***/ }),

/***/ 20553:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
  production: false,
  //apiUrl: 'https://staging-xpgny7ftdq-uc.a.run.app/',
  name: 'Dev',
  firebase: {
    apiKey: 'AIzaSyAIJE_wEHOYW9WA2gscn8GDuuJ2Q21JVVM',
    authDomain: 'identifast-3ae45.firebaseapp.com',
    projectId: 'identifast-3ae45',
    storageBucket: 'identifast-3ae45.appspot.com',
    messagingSenderId: '836434466649',
    appId: '1:836434466649:web:bda94c1e3963077917de48',
    measurementId: 'G-K4X2JBLHDN'
  }
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.

/***/ }),

/***/ 14913:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 11640);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 78629);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 20553);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
  (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule).catch(err => console.log(err));

/***/ }),

/***/ 50863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-accordion_2.entry.js": [
		29462,
		"common",
		"node_modules_ionic_core_dist_esm_ion-accordion_2_entry_js"
	],
	"./ion-action-sheet.entry.js": [
		16831,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		94150,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		80443,
		"default-node_modules_ionic_core_dist_esm_keyboard-controller-0c2dce71_js-node_modules_ionic_c-b0fbc0",
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		22881,
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		90413,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		85708,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-breadcrumb_2.entry.js": [
		56690,
		"common",
		"node_modules_ionic_core_dist_esm_ion-breadcrumb_2_entry_js"
	],
	"./ion-button_2.entry.js": [
		97892,
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		15095,
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		13731,
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		6960,
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		92345,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime-button.entry.js": [
		74082,
		"default-node_modules_ionic_core_dist_esm_data-4b448e3a_js-node_modules_ionic_core_dist_esm_th-4e82ad",
		"node_modules_ionic_core_dist_esm_ion-datetime-button_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		33449,
		"default-node_modules_ionic_core_dist_esm_data-4b448e3a_js-node_modules_ionic_core_dist_esm_th-4e82ad",
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		44100,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		32375,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		97583,
		"common",
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		53090,
		"default-node_modules_ionic_core_dist_esm_form-controller-ed77647a_js-node_modules_ionic_core_-d00699",
		"common",
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		7238,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		20815,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		41682,
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		45403,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		38597,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		31884,
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-picker-column-internal.entry.js": [
		54361,
		"common",
		"node_modules_ionic_core_dist_esm_ion-picker-column-internal_entry_js"
	],
	"./ion-picker-internal.entry.js": [
		49887,
		"node_modules_ionic_core_dist_esm_ion-picker-internal_entry_js"
	],
	"./ion-popover.entry.js": [
		15757,
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		18231,
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		26649,
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		62667,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		76591,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		71273,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		52282,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		68109,
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		43045,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		81752,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		42521,
		"common",
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-spinner.entry.js": [
		70126,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		30002,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		52263,
		"default-node_modules_ionic_core_dist_esm_keyboard-controller-0c2dce71_js-node_modules_ionic_c-b0fbc0",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		55902,
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		86806,
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		61605,
		"default-node_modules_ionic_core_dist_esm_form-controller-ed77647a_js-node_modules_ionic_core_-d00699",
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		76391,
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		8880,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 50863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 79595:
/*!***********************************************!*\
  !*** ./src/app/app.component.scss?ngResource ***!
  \***********************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "#page {\n  position: initial;\n}", "",{"version":3,"sources":["webpack://./src/app/app.component.scss"],"names":[],"mappings":"AAAA;EACE,iBAAA;AACF","sourcesContent":["#page {\n  position: initial;\n}\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 8196:
/*!***************************************************************!*\
  !*** ./src/app/shared/pages/error/error.page.scss?ngResource ***!
  \***************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 33383:
/*!***********************************************!*\
  !*** ./src/app/app.component.html?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div id=\"page\">\n  <ion-app>\n    <ion-router-outlet></ion-router-outlet>\n  </ion-app>\n</div>\n";

/***/ }),

/***/ 15472:
/*!***************************************************************!*\
  !*** ./src/app/shared/pages/error/error.page.html?ngResource ***!
  \***************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-page-layout\n  [hideBack]=\"true\"\n  [hideFooter]=\"hidePanel\"\n  [hideHeader]=\"hidePanel\"\n  [title]=\"'common.errorTitle'|translate\">\n  <div class=\"card-center text-center\">\n    <div class=\"content\">\n      <app-img-title\n        [faClass]=\"['fas','triangle-exclamation']\"\n        [faStyleClass]=\"'fa-xl'\"\n        [title]=\"errorTitle\"\n        [titleClass]=\"'pt-3'\"\n        [subtitle]=\"errorMessage\"\n        [subtitleClass]=\"'font-400 lh-lg text-center pt-2'\"></app-img-title>\n    </div>\n  </div>\n</app-page-layout>\n";

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(14913)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map