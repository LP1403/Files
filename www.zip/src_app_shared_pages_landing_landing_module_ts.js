(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_shared_pages_landing_landing_module_ts"],{

/***/ 27843:
/*!****************************************************************!*\
  !*** ./src/app/shared/pages/landing/landing-routing.module.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LandingPageRoutingModule": () => (/* binding */ LandingPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _landing_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./landing.page */ 70887);




const routes = [{
  path: '',
  component: _landing_page__WEBPACK_IMPORTED_MODULE_0__.LandingPage
}];
let LandingPageRoutingModule = class LandingPageRoutingModule {};
LandingPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
  imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
  exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
})], LandingPageRoutingModule);


/***/ }),

/***/ 74206:
/*!********************************************************!*\
  !*** ./src/app/shared/pages/landing/landing.module.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LandingPageModule": () => (/* binding */ LandingPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 89650);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _landing_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./landing-routing.module */ 27843);
/* harmony import */ var _landing_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./landing.page */ 70887);
/* harmony import */ var _shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../shared.module */ 56208);








let LandingPageModule = class LandingPageModule {};
LandingPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule, _landing_routing_module__WEBPACK_IMPORTED_MODULE_0__.LandingPageRoutingModule, _shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule],
  declarations: [_landing_page__WEBPACK_IMPORTED_MODULE_1__.LandingPage]
})], LandingPageModule);


/***/ }),

/***/ 70887:
/*!******************************************************!*\
  !*** ./src/app/shared/pages/landing/landing.page.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LandingPage": () => (/* binding */ LandingPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _landing_page_html_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./landing.page.html?ngResource */ 61066);
/* harmony import */ var _landing_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./landing.page.scss?ngResource */ 58073);
/* harmony import */ var _landing_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_landing_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! capacitor-native-biometric */ 51685);
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/user.service */ 31880);
/* harmony import */ var src_app_app_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/app.component */ 66401);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @capacitor/core */ 39734);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/auth/auth.service */ 75148);
/* harmony import */ var src_app_shared_components_update_update_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/components/update/update.component */ 51366);


var _class;












let LandingPage = (_class = class LandingPage {
  constructor(translate, userService, navController, authService) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "authService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "updateC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "loaded", false);
    this.translate = translate;
    this.userService = userService;
    this.navController = navController;
    this.authService = authService;
  }
  ngOnInit() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_capacitor_core__WEBPACK_IMPORTED_MODULE_7__.Capacitor.isNativePlatform()) {
        src_app_app_component__WEBPACK_IMPORTED_MODULE_6__.AppComponent.isIncompatible.subscribe( /*#__PURE__*/function () {
          var _ref = (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (incompatible) {
            if (!incompatible) {
              if (_this.userService.getLoginData() !== undefined) {
                _this.loaded = true;
                yield _this.updateC?.checkAndUpdateVersion();
                _this.validate();
              } else {
                yield _this.userService.getInitialPage();
                // await this.updateC.checkAndUpdateVersion();
              }
            } else {
              const navigationExtras = {
                state: {
                  error: JSON.stringify(_this.userService.errorMessage)
                }
              };
              _this.navController.navigateRoot('/error', navigationExtras);
            }
          });
          return function (_x) {
            return _ref.apply(this, arguments);
          };
        }());
      }
    })();
  }
  validate() {
    var _this2 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const verified = yield capacitor_native_biometric__WEBPACK_IMPORTED_MODULE_4__.NativeBiometric.verifyIdentity({
        reason: _this2.translate.instant('biometric.reason'),
        title: _this2.translate.instant('biometric.promptTitle'),
        description: _this2.translate.instant('biometric.promptDescription'),
        negativeButtonText: _this2.translate.instant('biometric.promptNegative')
      }).then(() => true).catch(() => false);
      if (verified) {
        yield _this2.userService.getInitialPage();
      } else {
        _this2.validate();
      }
    })();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__.TranslateService
}, {
  type: _services_user_service__WEBPACK_IMPORTED_MODULE_5__.UserService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.NavController
}, {
  type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_8__.AuthService
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "propDecorators", {
  updateC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.ViewChild,
    args: [src_app_shared_components_update_update_component__WEBPACK_IMPORTED_MODULE_9__.UpdateComponent]
  }]
}), _class);
LandingPage = (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Component)({
  selector: 'app-landing',
  template: _landing_page_html_ngResource__WEBPACK_IMPORTED_MODULE_2__,
  styles: [(_landing_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_3___default())]
})], LandingPage);


/***/ }),

/***/ 58073:
/*!*******************************************************************!*\
  !*** ./src/app/shared/pages/landing/landing.page.scss?ngResource ***!
  \*******************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 61066:
/*!*******************************************************************!*\
  !*** ./src/app/shared/pages/landing/landing.page.html?ngResource ***!
  \*******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"page-content pb-0\" *ngIf=\"loaded\">\n  <div data-card-height=\"cover\" class=\"card bg-highlight vh-100\">\n    <div class=\"card-center text-center\">\n      <div class=\"content mt-n5\">\n        <app-img-title\n          [imgClass]=\"'vh-35'\"\n          [imgSrc]=\"'assets/icons/iconbanner.svg'\"\n          [subtitle]=\"'biometric.subtitle'|translate\"\n          [subtitleClass]=\"'color-white pt-10 font-14 font-400 lh-lg'\"></app-img-title>\n      </div>\n    </div>\n  </div>\n</div>\n<div *ngIf=\"!loaded\" class=\"center\">\n  <div class=\"spinner-border color-blue-dark\" role=\"status\"></div>\n</div>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_shared_pages_landing_landing_module_ts.js.map