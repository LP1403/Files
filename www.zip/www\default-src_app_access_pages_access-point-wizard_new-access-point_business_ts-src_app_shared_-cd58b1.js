(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_access_pages_access-point-wizard_new-access-point_business_ts-src_app_shared_-cd58b1"],{

/***/ 42439:
/*!******************************************************************************************!*\
  !*** ./src/app/access/components/access-point-address/access-point-address.component.ts ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccessPointAddressComponent": () => (/* binding */ AccessPointAddressComponent),
/* harmony export */   "AccessPointAddressViewModel": () => (/* binding */ AccessPointAddressViewModel),
/* harmony export */   "UpdateAccessPointAddressViewModel": () => (/* binding */ UpdateAccessPointAddressViewModel)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _access_point_address_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./access-point-address.component.html?ngResource */ 65000);
/* harmony import */ var _access_point_address_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./access-point-address.component.scss?ngResource */ 22220);
/* harmony import */ var _access_point_address_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_access_point_address_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var _capacitor_keyboard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor/keyboard */ 60971);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 45667);

var _class;







let AccessPointAddressComponent = (_class = class AccessPointAddressComponent {
  constructor(fb, cdRef) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "fb", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "cdRef", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "addresstext", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "siteAddress", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "mapEditClick", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "placeClick", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessPointForm", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "imgString", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "autocomplete", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "selectedPlace", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "selectedPlaceCoords", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "Number", Number);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "autocompleteComponent", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "apa", void 0);
    this.fb = fb;
    this.cdRef = cdRef;
    this.autocomplete = {
      input: ''
    };
    this.selectedPlaceCoords = [];
  }
  get formValid() {
    return this.accessPointForm.valid;
  }
  get formDirty() {
    return this.accessPointForm.dirty;
  }
  get viewModel() {
    this.apa = new AccessPointAddressViewModel();
    if (this.selectedPlace?.formatted_address) this.apa.address = this.selectedPlace?.formatted_address;else this.apa.address = this.accessPointForm.get('address')?.value;
    this.apa.latitude = Number(this.selectedPlaceCoords[0]);
    this.apa.longitude = Number(this.selectedPlaceCoords[1]);
    this.apa.map = this.imgString;
    return this.apa;
  }
  ngOnInit() {
    this.initForm();
  }
  ngAfterViewInit() {
    this.getPlaceAutocomplete();
  }
  setForm(apa) {
    if (!apa) return;
    this.accessPointForm.get('address')?.setValue(apa.address);
    this.autocomplete.input = apa.address;
    this.selectedPlaceCoords = [apa.latitude.toString(), apa.longitude.toString()];
    this.imgString = apa.map;
  }
  initForm() {
    this.accessPointForm = this.fb.group({
      address: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required]
    });
  }
  getPlaceAutocomplete() {
    this.autocompleteComponent = new google.maps.places.Autocomplete(this.addresstext?.nativeElement, {
      fields: ['formatted_address', 'name', 'geometry']
    });
    google.maps.event.addListener(this.autocompleteComponent, 'place_changed', () => {
      const place = this.autocompleteComponent?.getPlace();
      if (place?.geometry) this.placeSelected(place);
    });
  }
  placeSelected(place) {
    this.selectedPlace = place;
    this.accessPointForm.get('address')?.setValue(place.formatted_address);
    this.accessPointForm.updateValueAndValidity();
    setTimeout(() => {
      this.addresstext?.nativeElement.focus();
      if ((0,_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.isPlatform)('capacitor')) {
        _capacitor_keyboard__WEBPACK_IMPORTED_MODULE_3__.Keyboard.hide();
      }
    }, 50);
    this.placeClick.emit(place);
    console.log(this.accessPointForm.get('address')?.value);
    const coords = place.geometry?.viewport.toUrlValue().split(',');
    if (coords && coords.length > 1) {
      const averageLat = (Number(coords[0]) + Number(coords[2])) / 2;
      const averageLong = (Number(coords[1]) + Number(coords[3])) / 2;
      this.selectedPlaceCoords = [averageLat.toString(), averageLong.toString()];
      this.imgString = `https://maps.googleapis.com/maps/api/staticmap?center=${this.selectedPlaceCoords[0]},${this.selectedPlaceCoords[1]}&zoom=16&size=300x300&scale=2&markers=color:red%7C${this.selectedPlaceCoords[0]},${this.selectedPlaceCoords[1]}&key=AIzaSyDrj-69Jfi_WZXZ_eLOREJcBJQXyQlwZPI`;
      this.cdRef.detectChanges();
    }
  }
  getAutocomplete(address) {
    this.accessPointForm?.get('address')?.setValue(address);
    this.accessPointForm.updateValueAndValidity();
    if (this.autocomplete) {
      this.autocomplete.input = address;
    }
    const autocompleteService = new google.maps.places.AutocompleteService();
    autocompleteService?.getPlacePredictions(this.autocomplete, (predictionsArr, placesServiceStatus) => {
      const placeRequest = {
        placeId: predictionsArr[0].place_id
      };
      const placeService = new google.maps.places.PlacesService(this.addresstext?.nativeElement);
      placeService.getDetails(placeRequest, (placeResult, placeServiceStatus) => {
        console.log('placeService :: placeResult = ', placeResult, '\n', 'placeServiceStatus = ', placeServiceStatus);
        this.placeSelected(placeResult);
      });
    });
  }
  clear() {
    this.autocomplete.input = '';
    this.selectedPlace = undefined;
    this.imgString = '';
    this.accessPointForm.get('address')?.setValue(null);
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.ChangeDetectorRef
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  addresstext: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.ViewChild,
    args: ['addressText']
  }],
  siteAddress: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input
  }],
  mapEditClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }],
  placeClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }]
}), _class);
AccessPointAddressComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
  selector: 'app-new-access-point-address',
  template: _access_point_address_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_access_point_address_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], AccessPointAddressComponent);

class AccessPointAddressViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "address", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "latitude", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "longitude", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "map", void 0);
  }
}
class UpdateAccessPointAddressViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "id", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "address", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "latitude", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "longitude", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "mapImageId", void 0);
  }
}

/***/ }),

/***/ 52403:
/*!******************************************************************************************!*\
  !*** ./src/app/access/components/access-point-control/access-point-control.component.ts ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccessPointControlComponent": () => (/* binding */ AccessPointControlComponent),
/* harmony export */   "AccessPointControlViewModel": () => (/* binding */ AccessPointControlViewModel),
/* harmony export */   "UpdateAccessPointControlViewModel": () => (/* binding */ UpdateAccessPointControlViewModel)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _access_point_control_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./access-point-control.component.html?ngResource */ 23490);
/* harmony import */ var _access_point_control_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./access-point-control.component.scss?ngResource */ 62700);
/* harmony import */ var _access_point_control_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_access_point_control_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 70997);

var _class;





let AccessPointControlComponent = (_class = class AccessPointControlComponent {
  constructor(fb) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "fb", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "saveForm", new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessPointForm", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "inputsNew", []);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "vm", void 0);
    this.fb = fb;
  }
  get formValid() {
    return this.accessPointForm.valid;
  }
  get formDirty() {
    return this.accessPointForm.dirty;
  }
  get viewModel() {
    this.vm = new AccessPointControlViewModel();
    Object.assign(this.vm, this.accessPointForm.getRawValue());
    this.inputsNew.map(x => {
      x.questionId = crypto.randomUUID();
    });
    this.vm.inputs = this.inputsNew;
    return this.vm;
  }
  ngOnInit() {
    this.initForm();
  }
  setForm(vm) {
    if (!vm) return;
    this.accessPointForm.setValue(vm);
    this.inputsNew = vm.inputs;
  }
  initForm() {
    this.accessPointForm = this.fb.group({
      noteAccess: ['']
    });
  }
  addNewInput(label) {
    const newInput = {
      label,
      value: '',
      questionId: ''
    };
    this.inputsNew.push(newInput);
  }
  editInput(input) {
    this.inputsNew.forEach(i => {
      if (i.questionId === input.questionId) {
        i.label = input.label;
      }
    });
  }
  deleteInput(input) {
    const index = this.inputsNew.findIndex(x => x.questionId === input.questionId);
    this.inputsNew.splice(index, 1);
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  saveForm: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output
  }]
}), _class);
AccessPointControlComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
  selector: 'app-access-point-control',
  template: _access_point_control_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_access_point_control_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], AccessPointControlComponent);

class AccessPointControlViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "noteAccess", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "inputs", void 0);
  }
}
class UpdateAccessPointControlViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "id", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "noteAccess", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "inputs", void 0);
  }
}

/***/ }),

/***/ 262:
/*!************************************************************************************!*\
  !*** ./src/app/access/components/access-point-date/access-point-date.component.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccessPointDateComponent": () => (/* binding */ AccessPointDateComponent),
/* harmony export */   "AccessPointDateViewModel": () => (/* binding */ AccessPointDateViewModel),
/* harmony export */   "UpdateAccessPointScheduleViewModel": () => (/* binding */ UpdateAccessPointScheduleViewModel)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _access_point_date_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./access-point-date.component.html?ngResource */ 3050);
/* harmony import */ var _access_point_date_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./access-point-date.component.scss?ngResource */ 11895);
/* harmony import */ var _access_point_date_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_access_point_date_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var src_app_shared_components_day_select_form_day_select_form_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/day-select-form/day-select-form.component */ 84599);

var _class;






let AccessPointDateComponent = (_class = class AccessPointDateComponent {
  constructor(fb) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "fb", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "daySelect", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessPointForm", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "vm", void 0);
    this.fb = fb;
  }
  get formValid() {
    return this.accessPointForm?.valid && this.daySelect?.formValid && this.timeValid;
  }
  get formDirty() {
    return this.accessPointForm?.dirty || this.daySelect?.formDirty;
  }
  get viewModel() {
    this.vm = new AccessPointDateViewModel();
    if (this.daySelect) this.vm.daysVM = this.daySelect.viewModel;
    Object.assign(this.vm, this.accessPointForm?.getRawValue());
    return this.vm;
  }
  get timeValid() {
    const allDay = this.accessPointForm?.get('allDay')?.value;
    return allDay || this.accessPointForm?.get('timeFrom').value !== '' && this.accessPointForm?.get('timeTo').value !== '';
  }
  ngOnInit() {
    this.initForm();
  }
  setForm(vm) {
    if (!vm) return;
    this.accessPointForm?.get('allDay')?.setValue(vm.allDay);
    this.accessPointForm?.get('timeFrom')?.setValue(vm.timeFrom);
    this.accessPointForm?.get('timeTo')?.setValue(vm.timeTo);
    this.daySelect?.setForm(vm.daysVM);
  }
  initForm() {
    this.accessPointForm = this.fb.group({
      allDay: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      timeFrom: [''],
      timeTo: ['']
    });
    this.accessPointForm.get('allDay')?.valueChanges.subscribe(value => {
      if (value === false) {
        this.accessPointForm?.get('timeFrom')?.setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required);
        this.accessPointForm?.get('timeFrom')?.updateValueAndValidity({
          emitEvent: false
        });
        this.accessPointForm?.get('timeTo')?.setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required);
        this.accessPointForm?.get('timeTo')?.updateValueAndValidity({
          emitEvent: false
        });
      } else {
        this.accessPointForm?.get('timeFrom')?.clearValidators();
        this.accessPointForm?.get('timeFrom')?.updateValueAndValidity({
          emitEvent: false
        });
        this.accessPointForm?.get('timeTo')?.clearValidators();
        this.accessPointForm?.get('timeTo')?.updateValueAndValidity({
          emitEvent: false
        });
      }
    });
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  daySelect: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.ViewChild,
    args: [src_app_shared_components_day_select_form_day_select_form_component__WEBPACK_IMPORTED_MODULE_3__.DaySelectFormComponent]
  }]
}), _class);
AccessPointDateComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
  selector: 'app-access-point-date',
  template: _access_point_date_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_access_point_date_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], AccessPointDateComponent);

class AccessPointDateViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "id", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "allDay", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "timeFrom", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "timeTo", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "hourFrom", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "hourTo", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "minuteFrom", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "minuteTo", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "daysVM", void 0);
  }
}
class UpdateAccessPointScheduleViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "id", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "hourFrom", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "hourTo", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "minuteFrom", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "minuteTo", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "allDays", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "monday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "tuesday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "wednesday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "thursday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "friday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "saturday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "sunday", void 0);
  }
}

/***/ }),

/***/ 20805:
/*!************************************************************************************!*\
  !*** ./src/app/access/components/access-point-edit/access-point-edit.component.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccessPointEditComponent": () => (/* binding */ AccessPointEditComponent)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _access_point_edit_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./access-point-edit.component.html?ngResource */ 88155);
/* harmony import */ var _access_point_edit_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./access-point-edit.component.scss?ngResource */ 61638);
/* harmony import */ var _access_point_edit_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_access_point_edit_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/button/button.component */ 62490);
/* harmony import */ var src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/components/footer/footer.component */ 68014);
/* harmony import */ var _access_point_address_access_point_address_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../access-point-address/access-point-address.component */ 42439);
/* harmony import */ var _access_point_control_access_point_control_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../access-point-control/access-point-control.component */ 52403);
/* harmony import */ var _access_point_date_access_point_date_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../access-point-date/access-point-date.component */ 262);
/* harmony import */ var _access_point_name_access_point_name_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../access-point-name/access-point-name.component */ 60295);

var _class;










let AccessPointEditComponent = (_class = class AccessPointEditComponent {
  constructor(cdRef) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "cdRef", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "modalC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "confirmModalC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "nameC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "addressC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "dateC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "controlC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "loading", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "site", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "apList", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "saveAccess", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "back", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "step", 1);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "footerOptions", src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_4__.FooterSelectedOption);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "buttonsConfig", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "titleLabel", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "confirmModalTextKey", 'common.confirmChanges');
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "isClosing", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "showKeyboard", false);
    this.cdRef = cdRef;
  }
  get stepValid() {
    switch (this.step) {
      case 1:
        return this.nameC?.formValid;
      case 2:
        return this.addressC?.formValid;
      case 3:
        return this.dateC?.formValid;
    }
  }
  get buttonState() {
    if (this.isClosing) return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_3__.ButtonState.enabled;
    if (!this.stepValid) {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_3__.ButtonState.disabled;
    } else if (!this.loading) {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_3__.ButtonState.enabled;
    } else {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_3__.ButtonState.loading;
    }
  }
  get hasChanges() {
    switch (this.step) {
      case 1:
        return this.nameC?.formDirty ?? false;
      case 2:
        return this.addressC?.formDirty ?? false;
      case 3:
        return this.dateC?.formDirty ?? false;
      default:
        return false;
    }
  }
  getState() {
    return this.buttonState;
  }
  fillStep(step, vm) {
    this.step = step;
    switch (step) {
      case 1:
        this.nameC?.setForm(vm.accessPointNameStep);
        break;
      case 2:
        this.addressC?.setForm(vm.accessPointAddressStep);
        break;
      case 3:
        this.dateC?.setForm(vm.accessPointDateStep);
        break;
    }
  }
  trySave() {
    if (this.hasChanges) {
      this.confirmModalTextKey = 'common.confirmChanges';
      this.confirmModalC?.show();
    } else {
      this.save();
    }
  }
  save() {
    let stepModel;
    switch (this.step) {
      case 1:
        stepModel = this.nameC?.viewModel;
        break;
      case 2:
        stepModel = this.addressC?.viewModel;
        break;
      case 3:
        stepModel = this.dateC?.viewModel;
        break;
    }
    this.loading = true;
    this.saveAccess.emit(stepModel);
  }
  tryClose() {
    if (this.hasChanges) {
      this.isClosing = true;
      this.confirmModalTextKey = 'common.confirmCancel';
      this.confirmModalC?.show();
    } else {
      this.cancel();
    }
  }
  confirmAccept() {
    if (this.confirmModalTextKey === 'common.confirmCancel') {
      this.cancel();
    } else {
      this.save();
    }
  }
  cancel() {
    this.back.emit();
  }
  hide() {
    this.showKeyboard = true;
    this.cdRef.detectChanges();
  }
  show() {
    this.showKeyboard = false;
    this.cdRef.detectChanges();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ChangeDetectorRef
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  modalC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild,
    args: ['modal']
  }],
  confirmModalC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild,
    args: ['confirmModal']
  }],
  nameC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild,
    args: [_access_point_name_access_point_name_component__WEBPACK_IMPORTED_MODULE_8__.AccessPointNameComponent]
  }],
  addressC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild,
    args: [_access_point_address_access_point_address_component__WEBPACK_IMPORTED_MODULE_5__.AccessPointAddressComponent]
  }],
  dateC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild,
    args: [_access_point_date_access_point_date_component__WEBPACK_IMPORTED_MODULE_7__.AccessPointDateComponent]
  }],
  controlC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild,
    args: [_access_point_control_access_point_control_component__WEBPACK_IMPORTED_MODULE_6__.AccessPointControlComponent]
  }],
  loading: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Input
  }],
  site: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Input
  }],
  apList: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Input
  }],
  saveAccess: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  back: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }]
}), _class);
AccessPointEditComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-access-point-edit',
  template: _access_point_edit_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_access_point_edit_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], AccessPointEditComponent);


/***/ }),

/***/ 60295:
/*!************************************************************************************!*\
  !*** ./src/app/access/components/access-point-name/access-point-name.component.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccessPointNameComponent": () => (/* binding */ AccessPointNameComponent),
/* harmony export */   "AccessPointNameViewModel": () => (/* binding */ AccessPointNameViewModel),
/* harmony export */   "UpdateAccessPointViewModel": () => (/* binding */ UpdateAccessPointViewModel)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _access_point_name_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./access-point-name.component.html?ngResource */ 49015);
/* harmony import */ var _access_point_name_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./access-point-name.component.scss?ngResource */ 35199);
/* harmony import */ var _access_point_name_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_access_point_name_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 70997);

var _class;





let AccessPointNameComponent = (_class = class AccessPointNameComponent {
  constructor(fb) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "fb", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "apList", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "newAccessForm", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "images", []);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "deleteImages", []);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "vm", void 0);
    this.fb = fb;
  }
  get formValid() {
    return this.newAccessForm?.valid;
  }
  get formDirty() {
    return this.newAccessForm?.dirty;
  }
  get viewModel() {
    this.vm = new AccessPointNameViewModel();
    Object.assign(this.vm, this.newAccessForm?.getRawValue());
    this.vm.images = this.images.filter(x => x.file !== null && x.file !== undefined);
    this.vm.doors = this.apList;
    this.vm.deleteImage = this.deleteImages;
    return this.vm;
  }
  ngOnInit() {
    this.initForm();
  }
  initForm() {
    this.newAccessForm = this.fb.group({
      name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required],
      previousAccess: ['']
    });
  }
  setForm(vm) {
    if (!vm) return;
    this.newAccessForm.get('name')?.setValue(vm.name);
    this.newAccessForm.get('previousAccess')?.setValue(vm.previousAccess);
    if (vm.images) this.images = vm.images.filter(x => x.id !== null && x.id !== undefined);
    if (vm.doors) this.apList = vm.doors;
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormBuilder
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  apList: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input
  }]
}), _class);
AccessPointNameComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
  selector: 'app-access-point-name',
  template: _access_point_name_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_access_point_name_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], AccessPointNameComponent);

class AccessPointNameViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "name", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "previousAccess", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "description", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "doors", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "images", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "deleteImage", void 0);
  }
}
class UpdateAccessPointViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "id", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "name", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessPointParentId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "externalFileId", void 0);
  }
}

/***/ }),

/***/ 11942:
/*!*******************************************************************************!*\
  !*** ./src/app/access/pages/access-point-wizard/new-access-point.business.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccessPointWizardViewModel": () => (/* binding */ AccessPointWizardViewModel),
/* harmony export */   "NewAccessPointBusiness": () => (/* binding */ NewAccessPointBusiness),
/* harmony export */   "PostAccessPointViewModel": () => (/* binding */ PostAccessPointViewModel)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var src_app_shared_services_access_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/services/access.service */ 46554);
/* harmony import */ var src_app_shared_services_site_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/services/site.service */ 19886);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _components_access_point_name_access_point_name_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/access-point-name/access-point-name.component */ 60295);
/* harmony import */ var _components_access_point_date_access_point_date_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/access-point-date/access-point-date.component */ 262);
/* harmony import */ var _components_access_point_control_access_point_control_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../components/access-point-control/access-point-control.component */ 52403);
/* harmony import */ var _components_access_point_edit_access_point_edit_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../components/access-point-edit/access-point-edit.component */ 20805);
/* harmony import */ var _components_access_point_address_access_point_address_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../components/access-point-address/access-point-address.component */ 42439);
/* harmony import */ var _shared_components_door_select_form_door_select_form_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../shared/components/door-select-form/door-select-form.component */ 6980);
/* harmony import */ var _shared_services_access_point_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../shared/services/access-point.service */ 58838);
/* harmony import */ var _shared_services_file_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../shared/services/file.service */ 30038);
/* harmony import */ var _shared_services_invitation_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../shared/services/invitation.service */ 21178);
/* harmony import */ var _shared_services_user_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../shared/services/user.service */ 31880);
/* harmony import */ var _shared_models_Image__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../shared/models/Image */ 90925);
/* harmony import */ var _shared_components_day_select_form_day_select_form_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../shared/components/day-select-form/day-select-form.component */ 84599);
/* harmony import */ var _shared_helpers_DaysViewModel__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../shared/helpers/DaysViewModel */ 12913);
/* harmony import */ var _shared_helpers_LocationViewModel__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../shared/helpers/LocationViewModel */ 52158);
/* harmony import */ var _shared_helpers_GetPostAccessPointViewModel__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../shared/helpers/GetPostAccessPointViewModel */ 49669);
/* harmony import */ var src_app_shared_models_PostAccessViewModel__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! src/app/shared/models/PostAccessViewModel */ 69062);
/* harmony import */ var src_app_invite_pages_invitation_wizard_invitation_wizard_business__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! src/app/invite/pages/invitation-wizard/invitation-wizard.business */ 8393);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! rxjs */ 51547);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var ionicons_icons__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ionicons/icons */ 64047);


var _class;


























let NewAccessPointBusiness = (_class = class NewAccessPointBusiness {
  constructor(route, accessService, accessPointService, invitationService, siteService, navController, fileService, userService, translateService, toastr) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "route", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPointService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitationService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "siteService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "fileService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "translateService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "toastr", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "editC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "edit", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "viewModel", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "loading", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitationId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "siteId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "site", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "apList", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPoint", void 0);
    this.route = route;
    this.accessService = accessService;
    this.accessPointService = accessPointService;
    this.invitationService = invitationService;
    this.siteService = siteService;
    this.navController = navController;
    this.fileService = fileService;
    this.userService = userService;
    this.translateService = translateService;
    this.toastr = toastr;
    this.viewModel = new AccessPointWizardViewModel();
  }
  get userId() {
    return this.userService.userData?.userId;
  }
  ngOnInit() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this.route.snapshot.params.id != null && !_this.edit) {
        _this.siteId = _this.route.snapshot.params.id;
        _this.siteService.getSiteById(_this.siteId).subscribe(response => {
          if (response.error == null) {
            _this.site = response.data;
          } else {
            _this.navController.navigateRoot('error');
          }
        });
        _this.accessPointService.getSiteAccessPoints(_this.siteId).subscribe(response => {
          if (response.error == null) {
            _this.apList = response.data.map(ap => {
              const door = new _shared_components_door_select_form_door_select_form_component__WEBPACK_IMPORTED_MODULE_9__.DoorsViewModel();
              door.selected = false;
              door.access = ap;
              return door;
            });
          } else {
            _this.navController.navigateRoot('error');
          }
        });
      }
    })();
  }
  openModal(apId, step) {
    var _this2 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this2.getWizardViewModel(apId, step);
      _this2.editC?.fillStep(step, _this2.viewModel);
      _this2.editC?.modalC?.show();
    })();
  }
  getPreviousDoors() {
    var _this3 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const that = _this3;
      _this3.apList = [];
      const response = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_22__.lastValueFrom)(_this3.accessPointService.getSiteAccessPoints(_this3.accessPoint.siteId));
      if (response.error == null) {
        response.data.forEach(ap => {
          if (ap.id !== _this3.accessPoint.id && ap.accessPointParent?.length === 0) {
            const door = new _shared_components_door_select_form_door_select_form_component__WEBPACK_IMPORTED_MODULE_9__.DoorsViewModel();
            door.selected = that.accessPoint.accessPointParent?.some(x => x.id === ap.id) ?? false;
            door.access = ap;
            _this3.apList.push(door);
          }
        });
        // this.apList = this.apList.filter(
        //   (x) =>
        //     x.access.id !== this.accessPoint.id && x.access.accessPointParent?.some((ap) => ap.id !== this.accessPoint.id)
        // );
      }
    })();
  }

  getWizardViewModel(apId, step) {
    var _this4 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const r = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_22__.lastValueFrom)(_this4.accessPointService.getAccessPointById(apId));
      if (r) _this4.accessPoint = r.data;
      yield _this4.getPreviousDoors();
      switch (step) {
        case 1:
          const apVM = new _components_access_point_name_access_point_name_component__WEBPACK_IMPORTED_MODULE_4__.AccessPointNameViewModel();
          apVM.name = _this4.accessPoint.name;
          if (_this4.accessPoint.presentationImg) {
            apVM.images = [];
            let i = 0;
            _this4.accessPoint.presentationImg.forEach(img => {
              const image = new _shared_models_Image__WEBPACK_IMPORTED_MODULE_14__.Image();
              image.id = img.id;
              image.image64 = img.url;
              image.name = `apImg${i}.png`;
              apVM.images?.push(image);
              i++;
            });
          }
          if (_this4.apList) {
            apVM.doors = _this4.apList.map(x => {
              const door = new _shared_components_door_select_form_door_select_form_component__WEBPACK_IMPORTED_MODULE_9__.DoorsViewModel();
              door.selected = x.selected;
              door.access = x.access;
              return door;
            });
          }
          _this4.viewModel.accessPointNameStep = apVM;
          break;
        case 2:
          const addressVM = new _components_access_point_address_access_point_address_component__WEBPACK_IMPORTED_MODULE_8__.AccessPointAddressViewModel();
          addressVM.address = _this4.accessPoint.address;
          addressVM.latitude = _this4.accessPoint.latitude;
          addressVM.longitude = _this4.accessPoint.longitude;
          addressVM.map = _this4.accessPoint.mapImage.url;
          _this4.viewModel.accessPointAddressStep = addressVM;
          break;
        case 3:
          const dateVM = new _components_access_point_date_access_point_date_component__WEBPACK_IMPORTED_MODULE_5__.AccessPointDateViewModel();
          if (_this4.accessPoint?.hourFrom !== null && _this4.accessPoint?.minuteFrom !== null) {
            dateVM.hourFrom = _this4.accessPoint.hourFrom;
            dateVM.minuteFrom = _this4.accessPoint.minuteTo;
            dateVM.timeFrom = (dateVM.hourFrom < 10 ? '0' + dateVM.hourFrom.toString() : dateVM.hourFrom) + ':' + (dateVM.minuteFrom < 10 ? '0' + dateVM.minuteFrom.toString() : dateVM.minuteFrom);
          }
          if (_this4.accessPoint.minuteTo !== null && _this4.accessPoint?.hourTo !== null) {
            dateVM.hourTo = _this4.accessPoint.hourTo;
            dateVM.minuteTo = _this4.accessPoint.minuteTo;
            dateVM.timeTo = (dateVM.hourTo < 10 ? '0' + dateVM.hourTo.toString() : dateVM.hourTo) + ':' + (dateVM.minuteTo < 10 ? '0' + dateVM.minuteTo.toString() : dateVM.minuteTo);
          }
          if ((dateVM.hourFrom === null || dateVM.hourFrom === undefined || dateVM.hourFrom === 0) && (dateVM.minuteFrom === null || dateVM.minuteFrom === undefined || dateVM.minuteFrom === 0) && (dateVM.hourTo === null || dateVM.hourTo === undefined || dateVM.hourTo === 0) && (dateVM.minuteTo === null || dateVM.minuteTo === undefined || dateVM.minuteTo === 0)) {
            dateVM.allDay = true;
          } else {
            dateVM.allDay = false;
          }
          dateVM.daysVM = new _shared_components_day_select_form_day_select_form_component__WEBPACK_IMPORTED_MODULE_15__.DaysViewModel();
          dateVM.daysVM.monday = _this4.accessPoint.monday;
          dateVM.daysVM.tuesday = _this4.accessPoint.tuesday;
          dateVM.daysVM.wednesday = _this4.accessPoint.wednesday;
          dateVM.daysVM.thursday = _this4.accessPoint.thursday;
          dateVM.daysVM.friday = _this4.accessPoint.friday;
          dateVM.daysVM.saturday = _this4.accessPoint.saturday;
          dateVM.daysVM.sunday = _this4.accessPoint.sunday;
          if (dateVM.daysVM.monday && dateVM.daysVM.tuesday && dateVM.daysVM.wednesday && dateVM.daysVM.thursday && dateVM.daysVM.friday && dateVM.daysVM.saturday && dateVM.daysVM.sunday) {
            dateVM.daysVM.allDays = true;
          } else {
            dateVM.daysVM.allDays = false;
          }
          _this4.viewModel.accessPointDateStep = dateVM;
          break;
        case 4:
          const controlVM = new _components_access_point_control_access_point_control_component__WEBPACK_IMPORTED_MODULE_6__.AccessPointControlViewModel();
          controlVM.noteAccess = _this4.accessPoint.notes;
          controlVM.inputs = _this4.accessPoint.inputs;
          _this4.viewModel.accessPointControlStep = controlVM;
          break;
      }
    })();
  }
  back() {
    if (!this.edit) {
      this.navController.back();
    } else {
      this.editC?.modalC?.hide();
    }
  }
  nextClick(model) {
    var _this5 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this5.fillVM(model);
    })();
  }
  save(model) {
    var _this6 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const step = _this6.fillVM(model);
      if (_this6.edit) {
        if (step === 1) {
          _this6.saveStep(1);
        } else if (step === 2) {
          if (_this6.viewModel.accessPointAddressStep?.address !== _this6.accessPoint.address) {
            _this6.saveStep(2);
          } else {
            _this6.loading = false;
            _this6.navController.back();
          }
        } else if (step === 3) {
          _this6.saveStep(3);
        } else if (step === 4) {
          _this6.saveStep(4);
        }
      } else {
        _this6.fillVM(model);
        const vmPost = _this6.getPostViewModel();
        const invVm = _this6.getInvitationPostViewModel();
        invVm.location = vmPost.id;
        const accessVm = new src_app_shared_models_PostAccessViewModel__WEBPACK_IMPORTED_MODULE_19__.PostAccessViewModel();
        accessVm.id = crypto.randomUUID();
        accessVm.invitationId = invVm.id;
        accessVm.userId = _this6.userId;
        accessVm.attendance = false;
        yield _this6.deleteImages(_this6.viewModel.accessPointNameStep);
        if (_this6.viewModel.accessPointNameStep?.images?.length === 0) {
          yield _this6.postServices(vmPost, invVm, accessVm);
        } else {
          const res = yield _this6.fileService.uploadFiles(_this6.viewModel.accessPointNameStep?.images).toPromise();
          if (res?.error === null) {
            vmPost.externalFileId = res.data;
          } else {
            _this6.toastr.create({
              message: _this6.translateService.instant('error.fileUpload'),
              duration: 3000,
              icon: ionicons_icons__WEBPACK_IMPORTED_MODULE_21__.alertCircleOutline,
              color: 'warning'
            }).then(t => t.present());
          }
          yield _this6.postServices(vmPost, invVm, accessVm);
        }
      }
    })();
  }
  postServices(apVm, invVm, accessVm) {
    var _this7 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const mapResult = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_22__.lastValueFrom)(yield _this7.fileService.uploadFileString(apVm.mapFileId));
      if (mapResult?.error === null) {
        apVm.mapFileId = mapResult.data[0];
        const result = yield _this7.accessPointService.postAccessPoint(apVm).toPromise();
        if (result?.error === null) {
          const res = yield _this7.invitationService.postInvitation(invVm).toPromise();
          if (res?.error === null) {
            const invitation = yield _this7.invitationService.getInvitationById(invVm.id).toPromise();
            if (invitation?.error === null) {
              accessVm.invitation = invitation.data;
            }
            const data = yield _this7.accessService.postAccess(accessVm).toPromise();
            if (data?.error === null) {
              _this7.loading = false;
              _this7.navController.back();
            } else {
              _this7.navController.navigateRoot('error');
            }
          } else {
            _this7.navController.navigateRoot('error');
          }
        } else {
          _this7.navController.navigateRoot('error');
        }
      } else {
        _this7.navController.navigateRoot('error');
      }
    })();
  }
  fillVM(model) {
    if (model instanceof _components_access_point_name_access_point_name_component__WEBPACK_IMPORTED_MODULE_4__.AccessPointNameViewModel) {
      this.viewModel.accessPointNameStep = model;
      return 1;
    }
    if (model instanceof _components_access_point_address_access_point_address_component__WEBPACK_IMPORTED_MODULE_8__.AccessPointAddressViewModel) {
      this.viewModel.accessPointAddressStep = model;
      return 2;
    }
    if (model instanceof _components_access_point_date_access_point_date_component__WEBPACK_IMPORTED_MODULE_5__.AccessPointDateViewModel) {
      this.viewModel.accessPointDateStep = model;
      return 3;
    }
    if (model instanceof _components_access_point_control_access_point_control_component__WEBPACK_IMPORTED_MODULE_6__.AccessPointControlViewModel) {
      this.viewModel.accessPointControlStep = model;
      return 4;
    }
  }
  saveStep(step) {
    var _this8 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      switch (step) {
        case 1:
          const firstVM = _this8.getUpdateViewModel(1);
          yield _this8.deleteImages(_this8.viewModel.accessPointNameStep);
          if (_this8.viewModel.accessPointNameStep?.images?.length === 0) {
            _this8.accessPointService.updateAccessPoint(firstVM).subscribe(as => {
              if (as.error === null) {
                _this8.navController.back();
              } else {
                _this8.navController.navigateRoot('error');
              }
            });
          } else {
            _this8.fileService.uploadFiles(_this8.viewModel.accessPointNameStep?.images).subscribe(res => {
              if (res.error === null) {
                firstVM.externalFileId = res.data;
              } else {
                _this8.toastr.create({
                  message: _this8.translateService.instant('error.fileUpload'),
                  duration: 3000,
                  icon: ionicons_icons__WEBPACK_IMPORTED_MODULE_21__.alertCircleOutline,
                  color: 'warning'
                }).then(t => t.present());
              }
              _this8.accessPointService.updateAccessPoint(firstVM).subscribe(as => {
                if (as.error === null) {
                  _this8.navController.back();
                } else {
                  _this8.navController.navigateRoot('error');
                }
              });
            });
          }
          break;
        case 2:
          const secondVM = _this8.getUpdateViewModel(2);
          const mapResult = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_22__.lastValueFrom)(yield _this8.fileService.uploadFileString(secondVM.mapImageId));
          if (mapResult?.error === null) {
            secondVM.mapImageId = mapResult.data[0];
            _this8.accessPointService.updateAddress(secondVM).subscribe(res => {
              if (res.error === null) {
                _this8.navController.back();
              } else {
                _this8.navController.navigateRoot('error');
              }
            });
          }
          break;
        case 3:
          const thridVM = _this8.getUpdateViewModel(3);
          _this8.accessPointService.updateSchedule(thridVM).subscribe(res => {
            if (res.error === null) {
              _this8.navController.back();
            } else {
              _this8.navController.navigateRoot('error');
            }
          });
          break;
        case 4:
          const fourVM = _this8.getUpdateViewModel(4);
          _this8.accessPointService.updateNotes(fourVM).subscribe(res => {
            if (res.error === null) {
              _this8.navController.back();
            } else {
              _this8.navController.navigateRoot('error');
            }
          });
          break;
      }
    })();
  }
  getUpdateViewModel(step) {
    let ret;
    switch (step) {
      case 1:
        ret = new _components_access_point_name_access_point_name_component__WEBPACK_IMPORTED_MODULE_4__.UpdateAccessPointViewModel();
        ret.id = this.accessPoint.id;
        ret.name = this.viewModel.accessPointNameStep?.name;
        ret.accessPointParentId = this.viewModel.accessPointNameStep?.doors?.filter(x => x.selected).map(x => x.access.id);
        break;
      case 2:
        ret = (0,_shared_helpers_LocationViewModel__WEBPACK_IMPORTED_MODULE_17__.locationViewModelForAccessPointSchedule)(this.viewModel.accessPointAddressStep);
        ret.id = this.accessPoint?.id;
        break;
      case 3:
        ret = (0,_shared_helpers_DaysViewModel__WEBPACK_IMPORTED_MODULE_16__.daysViewModelForAccessPointSchedule)(this.viewModel.accessPointDateStep);
        ret.id = this.accessPoint?.id;
        break;
      case 4:
        ret = new _components_access_point_control_access_point_control_component__WEBPACK_IMPORTED_MODULE_6__.UpdateAccessPointControlViewModel();
        ret.id = this.accessPoint.id;
        ret.noteAccess = this.viewModel.accessPointControlStep?.noteAccess;
        ret.inputs = this.viewModel.accessPointControlStep?.inputs;
        break;
    }
    return ret;
  }
  deleteImages(model) {
    var _this9 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      model?.deleteImage?.forEach( /*#__PURE__*/function () {
        var _ref = (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (img) {
          if (img) {
            yield (0,rxjs__WEBPACK_IMPORTED_MODULE_22__.lastValueFrom)(_this9.accessPointService.deleteImage(img));
          }
        });
        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }());
    })();
  }
  getPostViewModel() {
    const vm = (0,_shared_helpers_GetPostAccessPointViewModel__WEBPACK_IMPORTED_MODULE_18__.getPostViewModelForAccessPoint)(this.viewModel, this.siteId);
    vm.name = this.viewModel.accessPointNameStep?.name;
    vm.accessPointParentId = this.viewModel.accessPointNameStep?.doors?.filter(x => x.selected).map(x => x.access.id);
    return vm;
  }
  getInvitationPostViewModel() {
    const vm = new src_app_invite_pages_invitation_wizard_invitation_wizard_business__WEBPACK_IMPORTED_MODULE_20__.PostInvitationViewModel();
    vm.id = crypto.randomUUID();
    vm.categoryId = '28003411-a456-4030-85c8-2e73f64a579a';
    vm.description = this.translateService.instant('invite.defaultTitle');
    vm.motive = this.site.name + ' - ' + this.viewModel.accessPointNameStep?.name;
    vm.place = this.viewModel.accessPointAddressStep?.address;
    vm.siteId = this.siteId;
    vm.accessPointIds = [];
    vm.dateFrom = new Date().toISOString();
    if (!this.viewModel.accessPointDateStep?.allDay) {
      if (this.viewModel.accessPointDateStep?.timeFrom) {
        const time = this.viewModel.accessPointDateStep?.timeFrom.split(':');
        vm.hourFrom = Number(time[0]);
        vm.minuteFrom = Number(time[1]);
      }
      if (this.viewModel.accessPointDateStep?.timeTo) {
        const time = this.viewModel.accessPointDateStep?.timeTo.split(':');
        vm.hourTo = Number(time[0]);
        vm.minuteTo = Number(time[1]);
      }
    }
    vm.recurrency = true;
    vm.monday = this.viewModel.accessPointDateStep?.daysVM.monday;
    vm.tuesday = this.viewModel.accessPointDateStep?.daysVM.tuesday;
    vm.wednesday = this.viewModel.accessPointDateStep?.daysVM.wednesday;
    vm.thursday = this.viewModel.accessPointDateStep?.daysVM.thursday;
    vm.friday = this.viewModel.accessPointDateStep?.daysVM.friday;
    vm.saturday = this.viewModel.accessPointDateStep?.daysVM.saturday;
    vm.sunday = this.viewModel.accessPointDateStep?.daysVM.sunday;
    vm.default = true;
    return vm;
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_23__.ActivatedRoute
}, {
  type: src_app_shared_services_access_service__WEBPACK_IMPORTED_MODULE_2__.AccessService
}, {
  type: _shared_services_access_point_service__WEBPACK_IMPORTED_MODULE_10__.AccessPointService
}, {
  type: _shared_services_invitation_service__WEBPACK_IMPORTED_MODULE_12__.InvitationService
}, {
  type: src_app_shared_services_site_service__WEBPACK_IMPORTED_MODULE_3__.SiteService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.NavController
}, {
  type: _shared_services_file_service__WEBPACK_IMPORTED_MODULE_11__.FileService
}, {
  type: _shared_services_user_service__WEBPACK_IMPORTED_MODULE_13__.UserService
}, {
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_25__.TranslateService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.ToastController
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "propDecorators", {
  editC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_26__.ViewChild,
    args: [_components_access_point_edit_access_point_edit_component__WEBPACK_IMPORTED_MODULE_7__.AccessPointEditComponent]
  }],
  edit: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_26__.Input
  }]
}), _class);
NewAccessPointBusiness = (0,tslib__WEBPACK_IMPORTED_MODULE_27__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_26__.Component)({
  selector: 'app-new-access-point-business',
  template: `<app-new-access-point
      *ngIf="!edit"
      class="scroll-content"
      [site]="site"
      [apList]="apList"
      [loading]="loading"
      (back)="back()"
      (nextClick)="nextClick($event)"
      (saveAccess)="save($event)"></app-new-access-point>
    <app-access-point-edit
      *ngIf="edit"
      [loading]="loading"
      [apList]="apList"
      (back)="back()"
      (saveAccess)="save($event)">
    </app-access-point-edit>`
})], NewAccessPointBusiness);

class AccessPointWizardViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "id", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "siteId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPointNameStep", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPointAddressStep", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPointDateStep", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPointControlStep", void 0);
  }
}
class PostAccessPointViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "id", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "siteId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "name", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "questionId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "inputs", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "externalFileId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPointParentId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "mapFileId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "address", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "latitude", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "longitude", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "notes", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "hourFrom", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "hourTo", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "minuteFrom", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "minuteTo", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "monday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "tuesday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "wednesday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "thursday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "friday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "saturday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "sunday", void 0);
  }
}

/***/ }),

/***/ 12913:
/*!*************************************************!*\
  !*** ./src/app/shared/helpers/DaysViewModel.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "daysViewModelForAccessPointSchedule": () => (/* binding */ daysViewModelForAccessPointSchedule)
/* harmony export */ });
/* harmony import */ var _access_components_access_point_date_access_point_date_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../access/components/access-point-date/access-point-date.component */ 262);

function daysViewModelForAccessPointSchedule(viewModel) {
  const ret = new _access_components_access_point_date_access_point_date_component__WEBPACK_IMPORTED_MODULE_0__.UpdateAccessPointScheduleViewModel();
  ret.friday = viewModel?.daysVM.friday;
  ret.monday = viewModel?.daysVM.monday;
  ret.saturday = viewModel?.daysVM.saturday;
  ret.sunday = viewModel?.daysVM.sunday;
  ret.thursday = viewModel?.daysVM.thursday;
  ret.tuesday = viewModel?.daysVM.tuesday;
  ret.wednesday = viewModel?.daysVM.wednesday;
  if (!viewModel?.allDay) {
    if (viewModel?.timeFrom) {
      const time = viewModel.timeFrom.split(':');
      ret.hourFrom = Number(time[0]);
      ret.minuteFrom = Number(time[1]);
    }
    if (viewModel?.timeTo) {
      const time = viewModel.timeTo.split(':');
      ret.hourTo = Number(time[0]);
      ret.minuteTo = Number(time[1]);
    }
  }
  return ret;
}

/***/ }),

/***/ 49669:
/*!***************************************************************!*\
  !*** ./src/app/shared/helpers/GetPostAccessPointViewModel.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getPostViewModelForAccessPoint": () => (/* binding */ getPostViewModelForAccessPoint)
/* harmony export */ });
/* harmony import */ var _access_pages_access_point_wizard_new_access_point_business__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../access/pages/access-point-wizard/new-access-point.business */ 11942);

function getPostViewModelForAccessPoint(viewModel, siteId) {
  const vm = new _access_pages_access_point_wizard_new_access_point_business__WEBPACK_IMPORTED_MODULE_0__.PostAccessPointViewModel();
  vm.id = crypto.randomUUID();
  vm.address = viewModel.accessPointAddressStep.address;
  vm.latitude = viewModel.accessPointAddressStep.latitude;
  vm.longitude = viewModel.accessPointAddressStep.longitude;
  vm.mapFileId = viewModel.accessPointAddressStep.map;
  // vm.notes = viewModel.accessPointControlStep?.noteAccess;
  // vm.inputs = viewModel.accessPointControlStep?.inputs;
  vm.siteId = siteId;
  if (!viewModel.accessPointDateStep?.allDay) {
    if (viewModel.accessPointDateStep?.timeFrom) {
      const time = viewModel.accessPointDateStep?.timeFrom.split(':');
      vm.hourFrom = Number(time[0]);
      vm.minuteFrom = Number(time[1]);
    }
    if (viewModel.accessPointDateStep?.timeTo) {
      const time = viewModel.accessPointDateStep?.timeTo.split(':');
      vm.hourTo = Number(time[0]);
      vm.minuteTo = Number(time[1]);
    }
  }
  vm.monday = viewModel.accessPointDateStep.daysVM.monday;
  vm.tuesday = viewModel.accessPointDateStep.daysVM.tuesday;
  vm.wednesday = viewModel.accessPointDateStep.daysVM.wednesday;
  vm.thursday = viewModel.accessPointDateStep.daysVM.thursday;
  vm.friday = viewModel.accessPointDateStep.daysVM.friday;
  vm.saturday = viewModel.accessPointDateStep.daysVM.saturday;
  vm.sunday = viewModel.accessPointDateStep.daysVM.sunday;
  return vm;
}

/***/ }),

/***/ 52158:
/*!*****************************************************!*\
  !*** ./src/app/shared/helpers/LocationViewModel.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "locationViewModelForAccessPointSchedule": () => (/* binding */ locationViewModelForAccessPointSchedule)
/* harmony export */ });
/* harmony import */ var _access_components_access_point_address_access_point_address_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../access/components/access-point-address/access-point-address.component */ 42439);

function locationViewModelForAccessPointSchedule(viewModel) {
  const ret = new _access_components_access_point_address_access_point_address_component__WEBPACK_IMPORTED_MODULE_0__.UpdateAccessPointAddressViewModel();
  ret.address = viewModel.address;
  ret.latitude = viewModel.latitude;
  ret.longitude = viewModel.longitude;
  ret.mapImageId = viewModel.map;
  return ret;
}

/***/ }),

/***/ 69062:
/*!******************************************************!*\
  !*** ./src/app/shared/models/PostAccessViewModel.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PostAccessViewModel": () => (/* binding */ PostAccessViewModel)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);

class PostAccessViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "id", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "userId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "invitationId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "attendance", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "invitation", void 0);
  }
}

/***/ }),

/***/ 17558:
/*!*****************************************************!*\
  !*** ./src/app/sites/pages/users/users.business.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddProfileViewModel": () => (/* binding */ AddProfileViewModel),
/* harmony export */   "ContactParameters": () => (/* binding */ ContactParameters),
/* harmony export */   "UsersBusiness": () => (/* binding */ UsersBusiness)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 51547);
/* harmony import */ var src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/components/button/button.component */ 62490);
/* harmony import */ var src_app_shared_components_contact_page_contact_page_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/contact-page/contact-page.component */ 64155);
/* harmony import */ var src_app_shared_components_plans_modal_plans_modal_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/components/plans-modal/plans-modal.component */ 78726);
/* harmony import */ var src_app_shared_helpers_business__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/helpers/business */ 92237);
/* harmony import */ var src_app_shared_services_access_point_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/services/access-point.service */ 58838);
/* harmony import */ var src_app_shared_services_site_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/site.service */ 19886);


var _class;












let UsersBusiness = (_class = class UsersBusiness {
  constructor(siteService, accessPointService, router, route, translate, business, navController) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "siteService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPointService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "router", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "route", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "business", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "contactPage", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "plansModal", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "displayList", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "users", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "mobileContactList", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "role", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "isAccessPoint", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "siteId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPointId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "removePage", true);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "siteName", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPoint", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "site", void 0);
    this.siteService = siteService;
    this.accessPointService = accessPointService;
    this.router = router;
    this.route = route;
    this.translate = translate;
    this.business = business;
    this.navController = navController;
    this.displayList = [];
    this.users = [];
    this.mobileContactList = [];
  }
  get listTitle() {
    if (this.removePage) {
      return this.roleTitle;
    } else {
      return this.translate.instant('common.addUsersTitle', {
        role: this.translate.instant('roles.' + this.role?.toLowerCase()).toLowerCase()
      });
    }
  }
  get bannerTitle() {
    return this.translate.instant('users.bannerTitle') + this.roleTitle;
  }
  get bannerDesc() {
    return this.translate.instant('users.bannerDesc');
  }
  get roleTitle() {
    return this.translate.instant('roles.' + this.role?.toLowerCase() + 'Label');
  }
  get buttonLabel() {
    if (this.removePage) {
      return this.translate.instant('common.delete');
    } else {
      return this.translate.instant('common.add');
    }
  }
  get buttonLabelConfirmed() {
    if (this.removePage) {
      return this.translate.instant('common.delete');
    } else {
      return this.translate.instant('common.addConfirmed');
    }
  }
  get confirmMessage() {
    if (this.removePage) {
      return this.translate.instant('users.confirmRemoveTitle');
    } else {
      return this.translate.instant('users.confirmAddTitle');
    }
  }
  ngOnInit() {
    if (this.route.snapshot.params.id != null) {
      this.isAccessPoint = this.router.url.includes('access-point');
      if (this.isAccessPoint) {
        this.accessPointId = this.route.snapshot.params.id;
        this.fetchAccessPoint();
      } else {
        this.siteId = this.route.snapshot.params.id;
        this.fetchSite();
      }
    }
    this.getNavigation();
  }
  ionViewDidEnter() {
    if (this.contactPage?.contacts?.length === 0) {
      this.contactPage?.change();
    }
  }
  getNavigation() {
    const current = this.router.getCurrentNavigation();
    if (current) {
      if (current.extras.state !== undefined) {
        this.role = current.extras.state?.role;
        this.siteName = current.extras.state?.siteName;
      } else {
        this.navController.back();
      }
    }
  }
  fetchAccessPoint() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const res = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.lastValueFrom)(_this.accessPointService.getAccessPointById(_this.accessPointId));
      if (res.error === null) {
        _this.accessPoint = res.data;
      } else {
        _this.navController.navigateRoot('error');
      }
    })();
  }
  fetchSite() {
    var _this2 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const res = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.lastValueFrom)(_this2.siteService.getSiteById(_this2.siteId));
      if (res.error === null) {
        _this2.site = res.data;
      } else {
        _this2.navController.navigateRoot('error');
      }
    })();
  }
  backClick() {
    if (this.removePage) this.navController.navigateBack('sites/site-info/' + this.siteId);else {
      this.removePage = true;
    }
  }
  confirm(list) {
    var _this3 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const vm = new AddProfileViewModel();
      vm.phones = list.map(x => x.userPhone);
      vm.role = _this3.role;
      vm.phones = list.map(x => {
        const e164FormattedNumber = _this3.business.getFormattedPhoneNumber(x.userPhone);
        return e164FormattedNumber;
      });
      vm.phones = vm.phones.filter(x => x !== '');
      _this3.contactPage?.emptyList();
      if (_this3.isAccessPoint) {
        vm.id = _this3.accessPointId;
        const result = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.lastValueFrom)(_this3.accessPointService.addProfile(vm));
        if (result.error == null) {
          _this3.removePage = true;
          _this3.contactPage?.refresh(result.data);
          _this3.fetchAccessPoint();
        } else {
          if (result.code === 820) {
            _this3.handleLimitError();
          } else _this3.navController.navigateRoot('error');
        }
      } else {
        vm.id = _this3.siteId;
        const result = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.lastValueFrom)(_this3.siteService.addProfile(vm));
        if (result.error == null) {
          _this3.removePage = true;
          _this3.fetchSite();
          _this3.contactPage?.refresh(result.data);
        } else {
          if (result.code === 820) {
            _this3.handleLimitError();
          } else _this3.navController.navigateRoot('error');
        }
      }
    })();
  }
  confirmRemove(list) {
    var _this4 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const vm = new AddProfileViewModel();
      vm.phones = list.map(x => x.userPhone);
      vm.role = _this4.role;
      _this4.contactPage?.emptyList();
      if (_this4.isAccessPoint) {
        vm.id = _this4.accessPointId;
        const result = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.lastValueFrom)(_this4.accessPointService.deleteProfile(vm));
        if (result.error == null) {
          _this4.contactPage?.refresh(result.data);
          _this4.fetchAccessPoint();
        } else {
          _this4.navController.navigateRoot('error');
        }
      } else {
        vm.id = _this4.siteId;
        const result = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.lastValueFrom)(_this4.siteService.deleteProfile(vm));
        if (result.error == null) {
          _this4.contactPage?.refresh(result.data);
          _this4.fetchSite();
        } else {
          _this4.navController.navigateRoot('error');
        }
      }
    })();
  }
  bannerClick() {
    if (this.isAccessPoint) {
      if (this.accessPoint?.siteRemainingUsers !== null && this.accessPoint?.siteRemainingUsers !== undefined && this.accessPoint?.siteRemainingUsers <= 0) this.plansModal?.modal?.show();else this.removePage = !this.removePage;
    } else {
      if (this.site?.remainingUsers !== null && this.site?.remainingUsers !== undefined && this.site?.remainingUsers <= 0) this.plansModal?.modal?.show();else this.removePage = !this.removePage;
    }
  }
  handleLimitError() {
    this.plansModal?.modal?.show();
    this.contactPage.getNavigation();
    this.contactPage.getContactsMobile();
    this.contactPage.disableButton = src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_2__.ButtonState.disabled;
    this.removePage = true;
  }
  switchPage() {
    this.removePage = !this.removePage;
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_services_site_service__WEBPACK_IMPORTED_MODULE_7__.SiteService
}, {
  type: src_app_shared_services_access_point_service__WEBPACK_IMPORTED_MODULE_6__.AccessPointService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.Router
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.ActivatedRoute
}, {
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__.TranslateService
}, {
  type: src_app_shared_helpers_business__WEBPACK_IMPORTED_MODULE_5__["default"]
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.NavController
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "propDecorators", {
  contactPage: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.ViewChild,
    args: [src_app_shared_components_contact_page_contact_page_component__WEBPACK_IMPORTED_MODULE_3__.ContactPageComponent]
  }],
  plansModal: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.ViewChild,
    args: [src_app_shared_components_plans_modal_plans_modal_component__WEBPACK_IMPORTED_MODULE_4__.PlansModalComponent]
  }]
}), _class);
UsersBusiness = (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Component)({
  template: `<app-contact-page
      class="scroll-content"
      [title]="siteName"
      [listTitle]="listTitle"
      [removePage]="removePage"
      [bannerTitle]="('users.bannerTitle' | translate) + roleTitle.toLowerCase()"
      [bannerDesc]="'users.bannerDesc' | translate"
      [emptyTitle]="'users.emptyTitle' | translate: { role: roleTitle.toLowerCase() }"
      [emptyDesc]="'users.emptyDesc' | translate: { role: roleTitle.toLowerCase() }"
      [buttonLabel]="buttonLabel"
      [buttonLabelConfirmed]="buttonLabelConfirmed"
      [confirmMessage]="confirmMessage"
      (confirmAddClick)="confirm($event)"
      (confirmRemoveClick)="confirmRemove($event)"
      (bannerClick)="bannerClick()"
      (back)="backClick()"></app-contact-page>
    <app-plans-modal></app-plans-modal>`
})], UsersBusiness);

class ContactParameters {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "id", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitationId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "role", void 0);
  }
}
class AddProfileViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "id", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "role", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "phones", void 0);
  }
}

/***/ }),

/***/ 22220:
/*!*******************************************************************************************************!*\
  !*** ./src/app/access/components/access-point-address/access-point-address.component.scss?ngResource ***!
  \*******************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".input-style fa-icon {\n  padding: 9.5px;\n  position: absolute;\n  top: 50%;\n  margin-top: -22px;\n  right: 10px;\n  overflow: hidden;\n  background: white;\n}", "",{"version":3,"sources":["webpack://./src/app/access/components/access-point-address/access-point-address.component.scss"],"names":[],"mappings":"AAAA;EACE,cAAA;EACA,kBAAA;EACA,QAAA;EACA,iBAAA;EACA,WAAA;EACA,gBAAA;EACA,iBAAA;AACF","sourcesContent":[".input-style fa-icon {\n  padding: 9.5px;\n  position: absolute;\n  top: 50%;\n  margin-top: -22px;\n  right: 10px;\n  overflow: hidden;\n  background: white;\n}\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 62700:
/*!*******************************************************************************************************!*\
  !*** ./src/app/access/components/access-point-control/access-point-control.component.scss?ngResource ***!
  \*******************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 11895:
/*!*************************************************************************************************!*\
  !*** ./src/app/access/components/access-point-date/access-point-date.component.scss?ngResource ***!
  \*************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 61638:
/*!*************************************************************************************************!*\
  !*** ./src/app/access/components/access-point-edit/access-point-edit.component.scss?ngResource ***!
  \*************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 35199:
/*!*************************************************************************************************!*\
  !*** ./src/app/access/components/access-point-name/access-point-name.component.scss?ngResource ***!
  \*************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 65000:
/*!*******************************************************************************************************!*\
  !*** ./src/app/access/components/access-point-address/access-point-address.component.html?ngResource ***!
  \*******************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"content mt-0 mx-0\">\n  <h6 class=\"font-400 font-16 pb-3\">{{ 'sites.location' | translate }}</h6>\n\n  <div class=\"input-style input-style-always-active has-borders no-icon validate-field\">\n    <input #addressText type=\"text\" class=\"form-control validate-text\" [(ngModel)]=\"autocomplete.input\" />\n\n    <label class=\"color-theme text-uppercase font-400 font-10\">{{ 'common.address' | translate }}</label>\n    <em class=\"color-highlight opacity-75\" [class.disabled]=\"autocomplete.input !== ''\">{{\n      'common.required' | translate\n    }}</em>\n    <fa-icon\n      *ngIf=\"autocomplete.input !== ''\"\n      [icon]=\"['fas', 'xmark']\"\n      [size]=\"'xl'\"\n      class=\"color-red-dark\"\n      (click)=\"clear()\"></fa-icon>\n  </div>\n  <app-map-info\n    (editClick)=\"mapEditClick.emit()\"\n    [address]=\"selectedPlace?.formatted_address\"\n    [latitude]=\"Number(selectedPlaceCoords[0])\"\n    [longitude]=\"Number(selectedPlaceCoords[1])\"\n    [imgSrc]=\"imgString\"></app-map-info>\n</div>\n";

/***/ }),

/***/ 23490:
/*!*******************************************************************************************************!*\
  !*** ./src/app/access/components/access-point-control/access-point-control.component.html?ngResource ***!
  \*******************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"content mb-6 mt-0 mx-0\">\n  <form [formGroup]=\"accessPointForm\">\n    <h6 class=\"font-400 font-16 pb-3\">Control</h6>\n    <div class=\"input-style input-style-always-active has-borders no-icon mt-3\">\n      <textarea type=\"name\" class=\"form-control validate-text\" formControlName=\"noteAccess\"> </textarea>\n      <label class=\"color-theme text-uppercase font-400 font-10\">{{ 'common.noteAccess' | translate }}</label>\n      <em class=\"color-highlight opacity-75\">{{ 'common.optional' | translate }}</em>\n    </div>\n    <app-access-form\n      [title]=\"'common.questionTitle' | translate\"\n      [inputs]=\"inputsNew\"\n      [editable]=\"true\"\n      [isAdminOrOwner]=\"true\"\n      (save)=\"saveForm.emit()\"\n      (saveDeleteInput)=\"deleteInput($event)\"\n      (saveEditInput)=\"editInput($event)\"\n      (saveNewInput)=\"addNewInput($event)\"></app-access-form>\n  </form>\n</div>\n";

/***/ }),

/***/ 3050:
/*!*************************************************************************************************!*\
  !*** ./src/app/access/components/access-point-date/access-point-date.component.html?ngResource ***!
  \*************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"content mt-0 mx-0\" *ngIf=\"accessPointForm\">\n  <form [formGroup]=\"accessPointForm\">\n    <h6 class=\"font-400 font-16\">{{ 'sites.timeTitle' | translate }}</h6>\n    <div class=\"row position-relative mb-3\">\n      <div class=\"col-12 d-flex\">\n        <div class=\"pt-1 align-self-center\">\n          <label class=\"color-theme text-uppercase font-400 font-10\">{{ 'invite.allDayLabel' | translate }}</label>\n        </div>\n        <div class=\"ms-auto me-3 align-self-center pe-2\">\n          <app-toggle-switch [control]=\"$any(accessPointForm).controls['allDay']\"></app-toggle-switch>\n        </div>\n      </div>\n      <ng-container *ngIf=\"accessPointForm.get('allDay')?.value === false\">\n        <div class=\"col-6\">\n          <div class=\"input-date-time\">\n            <input type=\"time\" class=\"form-control\" formControlName=\"timeFrom\" />\n            <label class=\"color-theme text-uppercase font-400 font-10 custom-label-margin\">{{\n              'sites.timeFromInput' | translate\n            }}</label>\n            <em class=\"color-highlight opacity-75\" *ngIf=\"!accessPointForm.get('timeFrom')?.value\">{{\n              'common.required' | translate\n            }}</em>\n          </div>\n        </div>\n        <div class=\"col-6\">\n          <div class=\"input-date-time\">\n            <input type=\"time\" class=\"form-control\" formControlName=\"timeTo\" />\n            <label class=\"color-theme text-uppercase font-400 font-10 custom-label-margin\">{{\n              'sites.timeToInput' | translate\n            }}</label>\n            <em class=\"color-highlight opacity-75\" *ngIf=\"!accessPointForm.get('timeTo')?.value\">{{\n              'common.required' | translate\n            }}</em>\n          </div>\n        </div>\n      </ng-container>\n    </div>\n\n    <app-day-select-form [wizard]=\"'ap'\"></app-day-select-form>\n  </form>\n</div>\n";

/***/ }),

/***/ 88155:
/*!*************************************************************************************************!*\
  !*** ./src/app/access/components/access-point-edit/access-point-edit.component.html?ngResource ***!
  \*************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-modal-menu #modal [height]=\"'h-75'\" [static]=\"true\">\n  <ng-template #modalContent>\n    <div class=\"content mb-5\">\n      <a role=\"button\" (click)=\"tryClose()\" class=\"font-16 w-fit color-red-dark float-end\">\n        <fa-icon [icon]=\"['fas', 'times']\"></fa-icon\n      ></a>\n\n      <app-access-point-name [apList]=\"apList\" [hidden]=\"step !== 1\"></app-access-point-name>\n      <app-new-access-point-address [hidden]=\"step !== 2\"></app-new-access-point-address>\n      <app-access-point-date [hidden]=\"step !== 3\"></app-access-point-date>\n      <div class=\"pt-3\"></div>\n      <ng-container *ngIf=\"!showKeyboard\">\n        <app-button\n          [status]=\"buttonState\"\n          [label]=\"'common.save' | translate\"\n          (onHide)=\"hide()\"\n          (buttonClick)=\"trySave()\"></app-button>\n      </ng-container>\n      <div class=\"pb-3\"></div>\n    </div>\n  </ng-template>\n</app-modal-menu>\n\n<app-modal-menu #confirmModal [shadow]=\"true\">\n  <ng-template #modalContent>\n    <div class=\"center w-100 p-3\">\n      <h6 class=\"font-400 font-14 pb-3 text-center\">{{ confirmModalTextKey | translate }}</h6>\n      <app-button\n        class=\"w-fit\"\n        [label]=\"'common.accept' | translate\"\n        [status]=\"buttonState\"\n        (buttonClick)=\"confirmAccept(); confirmModal.hide()\"></app-button>\n      <div class=\"pt-2\"></div>\n      <app-button\n        class=\"w-fit\"\n        [bgClass]=\"'bg-transparent'\"\n        [customClass]=\"'w-100 border-highlight color-highlight'\"\n        [label]=\"'common.cancel' | translate\"\n        (buttonClick)=\"confirmModal.hide()\"></app-button>\n    </div>\n  </ng-template>\n</app-modal-menu>\n\n<ng-container *ngIf=\"showKeyboard\">\n  <app-button\n    [status]=\"buttonState\"\n    [label]=\"'common.save' | translate\"\n    [customClass]=\"'w-100 button-onkeyboard'\"\n    (onShow)=\"show()\"\n    (buttonClick)=\"trySave()\"></app-button>\n</ng-container>\n";

/***/ }),

/***/ 49015:
/*!*************************************************************************************************!*\
  !*** ./src/app/access/components/access-point-name/access-point-name.component.html?ngResource ***!
  \*************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"content mb-6 mt-0 mx-0\">\n  <form [formGroup]=\"newAccessForm\">\n    <h6 class=\"font-400 font-16 pb-3\">{{ 'access.newAccessFormTitle' | translate }}</h6>\n\n    <div class=\"input-style input-style-always-active has-borders no-icon validate-field\">\n      <input type=\"name\" class=\"form-control validate-text\" formControlName=\"name\" />\n      <label class=\"color-theme text-uppercase font-400 font-10\">{{ 'access.newAccessName' | translate }}</label>\n      <em class=\"color-highlight opacity-75\">{{ 'common.required' | translate }}</em>\n    </div>\n    <app-door-select-form [accessPoints]=\"apList\"></app-door-select-form>\n    <!-- <p class=\"text-uppercase font-400 font-10 opacity-50 float-right\">\n      {{ 'common.imageHelpNewAccess' | translate }}\n    </p> -->\n    <app-img-preview [images]=\"images\" [deleteImages]=\"deleteImages\"></app-img-preview>\n  </form>\n</div>\n";

/***/ })

}]);
//# sourceMappingURL=default-src_app_access_pages_access-point-wizard_new-access-point_business_ts-src_app_shared_-cd58b1.js.map