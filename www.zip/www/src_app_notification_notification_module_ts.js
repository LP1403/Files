(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_notification_notification_module_ts"],{

/***/ 96871:
/*!*********************************************************!*\
  !*** ./node_modules/ngx-timeago/language-strings/en.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "strings": () => (/* binding */ strings)
/* harmony export */ });
const strings = {
  prefixAgo: null,
  prefixFromNow: null,
  suffixAgo: 'ago',
  suffixFromNow: 'from now',
  seconds: 'less than a minute',
  minute: 'about a minute',
  minutes: '%d minutes',
  hour: 'about an hour',
  hours: 'about %d hours',
  day: 'a day',
  days: '%d days',
  month: 'about a month',
  months: '%d months',
  year: 'about a year',
  years: '%d years',
  wordSeparator: ' '
};

/***/ }),

/***/ 34358:
/*!*********************************************************!*\
  !*** ./node_modules/ngx-timeago/language-strings/es.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "strings": () => (/* binding */ strings)
/* harmony export */ });
const strings = {
  prefixAgo: 'hace',
  prefixFromNow: 'dentro de',
  suffixAgo: '',
  suffixFromNow: '',
  seconds: 'menos de un minuto',
  minute: 'un minuto',
  minutes: 'unos %d minutos',
  hour: 'una hora',
  hours: '%d horas',
  day: 'un día',
  days: '%d días',
  month: 'un mes',
  months: '%d meses',
  year: 'un año',
  years: '%d años'
};

/***/ }),

/***/ 29081:
/*!**********************************************************************************************************************!*\
  !*** ./src/app/notification/components/notification-list-item-skeleton/notification-list-item-skeleton.component.ts ***!
  \**********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationListItemSkeletonComponent": () => (/* binding */ NotificationListItemSkeletonComponent)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _notification_list_item_skeleton_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./notification-list-item-skeleton.component.html?ngResource */ 71008);
/* harmony import */ var _notification_list_item_skeleton_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./notification-list-item-skeleton.component.scss?ngResource */ 29098);
/* harmony import */ var _notification_list_item_skeleton_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_notification_list_item_skeleton_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51197);

var _class;




let NotificationListItemSkeletonComponent = (_class = class NotificationListItemSkeletonComponent {
  constructor() {}
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => []), _class);
NotificationListItemSkeletonComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
  selector: 'app-notification-list-item-skeleton',
  template: _notification_list_item_skeleton_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_notification_list_item_skeleton_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], NotificationListItemSkeletonComponent);


/***/ }),

/***/ 98739:
/*!****************************************************************************************************!*\
  !*** ./src/app/notification/components/notification-list-item/notification-list-item.component.ts ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationListItemComponent": () => (/* binding */ NotificationListItemComponent)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _notification_list_item_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./notification-list-item.component.html?ngResource */ 52097);
/* harmony import */ var _notification_list_item_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./notification-list-item.component.scss?ngResource */ 74295);
/* harmony import */ var _notification_list_item_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_notification_list_item_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51197);

var _class;




let NotificationListItemComponent = (_class = class NotificationListItemComponent {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "notification", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "img", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "title", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "topTexts", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "subText", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "viewNotification", new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter());
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => []), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  notification: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input
  }],
  img: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input
  }],
  title: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input
  }],
  topTexts: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input
  }],
  subText: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input
  }],
  viewNotification: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output
  }]
}), _class);
NotificationListItemComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
  selector: 'app-notification-list-item',
  template: _notification_list_item_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_notification_list_item_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], NotificationListItemComponent);


/***/ }),

/***/ 64552:
/*!******************************************************************************************!*\
  !*** ./src/app/notification/components/notification-menu/notification-menu.component.ts ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationMenuComponent": () => (/* binding */ NotificationMenuComponent)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _notification_menu_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./notification-menu.component.html?ngResource */ 49685);
/* harmony import */ var _notification_menu_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./notification-menu.component.scss?ngResource */ 31237);
/* harmony import */ var _notification_menu_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_notification_menu_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51197);

var _class;




let NotificationMenuComponent = (_class = class NotificationMenuComponent {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "notificationId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "markAsRead", new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "viewNotification", new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "goInvitation", new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "deleteNotification", new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter());
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => []), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  notificationId: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input
  }],
  markAsRead: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output
  }],
  viewNotification: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output
  }],
  goInvitation: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output
  }],
  deleteNotification: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output
  }]
}), _class);
NotificationMenuComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
  selector: 'app-notification-menu',
  template: _notification_menu_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_notification_menu_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], NotificationMenuComponent);


/***/ }),

/***/ 83459:
/*!*************************************************************!*\
  !*** ./src/app/notification/notification-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationRoutingModule": () => (/* binding */ NotificationRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _pages_notifications_notifications_business__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pages/notifications/notifications.business */ 14761);
/* harmony import */ var _pages_notification_notification_business__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pages/notification/notification.business */ 75871);





const routes = [{
  path: '',
  component: _pages_notifications_notifications_business__WEBPACK_IMPORTED_MODULE_0__.NotificationsBusiness
}, {
  path: 'notification/:id',
  component: _pages_notification_notification_business__WEBPACK_IMPORTED_MODULE_1__.NotificationBusiness
}];
let NotificationRoutingModule = class NotificationRoutingModule {};
NotificationRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
  imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)],
  exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
})], NotificationRoutingModule);


/***/ }),

/***/ 84858:
/*!*****************************************************!*\
  !*** ./src/app/notification/notification.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationModule": () => (/* binding */ NotificationModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 89650);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _notification_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./notification-routing.module */ 83459);
/* harmony import */ var _pages_notifications_notifications_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pages/notifications/notifications.page */ 44062);
/* harmony import */ var _pages_notifications_notifications_business__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pages/notifications/notifications.business */ 14761);
/* harmony import */ var _components_notification_menu_notification_menu_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/notification-menu/notification-menu.component */ 64552);
/* harmony import */ var _components_notification_list_item_notification_list_item_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/notification-list-item/notification-list-item.component */ 98739);
/* harmony import */ var _components_notification_list_item_skeleton_notification_list_item_skeleton_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/notification-list-item-skeleton/notification-list-item-skeleton.component */ 29081);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../shared/shared.module */ 56208);
/* harmony import */ var _pages_notification_notification_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./pages/notification/notification.page */ 8656);
/* harmony import */ var _pages_notification_notification_business__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./pages/notification/notification.business */ 75871);














let NotificationModule = class NotificationModule {};
NotificationModule = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.NgModule)({
  declarations: [_pages_notifications_notifications_page__WEBPACK_IMPORTED_MODULE_1__.NotificationsPage, _components_notification_menu_notification_menu_component__WEBPACK_IMPORTED_MODULE_3__.NotificationMenuComponent, _pages_notifications_notifications_business__WEBPACK_IMPORTED_MODULE_2__.NotificationsBusiness, _components_notification_list_item_notification_list_item_component__WEBPACK_IMPORTED_MODULE_4__.NotificationListItemComponent, _pages_notification_notification_page__WEBPACK_IMPORTED_MODULE_7__.NotificationPage, _pages_notification_notification_business__WEBPACK_IMPORTED_MODULE_8__.NotificationBusiness, _components_notification_list_item_skeleton_notification_list_item_skeleton_component__WEBPACK_IMPORTED_MODULE_5__.NotificationListItemSkeletonComponent],
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_11__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_13__.IonicModule, _notification_routing_module__WEBPACK_IMPORTED_MODULE_0__.NotificationRoutingModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_6__.SharedModule],
  exports: [_pages_notifications_notifications_page__WEBPACK_IMPORTED_MODULE_1__.NotificationsPage, _components_notification_menu_notification_menu_component__WEBPACK_IMPORTED_MODULE_3__.NotificationMenuComponent, _components_notification_list_item_notification_list_item_component__WEBPACK_IMPORTED_MODULE_4__.NotificationListItemComponent, _pages_notification_notification_page__WEBPACK_IMPORTED_MODULE_7__.NotificationPage]
})], NotificationModule);


/***/ }),

/***/ 75871:
/*!**************************************************************************!*\
  !*** ./src/app/notification/pages/notification/notification.business.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationBusiness": () => (/* binding */ NotificationBusiness)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 89650);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../src/app/shared/services/user.service */ 31880);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var src_app_shared_models_NotificationType__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/models/NotificationType */ 26755);


var _class;








let NotificationBusiness = (_class = class NotificationBusiness {
  constructor(userService, location, route, translate, router, navController) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "location", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "route", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "router", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "notificationId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "notification", void 0);
    this.userService = userService;
    this.location = location;
    this.route = route;
    this.translate = translate;
    this.router = router;
    this.navController = navController;
  }
  ngOnInit() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this.route.snapshot.params.id != null) {
        _this.notificationId = _this.route.snapshot.params.id;
        _this.userService.getNotificationById(_this.notificationId).subscribe(res => {
          if (res.error === null) {
            _this.notification = res.data;
            if (_this.notification?.read === false) {
              _this.markAsRead();
            }
          } else {
            _this.navController.navigateRoot('error');
          }
        });
      }
    })();
  }
  goToInvitation() {
    if (this.notification?.type.includes(src_app_shared_models_NotificationType__WEBPACK_IMPORTED_MODULE_3__.NotificationType.confirmAssist) || this.notification?.type.includes(src_app_shared_models_NotificationType__WEBPACK_IMPORTED_MODULE_3__.NotificationType.cancelAssist)) this.navController.navigateForward('invite/invitation/' + this.notification?.invitationId);else this.navController.navigateForward('access/access-info/' + this.notification?.accessId);
  }
  markAsRead() {
    this.userService.notificationMarkAsRead(this.notificationId).subscribe(res => {
      if (res.error === null) {
        console.log('Notification marked as read');
      } else {
        this.navController.navigateRoot('error');
      }
    });
  }
  backClick() {
    this.navController.navigateBack('notifications');
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: _src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_2__.UserService
}, {
  type: _angular_common__WEBPACK_IMPORTED_MODULE_4__.Location
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute
}, {
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController
}]), _class);
NotificationBusiness = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-component',
  template: `<app-notification
    [notification]="notification"
    (goInvitation)="goToInvitation()"
    (back)="backClick()"></app-notification>`
})], NotificationBusiness);


/***/ }),

/***/ 8656:
/*!**********************************************************************!*\
  !*** ./src/app/notification/pages/notification/notification.page.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationPage": () => (/* binding */ NotificationPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _notification_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./notification.page.html?ngResource */ 31966);
/* harmony import */ var _notification_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./notification.page.scss?ngResource */ 44049);
/* harmony import */ var _notification_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_notification_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../shared/components/footer/footer.component */ 68014);
/* harmony import */ var _shared_models_NotificationType__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../shared/models/NotificationType */ 26755);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var ngx_timeago__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-timeago */ 14899);
/* harmony import */ var ngx_timeago_language_strings_es__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-timeago/language-strings/es */ 34358);
/* harmony import */ var ngx_timeago_language_strings_en__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-timeago/language-strings/en */ 96871);

var _class;










let NotificationPage = (_class = class NotificationPage {
  constructor(translate, intl) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "notification", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "back", new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "goInvitation", new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "footerOptions", _shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__.FooterSelectedOption);
    this.translate = translate;
    switch (this.translate.currentLang) {
      case 'es':
        intl.strings = ngx_timeago_language_strings_es__WEBPACK_IMPORTED_MODULE_6__.strings;
        break;
      case 'en':
        intl.strings = ngx_timeago_language_strings_en__WEBPACK_IMPORTED_MODULE_7__.strings;
        break;
    }
    intl.changes.next();
  }
  get isInvitation() {
    return this.notification?.type.includes(_shared_models_NotificationType__WEBPACK_IMPORTED_MODULE_4__.NotificationType.invitation);
  }
  get isArrival() {
    return this.notification?.type.includes(_shared_models_NotificationType__WEBPACK_IMPORTED_MODULE_4__.NotificationType.arrival);
  }
  get isConfirmAssist() {
    return this.notification?.type.includes(_shared_models_NotificationType__WEBPACK_IMPORTED_MODULE_4__.NotificationType.confirmAssist);
  }
  get isCancelAssist() {
    return this.notification?.type.includes(_shared_models_NotificationType__WEBPACK_IMPORTED_MODULE_4__.NotificationType.cancelAssist);
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateService
}, {
  type: ngx_timeago__WEBPACK_IMPORTED_MODULE_9__.TimeagoIntl
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  notification: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input
  }],
  back: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output
  }],
  goInvitation: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output
  }]
}), _class);
NotificationPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
  selector: 'app-notification',
  template: _notification_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_notification_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], NotificationPage);


/***/ }),

/***/ 14761:
/*!****************************************************************************!*\
  !*** ./src/app/notification/pages/notifications/notifications.business.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationsBusiness": () => (/* binding */ NotificationsBusiness)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/services/user.service */ 31880);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../shared/services/notification.service */ 73477);


var _class;





let NotificationsBusiness = (_class = class NotificationsBusiness {
  constructor(userService, navController, notificationService) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "notificationService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "notifications", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "notificationsFiltered", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "all", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "subscription", void 0);
    this.userService = userService;
    this.navController = navController;
    this.notificationService = notificationService;
  }
  ngOnInit() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.subscription = _this.notificationService.notifications.subscribe(n => {
        _this.notifications = n;
        if (_this.all) _this.viewAll();else _this.viewUnread();
      });
    })();
  }
  ngOnDestroy() {
    this.subscription?.unsubscribe();
  }
  backClick() {
    this.navController.back();
  }
  viewAll() {
    this.notificationsFiltered = this.notifications;
    this.all = true;
  }
  viewUnread() {
    const unreadList = [];
    if (this.notifications) this.notifications.forEach(n => {
      if (n.read === false) unreadList.push(n);
    });
    this.notificationsFiltered = unreadList;
    this.all = false;
  }
  viewNotification(n) {
    this.navController.navigateForward('notifications/notification/' + n.id);
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_2__.UserService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController
}, {
  type: _shared_services_notification_service__WEBPACK_IMPORTED_MODULE_3__.NotificationService
}]), _class);
NotificationsBusiness = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
  selector: 'app-access-info-component',
  template: `<app-notifications
    [notifications]="notificationsFiltered"
    (back)="backClick()"
    (viewNotification)="viewNotification($event)"
    (viewAllClick)="viewAll()"
    (viewUnreadClick)="viewUnread()"></app-notifications>`
})], NotificationsBusiness);


/***/ }),

/***/ 44062:
/*!************************************************************************!*\
  !*** ./src/app/notification/pages/notifications/notifications.page.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationsPage": () => (/* binding */ NotificationsPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _notifications_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./notifications.page.html?ngResource */ 5955);
/* harmony import */ var _notifications_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./notifications.page.scss?ngResource */ 67263);
/* harmony import */ var _notifications_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_notifications_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var ngx_timeago__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-timeago */ 14899);
/* harmony import */ var src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/footer/footer.component */ 68014);
/* harmony import */ var src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/models/Enums */ 6452);
/* harmony import */ var ngx_timeago_language_strings_es__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-timeago/language-strings/es */ 34358);
/* harmony import */ var ngx_timeago_language_strings_en__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-timeago/language-strings/en */ 96871);

var _class;










let NotificationsPage = (_class = class NotificationsPage {
  // constructor(private translate: TranslateService, private business: Business) {}
  constructor(translate, intl, cdRef) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "cdRef", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "notifications", []);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "back", new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "viewAllClick", new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "viewUnreadClick", new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "viewNotification", new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "option", 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "footerOptions", src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__.FooterSelectedOption);
    this.translate = translate;
    this.cdRef = cdRef;
    switch (this.translate.currentLang) {
      case 'es':
        intl.strings = ngx_timeago_language_strings_es__WEBPACK_IMPORTED_MODULE_6__.strings;
        break;
      case 'en':
        intl.strings = ngx_timeago_language_strings_en__WEBPACK_IMPORTED_MODULE_7__.strings;
        break;
    }
    intl.changes.next();
  }
  viewUnread() {
    this.option = 0;
    this.viewUnreadClick.emit();
    this.cdRef.detectChanges();
  }
  viewAll() {
    this.option = 1;
    this.viewAllClick.emit();
    this.cdRef.detectChanges();
  }
  getInvitedTopText(n) {
    switch (n.type) {
      case src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_4__.NotificationType.invitation:
        return [n.fromUserName + this.translate.instant('notification.invitedBy')];
      case src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_4__.NotificationType.arrival:
        return [n.fromUserName + this.translate.instant('notification.arrival')];
      case src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_4__.NotificationType.assistConfirm:
        return [n.fromUserName + this.translate.instant('notification.assistConfirm')];
      case src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_4__.NotificationType.assistCancel:
        return [n.fromUserName + this.translate.instant('notification.assistCancel')];
    }
  }
  capitalizeFirstLetter(text) {
    if (text) return text.charAt(0).toUpperCase() + text.slice(1);
    return '';
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateService
}, {
  type: ngx_timeago__WEBPACK_IMPORTED_MODULE_9__.TimeagoIntl
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.ChangeDetectorRef
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  notifications: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input
  }],
  back: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output
  }],
  viewAllClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output
  }],
  viewUnreadClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output
  }],
  viewNotification: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output
  }]
}), _class);
NotificationsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
  selector: 'app-notifications',
  template: _notifications_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_notifications_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], NotificationsPage);


/***/ }),

/***/ 26755:
/*!***************************************************!*\
  !*** ./src/app/shared/models/NotificationType.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationType": () => (/* binding */ NotificationType)
/* harmony export */ });
var NotificationType;
(function (NotificationType) {
  NotificationType["invitation"] = "Invitation";
  NotificationType["arrival"] = "Arrival";
  NotificationType["confirmAssist"] = "AssistConfirm";
  NotificationType["cancelAssist"] = "AssistCancel";
})(NotificationType || (NotificationType = {}));

/***/ }),

/***/ 29098:
/*!***********************************************************************************************************************************!*\
  !*** ./src/app/notification/components/notification-list-item-skeleton/notification-list-item-skeleton.component.scss?ngResource ***!
  \***********************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".notification-read {\n  color: #6c6c6c !important;\n  opacity: 70% !important;\n}\n\n.item-container {\n  max-height: 6rem;\n  min-height: 5rem;\n}\n\n.img-container {\n  width: 20vw;\n}", "",{"version":3,"sources":["webpack://./src/app/notification/components/notification-list-item-skeleton/notification-list-item-skeleton.component.scss"],"names":[],"mappings":"AAAA;EACE,yBAAA;EACA,uBAAA;AACF;;AAEA;EACE,gBAAA;EACA,gBAAA;AACF;;AAEA;EACE,WAAA;AACF","sourcesContent":[".notification-read {\n  color: #6c6c6c !important;\n  opacity: 70% !important;\n}\n\n.item-container {\n  max-height: 6rem;\n  min-height: 5rem;\n}\n\n.img-container {\n  width: 20vw;\n}\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 74295:
/*!*****************************************************************************************************************!*\
  !*** ./src/app/notification/components/notification-list-item/notification-list-item.component.scss?ngResource ***!
  \*****************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".item-container {\n  max-height: 6rem;\n  min-height: 5rem;\n  flex-direction: row;\n  align-items: stretch;\n}\n\n.img-container {\n  width: 20vw;\n}", "",{"version":3,"sources":["webpack://./src/app/notification/components/notification-list-item/notification-list-item.component.scss"],"names":[],"mappings":"AAAA;EACE,gBAAA;EACA,gBAAA;EACA,mBAAA;EACA,oBAAA;AACF;;AAEA;EACE,WAAA;AACF","sourcesContent":[".item-container {\n  max-height: 6rem;\n  min-height: 5rem;\n  flex-direction: row;\n  align-items: stretch;\n}\n\n.img-container {\n  width: 20vw;\n}\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 31237:
/*!*******************************************************************************************************!*\
  !*** ./src/app/notification/components/notification-menu/notification-menu.component.scss?ngResource ***!
  \*******************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".dropdown-menu {\n  box-shadow: 0px 4px 24px rgba(0, 0, 0, 0.08);\n  border: none !important;\n}", "",{"version":3,"sources":["webpack://./src/app/notification/components/notification-menu/notification-menu.component.scss"],"names":[],"mappings":"AAAA;EACE,4CAAA;EACA,uBAAA;AACF","sourcesContent":[".dropdown-menu {\n  box-shadow: 0px 4px 24px rgba(0, 0, 0, 0.08);\n  border: none !important;\n}\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 44049:
/*!***********************************************************************************!*\
  !*** ./src/app/notification/pages/notification/notification.page.scss?ngResource ***!
  \***********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 67263:
/*!*************************************************************************************!*\
  !*** ./src/app/notification/pages/notifications/notifications.page.scss?ngResource ***!
  \*************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".card-style {\n  overflow: visible !important;\n}", "",{"version":3,"sources":["webpack://./src/app/notification/pages/notifications/notifications.page.scss"],"names":[],"mappings":"AAAA;EACE,4BAAA;AACF","sourcesContent":[".card-style {\n  overflow: visible !important;\n}\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 71008:
/*!***********************************************************************************************************************************!*\
  !*** ./src/app/notification/components/notification-list-item-skeleton/notification-list-item-skeleton.component.html?ngResource ***!
  \***********************************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<a>\n  <div class=\"item-container d-flex pb-3\">\n    <div class=\"me-3 img-container\">\n      <ngx-skeleton-loader\n        [theme]=\"{\n          'border-radius': '10px',\n          border: '1px solid white',\n          height: '-webkit-fill-available',\n          'margin-bottom': '0px'\n        }\"></ngx-skeleton-loader>\n    </div>\n    <div class=\"flex-fill\">\n      <ngx-skeleton-loader\n        class=\"d-flex\"\n        [theme]=\"{\n          height: '0.8rem',\n          width: '40%',\n          border: '1px solid white',\n          'margin-bottom': '0px'\n        }\"></ngx-skeleton-loader>\n      <ngx-skeleton-loader\n        class=\"d-flex\"\n        [theme]=\"{\n          height: '1.375rem',\n          width: '75%',\n          border: '1px solid white',\n          'margin-top': '5px'\n        }\"></ngx-skeleton-loader>\n      <ngx-skeleton-loader\n        class=\"d-flex\"\n        [theme]=\"{\n          height: '1rem',\n          width: '45%',\n          border: '1px solid white'\n        }\"></ngx-skeleton-loader>\n    </div>\n    <div class=\"ms-auto align-self-center px-2\">\n      <ngx-skeleton-loader\n        [theme]=\"{\n          height: '12px',\n          width: '12px',\n          border: '1px solid white',\n          'margin-bottom': '0px'\n        }\"></ngx-skeleton-loader>\n    </div>\n  </div>\n</a>\n";

/***/ }),

/***/ 52097:
/*!*****************************************************************************************************************!*\
  !*** ./src/app/notification/components/notification-list-item/notification-list-item.component.html?ngResource ***!
  \*****************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<a>\n  <div (click)=\"viewNotification.emit(notification)\" class=\"item-container d-flex pb-3\">\n    <div class=\"me-3 img-container\">\n      <app-img [img]=\"img\" [imgClass]=\"'rounded-sm ' + (notification.read ? 'notification-read' : '')\"></app-img>\n    </div>\n    <div class=\"flex-fill\">\n      <span\n        [class.notification-read]=\"notification.read\"\n        *ngFor=\"let topText of topTexts\"\n        class=\"color-highlight font-300 d-block text-uppercase font-10 lh-sm\"\n        >{{ topText }}</span\n      >\n      <strong class=\"color-theme font-16 d-block lh-sm pb-1\" [class.notification-read]=\"notification.read\">{{\n        title\n      }}</strong>\n      <div>\n        <span class=\"font-11 mb-n1 color-theme lh-sm\" [class.notification-read]=\"notification.read\">\n          {{ subText }}</span\n        >\n      </div>\n    </div>\n    <div class=\"ms-auto align-self-center px-2\">\n      <fa-icon role=\"button\" [icon]=\"['fas', 'chevron-right']\" class=\"font-12\"></fa-icon>\n    </div>\n  </div>\n</a>\n";

/***/ }),

/***/ 49685:
/*!*******************************************************************************************************!*\
  !*** ./src/app/notification/components/notification-menu/notification-menu.component.html?ngResource ***!
  \*******************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"dropdown\">\n  <fa-icon\n    role=\"button\"\n    [icon]=\"['fas', 'ellipsis']\"\n    type=\"button\"\n    data-bs-toggle=\"dropdown\"\n    aria-expanded=\"false\"\n    class=\"font-16 color-theme\"></fa-icon>\n\n  <ul class=\"dropdown-menu rounded-m\">\n    <li>\n      <a (click)=\"markAsRead.emit()\" role=\"button\" class=\"dropdown-item\">\n        <fa-icon [icon]=\"['fas', 'check-double']\" class=\"font-16 color-highlight\"></fa-icon>\n        <span class=\"ps-3 font-13\">{{ 'notification.markAsRead' | translate }}</span></a\n      >\n    </li>\n    <div class=\"divider mt-2 mb-2\"></div>\n    <li>\n      <a (click)=\"viewNotification.emit()\" role=\"button\" class=\"dropdown-item\">\n        <fa-icon [icon]=\"['fas', 'envelope']\" class=\"font-16 color-highlight\"></fa-icon>\n        <span class=\"ps-3 font-13\">{{ 'notification.viewNotification' | translate }}</span></a\n      >\n    </li>\n    <div class=\"divider mt-2 mb-2\"></div>\n    <li>\n      <a (click)=\"goInvitation.emit()\" role=\"button\" class=\"dropdown-item\">\n        <fa-icon [icon]=\"['fas', 'arrow-right']\" class=\"font-16 color-highlight\"></fa-icon>\n        <span class=\"ps-3 font-13\">{{ 'notification.goInvitation' | translate }}</span></a\n      >\n    </li>\n    <div class=\"divider mt-2 mb-2\"></div>\n    <li>\n      <a (click)=\"deleteNotification.emit()\" role=\"button\" class=\"dropdown-item\">\n        <fa-icon [icon]=\"['fas', 'trash-can']\" class=\"font-16 color-highlight\"></fa-icon>\n        <span class=\"ps-3 font-13\">{{ 'notification.deleteNotification' | translate }}</span></a\n      >\n    </li>\n  </ul>\n</div>\n";

/***/ }),

/***/ 31966:
/*!***********************************************************************************!*\
  !*** ./src/app/notification/pages/notification/notification.page.html?ngResource ***!
  \***********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-page-layout [footerSelectedOption]=\"\" (back)=\"back.emit()\" [title]=\"'common.notificationsTitle' | translate\">\n  <div class=\"card card-style\">\n    <div class=\"content\">\n      <div *ngIf=\"isInvitation\">\n        <span class=\"font-11 mb-n1 color-gray lh-sm\">\n          {{notification?.fromUserName}} {{ 'notification.invited' | translate }} {{ notification?.createDate |\n          timeago}}</span\n        >\n      </div>\n      <div *ngIf=\"isArrival\">\n        <span class=\"font-11 mb-n1 color-gray lh-sm\">\n          {{notification?.fromUserName}} {{ 'notification.arrived' | translate }} {{ notification?.createDate |\n          timeago}}</span\n        >\n      </div>\n      <div *ngIf=\"isConfirmAssist\">\n        <span class=\"font-11 mb-n1 color-gray lh-sm\">\n          {{notification?.fromUserName}} {{ 'notification.confirm' | translate }} {{ notification?.createDate |\n          timeago}}</span\n        >\n      </div>\n      <div *ngIf=\"isCancelAssist\">\n        <span class=\"font-11 mb-n1 color-gray lh-sm\">\n          {{notification?.fromUserName}} {{ 'notification.cancel' | translate }} {{ notification?.createDate |\n          timeago}}</span\n        >\n      </div>\n      <div>\n        <strong class=\"color-theme font-16 d-block lh-sm pb-1\">{{ notification?.motive }}</strong>\n      </div>\n      <div class=\"ms-auto d-flex align-self-center\">\n        <fa-icon [icon]=\"['far', 'calendar']\" class=\"py-2 px-3 font-18 color-highlight\"></fa-icon>\n        <div class=\"d-grid font-400 color-theme\">\n          <span class=\"font-9 mb-n2\">Fecha</span>\n          <span class=\"font-13\">{{ notification?.eventDate | date:'fullDate'}}</span>\n        </div>\n      </div>\n      <div class=\"ms-auto d-flex align-self-center\">\n        <fa-icon [icon]=\"['far', 'clock']\" class=\"py-2 px-3 font-18 color-highlight\"></fa-icon>\n        <div class=\"d-grid font-400 color-theme\">\n          <span class=\"font-9 mb-n2\">Hora</span>\n          <span class=\"font-13\">{{ notification?.eventDate | date:'shortTime' : 'UTC' }}</span>\n        </div>\n      </div>\n      <br />\n      <app-button [label]=\"'notification.goInvitation' | translate\" (buttonClick)=\"goInvitation.emit()\"></app-button>\n    </div>\n  </div>\n</app-page-layout>\n";

/***/ }),

/***/ 5955:
/*!*************************************************************************************!*\
  !*** ./src/app/notification/pages/notifications/notifications.page.html?ngResource ***!
  \*************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-page-layout [footerSelectedOption]=\"\" (back)=\"back.emit()\" [title]=\"'common.notificationsTitle' | translate\">\n  <div class=\"card card-style\">\n    <div class=\"content\">\n      <div class=\"tab-controls tabs-small tabs-rounded pb-4\">\n        <a role=\"button\" (click)=\"viewUnread()\" [class.no-click]=\"option === 0\" [class.bg-highlight]=\"option === 0\"\n          >{{'notification.unread' | translate}}</a\n        >\n        <a role=\"button\" (click)=\"viewAll()\" [class.no-click]=\"option === 1\" [class.bg-highlight]=\"option === 1\"\n          >{{'notification.all' | translate}}</a\n        >\n      </div>\n\n      <ng-container *ngIf=\"notifications\">\n        <app-notification-list-item\n          *ngFor=\"let n of notifications\"\n          [notification]=\"n\"\n          [title]=\"n.motive\"\n          [img]=\"n.presentationImg[0].url\"\n          [topTexts]=\"getInvitedTopText(n)\"\n          [subText]=\"capitalizeFirstLetter(n.createDate | timeago)\"\n          (viewNotification)=\"viewNotification.emit($event)\"></app-notification-list-item>\n      </ng-container>\n      <ng-container *ngIf=\"!notifications\">\n        <app-notification-list-item-skeleton *ngFor=\"let item of [1,2]\"></app-notification-list-item-skeleton>\n      </ng-container>\n      <ng-container *ngIf=\"notifications?.length === 0\">\n        <p class=\"text-center\">{{'notification.emptyNotificationMsg' | translate}}</p>\n      </ng-container>\n    </div>\n  </div>\n</app-page-layout>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_notification_notification_module_ts.js.map