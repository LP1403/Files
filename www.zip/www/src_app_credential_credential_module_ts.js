(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_credential_credential_module_ts"],{

/***/ 96884:
/*!*************************************************************************************!*\
  !*** ./node_modules/@capacitor-community/screen-brightness/dist/esm/definitions.js ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);


/***/ }),

/***/ 44929:
/*!*******************************************************************************!*\
  !*** ./node_modules/@capacitor-community/screen-brightness/dist/esm/index.js ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ScreenBrightness": () => (/* binding */ ScreenBrightness)
/* harmony export */ });
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 39734);
/* harmony import */ var _definitions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./definitions */ 96884);

const ScreenBrightness = (0,_capacitor_core__WEBPACK_IMPORTED_MODULE_0__.registerPlugin)('ScreenBrightness', {});



/***/ }),

/***/ 98566:
/*!****************************************!*\
  !*** ./node_modules/jssha/dist/sha.js ***!
  \****************************************/
/***/ (function(module) {

/**
 * A JavaScript implementation of the SHA family of hashes - defined in FIPS PUB 180-4, FIPS PUB 202,
 * and SP 800-185 - as well as the corresponding HMAC implementation as defined in FIPS PUB 198-1.
 *
 * Copyright 2008-2023 Brian Turek, 1998-2009 Paul Johnston & Contributors
 * Distributed under the BSD License
 * See http://caligatio.github.com/jsSHA/ for more information
 *
 * Two ECMAScript polyfill functions carry the following license:
 *
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING WITHOUT LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
 * MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing permissions and limitations under the License.
 */
!function (n, r) {
   true ? module.exports = r() : 0;
}(this, function () {
  "use strict";

  var n = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
    r = "ARRAYBUFFER not supported by this environment",
    t = "UINT8ARRAY not supported by this environment";
  function e(n, r, t, e) {
    var i,
      o,
      u,
      f = r || [0],
      s = (t = t || 0) >>> 3,
      w = -1 === e ? 3 : 0;
    for (i = 0; i < n.length; i += 1) o = (u = i + s) >>> 2, f.length <= o && f.push(0), f[o] |= n[i] << 8 * (w + e * (u % 4));
    return {
      value: f,
      binLen: 8 * n.length + t
    };
  }
  function i(i, o, u) {
    switch (o) {
      case "UTF8":
      case "UTF16BE":
      case "UTF16LE":
        break;
      default:
        throw new Error("encoding must be UTF8, UTF16BE, or UTF16LE");
    }
    switch (i) {
      case "HEX":
        return function (n, r, t) {
          return function (n, r, t, e) {
            var i, o, u, f;
            if (0 != n.length % 2) throw new Error("String of HEX type must be in byte increments");
            var s = r || [0],
              w = (t = t || 0) >>> 3,
              a = -1 === e ? 3 : 0;
            for (i = 0; i < n.length; i += 2) {
              if (o = parseInt(n.substr(i, 2), 16), isNaN(o)) throw new Error("String of HEX type contains invalid characters");
              for (u = (f = (i >>> 1) + w) >>> 2; s.length <= u;) s.push(0);
              s[u] |= o << 8 * (a + e * (f % 4));
            }
            return {
              value: s,
              binLen: 4 * n.length + t
            };
          }(n, r, t, u);
        };
      case "TEXT":
        return function (n, r, t) {
          return function (n, r, t, e, i) {
            var o,
              u,
              f,
              s,
              w,
              a,
              h,
              c,
              v = 0,
              A = t || [0],
              E = (e = e || 0) >>> 3;
            if ("UTF8" === r) for (h = -1 === i ? 3 : 0, f = 0; f < n.length; f += 1) for (u = [], 128 > (o = n.charCodeAt(f)) ? u.push(o) : 2048 > o ? (u.push(192 | o >>> 6), u.push(128 | 63 & o)) : 55296 > o || 57344 <= o ? u.push(224 | o >>> 12, 128 | o >>> 6 & 63, 128 | 63 & o) : (f += 1, o = 65536 + ((1023 & o) << 10 | 1023 & n.charCodeAt(f)), u.push(240 | o >>> 18, 128 | o >>> 12 & 63, 128 | o >>> 6 & 63, 128 | 63 & o)), s = 0; s < u.length; s += 1) {
              for (w = (a = v + E) >>> 2; A.length <= w;) A.push(0);
              A[w] |= u[s] << 8 * (h + i * (a % 4)), v += 1;
            } else for (h = -1 === i ? 2 : 0, c = "UTF16LE" === r && 1 !== i || "UTF16LE" !== r && 1 === i, f = 0; f < n.length; f += 1) {
              for (o = n.charCodeAt(f), !0 === c && (o = (s = 255 & o) << 8 | o >>> 8), w = (a = v + E) >>> 2; A.length <= w;) A.push(0);
              A[w] |= o << 8 * (h + i * (a % 4)), v += 2;
            }
            return {
              value: A,
              binLen: 8 * v + e
            };
          }(n, o, r, t, u);
        };
      case "B64":
        return function (r, t, e) {
          return function (r, t, e, i) {
            var o,
              u,
              f,
              s,
              w,
              a,
              h = 0,
              c = t || [0],
              v = (e = e || 0) >>> 3,
              A = -1 === i ? 3 : 0,
              E = r.indexOf("=");
            if (-1 === r.search(/^[a-zA-Z0-9=+/]+$/)) throw new Error("Invalid character in base-64 string");
            if (r = r.replace(/=/g, ""), -1 !== E && E < r.length) throw new Error("Invalid '=' found in base-64 string");
            for (o = 0; o < r.length; o += 4) {
              for (s = r.substr(o, 4), f = 0, u = 0; u < s.length; u += 1) f |= n.indexOf(s.charAt(u)) << 18 - 6 * u;
              for (u = 0; u < s.length - 1; u += 1) {
                for (w = (a = h + v) >>> 2; c.length <= w;) c.push(0);
                c[w] |= (f >>> 16 - 8 * u & 255) << 8 * (A + i * (a % 4)), h += 1;
              }
            }
            return {
              value: c,
              binLen: 8 * h + e
            };
          }(r, t, e, u);
        };
      case "BYTES":
        return function (n, r, t) {
          return function (n, r, t, e) {
            var i,
              o,
              u,
              f,
              s = r || [0],
              w = (t = t || 0) >>> 3,
              a = -1 === e ? 3 : 0;
            for (o = 0; o < n.length; o += 1) i = n.charCodeAt(o), u = (f = o + w) >>> 2, s.length <= u && s.push(0), s[u] |= i << 8 * (a + e * (f % 4));
            return {
              value: s,
              binLen: 8 * n.length + t
            };
          }(n, r, t, u);
        };
      case "ARRAYBUFFER":
        try {
          new ArrayBuffer(0);
        } catch (n) {
          throw new Error(r);
        }
        return function (n, r, t) {
          return function (n, r, t, i) {
            return e(new Uint8Array(n), r, t, i);
          }(n, r, t, u);
        };
      case "UINT8ARRAY":
        try {
          new Uint8Array(0);
        } catch (n) {
          throw new Error(t);
        }
        return function (n, r, t) {
          return e(n, r, t, u);
        };
      default:
        throw new Error("format must be HEX, TEXT, B64, BYTES, ARRAYBUFFER, or UINT8ARRAY");
    }
  }
  function o(e, i, o, u) {
    switch (e) {
      case "HEX":
        return function (n) {
          return function (n, r, t, e) {
            var i,
              o,
              u = "0123456789abcdef",
              f = "",
              s = r / 8,
              w = -1 === t ? 3 : 0;
            for (i = 0; i < s; i += 1) o = n[i >>> 2] >>> 8 * (w + t * (i % 4)), f += u.charAt(o >>> 4 & 15) + u.charAt(15 & o);
            return e.outputUpper ? f.toUpperCase() : f;
          }(n, i, o, u);
        };
      case "B64":
        return function (r) {
          return function (r, t, e, i) {
            var o,
              u,
              f,
              s,
              w,
              a = "",
              h = t / 8,
              c = -1 === e ? 3 : 0;
            for (o = 0; o < h; o += 3) for (s = o + 1 < h ? r[o + 1 >>> 2] : 0, w = o + 2 < h ? r[o + 2 >>> 2] : 0, f = (r[o >>> 2] >>> 8 * (c + e * (o % 4)) & 255) << 16 | (s >>> 8 * (c + e * ((o + 1) % 4)) & 255) << 8 | w >>> 8 * (c + e * ((o + 2) % 4)) & 255, u = 0; u < 4; u += 1) a += 8 * o + 6 * u <= t ? n.charAt(f >>> 6 * (3 - u) & 63) : i.b64Pad;
            return a;
          }(r, i, o, u);
        };
      case "BYTES":
        return function (n) {
          return function (n, r, t) {
            var e,
              i,
              o = "",
              u = r / 8,
              f = -1 === t ? 3 : 0;
            for (e = 0; e < u; e += 1) i = n[e >>> 2] >>> 8 * (f + t * (e % 4)) & 255, o += String.fromCharCode(i);
            return o;
          }(n, i, o);
        };
      case "ARRAYBUFFER":
        try {
          new ArrayBuffer(0);
        } catch (n) {
          throw new Error(r);
        }
        return function (n) {
          return function (n, r, t) {
            var e,
              i = r / 8,
              o = new ArrayBuffer(i),
              u = new Uint8Array(o),
              f = -1 === t ? 3 : 0;
            for (e = 0; e < i; e += 1) u[e] = n[e >>> 2] >>> 8 * (f + t * (e % 4)) & 255;
            return o;
          }(n, i, o);
        };
      case "UINT8ARRAY":
        try {
          new Uint8Array(0);
        } catch (n) {
          throw new Error(t);
        }
        return function (n) {
          return function (n, r, t) {
            var e,
              i = r / 8,
              o = -1 === t ? 3 : 0,
              u = new Uint8Array(i);
            for (e = 0; e < i; e += 1) u[e] = n[e >>> 2] >>> 8 * (o + t * (e % 4)) & 255;
            return u;
          }(n, i, o);
        };
      default:
        throw new Error("format must be HEX, B64, BYTES, ARRAYBUFFER, or UINT8ARRAY");
    }
  }
  var u = 4294967296,
    f = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298],
    s = [3238371032, 914150663, 812702999, 4144912697, 4290775857, 1750603025, 1694076839, 3204075428],
    w = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225],
    a = "Chosen SHA variant is not supported",
    h = "Cannot set numRounds with MAC";
  function c(n, r) {
    var t,
      e,
      i = n.binLen >>> 3,
      o = r.binLen >>> 3,
      u = i << 3,
      f = 4 - i << 3;
    if (i % 4 != 0) {
      for (t = 0; t < o; t += 4) e = i + t >>> 2, n.value[e] |= r.value[t >>> 2] << u, n.value.push(0), n.value[e + 1] |= r.value[t >>> 2] >>> f;
      return (n.value.length << 2) - 4 >= o + i && n.value.pop(), {
        value: n.value,
        binLen: n.binLen + r.binLen
      };
    }
    return {
      value: n.value.concat(r.value),
      binLen: n.binLen + r.binLen
    };
  }
  function v(n) {
    var r = {
        outputUpper: !1,
        b64Pad: "=",
        outputLen: -1
      },
      t = n || {},
      e = "Output length must be a multiple of 8";
    if (r.outputUpper = t.outputUpper || !1, t.b64Pad && (r.b64Pad = t.b64Pad), t.outputLen) {
      if (t.outputLen % 8 != 0) throw new Error(e);
      r.outputLen = t.outputLen;
    } else if (t.shakeLen) {
      if (t.shakeLen % 8 != 0) throw new Error(e);
      r.outputLen = t.shakeLen;
    }
    if ("boolean" != typeof r.outputUpper) throw new Error("Invalid outputUpper formatting option");
    if ("string" != typeof r.b64Pad) throw new Error("Invalid b64Pad formatting option");
    return r;
  }
  function A(n, r, t, e) {
    var o = n + " must include a value and format";
    if (!r) {
      if (!e) throw new Error(o);
      return e;
    }
    if (void 0 === r.value || !r.format) throw new Error(o);
    return i(r.format, r.encoding || "UTF8", t)(r.value);
  }
  var E = function () {
      function n(n, r, t) {
        var e = t || {};
        if (this.t = r, this.i = e.encoding || "UTF8", this.numRounds = e.numRounds || 1, isNaN(this.numRounds) || this.numRounds !== parseInt(this.numRounds, 10) || 1 > this.numRounds) throw new Error("numRounds must a integer >= 1");
        this.o = n, this.u = [], this.h = 0, this.v = !1, this.A = 0, this.l = !1, this.S = [], this.H = [];
      }
      return n.prototype.update = function (n) {
        var r,
          t = 0,
          e = this.p >>> 5,
          i = this.m(n, this.u, this.h),
          o = i.binLen,
          u = i.value,
          f = o >>> 5;
        for (r = 0; r < f; r += e) t + this.p <= o && (this.U = this.R(u.slice(r, r + e), this.U), t += this.p);
        return this.A += t, this.u = u.slice(t >>> 5), this.h = o % this.p, this.v = !0, this;
      }, n.prototype.getHash = function (n, r) {
        var t,
          e,
          i = this.T,
          u = v(r);
        if (this.C) {
          if (-1 === u.outputLen) throw new Error("Output length must be specified in options");
          i = u.outputLen;
        }
        var f = o(n, i, this.F, u);
        if (this.l && this.K) return f(this.K(u));
        for (e = this.g(this.u.slice(), this.h, this.A, this.L(this.U), i), t = 1; t < this.numRounds; t += 1) this.C && i % 32 != 0 && (e[e.length - 1] &= 16777215 >>> 24 - i % 32), e = this.g(e, i, 0, this.B(this.o), i);
        return f(e);
      }, n.prototype.setHMACKey = function (n, r, t) {
        if (!this.k) throw new Error("Variant does not support HMAC");
        if (this.v) throw new Error("Cannot set MAC key after calling update");
        var e = i(r, (t || {}).encoding || "UTF8", this.F);
        this.Y(e(n));
      }, n.prototype.Y = function (n) {
        var r,
          t = this.p >>> 3,
          e = t / 4 - 1;
        if (1 !== this.numRounds) throw new Error(h);
        if (this.l) throw new Error("MAC key already set");
        for (t < n.binLen / 8 && (n.value = this.g(n.value, n.binLen, 0, this.B(this.o), this.T)); n.value.length <= e;) n.value.push(0);
        for (r = 0; r <= e; r += 1) this.S[r] = 909522486 ^ n.value[r], this.H[r] = 1549556828 ^ n.value[r];
        this.U = this.R(this.S, this.U), this.A = this.p, this.l = !0;
      }, n.prototype.getHMAC = function (n, r) {
        var t = v(r);
        return o(n, this.T, this.F, t)(this.N());
      }, n.prototype.N = function () {
        var n;
        if (!this.l) throw new Error("Cannot call getHMAC without first setting MAC key");
        var r = this.g(this.u.slice(), this.h, this.A, this.L(this.U), this.T);
        return n = this.R(this.H, this.B(this.o)), n = this.g(r, this.T, this.p, n, this.T);
      }, n;
    }(),
    l = function (n, r) {
      return l = Object.setPrototypeOf || {
        __proto__: []
      } instanceof Array && function (n, r) {
        n.__proto__ = r;
      } || function (n, r) {
        for (var t in r) Object.prototype.hasOwnProperty.call(r, t) && (n[t] = r[t]);
      }, l(n, r);
    };
  function b(n, r) {
    if ("function" != typeof r && null !== r) throw new TypeError("Class extends value " + String(r) + " is not a constructor or null");
    function t() {
      this.constructor = n;
    }
    l(n, r), n.prototype = null === r ? Object.create(r) : (t.prototype = r.prototype, new t());
  }
  function S(n, r) {
    return n << r | n >>> 32 - r;
  }
  function H(n, r) {
    return n >>> r | n << 32 - r;
  }
  function d(n, r) {
    return n >>> r;
  }
  function p(n, r, t) {
    return n ^ r ^ t;
  }
  function y(n, r, t) {
    return n & r ^ ~n & t;
  }
  function m(n, r, t) {
    return n & r ^ n & t ^ r & t;
  }
  function U(n) {
    return H(n, 2) ^ H(n, 13) ^ H(n, 22);
  }
  function R(n, r) {
    var t = (65535 & n) + (65535 & r);
    return (65535 & (n >>> 16) + (r >>> 16) + (t >>> 16)) << 16 | 65535 & t;
  }
  function T(n, r, t, e) {
    var i = (65535 & n) + (65535 & r) + (65535 & t) + (65535 & e);
    return (65535 & (n >>> 16) + (r >>> 16) + (t >>> 16) + (e >>> 16) + (i >>> 16)) << 16 | 65535 & i;
  }
  function C(n, r, t, e, i) {
    var o = (65535 & n) + (65535 & r) + (65535 & t) + (65535 & e) + (65535 & i);
    return (65535 & (n >>> 16) + (r >>> 16) + (t >>> 16) + (e >>> 16) + (i >>> 16) + (o >>> 16)) << 16 | 65535 & o;
  }
  function F(n) {
    return H(n, 7) ^ H(n, 18) ^ d(n, 3);
  }
  function K(n) {
    return H(n, 6) ^ H(n, 11) ^ H(n, 25);
  }
  function g(n) {
    return [1732584193, 4023233417, 2562383102, 271733878, 3285377520];
  }
  function L(n, r) {
    var t,
      e,
      i,
      o,
      u,
      f,
      s,
      w = [];
    for (t = r[0], e = r[1], i = r[2], o = r[3], u = r[4], s = 0; s < 80; s += 1) w[s] = s < 16 ? n[s] : S(w[s - 3] ^ w[s - 8] ^ w[s - 14] ^ w[s - 16], 1), f = s < 20 ? C(S(t, 5), y(e, i, o), u, 1518500249, w[s]) : s < 40 ? C(S(t, 5), p(e, i, o), u, 1859775393, w[s]) : s < 60 ? C(S(t, 5), m(e, i, o), u, 2400959708, w[s]) : C(S(t, 5), p(e, i, o), u, 3395469782, w[s]), u = o, o = i, i = S(e, 30), e = t, t = f;
    return r[0] = R(t, r[0]), r[1] = R(e, r[1]), r[2] = R(i, r[2]), r[3] = R(o, r[3]), r[4] = R(u, r[4]), r;
  }
  function B(n, r, t, e) {
    for (var i, o = 15 + (r + 65 >>> 9 << 4), f = r + t; n.length <= o;) n.push(0);
    for (n[r >>> 5] |= 128 << 24 - r % 32, n[o] = 4294967295 & f, n[o - 1] = f / u | 0, i = 0; i < n.length; i += 16) e = L(n.slice(i, i + 16), e);
    return e;
  }
  "function" == typeof SuppressedError && SuppressedError;
  var k = function (n) {
    function r(r, t, e) {
      var o = this;
      if ("SHA-1" !== r) throw new Error(a);
      var u = e || {};
      return (o = n.call(this, r, t, e) || this).k = !0, o.K = o.N, o.F = -1, o.m = i(o.t, o.i, o.F), o.R = L, o.L = function (n) {
        return n.slice();
      }, o.B = g, o.g = B, o.U = [1732584193, 4023233417, 2562383102, 271733878, 3285377520], o.p = 512, o.T = 160, o.C = !1, u.hmacKey && o.Y(A("hmacKey", u.hmacKey, o.F)), o;
    }
    return b(r, n), r;
  }(E);
  function Y(n) {
    return "SHA-224" == n ? s.slice() : w.slice();
  }
  function N(n, r) {
    var t,
      e,
      i,
      o,
      u,
      s,
      w,
      a,
      h,
      c,
      v,
      A,
      E = [];
    for (t = r[0], e = r[1], i = r[2], o = r[3], u = r[4], s = r[5], w = r[6], a = r[7], v = 0; v < 64; v += 1) E[v] = v < 16 ? n[v] : T(H(A = E[v - 2], 17) ^ H(A, 19) ^ d(A, 10), E[v - 7], F(E[v - 15]), E[v - 16]), h = C(a, K(u), y(u, s, w), f[v], E[v]), c = R(U(t), m(t, e, i)), a = w, w = s, s = u, u = R(o, h), o = i, i = e, e = t, t = R(h, c);
    return r[0] = R(t, r[0]), r[1] = R(e, r[1]), r[2] = R(i, r[2]), r[3] = R(o, r[3]), r[4] = R(u, r[4]), r[5] = R(s, r[5]), r[6] = R(w, r[6]), r[7] = R(a, r[7]), r;
  }
  var I = function (n) {
      function r(r, t, e) {
        var o = this;
        if ("SHA-224" !== r && "SHA-256" !== r) throw new Error(a);
        var f = e || {};
        return (o = n.call(this, r, t, e) || this).K = o.N, o.k = !0, o.F = -1, o.m = i(o.t, o.i, o.F), o.R = N, o.L = function (n) {
          return n.slice();
        }, o.B = Y, o.g = function (n, t, e, i) {
          return function (n, r, t, e, i) {
            for (var o, f = 15 + (r + 65 >>> 9 << 4), s = r + t; n.length <= f;) n.push(0);
            for (n[r >>> 5] |= 128 << 24 - r % 32, n[f] = 4294967295 & s, n[f - 1] = s / u | 0, o = 0; o < n.length; o += 16) e = N(n.slice(o, o + 16), e);
            return "SHA-224" === i ? [e[0], e[1], e[2], e[3], e[4], e[5], e[6]] : e;
          }(n, t, e, i, r);
        }, o.U = Y(r), o.p = 512, o.T = "SHA-224" === r ? 224 : 256, o.C = !1, f.hmacKey && o.Y(A("hmacKey", f.hmacKey, o.F)), o;
      }
      return b(r, n), r;
    }(E),
    M = function (n, r) {
      this.I = n, this.M = r;
    };
  function X(n, r) {
    var t;
    return r > 32 ? (t = 64 - r, new M(n.M << r | n.I >>> t, n.I << r | n.M >>> t)) : 0 !== r ? (t = 32 - r, new M(n.I << r | n.M >>> t, n.M << r | n.I >>> t)) : n;
  }
  function z(n, r) {
    var t;
    return r < 32 ? (t = 32 - r, new M(n.I >>> r | n.M << t, n.M >>> r | n.I << t)) : (t = 64 - r, new M(n.M >>> r | n.I << t, n.I >>> r | n.M << t));
  }
  function O(n, r) {
    return new M(n.I >>> r, n.M >>> r | n.I << 32 - r);
  }
  function j(n, r, t) {
    return new M(n.I & r.I ^ ~n.I & t.I, n.M & r.M ^ ~n.M & t.M);
  }
  function _(n, r, t) {
    return new M(n.I & r.I ^ n.I & t.I ^ r.I & t.I, n.M & r.M ^ n.M & t.M ^ r.M & t.M);
  }
  function x(n) {
    var r = z(n, 28),
      t = z(n, 34),
      e = z(n, 39);
    return new M(r.I ^ t.I ^ e.I, r.M ^ t.M ^ e.M);
  }
  function P(n, r) {
    var t, e;
    t = (65535 & n.M) + (65535 & r.M);
    var i = (65535 & (e = (n.M >>> 16) + (r.M >>> 16) + (t >>> 16))) << 16 | 65535 & t;
    return t = (65535 & n.I) + (65535 & r.I) + (e >>> 16), e = (n.I >>> 16) + (r.I >>> 16) + (t >>> 16), new M((65535 & e) << 16 | 65535 & t, i);
  }
  function V(n, r, t, e) {
    var i, o;
    i = (65535 & n.M) + (65535 & r.M) + (65535 & t.M) + (65535 & e.M);
    var u = (65535 & (o = (n.M >>> 16) + (r.M >>> 16) + (t.M >>> 16) + (e.M >>> 16) + (i >>> 16))) << 16 | 65535 & i;
    return i = (65535 & n.I) + (65535 & r.I) + (65535 & t.I) + (65535 & e.I) + (o >>> 16), o = (n.I >>> 16) + (r.I >>> 16) + (t.I >>> 16) + (e.I >>> 16) + (i >>> 16), new M((65535 & o) << 16 | 65535 & i, u);
  }
  function Z(n, r, t, e, i) {
    var o, u;
    o = (65535 & n.M) + (65535 & r.M) + (65535 & t.M) + (65535 & e.M) + (65535 & i.M);
    var f = (65535 & (u = (n.M >>> 16) + (r.M >>> 16) + (t.M >>> 16) + (e.M >>> 16) + (i.M >>> 16) + (o >>> 16))) << 16 | 65535 & o;
    return o = (65535 & n.I) + (65535 & r.I) + (65535 & t.I) + (65535 & e.I) + (65535 & i.I) + (u >>> 16), u = (n.I >>> 16) + (r.I >>> 16) + (t.I >>> 16) + (e.I >>> 16) + (i.I >>> 16) + (o >>> 16), new M((65535 & u) << 16 | 65535 & o, f);
  }
  function q(n, r) {
    return new M(n.I ^ r.I, n.M ^ r.M);
  }
  function D(n) {
    var r = z(n, 1),
      t = z(n, 8),
      e = O(n, 7);
    return new M(r.I ^ t.I ^ e.I, r.M ^ t.M ^ e.M);
  }
  function G(n) {
    var r = z(n, 14),
      t = z(n, 18),
      e = z(n, 41);
    return new M(r.I ^ t.I ^ e.I, r.M ^ t.M ^ e.M);
  }
  var J = [new M(f[0], 3609767458), new M(f[1], 602891725), new M(f[2], 3964484399), new M(f[3], 2173295548), new M(f[4], 4081628472), new M(f[5], 3053834265), new M(f[6], 2937671579), new M(f[7], 3664609560), new M(f[8], 2734883394), new M(f[9], 1164996542), new M(f[10], 1323610764), new M(f[11], 3590304994), new M(f[12], 4068182383), new M(f[13], 991336113), new M(f[14], 633803317), new M(f[15], 3479774868), new M(f[16], 2666613458), new M(f[17], 944711139), new M(f[18], 2341262773), new M(f[19], 2007800933), new M(f[20], 1495990901), new M(f[21], 1856431235), new M(f[22], 3175218132), new M(f[23], 2198950837), new M(f[24], 3999719339), new M(f[25], 766784016), new M(f[26], 2566594879), new M(f[27], 3203337956), new M(f[28], 1034457026), new M(f[29], 2466948901), new M(f[30], 3758326383), new M(f[31], 168717936), new M(f[32], 1188179964), new M(f[33], 1546045734), new M(f[34], 1522805485), new M(f[35], 2643833823), new M(f[36], 2343527390), new M(f[37], 1014477480), new M(f[38], 1206759142), new M(f[39], 344077627), new M(f[40], 1290863460), new M(f[41], 3158454273), new M(f[42], 3505952657), new M(f[43], 106217008), new M(f[44], 3606008344), new M(f[45], 1432725776), new M(f[46], 1467031594), new M(f[47], 851169720), new M(f[48], 3100823752), new M(f[49], 1363258195), new M(f[50], 3750685593), new M(f[51], 3785050280), new M(f[52], 3318307427), new M(f[53], 3812723403), new M(f[54], 2003034995), new M(f[55], 3602036899), new M(f[56], 1575990012), new M(f[57], 1125592928), new M(f[58], 2716904306), new M(f[59], 442776044), new M(f[60], 593698344), new M(f[61], 3733110249), new M(f[62], 2999351573), new M(f[63], 3815920427), new M(3391569614, 3928383900), new M(3515267271, 566280711), new M(3940187606, 3454069534), new M(4118630271, 4000239992), new M(116418474, 1914138554), new M(174292421, 2731055270), new M(289380356, 3203993006), new M(460393269, 320620315), new M(685471733, 587496836), new M(852142971, 1086792851), new M(1017036298, 365543100), new M(1126000580, 2618297676), new M(1288033470, 3409855158), new M(1501505948, 4234509866), new M(1607167915, 987167468), new M(1816402316, 1246189591)];
  function Q(n) {
    return "SHA-384" === n ? [new M(3418070365, s[0]), new M(1654270250, s[1]), new M(2438529370, s[2]), new M(355462360, s[3]), new M(1731405415, s[4]), new M(41048885895, s[5]), new M(3675008525, s[6]), new M(1203062813, s[7])] : [new M(w[0], 4089235720), new M(w[1], 2227873595), new M(w[2], 4271175723), new M(w[3], 1595750129), new M(w[4], 2917565137), new M(w[5], 725511199), new M(w[6], 4215389547), new M(w[7], 327033209)];
  }
  function W(n, r) {
    var t,
      e,
      i,
      o,
      u,
      f,
      s,
      w,
      a,
      h,
      c,
      v,
      A,
      E,
      l,
      b,
      S = [];
    for (t = r[0], e = r[1], i = r[2], o = r[3], u = r[4], f = r[5], s = r[6], w = r[7], c = 0; c < 80; c += 1) c < 16 ? (v = 2 * c, S[c] = new M(n[v], n[v + 1])) : S[c] = V((A = S[c - 2], E = void 0, l = void 0, b = void 0, E = z(A, 19), l = z(A, 61), b = O(A, 6), new M(E.I ^ l.I ^ b.I, E.M ^ l.M ^ b.M)), S[c - 7], D(S[c - 15]), S[c - 16]), a = Z(w, G(u), j(u, f, s), J[c], S[c]), h = P(x(t), _(t, e, i)), w = s, s = f, f = u, u = P(o, a), o = i, i = e, e = t, t = P(a, h);
    return r[0] = P(t, r[0]), r[1] = P(e, r[1]), r[2] = P(i, r[2]), r[3] = P(o, r[3]), r[4] = P(u, r[4]), r[5] = P(f, r[5]), r[6] = P(s, r[6]), r[7] = P(w, r[7]), r;
  }
  var $ = function (n) {
      function r(r, t, e) {
        var o = this;
        if ("SHA-384" !== r && "SHA-512" !== r) throw new Error(a);
        var f = e || {};
        return (o = n.call(this, r, t, e) || this).K = o.N, o.k = !0, o.F = -1, o.m = i(o.t, o.i, o.F), o.R = W, o.L = function (n) {
          return n.slice();
        }, o.B = Q, o.g = function (n, t, e, i) {
          return function (n, r, t, e, i) {
            for (var o, f = 31 + (r + 129 >>> 10 << 5), s = r + t; n.length <= f;) n.push(0);
            for (n[r >>> 5] |= 128 << 24 - r % 32, n[f] = 4294967295 & s, n[f - 1] = s / u | 0, o = 0; o < n.length; o += 32) e = W(n.slice(o, o + 32), e);
            return "SHA-384" === i ? [e[0].I, e[0].M, e[1].I, e[1].M, e[2].I, e[2].M, e[3].I, e[3].M, e[4].I, e[4].M, e[5].I, e[5].M] : [e[0].I, e[0].M, e[1].I, e[1].M, e[2].I, e[2].M, e[3].I, e[3].M, e[4].I, e[4].M, e[5].I, e[5].M, e[6].I, e[6].M, e[7].I, e[7].M];
          }(n, t, e, i, r);
        }, o.U = Q(r), o.p = 1024, o.T = "SHA-384" === r ? 384 : 512, o.C = !1, f.hmacKey && o.Y(A("hmacKey", f.hmacKey, o.F)), o;
      }
      return b(r, n), r;
    }(E),
    nn = [new M(0, 1), new M(0, 32898), new M(2147483648, 32906), new M(2147483648, 2147516416), new M(0, 32907), new M(0, 2147483649), new M(2147483648, 2147516545), new M(2147483648, 32777), new M(0, 138), new M(0, 136), new M(0, 2147516425), new M(0, 2147483658), new M(0, 2147516555), new M(2147483648, 139), new M(2147483648, 32905), new M(2147483648, 32771), new M(2147483648, 32770), new M(2147483648, 128), new M(0, 32778), new M(2147483648, 2147483658), new M(2147483648, 2147516545), new M(2147483648, 32896), new M(0, 2147483649), new M(2147483648, 2147516424)],
    rn = [[0, 36, 3, 41, 18], [1, 44, 10, 45, 2], [62, 6, 43, 15, 61], [28, 55, 25, 21, 56], [27, 20, 39, 8, 14]];
  function tn(n) {
    var r,
      t = [];
    for (r = 0; r < 5; r += 1) t[r] = [new M(0, 0), new M(0, 0), new M(0, 0), new M(0, 0), new M(0, 0)];
    return t;
  }
  function en(n) {
    var r,
      t = [];
    for (r = 0; r < 5; r += 1) t[r] = n[r].slice();
    return t;
  }
  function on(n, r) {
    var t,
      e,
      i,
      o,
      u,
      f,
      s,
      w,
      a,
      h = [],
      c = [];
    if (null !== n) for (e = 0; e < n.length; e += 2) r[(e >>> 1) % 5][(e >>> 1) / 5 | 0] = q(r[(e >>> 1) % 5][(e >>> 1) / 5 | 0], new M(n[e + 1], n[e]));
    for (t = 0; t < 24; t += 1) {
      for (o = tn(), e = 0; e < 5; e += 1) h[e] = (u = r[e][0], f = r[e][1], s = r[e][2], w = r[e][3], a = r[e][4], new M(u.I ^ f.I ^ s.I ^ w.I ^ a.I, u.M ^ f.M ^ s.M ^ w.M ^ a.M));
      for (e = 0; e < 5; e += 1) c[e] = q(h[(e + 4) % 5], X(h[(e + 1) % 5], 1));
      for (e = 0; e < 5; e += 1) for (i = 0; i < 5; i += 1) r[e][i] = q(r[e][i], c[e]);
      for (e = 0; e < 5; e += 1) for (i = 0; i < 5; i += 1) o[i][(2 * e + 3 * i) % 5] = X(r[e][i], rn[e][i]);
      for (e = 0; e < 5; e += 1) for (i = 0; i < 5; i += 1) r[e][i] = q(o[e][i], new M(~o[(e + 1) % 5][i].I & o[(e + 2) % 5][i].I, ~o[(e + 1) % 5][i].M & o[(e + 2) % 5][i].M));
      r[0][0] = q(r[0][0], nn[t]);
    }
    return r;
  }
  function un(n) {
    var r,
      t,
      e = 0,
      i = [0, 0],
      o = [4294967295 & n, n / u & 2097151];
    for (r = 6; r >= 0; r--) 0 === (t = o[r >> 2] >>> 8 * r & 255) && 0 === e || (i[e + 1 >> 2] |= t << 8 * (e + 1), e += 1);
    return e = 0 !== e ? e : 1, i[0] |= e, {
      value: e + 1 > 4 ? i : [i[0]],
      binLen: 8 + 8 * e
    };
  }
  function fn(n) {
    return c(un(n.binLen), n);
  }
  function sn(n, r) {
    var t,
      e = un(r),
      i = r >>> 2,
      o = (i - (e = c(e, n)).value.length % i) % i;
    for (t = 0; t < o; t++) e.value.push(0);
    return e.value;
  }
  var wn = function (n) {
    function r(r, t, e) {
      var o = this,
        u = 6,
        f = 0,
        s = e || {};
      if (1 !== (o = n.call(this, r, t, e) || this).numRounds) {
        if (s.kmacKey || s.hmacKey) throw new Error(h);
        if ("CSHAKE128" === o.o || "CSHAKE256" === o.o) throw new Error("Cannot set numRounds for CSHAKE variants");
      }
      switch (o.F = 1, o.m = i(o.t, o.i, o.F), o.R = on, o.L = en, o.B = tn, o.U = tn(), o.C = !1, r) {
        case "SHA3-224":
          o.p = f = 1152, o.T = 224, o.k = !0, o.K = o.N;
          break;
        case "SHA3-256":
          o.p = f = 1088, o.T = 256, o.k = !0, o.K = o.N;
          break;
        case "SHA3-384":
          o.p = f = 832, o.T = 384, o.k = !0, o.K = o.N;
          break;
        case "SHA3-512":
          o.p = f = 576, o.T = 512, o.k = !0, o.K = o.N;
          break;
        case "SHAKE128":
          u = 31, o.p = f = 1344, o.T = -1, o.C = !0, o.k = !1, o.K = null;
          break;
        case "SHAKE256":
          u = 31, o.p = f = 1088, o.T = -1, o.C = !0, o.k = !1, o.K = null;
          break;
        case "KMAC128":
          u = 4, o.p = f = 1344, o.X(e), o.T = -1, o.C = !0, o.k = !1, o.K = o.O;
          break;
        case "KMAC256":
          u = 4, o.p = f = 1088, o.X(e), o.T = -1, o.C = !0, o.k = !1, o.K = o.O;
          break;
        case "CSHAKE128":
          o.p = f = 1344, u = o.j(e), o.T = -1, o.C = !0, o.k = !1, o.K = null;
          break;
        case "CSHAKE256":
          o.p = f = 1088, u = o.j(e), o.T = -1, o.C = !0, o.k = !1, o.K = null;
          break;
        default:
          throw new Error(a);
      }
      return o.g = function (n, r, t, e, i) {
        return function (n, r, t, e, i, o, u) {
          var f,
            s,
            w = 0,
            a = [],
            h = i >>> 5,
            c = r >>> 5;
          for (f = 0; f < c && r >= i; f += h) e = on(n.slice(f, f + h), e), r -= i;
          for (n = n.slice(f), r %= i; n.length < h;) n.push(0);
          for (n[(f = r >>> 3) >> 2] ^= o << f % 4 * 8, n[h - 1] ^= 2147483648, e = on(n, e); 32 * a.length < u && (s = e[w % 5][w / 5 | 0], a.push(s.M), !(32 * a.length >= u));) a.push(s.I), 0 == 64 * (w += 1) % i && (on(null, e), w = 0);
          return a;
        }(n, r, 0, e, f, u, i);
      }, s.hmacKey && o.Y(A("hmacKey", s.hmacKey, o.F)), o;
    }
    return b(r, n), r.prototype.j = function (n, r) {
      var t = function (n) {
        var r = n || {};
        return {
          funcName: A("funcName", r.funcName, 1, {
            value: [],
            binLen: 0
          }),
          customization: A("Customization", r.customization, 1, {
            value: [],
            binLen: 0
          })
        };
      }(n || {});
      r && (t.funcName = r);
      var e = c(fn(t.funcName), fn(t.customization));
      if (0 !== t.customization.binLen || 0 !== t.funcName.binLen) {
        for (var i = sn(e, this.p >>> 3), o = 0; o < i.length; o += this.p >>> 5) this.U = this.R(i.slice(o, o + (this.p >>> 5)), this.U), this.A += this.p;
        return 4;
      }
      return 31;
    }, r.prototype.X = function (n) {
      var r = function (n) {
        var r = n || {};
        return {
          kmacKey: A("kmacKey", r.kmacKey, 1),
          funcName: {
            value: [1128353099],
            binLen: 32
          },
          customization: A("Customization", r.customization, 1, {
            value: [],
            binLen: 0
          })
        };
      }(n || {});
      this.j(n, r.funcName);
      for (var t = sn(fn(r.kmacKey), this.p >>> 3), e = 0; e < t.length; e += this.p >>> 5) this.U = this.R(t.slice(e, e + (this.p >>> 5)), this.U), this.A += this.p;
      this.l = !0;
    }, r.prototype.O = function (n) {
      var r = c({
        value: this.u.slice(),
        binLen: this.h
      }, function (n) {
        var r,
          t,
          e = 0,
          i = [0, 0],
          o = [4294967295 & n, n / u & 2097151];
        for (r = 6; r >= 0; r--) 0 == (t = o[r >> 2] >>> 8 * r & 255) && 0 === e || (i[e >> 2] |= t << 8 * e, e += 1);
        return i[(e = 0 !== e ? e : 1) >> 2] |= e << 8 * e, {
          value: e + 1 > 4 ? i : [i[0]],
          binLen: 8 + 8 * e
        };
      }(n.outputLen));
      return this.g(r.value, r.binLen, this.A, this.L(this.U), n.outputLen);
    }, r;
  }(E);
  return function () {
    function n(n, r, t) {
      if ("SHA-1" == n) this._ = new k(n, r, t);else if ("SHA-224" == n || "SHA-256" == n) this._ = new I(n, r, t);else if ("SHA-384" == n || "SHA-512" == n) this._ = new $(n, r, t);else {
        if ("SHA3-224" != n && "SHA3-256" != n && "SHA3-384" != n && "SHA3-512" != n && "SHAKE128" != n && "SHAKE256" != n && "CSHAKE128" != n && "CSHAKE256" != n && "KMAC128" != n && "KMAC256" != n) throw new Error(a);
        this._ = new wn(n, r, t);
      }
    }
    return n.prototype.update = function (n) {
      return this._.update(n), this;
    }, n.prototype.getHash = function (n, r) {
      return this._.getHash(n, r);
    }, n.prototype.setHMACKey = function (n, r, t) {
      this._.setHMACKey(n, r, t);
    }, n.prototype.getHMAC = function (n, r) {
      return this._.getHMAC(n, r);
    }, n;
  }();
});

/***/ }),

/***/ 28314:
/*!**********************************************!*\
  !*** ./node_modules/totp-generator/index.js ***!
  \**********************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


let JsSHA = __webpack_require__(/*! jssha */ 98566);
if (JsSHA.default) {
  // If the default property exist we are probably in webpack
  JsSHA = JsSHA.default;
}
module.exports = function getToken(key, options) {
  options = options || {};
  let epoch, time, shaObj, hmac, offset, otp;
  options.period = options.period || 30;
  options.algorithm = options.algorithm || "SHA-1";
  options.digits = options.digits || 6;
  options.timestamp = options.timestamp || Date.now();
  key = base32tohex(key);
  epoch = Math.floor(options.timestamp / 1000.0);
  time = leftpad(dec2hex(Math.floor(epoch / options.period)), 16, "0");
  shaObj = new JsSHA(options.algorithm, "HEX");
  shaObj.setHMACKey(key, "HEX");
  shaObj.update(time);
  hmac = shaObj.getHMAC("HEX");
  offset = hex2dec(hmac.substring(hmac.length - 1));
  otp = (hex2dec(hmac.substr(offset * 2, 8)) & hex2dec("7fffffff")) + "";
  otp = otp.substr(Math.max(otp.length - options.digits, 0), options.digits);
  return otp;
};
function hex2dec(s) {
  return parseInt(s, 16);
}
function dec2hex(s) {
  return (s < 15.5 ? "0" : "") + Math.round(s).toString(16);
}
function base32tohex(base32) {
  let base32chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567",
    bits = "",
    hex = "";
  base32 = base32.replace(/=+$/, "");
  for (let i = 0; i < base32.length; i++) {
    let val = base32chars.indexOf(base32.charAt(i).toUpperCase());
    if (val === -1) throw new Error("Invalid base32 character in key");
    bits += leftpad(val.toString(2), 5, "0");
  }
  for (let i = 0; i + 8 <= bits.length; i += 8) {
    let chunk = bits.substr(i, 8);
    hex = hex + leftpad(parseInt(chunk, 2).toString(16), 2, "0");
  }
  return hex;
}
function leftpad(str, len, pad) {
  if (len + 1 >= str.length) {
    str = Array(len + 1 - str.length).join(pad) + str;
  }
  return str;
}

/***/ }),

/***/ 95167:
/*!*********************************************************!*\
  !*** ./src/app/credential/credential-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CredentialPageRoutingModule": () => (/* binding */ CredentialPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _credential_business__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./credential.business */ 76);




const routes = [{
  path: '',
  component: _credential_business__WEBPACK_IMPORTED_MODULE_0__.CredentialBusiness
}];
let CredentialPageRoutingModule = class CredentialPageRoutingModule {};
CredentialPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
  imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
  exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
})], CredentialPageRoutingModule);


/***/ }),

/***/ 76:
/*!***************************************************!*\
  !*** ./src/app/credential/credential.business.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CredentialBusiness": () => (/* binding */ CredentialBusiness)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _shared_helpers_business__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../shared/helpers/business */ 92237);
/* harmony import */ var _shared_services_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../shared/services/user.service */ 31880);
/* harmony import */ var _capacitor_community_screen_brightness__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor-community/screen-brightness */ 44929);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 51547);


var _class;







let CredentialBusiness = (_class = class CredentialBusiness {
  constructor(userService, business, platform, cdRef, navController) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "business", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "platform", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "cdRef", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userProfile", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "totp", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "qrData", new _shared_helpers_business__WEBPACK_IMPORTED_MODULE_2__.QRData());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "callbackBright", undefined);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "originalBright", undefined);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "implementBright", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "getTokenInterval", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "appInitializing", true);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "serverTime", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "diffTime", 0);
    this.userService = userService;
    this.business = business;
    this.platform = platform;
    this.cdRef = cdRef;
    this.navController = navController;
  }
  ngOnInit() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.serverTime = new Date();
      if (_this.userService.isOnline) {
        const time = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.lastValueFrom)(_this.userService.getServerCurrentTime());
        if (time) {
          const now = new Date();
          _this.serverTime = time.data;
          _this.serverTime = new Date(_this.serverTime);
          _this.diffTime = now.getTime() - _this.serverTime.getTime();
        }
      }
      yield _this.platform.ready();
      _this.implementBright = _this.platform.is('capacitor');
      if (_this.implementBright) _this.originalBright = yield _capacitor_community_screen_brightness__WEBPACK_IMPORTED_MODULE_4__.ScreenBrightness.getBrightness();
    })();
  }
  ionViewWillEnter() {
    var _this2 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.userProfile = undefined;
      if (_this2.userService.isOnline) {
        const res = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.lastValueFrom)(_this2.userService.getUser());
        if (res.error === null) {
          _this2.userProfile = res.data;
        } else if (res.code === 0) {
          _this2.userProfile = _this2.userService.getLoginData();
        } else {
          _this2.navController.navigateRoot('error');
        }
      } else {
        _this2.userProfile = _this2.userService.getLoginData();
      }
      _this2.getToken();
      _this2.getTokenInterval = setInterval(() => {
        _this2.getToken();
      }, 10000);
      if (!_this2.userService.initializing) _this2.setBright(1);else _this2.userService.initializing = false;
    })();
  }
  ionViewWillLeave() {
    clearInterval(this.getTokenInterval);
  }
  ionViewDidEnter() {
    console.log('enter');
    this.cdRef.detectChanges();
  }
  ionViewDidLeave() {
    console.log('leaving');
    this.restoreBright();
  }
  getToken() {
    var _this3 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const totpGenerate = __webpack_require__(/*! totp-generator */ 28314);
      const now = new Date();
      if (_this3.serverTime === undefined) _this3.serverTime = new Date();
      const userData = _this3.userService.getLoginData();
      if (userData === undefined) return;
      const qrSeed = userData.qrSeed;
      const token = totpGenerate(qrSeed, {
        digits: 6,
        period: 10,
        timestamp: now.getTime() - _this3.diffTime
      });
      const userId = userData.userId;
      _this3.qrData.qr = `http://www.identifast.com/qr/${userId}/${token}`;
    })();
  }
  setBright(bright) {
    if (this.implementBright) {
      _capacitor_community_screen_brightness__WEBPACK_IMPORTED_MODULE_4__.ScreenBrightness.setBrightness({
        brightness: bright
      });
    }
  }
  restoreBright() {
    if (this.implementBright && this.originalBright !== undefined) _capacitor_community_screen_brightness__WEBPACK_IMPORTED_MODULE_4__.ScreenBrightness.setBrightness({
      brightness: this.originalBright.brightness
    });
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: _shared_services_user_service__WEBPACK_IMPORTED_MODULE_3__.UserService
}, {
  type: _shared_helpers_business__WEBPACK_IMPORTED_MODULE_2__["default"]
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.Platform
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ChangeDetectorRef
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController
}]), _class);
CredentialBusiness = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
  selector: 'app-credential-business',
  template: `<app-credential *ngIf="userProfile" [userProfile]="userProfile" [qrData]="qrData.qr"></app-credential>
    <div *ngIf="!userProfile" class="center">
      <div class="spinner-border color-blue-dark" role="status"></div>
    </div> `
})], CredentialBusiness);


/***/ }),

/***/ 2702:
/*!*************************************************!*\
  !*** ./src/app/credential/credential.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CredentialPageModule": () => (/* binding */ CredentialPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 89650);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _credential_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./credential-routing.module */ 95167);
/* harmony import */ var _credential_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./credential.page */ 6032);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../shared/shared.module */ 56208);
/* harmony import */ var _credential_business__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./credential.business */ 76);









let CredentialPageModule = class CredentialPageModule {};
CredentialPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule, _credential_routing_module__WEBPACK_IMPORTED_MODULE_0__.CredentialPageRoutingModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule],
  declarations: [_credential_page__WEBPACK_IMPORTED_MODULE_1__.CredentialPage, _credential_business__WEBPACK_IMPORTED_MODULE_3__.CredentialBusiness],
  exports: [_credential_page__WEBPACK_IMPORTED_MODULE_1__.CredentialPage]
})], CredentialPageModule);


/***/ }),

/***/ 6032:
/*!***********************************************!*\
  !*** ./src/app/credential/credential.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CredentialPage": () => (/* binding */ CredentialPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _credential_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./credential.page.html?ngResource */ 96996);
/* harmony import */ var _credential_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./credential.page.scss?ngResource */ 82939);
/* harmony import */ var _credential_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_credential_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../shared/components/footer/footer.component */ 68014);

var _class;





let CredentialPage = (_class = class CredentialPage {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "userProfile", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "qrData", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "qrClick", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "originalBright", 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "loading", true);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "footerOptions", _shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__.FooterSelectedOption);
  }
  get hasPicture() {
    return localStorage.getItem('userPicture') !== null && localStorage.getItem('userPicture') !== '';
  }
  get userPicture() {
    const imgCacheString = localStorage.getItem('userPicture');
    if (imgCacheString !== null && imgCacheString !== '') return imgCacheString;else if (this.userProfile.image?.url !== undefined) return this.userProfile.image?.url + '&thumb=true';else return null;
  }
  get userName() {
    return this.userProfile.name?.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]|[\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD10-\uDDFF]/gi, '');
  }
  hideLoader() {
    this.loading = false;
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => []), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  userProfile: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input
  }],
  qrData: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input
  }],
  qrClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }]
}), _class);
CredentialPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
  selector: 'app-credential',
  template: _credential_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_credential_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], CredentialPage);


/***/ }),

/***/ 82939:
/*!************************************************************!*\
  !*** ./src/app/credential/credential.page.scss?ngResource ***!
  \************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".custom-margin-vh {\n  margin-bottom: -2vh;\n  margin-top: -2vh;\n}\n\n.pos {\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, 50%);\n}", "",{"version":3,"sources":["webpack://./src/app/credential/credential.page.scss"],"names":[],"mappings":"AAAA;EACE,mBAAA;EACA,gBAAA;AACF;;AAEA;EACE,QAAA;EACA,SAAA;EACA,+BAAA;AACF","sourcesContent":[".custom-margin-vh {\n  margin-bottom: -2vh;\n  margin-top: -2vh;\n}\n\n.pos {\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, 50%);\n}\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 96996:
/*!************************************************************!*\
  !*** ./src/app/credential/credential.page.html?ngResource ***!
  \************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-page-layout [footerSelectedOption]=\"footerOptions.qr\" [hideBack]=\"true\" [title]=\"'credential.title'|translate\">\n  <!-- Margin bottom and padding-bottom to pull the card under the image-->\n  <!-- Top card must have over-card class to go over the card below it -->\n  <ng-container *ngIf=\"userPicture\">\n    <div *ngIf=\"loading\" class=\"pos over-card-img d-flex justify-content-center\" style=\"margin-top: -5vh\">\n      <ngx-skeleton-loader\n        [theme]=\"{\n        'border-radius': '50%',\n        width: '100px',\n        height: '100px',\n        border: '1px solid white',\n        'vertical-align': 'middle'\n      }\"></ngx-skeleton-loader>\n    </div>\n    <img\n      #image\n      (load)=\"hideLoader()\"\n      [src]=\"userPicture | secure: 'url' | async\"\n      class=\"avatar pos over-card-img\"\n      style=\"margin-top: -5vh\"\n      [ngStyle]=\"{ visibility: loading ? 'hidden' : '', position: loading ? 'absolute' : '' }\" />\n  </ng-container>\n  <ng-container *ngIf=\"!userPicture\">\n    <div style=\"margin-top: -5vh\">\n      <ngx-avatars\n        class=\"pos over-card-img d-flex justify-content-center\"\n        size=\"100\"\n        bgColor=\"#0078d7\"\n        [name]=\"userName\"\n        (load)=\"hideLoader()\"></ngx-avatars>\n    </div>\n  </ng-container>\n\n  <div class=\"card card-style\">\n    <div class=\"content mt-0 mb-1 text-center\">\n      <div class=\"col-12\">\n        <div style=\"height: 60px\"></div>\n        <h3 class=\"font-400 lh-sm position-relative z-100 mb-0\">{{userProfile?.name}}</h3>\n        <p class=\"font-400 lh-sm position-relative z-100 pb-2 mb-0\">{{'credential.subtitle'|translate}}</p>\n        <div *ngIf=\"qrData\">\n          <app-qr [data]=\"qrData\"></app-qr>\n        </div>\n        <div *ngIf=\"!qrData\">\n          <div class=\"qr-container\">\n            <ngx-skeleton-loader\n              [theme]=\"{\n              width: '300px',\n              height: '300px',\n              border: '1px solid white',\n              'vertical-align': 'middle'\n            }\"></ngx-skeleton-loader>\n            <ngx-skeleton-loader\n              [theme]=\"{\n                  width: '50px',\n                  height: '1rem',\n                  border: '1px solid white',\n                  'vertical-align': 'middle'\n                }\"></ngx-skeleton-loader>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n  <div class=\"content\">\n    <p class=\"line-height-s text-center\" [innerHTML]=\"'credential.qrAdvise'|translate\"></p>\n  </div>\n</app-page-layout>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_credential_credential_module_ts.js.map