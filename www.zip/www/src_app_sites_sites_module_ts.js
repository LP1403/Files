(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_sites_sites_module_ts"],{

/***/ 12784:
/*!*****************************************************************************************!*\
  !*** ./src/app/sites/components/access-point-address/access-point-address.component.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccessPointAddressComponent": () => (/* binding */ AccessPointAddressComponent),
/* harmony export */   "AccessPointAddressViewModel": () => (/* binding */ AccessPointAddressViewModel)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _access_point_address_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./access-point-address.component.html?ngResource */ 44000);
/* harmony import */ var _access_point_address_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./access-point-address.component.scss?ngResource */ 242);
/* harmony import */ var _access_point_address_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_access_point_address_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var _capacitor_keyboard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor/keyboard */ 60971);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 45667);
/* harmony import */ var src_app_shared_services_file_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/services/file.service */ 30038);

var _class;








let AccessPointAddressComponent = (_class = class AccessPointAddressComponent {
  constructor(fb, cdRef, fileService) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "fb", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "cdRef", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "fileService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "addresstext", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "mapEditClick", new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessPointForm", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "imgString", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "autocomplete", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "selectedPlace", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "selectedPlaceCoords", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "Number", Number);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "apa", void 0);
    this.fb = fb;
    this.cdRef = cdRef;
    this.fileService = fileService;
    this.autocomplete = {
      input: ''
    };
    this.selectedPlaceCoords = [];
  }
  get formValid() {
    return this.accessPointForm.valid;
  }
  get formDirty() {
    return this.accessPointForm.dirty;
  }
  get viewModel() {
    this.apa = new AccessPointAddressViewModel();
    this.apa.map = this.imgString;
    this.apa.address = this.selectedPlace?.formatted_address;
    this.apa.latitude = Number(this.selectedPlaceCoords[0]);
    this.apa.longitude = Number(this.selectedPlaceCoords[1]);
    return this.apa;
  }
  ngOnInit() {
    this.initForm();
  }
  ngAfterViewInit() {
    this.getPlaceAutocomplete();
  }
  setForm(apa) {
    if (!apa) return;
    this.accessPointForm.setValue(apa);
  }
  initForm() {
    this.accessPointForm = this.fb.group({
      address: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required]
    });
  }
  getPlaceAutocomplete() {
    const autocomplete = new google.maps.places.Autocomplete(this.addresstext?.nativeElement, {
      fields: ['formatted_address', 'name', 'geometry']
    });
    google.maps.event.addListener(autocomplete, 'place_changed', () => {
      const place = autocomplete.getPlace();
      if (place.geometry) this.placeSelected(place);
    });
  }
  placeSelected(place) {
    this.selectedPlace = place;
    this.accessPointForm.get('address')?.setValue(place.formatted_address);
    setTimeout(() => {
      this.addresstext?.nativeElement.focus();
      if ((0,_ionic_angular__WEBPACK_IMPORTED_MODULE_7__.isPlatform)('capacitor')) {
        _capacitor_keyboard__WEBPACK_IMPORTED_MODULE_3__.Keyboard.hide();
      }
    }, 50);
    const coords = place.geometry?.viewport.toUrlValue().split(',');
    if (coords && coords.length > 1) {
      const averageLat = (Number(coords[0]) + Number(coords[2])) / 2;
      const averageLong = (Number(coords[1]) + Number(coords[3])) / 2;
      this.selectedPlaceCoords = [averageLat.toString(), averageLong.toString()];
      this.imgString = `https://maps.googleapis.com/maps/api/staticmap?center=${this.selectedPlaceCoords[0]},${this.selectedPlaceCoords[1]}&zoom=16&size=300x300&scale=2&markers=color:red%7C${this.selectedPlaceCoords[0]},${this.selectedPlaceCoords[1]}&key=AIzaSyDrj-69Jfi_WZXZ_eLOREJcBJQXyQlwZPI`;
      this.cdRef.detectChanges();
    }
  }
  clear() {
    this.autocomplete.input = '';
    this.selectedPlace = undefined;
    this.imgString = '';
    this.accessPointForm.get('address')?.setValue(null);
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.ChangeDetectorRef
}, {
  type: src_app_shared_services_file_service__WEBPACK_IMPORTED_MODULE_4__.FileService
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  addresstext: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.ViewChild,
    args: ['addressText']
  }],
  mapEditClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output
  }]
}), _class);
AccessPointAddressComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
  selector: 'app-access-point-address',
  template: _access_point_address_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_access_point_address_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], AccessPointAddressComponent);

class AccessPointAddressViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "address", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "map", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "latitude", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "longitude", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "vm", void 0);
  }
}

/***/ }),

/***/ 3762:
/*!***********************************************************************************!*\
  !*** ./src/app/sites/components/access-point-data/access-point-data.component.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccessPointDataComponent": () => (/* binding */ AccessPointDataComponent),
/* harmony export */   "AccessPointDataViewModel": () => (/* binding */ AccessPointDataViewModel)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _access_point_data_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./access-point-data.component.html?ngResource */ 41394);
/* harmony import */ var _access_point_data_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./access-point-data.component.scss?ngResource */ 44088);
/* harmony import */ var _access_point_data_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_access_point_data_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 70997);

var _class;





let AccessPointDataComponent = (_class = class AccessPointDataComponent {
  constructor(fb) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "fb", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "saveForm", new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessPointForm", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "inputsNew", []);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "vm", void 0);
    this.fb = fb;
  }
  get formValid() {
    return this.accessPointForm.valid;
  }
  get formDirty() {
    return this.accessPointForm.dirty;
  }
  get viewModel() {
    this.vm = new AccessPointDataViewModel();
    Object.assign(this.vm, this.accessPointForm.getRawValue());
    this.inputsNew.map(x => {
      x.questionId = crypto.randomUUID();
    });
    this.vm.inputs = this.inputsNew;
    return this.vm;
  }
  ngOnInit() {
    this.initForm();
  }
  setForm(vm) {
    if (!vm) return;
    this.accessPointForm.setValue(vm);
    this.inputsNew = vm.inputs;
  }
  initForm() {
    this.accessPointForm = this.fb.group({
      noteAccess: ['']
    });
  }
  addNewInput(label) {
    const newInput = {
      label,
      value: '',
      questionId: ''
    };
    this.inputsNew.push(newInput);
  }
  editInput(input) {
    this.inputsNew.forEach(i => {
      if (i.questionId === input.questionId) {
        i.label = input.label;
      }
    });
  }
  deleteInput(input) {
    const index = this.inputsNew.findIndex(x => x.questionId === input.questionId);
    this.inputsNew.splice(index, 1);
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  saveForm: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output
  }]
}), _class);
AccessPointDataComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
  selector: 'app-access-point-data',
  template: _access_point_data_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_access_point_data_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], AccessPointDataComponent);

class AccessPointDataViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "noteAccess", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "inputs", void 0);
  }
}

/***/ }),

/***/ 8267:
/*!***********************************************************************************!*\
  !*** ./src/app/sites/components/access-point-date/access-point-date.component.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccessPointDateComponent": () => (/* binding */ AccessPointDateComponent),
/* harmony export */   "AccessPointDateViewModel": () => (/* binding */ AccessPointDateViewModel)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _access_point_date_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./access-point-date.component.html?ngResource */ 96794);
/* harmony import */ var _access_point_date_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./access-point-date.component.scss?ngResource */ 79300);
/* harmony import */ var _access_point_date_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_access_point_date_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var src_app_shared_components_day_select_form_day_select_form_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/day-select-form/day-select-form.component */ 84599);

var _class;






let AccessPointDateComponent = (_class = class AccessPointDateComponent {
  constructor(fb) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "fb", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "daySelect", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessPointForm", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "vm", void 0);
    this.fb = fb;
  }
  get formValid() {
    return this.accessPointForm.valid && this.daySelect?.formValid && this.timeValid;
  }
  get formDirty() {
    return this.accessPointForm.dirty || this.daySelect?.formDirty;
  }
  get viewModel() {
    this.vm = new AccessPointDateViewModel();
    if (this.daySelect) this.vm.daysVM = this.daySelect.viewModel;
    Object.assign(this.vm, this.accessPointForm.getRawValue());
    return this.vm;
  }
  get timeValid() {
    const allDay = this.accessPointForm.get('allDay')?.value;
    return allDay || this.accessPointForm.get('timeFrom').value !== '' && this.accessPointForm.get('timeTo').value !== '';
  }
  ngOnInit() {
    this.initForm();
  }
  setForm(vm) {
    if (!vm) return;
    this.accessPointForm.setValue(vm);
    this.daySelect?.setForm(vm.daysVM);
  }
  initForm() {
    this.accessPointForm = this.fb.group({
      allDay: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      timeFrom: [''],
      timeTo: ['']
    });
    this.accessPointForm.get('allDay')?.valueChanges.subscribe(value => {
      if (value === false) {
        this.accessPointForm.get('timeFrom')?.setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required);
        this.accessPointForm.get('timeFrom')?.updateValueAndValidity({
          emitEvent: false
        });
        this.accessPointForm.get('timeTo')?.setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required);
        this.accessPointForm.get('timeTo')?.updateValueAndValidity({
          emitEvent: false
        });
      } else {
        this.accessPointForm.get('timeFrom')?.clearValidators();
        this.accessPointForm.get('timeFrom')?.updateValueAndValidity({
          emitEvent: false
        });
        this.accessPointForm.get('timeTo')?.clearValidators();
        this.accessPointForm.get('timeTo')?.updateValueAndValidity({
          emitEvent: false
        });
      }
    });
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  daySelect: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.ViewChild,
    args: [src_app_shared_components_day_select_form_day_select_form_component__WEBPACK_IMPORTED_MODULE_3__.DaySelectFormComponent]
  }]
}), _class);
AccessPointDateComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
  selector: 'app-access-point-date-site',
  template: _access_point_date_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_access_point_date_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], AccessPointDateComponent);

class AccessPointDateViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "allDay", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "timeFrom", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "timeTo", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "daysVM", void 0);
  }
}

/***/ }),

/***/ 38593:
/*!*****************************************************************!*\
  !*** ./src/app/sites/components/new-site/new-site.component.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewSiteComponent": () => (/* binding */ NewSiteComponent),
/* harmony export */   "NewSiteViewModel": () => (/* binding */ NewSiteViewModel),
/* harmony export */   "UpdateSiteViewModel": () => (/* binding */ UpdateSiteViewModel)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _new_site_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./new-site.component.html?ngResource */ 8227);
/* harmony import */ var _new_site_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./new-site.component.scss?ngResource */ 92520);
/* harmony import */ var _new_site_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_new_site_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var src_app_shared_models_SelectListItem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/models/SelectListItem */ 75987);
/* harmony import */ var src_app_shared_models_NotDefaultValueValidator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/models/NotDefaultValueValidator */ 86317);

var _class;







let NewSiteComponent = (_class = class NewSiteComponent {
  constructor(fb) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "fb", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "categoryList", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "isEdit", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "siteForm", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "images", []);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "deleteImages", []);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "vm", void 0);
    this.fb = fb;
  }
  get formValid() {
    return this.siteForm.valid;
  }
  get formDirty() {
    return this.siteForm.dirty;
  }
  get viewModel() {
    this.vm = new NewSiteViewModel();
    //Object.assign(this.vm, this.siteForm.getRawValue());
    this.vm.name = this.siteForm.get('name')?.value;
    this.vm.category = new src_app_shared_models_SelectListItem__WEBPACK_IMPORTED_MODULE_3__.SelectListItem();
    this.vm.category.id = this.siteForm.get('category')?.value;
    this.vm.description = this.siteForm.get('description')?.value;
    this.vm.images = this.images.filter(x => x.file !== null && x.file !== undefined);
    this.vm.deleteImage = this.deleteImages;
    return this.vm;
  }
  ngOnInit() {
    this.initForm();
  }
  setForm(vm) {
    if (!vm) return;
    this.siteForm.get('name')?.setValue(vm.name);
    this.siteForm.get('category')?.setValue(vm.category?.id);
    this.siteForm.get('description')?.setValue(vm.description);
    if (vm.images) {
      this.images = vm.images.filter(x => x.id !== null && x.id !== undefined);
    }
  }
  initForm() {
    this.siteForm = this.fb.group({
      name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      category: ['0', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required, src_app_shared_models_NotDefaultValueValidator__WEBPACK_IMPORTED_MODULE_4__.notDefaultValueValidator]],
      description: [''],
      id: ['']
    });
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  categoryList: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Input
  }],
  isEdit: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Input
  }]
}), _class);
NewSiteComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
  selector: 'app-new-site',
  template: _new_site_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_new_site_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], NewSiteComponent);

class NewSiteViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "name", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "category", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "description", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "images", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "deleteImage", void 0);
  }
}
class UpdateSiteViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "id", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "name", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "description", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "categoryId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "externalIds", void 0);
  }
}

/***/ }),

/***/ 91233:
/*!*********************************************************************!*\
  !*** ./src/app/sites/components/sites-list/sites-list.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SitesListComponent": () => (/* binding */ SitesListComponent)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _sites_list_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sites-list.component.html?ngResource */ 54780);
/* harmony import */ var _sites_list_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./sites-list.component.scss?ngResource */ 50093);
/* harmony import */ var _sites_list_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_sites_list_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51197);

var _class;




let SitesListComponent = (_class = class SitesListComponent {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "sites", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "invClick", new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "siteClick", new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter());
  }
  getBadgeText(s) {
    if (s.roles.find(x => x === 'Administrator')) {
      return 'common.roles.admin';
    }
    return '';
  }
  getBagdeIcon(s) {
    if (s.roles.find(x => x === 'Administrator')) {
      return 'user-check';
    }
    return undefined;
  }
  sortByAdministratorRole(sites) {
    return sites.sort((a, b) => {
      const aIsAdmin = a.roles.includes('Administrator');
      const bIsAdmin = b.roles.includes('Administrator');
      if (aIsAdmin && !bIsAdmin) {
        return -1;
      } else if (!aIsAdmin && bIsAdmin) {
        return 1;
      } else {
        return 0;
      }
    });
  }
  getSitesSortedByAdministrator() {
    if (this.sites) {
      return this.sortByAdministratorRole(this.sites);
    }
    return undefined;
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => []), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  sites: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input
  }],
  invClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output
  }],
  siteClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output
  }]
}), _class);
SitesListComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
  selector: 'app-sites-list',
  template: _sites_list_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_sites_list_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], SitesListComponent);


/***/ }),

/***/ 47754:
/*!*********************************************************!*\
  !*** ./src/app/sites/pages/site-edit/site-edit.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SiteEditPage": () => (/* binding */ SiteEditPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _site_edit_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./site-edit.page.html?ngResource */ 42202);
/* harmony import */ var _site_edit_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./site-edit.page.scss?ngResource */ 17466);
/* harmony import */ var _site_edit_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_site_edit_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _components_new_site_new_site_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../components/new-site/new-site.component */ 38593);
/* harmony import */ var _components_access_point_date_access_point_date_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/access-point-date/access-point-date.component */ 8267);
/* harmony import */ var _components_access_point_address_access_point_address_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/access-point-address/access-point-address.component */ 12784);
/* harmony import */ var _components_access_point_data_access_point_data_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../components/access-point-data/access-point-data.component */ 3762);
/* harmony import */ var src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/components/footer/footer.component */ 68014);
/* harmony import */ var src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/components/button/button.component */ 62490);

var _class;










let SiteEditPage = (_class = class SiteEditPage {
  constructor(cdRef) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "cdRef", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "modalC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "confirmModalC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "newSiteC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "apDateC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "apAddress", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "apDataC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "categoryList", []);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "loading", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "backClick", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "saveClick", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "steps", [1, 2, 3, 4]);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "step", 1);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "footerOptions", src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_7__.FooterSelectedOption);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "confirmModalTextKey", 'common.confirmChanges');
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "isClosing", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "showKeyboard", false);
    this.cdRef = cdRef;
  }
  get stepValid() {
    switch (this.step) {
      case 1:
        return this.newSiteC?.formValid;
      case 2:
        return this.apAddress?.formValid;
      case 4:
        return this.apDateC?.formValid;
      case 3:
        return this.apDataC?.formValid;
    }
  }
  get buttonState() {
    if (!this.stepValid) {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_8__.ButtonState.disabled;
    } else if (!this.loading) {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_8__.ButtonState.enabled;
    } else {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_8__.ButtonState.loading;
    }
  }
  get hasChanges() {
    switch (this.step) {
      case 1:
        return this.newSiteC?.formDirty ?? false;
      case 2:
        return this.apAddress?.formDirty ?? false;
      case 4:
        return this.apDateC?.formDirty ?? false;
      case 3:
        return this.apDataC?.formDirty ?? false;
      default:
        return false;
    }
  }
  getState() {
    return this.buttonState;
  }
  fillStep(step, vm) {
    switch (step) {
      case 1:
        this.newSiteC?.setForm(vm.newSiteStep);
        break;
      case 2:
        this.apAddress?.setForm(vm.accessPointAddressStep);
        break;
      case 3:
        this.apDataC?.setForm(vm.accessPointControlStep);
        break;
      case 4:
        this.apDateC?.setForm(vm.accessPointDateStep);
        break;
    }
  }
  trySave() {
    if (this.hasChanges) {
      this.confirmModalTextKey = 'common.confirmChanges';
      this.confirmModalC?.show();
    } else {
      this.save();
    }
  }
  save() {
    let stepModel;
    switch (this.step) {
      case 1:
        stepModel = this.newSiteC?.viewModel;
        break;
      case 2:
        stepModel = this.apAddress?.viewModel;
        break;
      case 3:
        stepModel = this.apDataC?.viewModel;
        break;
      case 4:
        stepModel = this.apDateC?.viewModel;
        break;
    }
    this.loading = true;
    this.saveClick.emit(stepModel);
  }
  tryClose() {
    this.isClosing = true;
    if (this.hasChanges) {
      this.confirmModalTextKey = 'common.confirmCancel';
      this.confirmModalC?.show();
    } else {
      this.cancel();
    }
  }
  confirmAccept() {
    if (this.confirmModalTextKey === 'common.confirmCancel') {
      this.cancel();
    } else {
      this.save();
    }
  }
  cancel() {
    this.backClick.emit();
  }
  hide() {
    this.showKeyboard = true;
    this.cdRef.detectChanges();
  }
  show() {
    this.showKeyboard = false;
    this.cdRef.detectChanges();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ChangeDetectorRef
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  modalC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild,
    args: ['modal']
  }],
  confirmModalC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild,
    args: ['confirmModal']
  }],
  newSiteC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild,
    args: [_components_new_site_new_site_component__WEBPACK_IMPORTED_MODULE_3__.NewSiteComponent]
  }],
  apDateC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild,
    args: [_components_access_point_date_access_point_date_component__WEBPACK_IMPORTED_MODULE_4__.AccessPointDateComponent]
  }],
  apAddress: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild,
    args: [_components_access_point_address_access_point_address_component__WEBPACK_IMPORTED_MODULE_5__.AccessPointAddressComponent]
  }],
  apDataC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild,
    args: [_components_access_point_data_access_point_data_component__WEBPACK_IMPORTED_MODULE_6__.AccessPointDataComponent]
  }],
  categoryList: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Input
  }],
  loading: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Input
  }],
  backClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  saveClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }]
}), _class);
SiteEditPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-site-edit',
  template: _site_edit_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_site_edit_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], SiteEditPage);


/***/ }),

/***/ 71483:
/*!*************************************************************!*\
  !*** ./src/app/sites/pages/site-info/site-info.business.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SiteInfoBusiness": () => (/* binding */ SiteInfoBusiness)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var src_app_shared_components_profile_selection_profile_selection_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/components/profile-selection/profile-selection.component */ 10763);
/* harmony import */ var src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/models/Enums */ 6452);
/* harmony import */ var src_app_shared_services_site_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/services/site.service */ 19886);
/* harmony import */ var _site_info_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./site-info.component */ 16180);
/* harmony import */ var _users_users_business__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../users/users.business */ 17558);
/* harmony import */ var _site_wizard_site_wizard_business__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../site-wizard/site-wizard.business */ 19129);
/* harmony import */ var src_app_shared_services_invitation_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/services/invitation.service */ 21178);
/* harmony import */ var src_app_shared_services_access_point_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/services/access-point.service */ 58838);
/* harmony import */ var src_app_shared_components_confirm_modal_confirm_modal_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/shared/components/confirm-modal/confirm-modal.component */ 4562);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 51547);
/* harmony import */ var src_app_shared_components_plans_modal_plans_modal_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/shared/components/plans-modal/plans-modal.component */ 78726);


var _class;















let SiteInfoBusiness = (_class = class SiteInfoBusiness {
  constructor(siteService, accessPointService, invitationService, route, router, navController, cdRef) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "siteService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPointService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitationService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "route", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "router", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "cdRef", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "siteInfoC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "profileModal", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "siteEditC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "confirmModalC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "plansModal", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "site", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "apList", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitations", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessList", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "siteId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "isLoaded", false);
    this.siteService = siteService;
    this.accessPointService = accessPointService;
    this.invitationService = invitationService;
    this.route = route;
    this.router = router;
    this.navController = navController;
    this.cdRef = cdRef;
    this.route.queryParams.subscribe(() => {
      if (this.router?.getCurrentNavigation()?.extras.state) {
        const state = this.router.getCurrentNavigation()?.extras.state;
        if (state) {
          const users = state.contacts;
          console.table(users);
          console.log('save confirm');
        }
      }
    });
  }
  get userRoles() {
    if (this.site?.roles.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_3__.AccessPointRole.administrator)) return src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_3__.AccessPointRole.administrator;
    if (this.site?.roles.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_3__.AccessPointRole.owner)) return src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_3__.AccessPointRole.owner;else return src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_3__.AccessPointRole.operator;
  }
  ionViewWillEnter() {
    this.isLoaded = false;
    if (this.route.snapshot.params.id != null) {
      this.siteId = this.route.snapshot.params.id;
      this.fetchSite();
    }
  }
  ionViewWillLeave() {
    this.site = undefined;
    this.apList = undefined;
    this.invitations = undefined;
  }
  fetchSite() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const response = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.lastValueFrom)(_this.siteService.getSiteById(_this.siteId));
      if (response.error == null) {
        _this.site = response.data;
        _this.siteInfoC?.getButtonsConfig(_this.site);
        _this.accessPointService.getSiteAccessPoints(_this.siteId).subscribe(apResponse => {
          if (apResponse.error == null) _this.apList = apResponse.data;else _this.navController.navigateRoot('error');
        });
        _this.invitationService.getInvitationsBySiteId(_this.siteId).subscribe(apResponse => {
          if (apResponse.error == null) _this.invitations = apResponse.data;else _this.navController.navigateRoot('error');
        });
        _this.isLoaded = true;
      } else _this.navController.navigateRoot('error');
    })();
  }
  refresh() {
    this.site = undefined;
    this.apList = undefined;
    this.invitations = undefined;
    this.isLoaded = false;
    this.cdRef.detectChanges();
    this.fetchSite();
  }
  backClick() {
    this.navController.back();
  }
  editImg() {
    console.log('Img edit Click!');
    this.siteEditC?.openModal(this.siteId, 1);
  }
  editDescription() {
    console.log('Description edit Click!');
    this.siteEditC?.openModal(this.siteId, 1);
  }
  accessPointClick(apid) {
    const isMainDoor = this.apList?.length === 1;
    const navigationExtras = {
      state: {
        title: this.site?.name,
        mainDoor: isMainDoor
      }
    };
    this.navController.navigateForward('access/access-point/' + apid, navigationExtras);
  }
  doorClick() {
    if (this.site?.remainingDoors !== null && this.site?.remainingDoors !== undefined && this.site?.remainingDoors <= 0) this.plansModal?.modal?.show();else this.navController.navigateForward('access/new-access-point/' + this.siteId);
  }
  assistanceClick() {
    const navigationExtras = {
      state: {
        component: 'site'
      }
    };
    console.log('Assistance button Click!');
    this.navController.navigateForward('sites/attendance/' + this.siteId, navigationExtras);
  }
  rolesClick() {
    console.log('Roles button Click!');
    this.profileModal?.modal?.show();
  }
  roleSelected(role) {
    var _this2 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('Role selected: ' + role);
      let users;
      const vm = new _users_users_business__WEBPACK_IMPORTED_MODULE_6__.ContactParameters();
      vm.id = _this2.siteId;
      vm.role = role;
      yield _this2.siteService.getUsers(vm).subscribe(gResponse => {
        if (gResponse.error == null) {
          users = gResponse.data;
          _this2.profileModal?.modal?.hide();
          _this2.navController.navigateForward('sites/users/' + _this2.siteId, {
            state: {
              siteName: _this2.site?.name,
              contacts: users,
              role
            }
          });
        } else _this2.navController.navigateRoot('error');
      });
    })();
  }
  deleteClick() {
    this.confirmModalC?.show();
  }
  confirmDelete() {
    var _this3 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('Delete button Click!');
      yield _this3.siteService.delete(_this3.siteId).subscribe(r => {
        if (r.error == null) {
          _this3.navController.navigateRoot('sites');
          console.log('Delete button Click!');
        } else _this3.navController.navigateRoot('error');
      });
    })();
  }
  newInvitation() {
    console.log('New Invitation click!');
    this.navController.navigateForward('invite/new-invitation/' + this.siteId);
  }
  newInvite(i) {
    var _this4 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('Invite click: ' + i.invitationId);
      yield _this4.invitationService.getContacts(i.invitationId).subscribe(gResponse => {
        if (gResponse.error == null) {
          const guests = gResponse.data;
          _this4.goToContactsPage(i.invitationId, guests, i.description);
        } else _this4.navController.navigateRoot('error');
      });
    })();
  }
  goToGuests(id) {
    var _this5 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this5.invitationService.getContacts(id).subscribe(gResponse => {
        if (gResponse.error == null) {
          const guests = gResponse.data;
          _this5.goToContactsPage(id, guests);
        } else _this5.navController.navigateRoot('error');
      });
    })();
  }
  goToContactsPage(id, contacts, title) {
    this.navController.navigateForward('invite/guests/' + id, {
      state: {
        contacts,
        invDescription: title
      }
    });
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_services_site_service__WEBPACK_IMPORTED_MODULE_4__.SiteService
}, {
  type: src_app_shared_services_access_point_service__WEBPACK_IMPORTED_MODULE_9__.AccessPointService
}, {
  type: src_app_shared_services_invitation_service__WEBPACK_IMPORTED_MODULE_8__.InvitationService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_13__.ActivatedRoute
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_13__.Router
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.NavController
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_15__.ChangeDetectorRef
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "propDecorators", {
  siteInfoC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_15__.ViewChild,
    args: [_site_info_component__WEBPACK_IMPORTED_MODULE_5__.SiteInfoComponent]
  }],
  profileModal: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_15__.ViewChild,
    args: [src_app_shared_components_profile_selection_profile_selection_component__WEBPACK_IMPORTED_MODULE_2__.ProfileSelectionComponent]
  }],
  siteEditC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_15__.ViewChild,
    args: [_site_wizard_site_wizard_business__WEBPACK_IMPORTED_MODULE_7__.SiteWizardBusiness]
  }],
  confirmModalC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_15__.ViewChild,
    args: [src_app_shared_components_confirm_modal_confirm_modal_component__WEBPACK_IMPORTED_MODULE_10__.ConfirmModalComponent]
  }],
  plansModal: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_15__.ViewChild,
    args: [src_app_shared_components_plans_modal_plans_modal_component__WEBPACK_IMPORTED_MODULE_11__.PlansModalComponent]
  }]
}), _class);
SiteInfoBusiness = (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_15__.Component)({
  selector: 'app-access-info-component',
  template: `<app-site-info
      class="scroll-content"
      [site]="site"
      [invitations]="invitations"
      [accessList]="accessList"
      [accessPoints]="apList"
      (back)="backClick()"
      (imgEditClick)="editImg()"
      (newInvitation)="newInvitation()"
      (newInvite)="newInvite($event)"
      (accessPointClick)="accessPointClick($event)"
      (descriptionEditClick)="editDescription()"
      (doorButtonClick)="doorClick()"
      (assistButtonClick)="assistanceClick()"
      (rolesButtonClick)="rolesClick()"
      (deleteButtonClick)="deleteClick()"
      (guestsClick)="goToGuests($event)">
    </app-site-info>
    <app-profile-selection
      *ngIf="isLoaded"
      [userRole]="userRoles"
      (roleClick)="roleSelected($event)"></app-profile-selection>
    <app-site-wizard-business (refresh)="refresh()" [edit]="true"></app-site-wizard-business>
    <app-confirm-modal [title]="'sites.confirmDelete' | translate" (confirmClick)="confirmDelete()"></app-confirm-modal>
    <app-plans-modal></app-plans-modal>`
})], SiteInfoBusiness);


/***/ }),

/***/ 16180:
/*!**************************************************************!*\
  !*** ./src/app/sites/pages/site-info/site-info.component.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SiteInfoComponent": () => (/* binding */ SiteInfoComponent)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _site_info_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./site-info.component.html?ngResource */ 90055);
/* harmony import */ var _site_info_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./site-info.component.scss?ngResource */ 40699);
/* harmony import */ var _site_info_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_site_info_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var src_app_shared_components_access_selection_access_selection_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/access-selection/access-selection.component */ 70239);
/* harmony import */ var src_app_shared_components_button_panel_button_panel_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/components/button-panel/button-panel.component */ 35081);
/* harmony import */ var src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/components/footer/footer.component */ 68014);
/* harmony import */ var src_app_shared_helpers_business__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/helpers/business */ 92237);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/models/Enums */ 6452);

var _class;










let SiteInfoComponent = (_class = class SiteInfoComponent {
  constructor(business, translate) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "business", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessModal", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "site", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessPoints", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessList", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "invitations", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "back", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessPointClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "imgEditClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "descriptionEditClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "inviteButtonClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "doorButtonClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "assistButtonClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "rolesButtonClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "deleteButtonClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "newInvitation", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "newInvite", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "guestsClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "footerOptions", src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_5__.FooterSelectedOption);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "buttonsConfig", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "currentStep", 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "role", src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_7__.AccessPointRole);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "activeButtonPanel", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "buttonPanelClass", 'justify-content-center mb-n2');
    this.business = business;
    this.translate = translate;
  }
  get isAdmin() {
    return this.site?.roles.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_7__.AccessPointRole.administrator);
  }
  get isGuest() {
    return this.site?.roles.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_7__.AccessPointRole.guest);
  }
  get isOwner() {
    return this.site?.roles.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_7__.AccessPointRole.owner);
  }
  get isOperator() {
    return this.site?.roles.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_7__.AccessPointRole.operator);
  }
  ngOnInit() {
    if (this.site) this.getButtonsConfig(this.site);
  }
  getButtonsConfig(site) {
    this.site = site;
    if (this.isAdmin) {
      this.buttonsConfig = new src_app_shared_components_button_panel_button_panel_component__WEBPACK_IMPORTED_MODULE_4__.ButtonPanelConfig();
      const buttons = [];
      let button = {
        click: () => {
          this.inviteButtonClick.emit();
          this.accessModal?.modal?.show();
        },
        label: this.translate.instant('common.invite'),
        faClass: ['fas', 'envelope-open-text']
      };
      buttons.push(button);
      button = {
        click: () => {
          this.descriptionEditClick.emit();
        },
        label: this.translate.instant('common.editButton'),
        faClass: ['fas', 'pencil']
      };
      buttons.push(button);
      button = {
        click: () => {
          this.doorButtonClick.emit();
        },
        label: this.translate.instant('common.doorButton'),
        faClass: ['fas', 'door-closed']
      };
      buttons.push(button);
      button = {
        click: () => {
          this.rolesButtonClick.emit();
        },
        label: this.translate.instant('common.permissionButton'),
        faClass: ['fas', 'user-gear']
      };
      buttons.push(button);
      button = {
        click: () => {
          this.assistButtonClick.emit();
        },
        label: this.translate.instant('common.attendanceButton'),
        faClass: ['fas', 'users']
      };
      buttons.push(button);
      button = {
        click: () => {
          this.deleteButtonClick.emit();
        },
        label: this.translate.instant('common.deleteButton'),
        faClass: ['fas', 'trash-can']
      };
      buttons.push(button);
      this.buttonsConfig.buttons = buttons;
      this.activeButtonPanel = true;
      this.buttonPanelClass = 'mb-3 justify-content-center';
    } else if (this.isOperator) {
      this.buttonsConfig = new src_app_shared_components_button_panel_button_panel_component__WEBPACK_IMPORTED_MODULE_4__.ButtonPanelConfig();
      this.buttonPanelClass = 'mb-3 justify-content-center';
      const buttons = [];
      let button = {
        click: () => {
          this.inviteButtonClick.emit();
          this.accessModal?.modal?.show();
        },
        label: this.translate.instant('common.invite'),
        faClass: ['fas', 'envelope-open-text']
      };
      buttons.push(button);
      button = {
        click: () => {
          this.rolesButtonClick.emit();
        },
        label: this.translate.instant('common.permissionButton'),
        faClass: ['fas', 'user-gear']
      };
      buttons.push(button);
      button = {
        click: () => {
          this.assistButtonClick.emit();
        },
        label: this.translate.instant('common.attendanceButton'),
        faClass: ['fas', 'users']
      };
      buttons.push(button);
      this.buttonsConfig.buttons = buttons;
      this.activeButtonPanel = true;
    } else if (this.isOwner) {
      this.buttonsConfig = new src_app_shared_components_button_panel_button_panel_component__WEBPACK_IMPORTED_MODULE_4__.ButtonPanelConfig();
      this.buttonPanelClass = 'mb-3 justify-content-center';
      const buttons = [];
      let button = {
        click: () => {
          this.inviteButtonClick.emit();
          this.accessModal?.modal?.show();
        },
        label: this.translate.instant('common.invite'),
        faClass: ['fas', 'envelope-open-text']
      };
      buttons.push(button);
      button = {
        click: () => {
          this.rolesButtonClick.emit();
        },
        label: this.translate.instant('common.permissionButton'),
        faClass: ['fas', 'user-gear']
      };
      buttons.push(button);
      this.buttonsConfig.buttons = buttons;
      this.activeButtonPanel = true;
    }
  }
  getRecurrence(ap) {
    return [this.business.getRecurrence(ap), this.business.getTimeRange(ap)];
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_helpers_business__WEBPACK_IMPORTED_MODULE_6__["default"]
}, {
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateService
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  accessModal: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild,
    args: [src_app_shared_components_access_selection_access_selection_component__WEBPACK_IMPORTED_MODULE_3__.AccessSelectionComponent]
  }],
  site: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input
  }],
  accessPoints: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input
  }],
  accessList: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input
  }],
  invitations: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input
  }],
  back: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  accessPointClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  imgEditClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  descriptionEditClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  inviteButtonClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  doorButtonClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  assistButtonClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  rolesButtonClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  deleteButtonClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  newInvitation: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  newInvite: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  guestsClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  accessClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }]
}), _class);
SiteInfoComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
  selector: 'app-site-info',
  template: _site_info_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_site_info_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], SiteInfoComponent);


/***/ }),

/***/ 19129:
/*!*****************************************************************!*\
  !*** ./src/app/sites/pages/site-wizard/site-wizard.business.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PostSiteViewModel": () => (/* binding */ PostSiteViewModel),
/* harmony export */   "SiteWizardBusiness": () => (/* binding */ SiteWizardBusiness),
/* harmony export */   "SiteWizardViewModel": () => (/* binding */ SiteWizardViewModel)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var src_app_shared_services_site_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/services/site.service */ 19886);
/* harmony import */ var _components_access_point_date_access_point_date_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../components/access-point-date/access-point-date.component */ 8267);
/* harmony import */ var _components_access_point_data_access_point_data_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/access-point-data/access-point-data.component */ 3762);
/* harmony import */ var _components_new_site_new_site_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/new-site/new-site.component */ 38593);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _components_access_point_address_access_point_address_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../components/access-point-address/access-point-address.component */ 12784);
/* harmony import */ var _site_edit_site_edit_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../site-edit/site-edit.page */ 47754);
/* harmony import */ var src_app_shared_services_access_point_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/services/access-point.service */ 58838);
/* harmony import */ var src_app_shared_services_file_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/services/file.service */ 30038);
/* harmony import */ var src_app_access_components_access_point_control_access_point_control_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/access/components/access-point-control/access-point-control.component */ 52403);
/* harmony import */ var src_app_shared_models_Image__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/shared/models/Image */ 90925);
/* harmony import */ var src_app_shared_components_day_select_form_day_select_form_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/shared/components/day-select-form/day-select-form.component */ 84599);
/* harmony import */ var src_app_shared_models_PostAccessViewModel__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/shared/models/PostAccessViewModel */ 69062);
/* harmony import */ var src_app_shared_helpers_LocationViewModel__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/shared/helpers/LocationViewModel */ 52158);
/* harmony import */ var src_app_shared_helpers_DaysViewModel__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/shared/helpers/DaysViewModel */ 12913);
/* harmony import */ var src_app_shared_helpers_GetPostAccessPointViewModel__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/shared/helpers/GetPostAccessPointViewModel */ 49669);
/* harmony import */ var src_app_invite_pages_invitation_wizard_invitation_wizard_business__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/invite/pages/invitation-wizard/invitation-wizard.business */ 8393);
/* harmony import */ var src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/shared/services/user.service */ 31880);
/* harmony import */ var src_app_shared_services_invitation_service__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! src/app/shared/services/invitation.service */ 21178);
/* harmony import */ var src_app_shared_services_access_service__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! src/app/shared/services/access.service */ 46554);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! rxjs */ 51547);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var ionicons_icons__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ionicons/icons */ 64047);


var _class;

























let SiteWizardBusiness = (_class = class SiteWizardBusiness {
  constructor(siteService, navController, toastr, accessPointService, fileService, userService, invitationService, accessService, translateService) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "siteService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "toastr", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPointService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "fileService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitationService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "translateService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "editC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "edit", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "refresh", new _angular_core__WEBPACK_IMPORTED_MODULE_22__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "site", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPoint", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "viewModel", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "loading", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "categoryList", []);
    this.siteService = siteService;
    this.navController = navController;
    this.toastr = toastr;
    this.accessPointService = accessPointService;
    this.fileService = fileService;
    this.userService = userService;
    this.invitationService = invitationService;
    this.accessService = accessService;
    this.translateService = translateService;
    this.viewModel = new SiteWizardViewModel();
  }
  get userId() {
    return this.userService.userData?.userId;
  }
  ngOnInit() {
    this.getCategoryList();
  }
  openModal(siteId, step) {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.getWizardViewModel(siteId, step);
      _this.editC?.fillStep(step, _this.viewModel);
      _this.editC?.modalC?.show();
    })();
  }
  getCategoryList() {
    this.siteService.getSiteCategories().subscribe(response => {
      if (response.error === null) {
        this.categoryList = response.data;
        this.categoryList.unshift({
          id: '0',
          name: this.translateService.instant('common.selectCategory'),
          image: ''
        });
      } else {
        this.navController.navigateRoot('error');
      }
    });
  }
  getWizardViewModel(id, step) {
    var _this2 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const r = yield _this2.siteService.getSiteById(id).toPromise();
      if (r) _this2.site = r.data;
      switch (step) {
        case 1:
          const siteVM = new _components_new_site_new_site_component__WEBPACK_IMPORTED_MODULE_5__.NewSiteViewModel();
          siteVM.category = {
            name: _this2.site.category.name,
            id: _this2.site.category.id
          };
          siteVM.description = _this2.site.description;
          siteVM.name = _this2.site.name;
          if (_this2.site.presentationImg) {
            siteVM.images = [];
            let i = 0;
            _this2.site.presentationImg.forEach(img => {
              const image = new src_app_shared_models_Image__WEBPACK_IMPORTED_MODULE_11__.Image();
              image.id = img.id;
              image.image64 = img.url;
              image.name = `invitationImg${i}.png`;
              siteVM.images.push(image);
              i++;
            });
          }
          _this2.viewModel.newSiteStep = siteVM;
          break;
      }
    })();
  }
  back() {
    if (!this.edit) {
      this.navController.back();
    } else {
      this.editC?.modalC?.hide();
    }
  }
  nextClick(model) {
    var _this3 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('Next click');
      console.log(model);
      _this3.fillVM(model);
    })();
  }
  save(model) {
    var _this4 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const step = _this4.fillVM(model);
      if (_this4.edit) {
        if (step === 1) {
          _this4.saveStep(1);
        } else if (step === 2) {
          _this4.saveStep(2);
        } else if (step === 3) {
          _this4.saveStep(3);
        } else if (step === 4) {
          _this4.saveStep(4);
        }
      } else {
        const vm = _this4.getPostViewModel();
        const vmAP = _this4.getAPPostViewModel();
        vmAP.siteId = vm.id;
        const invVm = _this4.getInvitationPostViewModel();
        invVm.motive = vm.name + ' - ' + vmAP.name;
        invVm.place = vmAP.address;
        invVm.siteId = vm.id;
        invVm.location = vmAP.id;
        const accessVm = new src_app_shared_models_PostAccessViewModel__WEBPACK_IMPORTED_MODULE_13__.PostAccessViewModel();
        accessVm.id = crypto.randomUUID();
        accessVm.invitationId = invVm.id;
        accessVm.userId = _this4.userId;
        accessVm.attendance = false;
        yield _this4.deleteImages(_this4.viewModel.newSiteStep);
        if (_this4.viewModel.newSiteStep?.images?.length === 0) {
          yield _this4.postServices(vm, vmAP, invVm, accessVm);
        } else {
          const res = yield _this4.fileService.uploadFiles(_this4.viewModel.newSiteStep.images).toPromise();
          if (res?.error === null) {
            vm.externalIds = res.data;
          } else {
            _this4.toastr.create({
              message: _this4.translateService.instant('error.fileUpload'),
              icon: ionicons_icons__WEBPACK_IMPORTED_MODULE_21__.alertCircleOutline,
              duration: 3000,
              color: 'warning'
            }).then(t => t.present());
          }
          yield _this4.postServices(vm, vmAP, invVm, accessVm);
        }
      }
    })();
  }
  postServices(siteVm, apVm, invVm, accessVm) {
    var _this5 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const ret = yield _this5.siteService.postNewSite(siteVm).toPromise();
      if (ret?.error === null) {
        const mapResult = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_23__.lastValueFrom)(yield _this5.fileService.uploadFileString(apVm.mapFileId));
        if (mapResult?.error === null) {
          apVm.mapFileId = mapResult.data[0];
          const result = yield _this5.accessPointService.postAccessPoint(apVm).toPromise();
          if (result?.error === null) {
            const res = yield _this5.invitationService.postInvitation(invVm).toPromise();
            if (res?.error === null) {
              const invitation = yield _this5.invitationService.getInvitationById(invVm.id).toPromise();
              if (invitation?.error === null) {
                accessVm.invitation = invitation.data;
              }
              const data = yield _this5.accessService.postAccess(accessVm).toPromise();
              if (data?.error === null) {
                _this5.loading = false;
                _this5.navController.navigateForward('/sites');
              } else {
                _this5.navController.navigateRoot('error');
              }
            } else {
              _this5.navController.navigateRoot('error');
            }
          } else {
            _this5.navController.navigateRoot('error');
          }
        } else {
          _this5.navController.navigateRoot('error');
        }
      } else {
        _this5.navController.navigateRoot('error');
      }
    })();
  }
  fillVM(model) {
    if (model instanceof _components_new_site_new_site_component__WEBPACK_IMPORTED_MODULE_5__.NewSiteViewModel) {
      this.viewModel.newSiteStep = model;
      return 1;
    }
    if (model instanceof _components_access_point_address_access_point_address_component__WEBPACK_IMPORTED_MODULE_6__.AccessPointAddressViewModel) {
      this.viewModel.accessPointAddressStep = model;
      if (!this.edit) {
        this.getDefaultDateStep();
      }
      return 2;
    }
    if (model instanceof _components_access_point_data_access_point_data_component__WEBPACK_IMPORTED_MODULE_4__.AccessPointDataViewModel) {
      this.viewModel.accessPointControlStep = model;
      return 3;
    }
    if (model instanceof _components_access_point_date_access_point_date_component__WEBPACK_IMPORTED_MODULE_3__.AccessPointDateViewModel) {
      this.viewModel.accessPointDateStep = model;
      return 4;
    }
  }
  saveStep(step) {
    var _this6 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      switch (step) {
        case 1:
          const firstVM = _this6.getUpdateViewModel(1);
          yield _this6.deleteImages(_this6.viewModel.newSiteStep);
          if (_this6.viewModel.newSiteStep?.images?.length === 0) {
            _this6.siteService.updateSite(firstVM).subscribe(as => {
              if (as.error === null) {
                _this6.siteRefresh();
              } else {
                _this6.navController.navigateRoot('error');
              }
            });
          } else {
            _this6.fileService.uploadFiles(_this6.viewModel.newSiteStep.images).subscribe(res => {
              if (res.error === null) {
                firstVM.externalIds = res.data;
              } else {
                _this6.toastr.create({
                  message: _this6.translateService.instant('error.fileUpload'),
                  icon: ionicons_icons__WEBPACK_IMPORTED_MODULE_21__.alertCircleOutline,
                  duration: 3000,
                  color: 'warning'
                }).then(t => t.present());
              }
              _this6.siteService.updateSite(firstVM).subscribe(as => {
                if (as.error === null) {
                  _this6.siteRefresh();
                } else {
                  _this6.navController.navigateRoot('error');
                }
              });
            });
          }
          break;
        case 2:
          const secVM = _this6.getUpdateViewModel(2);
          _this6.accessPointService.updateAddress(secVM).subscribe(res => {
            if (res.error === null) {
              _this6.siteRefresh();
            } else {
              _this6.navController.navigateRoot('error');
            }
          });
          break;
        case 3:
          const fourVM = _this6.getUpdateViewModel(3);
          console.log(fourVM);
          _this6.accessPointService.updateNotes(fourVM).subscribe(res => {
            if (res.error === null) {
              _this6.siteRefresh();
            } else {
              _this6.navController.navigateRoot('error');
            }
          });
          break;
        case 4:
          const thirdVM = _this6.getUpdateViewModel(4);
          console.log(thirdVM);
          _this6.accessPointService.updateSchedule(thirdVM).subscribe(res => {
            if (res.error === null) {
              _this6.siteRefresh();
            } else {
              _this6.navController.navigateRoot('error');
            }
          });
          break;
      }
    })();
  }
  getUpdateViewModel(step) {
    let ret;
    switch (step) {
      case 1:
        ret = new _components_new_site_new_site_component__WEBPACK_IMPORTED_MODULE_5__.UpdateSiteViewModel();
        ret.categoryId = this.viewModel.newSiteStep?.category.id;
        ret.description = this.viewModel.newSiteStep?.description;
        ret.name = this.viewModel.newSiteStep?.name;
        ret.id = this.site?.id;
        break;
      case 2:
        ret = (0,src_app_shared_helpers_LocationViewModel__WEBPACK_IMPORTED_MODULE_14__.locationViewModelForAccessPointSchedule)(this.viewModel.accessPointAddressStep);
        ret.id = this.accessPoint?.id;
        break;
      case 3:
        ret = new src_app_access_components_access_point_control_access_point_control_component__WEBPACK_IMPORTED_MODULE_10__.UpdateAccessPointControlViewModel();
        ret.id = this.accessPoint?.id;
        ret.noteAccess = this.viewModel.accessPointControlStep?.noteAccess;
        ret.inputs = this.viewModel.accessPointControlStep?.inputs;
        break;
      case 4:
        ret = (0,src_app_shared_helpers_DaysViewModel__WEBPACK_IMPORTED_MODULE_15__.daysViewModelForAccessPointSchedule)(this.viewModel.accessPointDateStep);
        ret.id = this.accessPoint?.id;
        break;
    }
    return ret;
  }
  deleteImages(model) {
    var _this7 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      model.deleteImage?.forEach( /*#__PURE__*/function () {
        var _ref = (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (img) {
          if (img) {
            yield (0,rxjs__WEBPACK_IMPORTED_MODULE_23__.lastValueFrom)(_this7.siteService.deleteImage(img));
          }
        });
        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }());
    })();
  }
  getPostViewModel() {
    const vm = new PostSiteViewModel();
    vm.id = crypto.randomUUID();
    vm.categoryId = this.viewModel.newSiteStep?.category.id;
    vm.description = this.viewModel.newSiteStep?.description;
    vm.name = this.viewModel.newSiteStep?.name;
    return vm;
  }
  getAPPostViewModel() {
    const vm = (0,src_app_shared_helpers_GetPostAccessPointViewModel__WEBPACK_IMPORTED_MODULE_16__.getPostViewModelForAccessPoint)(this.viewModel, this.site?.id);
    vm.name = this.translateService.instant('invite.defaultTitle');
    return vm;
  }
  getInvitationPostViewModel() {
    const vm = new src_app_invite_pages_invitation_wizard_invitation_wizard_business__WEBPACK_IMPORTED_MODULE_17__.PostInvitationViewModel();
    vm.id = crypto.randomUUID();
    vm.categoryId = '28003411-a456-4030-85c8-2e73f64a579a';
    vm.description = this.translateService.instant('invite.defaultTitle');
    vm.accessPointIds = [];
    vm.dateFrom = new Date().toISOString();
    if (!this.viewModel.accessPointDateStep?.daysVM.allDays) {
      if (this.viewModel.accessPointDateStep?.timeFrom) {
        const time = this.viewModel.accessPointDateStep?.timeFrom.split(':');
        vm.hourFrom = Number(time[0]);
        vm.minuteFrom = Number(time[1]);
      }
      if (this.viewModel.accessPointDateStep?.timeTo) {
        const time = this.viewModel.accessPointDateStep?.timeTo.split(':');
        vm.hourTo = Number(time[0]);
        vm.minuteTo = Number(time[1]);
      }
    }
    vm.recurrency = true;
    if (vm.recurrency) {
      vm.monday = this.viewModel.accessPointDateStep?.daysVM.monday;
      vm.tuesday = this.viewModel.accessPointDateStep?.daysVM.tuesday;
      vm.wednesday = this.viewModel.accessPointDateStep?.daysVM.wednesday;
      vm.thursday = this.viewModel.accessPointDateStep?.daysVM.thursday;
      vm.friday = this.viewModel.accessPointDateStep?.daysVM.friday;
      vm.saturday = this.viewModel.accessPointDateStep?.daysVM.saturday;
      vm.sunday = this.viewModel.accessPointDateStep?.daysVM.sunday;
    }
    vm.default = true;
    return vm;
  }
  getDefaultDateStep() {
    this.viewModel.accessPointDateStep = new _components_access_point_date_access_point_date_component__WEBPACK_IMPORTED_MODULE_3__.AccessPointDateViewModel();
    this.viewModel.accessPointDateStep.daysVM = new src_app_shared_components_day_select_form_day_select_form_component__WEBPACK_IMPORTED_MODULE_12__.DaysViewModel();
    this.viewModel.accessPointDateStep.daysVM.allDays = true;
    this.viewModel.accessPointDateStep.daysVM.monday = true;
    this.viewModel.accessPointDateStep.daysVM.tuesday = true;
    this.viewModel.accessPointDateStep.daysVM.wednesday = true;
    this.viewModel.accessPointDateStep.daysVM.thursday = true;
    this.viewModel.accessPointDateStep.daysVM.friday = true;
    this.viewModel.accessPointDateStep.daysVM.saturday = true;
    this.viewModel.accessPointDateStep.daysVM.sunday = true;
    this.viewModel.accessPointDateStep.allDay = true;
  }
  siteRefresh() {
    this.editC.loading = false;
    this.editC?.modalC?.hide();
    this.refresh.emit();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_services_site_service__WEBPACK_IMPORTED_MODULE_2__.SiteService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.NavController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.ToastController
}, {
  type: src_app_shared_services_access_point_service__WEBPACK_IMPORTED_MODULE_8__.AccessPointService
}, {
  type: src_app_shared_services_file_service__WEBPACK_IMPORTED_MODULE_9__.FileService
}, {
  type: src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_18__.UserService
}, {
  type: src_app_shared_services_invitation_service__WEBPACK_IMPORTED_MODULE_19__.InvitationService
}, {
  type: src_app_shared_services_access_service__WEBPACK_IMPORTED_MODULE_20__.AccessService
}, {
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_25__.TranslateService
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "propDecorators", {
  editC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_22__.ViewChild,
    args: [_site_edit_site_edit_page__WEBPACK_IMPORTED_MODULE_7__.SiteEditPage]
  }],
  edit: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_22__.Input
  }],
  refresh: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_22__.Output
  }]
}), _class);
SiteWizardBusiness = (0,tslib__WEBPACK_IMPORTED_MODULE_26__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_22__.Component)({
  selector: 'app-site-wizard-business',
  template: `<app-site-wizard
      class="scroll-content"
      *ngIf="!edit"
      [categoryList]="categoryList"
      [loading]="loading"
      (backClick)="back()"
      (nextClick)="nextClick($event)"
      (saveClick)="save($event)"></app-site-wizard>
    <app-site-edit
      *ngIf="edit"
      [categoryList]="categoryList"
      [loading]="loading"
      (backClick)="back()"
      (saveClick)="save($event)">
    </app-site-edit>`
})], SiteWizardBusiness);

class SiteWizardViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "id", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "newSiteStep", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPointDateStep", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPointControlStep", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPointAddressStep", void 0);
  }
}
class PostSiteViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "id", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "name", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "description", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "categoryId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "externalIds", void 0);
  }
}

/***/ }),

/***/ 48412:
/*!*************************************************************!*\
  !*** ./src/app/sites/pages/site-wizard/site-wizard.page.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SiteFormViewModel": () => (/* binding */ SiteFormViewModel),
/* harmony export */   "SiteWizardPage": () => (/* binding */ SiteWizardPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _site_wizard_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./site-wizard.page.html?ngResource */ 66974);
/* harmony import */ var _site_wizard_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./site-wizard.page.scss?ngResource */ 87546);
/* harmony import */ var _site_wizard_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_site_wizard_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/footer/footer.component */ 68014);
/* harmony import */ var _components_new_site_new_site_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/new-site/new-site.component */ 38593);
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/animations */ 66400);
/* harmony import */ var _components_access_point_address_access_point_address_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/access-point-address/access-point-address.component */ 12784);
/* harmony import */ var _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../shared/components/button/button.component */ 62490);

var _class;









const left = [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.query)(':enter, :leave', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
  position: 'fixed',
  width: '100%'
}), {
  optional: true
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.group)([(0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.query)(':enter', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
  transform: 'translateX(-100%)'
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.animate)('.3s ease-out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
  transform: 'translateX(0%)'
}))], {
  optional: true
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.query)(':leave', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
  transform: 'translateX(0%)'
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.animate)('.3s ease-out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
  transform: 'translateX(100%)'
}))], {
  optional: true
})])];
const right = [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.query)(':enter, :leave', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
  position: 'fixed',
  width: '100%'
}), {
  optional: true
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.group)([(0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.query)(':enter', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
  transform: 'translateX(100%)'
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.animate)('.3s ease-out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
  transform: 'translateX(0%)'
}))], {
  optional: true
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.query)(':leave', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
  transform: 'translateX(0%)'
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.animate)('.3s ease-out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
  transform: 'translateX(-100%)'
}))], {
  optional: true
})])];
let SiteWizardPage = (_class = class SiteWizardPage {
  constructor(cdRef) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "cdRef", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "newSiteC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "apAddress", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "categoryList", []);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "loading", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "nextClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "backClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "saveClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "steps", [1, 2]);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "currentStep", 1);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "footerOptions", src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__.FooterSelectedOption);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "showKeyboard", false);
    this.cdRef = cdRef;
  }
  get currentStepValid() {
    switch (this.currentStep) {
      case 1:
        return this.newSiteC?.formValid;
      case 2:
        return this.apAddress?.formValid;
      // case 4:
      //   return this.apDateC?.formValid;
      // case 3:
      //   return this.apDataC?.formValid;
    }
  }

  get buttonState() {
    if (!this.currentStepValid) {
      return _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_6__.ButtonState.disabled;
    } else if (!this.loading) {
      return _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_6__.ButtonState.enabled;
    } else {
      return _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_6__.ButtonState.loading;
    }
  }
  getState() {
    return this.buttonState;
  }
  nextStep() {
    let currentStepModel;
    switch (this.currentStep) {
      case 1:
        currentStepModel = this.newSiteC?.viewModel;
        break;
      case 2:
        currentStepModel = this.apAddress?.viewModel;
        break;
      // case 4:
      //   currentStepModel = this.apDateC?.viewModel;
      //   break;
      // case 3:
      //   currentStepModel = this.apDataC?.viewModel;
      //   break;
    }

    if (this.currentStep !== this.steps.length) {
      this.nextClick.emit(currentStepModel);
      this.currentStep++;
    } else {
      this.loading = true;
      this.saveClick.emit(currentStepModel);
    }
    this.cdRef.detectChanges();
  }
  backStep(step) {
    if (step) {
      this.currentStep = step;
    } else {
      if (this.currentStep === 1) {
        this.backClick.emit();
      }
      this.currentStep--;
    }
  }
  hide() {
    this.showKeyboard = true;
    this.cdRef.detectChanges();
  }
  show() {
    this.showKeyboard = false;
    this.cdRef.detectChanges();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ChangeDetectorRef
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  newSiteC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild,
    args: [_components_new_site_new_site_component__WEBPACK_IMPORTED_MODULE_4__.NewSiteComponent]
  }],
  apAddress: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild,
    args: [_components_access_point_address_access_point_address_component__WEBPACK_IMPORTED_MODULE_5__.AccessPointAddressComponent]
  }],
  categoryList: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input
  }],
  loading: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input
  }],
  nextClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  backClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  saveClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }]
}), _class);
SiteWizardPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
  selector: 'app-site-wizard',
  template: _site_wizard_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  animations: [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.trigger)('animSlider', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.transition)(':increment', right), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.transition)(':decrement', left)])],
  styles: [(_site_wizard_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], SiteWizardPage);

class SiteFormViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "id", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "newSiteVM", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessPointDate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessPointData", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessPointAddress", void 0);
  }
}

/***/ }),

/***/ 67861:
/*!*****************************************************!*\
  !*** ./src/app/sites/pages/sites/sites.business.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SitesBusiness": () => (/* binding */ SitesBusiness)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 51547);
/* harmony import */ var src_app_shared_components_plans_modal_plans_modal_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/components/plans-modal/plans-modal.component */ 78726);
/* harmony import */ var src_app_shared_services_site_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/services/site.service */ 19886);
/* harmony import */ var src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/services/user.service */ 31880);


var _class;







let SitesBusiness = (_class = class SitesBusiness {
  constructor(siteService, navController, cdRef, userService) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "siteService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "cdRef", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "plansModal", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "mySites", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "filteredList", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userViewModel", void 0);
    this.siteService = siteService;
    this.navController = navController;
    this.cdRef = cdRef;
    this.userService = userService;
  }
  ionViewWillEnter() {
    this.filteredList = this.mySites = undefined;
    this.fetchSites();
    this.fetchUser();
  }
  fetchSites() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const siteRes = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.lastValueFrom)(_this.siteService.getSites());
      if (siteRes.error === null) {
        _this.filteredList = _this.mySites = siteRes.data;
      } else {
        _this.navController.navigateRoot('error');
      }
    })();
  }
  fetchUser() {
    var _this2 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const res = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.lastValueFrom)(_this2.userService.getUser());
      if (res.error === null) {
        _this2.userViewModel = res.data;
      }
    })();
  }
  siteClick(sId) {
    var _this3 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this3.navController.navigateForward('sites/site-info/' + sId);
    })();
  }
  invClick(sId) {
    var _this4 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this4.navController.navigateForward('invite/invitations/' + sId);
    })();
  }
  bannerClick() {
    var _this5 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this5.userViewModel?.remainingSites !== null && _this5.userViewModel?.remainingSites !== undefined && _this5.userViewModel?.remainingSites <= 0) {
        _this5.plansModal?.modal?.show();
      } else {
        _this5.navController.navigateForward('sites/new-site');
      }
    })();
  }
  search(t) {
    this.filteredList = this.mySites?.filter(s => s.name.toLowerCase().includes(t.toLowerCase()));
    this.cdRef.detectChanges();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_services_site_service__WEBPACK_IMPORTED_MODULE_3__.SiteService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ChangeDetectorRef
}, {
  type: src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_4__.UserService
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "propDecorators", {
  plansModal: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild,
    args: [src_app_shared_components_plans_modal_plans_modal_component__WEBPACK_IMPORTED_MODULE_2__.PlansModalComponent]
  }]
}), _class);
SitesBusiness = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
  selector: 'app-sites-business',
  template: `<app-sites-page
      class="scroll-content"
      [sites]="filteredList"
      (bannerClick)="bannerClick()"
      (search)="search($event)"
      (invClick)="invClick($event)"
      (siteClick)="siteClick($event)"></app-sites-page>
    <app-plans-modal></app-plans-modal>`
})], SitesBusiness);


/***/ }),

/***/ 59874:
/*!*************************************************!*\
  !*** ./src/app/sites/pages/sites/sites.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SitesPage": () => (/* binding */ SitesPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _sites_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sites.page.html?ngResource */ 93497);
/* harmony import */ var _sites_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./sites.page.scss?ngResource */ 73963);
/* harmony import */ var _sites_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_sites_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/footer/footer.component */ 68014);

var _class;





let SitesPage = (_class = class SitesPage {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "sites", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "bannerClick", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "search", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "invClick", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "siteClick", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "footerOptions", src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__.FooterSelectedOption);
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  sites: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input
  }],
  bannerClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }],
  search: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }],
  invClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }],
  siteClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }]
}), _class);
SitesPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
  selector: 'app-sites-page',
  template: _sites_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_sites_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], SitesPage);


/***/ }),

/***/ 93702:
/*!***********************************************!*\
  !*** ./src/app/sites/sites-routing.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SitesPageRoutingModule": () => (/* binding */ SitesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _pages_site_info_site_info_business__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pages/site-info/site-info.business */ 71483);
/* harmony import */ var _pages_site_wizard_site_wizard_business__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pages/site-wizard/site-wizard.business */ 19129);
/* harmony import */ var _pages_sites_sites_business__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pages/sites/sites.business */ 67861);
/* harmony import */ var _src_app_shared_pages_attendance_attendance_business__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../src/app/shared/pages/attendance/attendance.business */ 99353);
/* harmony import */ var _pages_users_users_business__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/users/users.business */ 17558);








const routes = [{
  path: '',
  component: _pages_sites_sites_business__WEBPACK_IMPORTED_MODULE_2__.SitesBusiness
}, {
  path: 'site-info/:id',
  component: _pages_site_info_site_info_business__WEBPACK_IMPORTED_MODULE_0__.SiteInfoBusiness
}, {
  path: 'new-site',
  component: _pages_site_wizard_site_wizard_business__WEBPACK_IMPORTED_MODULE_1__.SiteWizardBusiness
}, {
  path: 'attendance/:id',
  component: _src_app_shared_pages_attendance_attendance_business__WEBPACK_IMPORTED_MODULE_3__.AttendanceBusiness
}, {
  path: 'users/:id',
  component: _pages_users_users_business__WEBPACK_IMPORTED_MODULE_4__.UsersBusiness
}, {
  path: 'edit-site/:id',
  component: _pages_site_wizard_site_wizard_business__WEBPACK_IMPORTED_MODULE_1__.SiteWizardBusiness
}];
let SitesPageRoutingModule = class SitesPageRoutingModule {};
SitesPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
  imports: [_angular_router__WEBPACK_IMPORTED_MODULE_7__.RouterModule.forChild(routes)],
  exports: [_angular_router__WEBPACK_IMPORTED_MODULE_7__.RouterModule]
})], SitesPageRoutingModule);


/***/ }),

/***/ 68090:
/*!***************************************!*\
  !*** ./src/app/sites/sites.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SitesModule": () => (/* binding */ SitesModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/common */ 89650);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _sites_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./sites-routing.module */ 93702);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../shared/shared.module */ 56208);
/* harmony import */ var _components_sites_list_sites_list_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/sites-list/sites-list.component */ 91233);
/* harmony import */ var _pages_sites_sites_business__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/sites/sites.business */ 67861);
/* harmony import */ var _pages_sites_sites_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/sites/sites.page */ 59874);
/* harmony import */ var _pages_site_info_site_info_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages/site-info/site-info.component */ 16180);
/* harmony import */ var _pages_site_info_site_info_business__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pages/site-info/site-info.business */ 71483);
/* harmony import */ var _pages_site_wizard_site_wizard_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./pages/site-wizard/site-wizard.page */ 48412);
/* harmony import */ var _components_new_site_new_site_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./components/new-site/new-site.component */ 38593);
/* harmony import */ var _components_access_point_date_access_point_date_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/access-point-date/access-point-date.component */ 8267);
/* harmony import */ var _pages_site_wizard_site_wizard_business__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./pages/site-wizard/site-wizard.business */ 19129);
/* harmony import */ var _components_access_point_address_access_point_address_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./components/access-point-address/access-point-address.component */ 12784);
/* harmony import */ var _components_access_point_data_access_point_data_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./components/access-point-data/access-point-data.component */ 3762);
/* harmony import */ var _pages_users_users_business__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./pages/users/users.business */ 17558);
/* harmony import */ var _invite_invite_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../invite/invite.module */ 26723);
/* harmony import */ var _pages_site_edit_site_edit_page__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./pages/site-edit/site-edit.page */ 47754);





















let SitesModule = class SitesModule {};
SitesModule = (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_17__.NgModule)({
  declarations: [_pages_sites_sites_page__WEBPACK_IMPORTED_MODULE_4__.SitesPage, _components_sites_list_sites_list_component__WEBPACK_IMPORTED_MODULE_2__.SitesListComponent, _pages_sites_sites_business__WEBPACK_IMPORTED_MODULE_3__.SitesBusiness, _pages_site_info_site_info_component__WEBPACK_IMPORTED_MODULE_5__.SiteInfoComponent, _pages_site_info_site_info_business__WEBPACK_IMPORTED_MODULE_6__.SiteInfoBusiness, _pages_site_wizard_site_wizard_page__WEBPACK_IMPORTED_MODULE_7__.SiteWizardPage, _components_new_site_new_site_component__WEBPACK_IMPORTED_MODULE_8__.NewSiteComponent, _components_access_point_date_access_point_date_component__WEBPACK_IMPORTED_MODULE_9__.AccessPointDateComponent, _pages_site_wizard_site_wizard_business__WEBPACK_IMPORTED_MODULE_10__.SiteWizardBusiness, _components_access_point_data_access_point_data_component__WEBPACK_IMPORTED_MODULE_12__.AccessPointDataComponent, _components_access_point_address_access_point_address_component__WEBPACK_IMPORTED_MODULE_11__.AccessPointAddressComponent, _pages_users_users_business__WEBPACK_IMPORTED_MODULE_13__.UsersBusiness, _pages_site_edit_site_edit_page__WEBPACK_IMPORTED_MODULE_15__.SiteEditPage],
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_18__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.FormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.ReactiveFormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_20__.IonicModule, _sites_routing_module__WEBPACK_IMPORTED_MODULE_0__.SitesPageRoutingModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule, _invite_invite_module__WEBPACK_IMPORTED_MODULE_14__.InviteModule],
  exports: [_pages_sites_sites_page__WEBPACK_IMPORTED_MODULE_4__.SitesPage, _pages_site_info_site_info_component__WEBPACK_IMPORTED_MODULE_5__.SiteInfoComponent, _components_new_site_new_site_component__WEBPACK_IMPORTED_MODULE_8__.NewSiteComponent, _pages_site_wizard_site_wizard_page__WEBPACK_IMPORTED_MODULE_7__.SiteWizardPage, _components_access_point_date_access_point_date_component__WEBPACK_IMPORTED_MODULE_9__.AccessPointDateComponent, _components_access_point_data_access_point_data_component__WEBPACK_IMPORTED_MODULE_12__.AccessPointDataComponent, _components_access_point_address_access_point_address_component__WEBPACK_IMPORTED_MODULE_11__.AccessPointAddressComponent]
})], SitesModule);


/***/ }),

/***/ 242:
/*!******************************************************************************************************!*\
  !*** ./src/app/sites/components/access-point-address/access-point-address.component.scss?ngResource ***!
  \******************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "em.disabled {\n  display: none !important;\n}\n\n.input-style fa-icon {\n  padding: 9.5px;\n  position: absolute;\n  top: 50%;\n  margin-top: -22px;\n  right: 10px;\n  overflow: hidden;\n  background: white;\n}", "",{"version":3,"sources":["webpack://./src/app/sites/components/access-point-address/access-point-address.component.scss"],"names":[],"mappings":"AAAA;EACE,wBAAA;AACF;;AACA;EACE,cAAA;EACA,kBAAA;EACA,QAAA;EACA,iBAAA;EACA,WAAA;EACA,gBAAA;EACA,iBAAA;AAEF","sourcesContent":["em.disabled {\n  display: none !important;\n}\n.input-style fa-icon {\n  padding: 9.5px;\n  position: absolute;\n  top: 50%;\n  margin-top: -22px;\n  right: 10px;\n  overflow: hidden;\n  background: white;\n}\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 44088:
/*!************************************************************************************************!*\
  !*** ./src/app/sites/components/access-point-data/access-point-data.component.scss?ngResource ***!
  \************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 79300:
/*!************************************************************************************************!*\
  !*** ./src/app/sites/components/access-point-date/access-point-date.component.scss?ngResource ***!
  \************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "input::-webkit-calendar-picker-indicator {\n  width: 10vw;\n  height: 1rem;\n  background: transparent !important;\n  position: absolute;\n  transform: scale(2);\n  color: transparent !important;\n}\n\n.input-style.has-borders.input-style-always-active label {\n  margin-left: 10px !important;\n}\n\n.input-style {\n  margin-bottom: 0 !important;\n}\n\n.input-date-time label {\n  margin-left: 0px !important;\n}\n\n.pos-bottom {\n  position: absolute;\n  bottom: -1.5rem;\n}\n\n@media (max-width: 329px) {\n  .col-6 {\n    width: 100%;\n    margin-bottom: 1rem;\n  }\n  .row {\n    margin-bottom: 50px;\n  }\n  .pos-bottom {\n    bottom: -3.1rem;\n  }\n}", "",{"version":3,"sources":["webpack://./src/app/sites/components/access-point-date/access-point-date.component.scss"],"names":[],"mappings":"AAAA;EACE,WAAA;EACA,YAAA;EACA,kCAAA;EACA,kBAAA;EACA,mBAAA;EACA,6BAAA;AACF;;AAEA;EACE,4BAAA;AACF;;AACA;EACE,2BAAA;AAEF;;AAEE;EACE,2BAAA;AACJ;;AAGA;EACE,kBAAA;EACA,eAAA;AAAF;;AAGA;EACE;IACE,WAAA;IACA,mBAAA;EAAF;EAEA;IACE,mBAAA;EAAF;EAEA;IACE,eAAA;EAAF;AACF","sourcesContent":["input::-webkit-calendar-picker-indicator {\n  width: 10vw;\n  height: 1rem;\n  background: transparent !important;\n  position: absolute;\n  transform: scale(2);\n  color: transparent !important;\n}\n\n.input-style.has-borders.input-style-always-active label {\n  margin-left: 10px !important;\n}\n.input-style {\n  margin-bottom: 0 !important;\n}\n\n.input-date-time {\n  label {\n    margin-left: 0px !important;\n  }\n}\n\n.pos-bottom {\n  position: absolute;\n  bottom: -1.5rem;\n}\n\n@media (max-width: 329px) {\n  .col-6 {\n    width: 100%;\n    margin-bottom: 1rem;\n  }\n  .row {\n    margin-bottom: 50px;\n  }\n  .pos-bottom {\n    bottom: -3.1rem;\n  }\n}\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 92520:
/*!******************************************************************************!*\
  !*** ./src/app/sites/components/new-site/new-site.component.scss?ngResource ***!
  \******************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "input::file-selector-button {\n  background-color: transparent !important;\n  border: none !important;\n  border-right: 1px solid lightgray !important;\n}\n\nul {\n  list-style: none;\n}", "",{"version":3,"sources":["webpack://./src/app/sites/components/new-site/new-site.component.scss"],"names":[],"mappings":"AAAA;EACE,wCAAA;EACA,uBAAA;EACA,4CAAA;AACF;;AAEA;EACE,gBAAA;AACF","sourcesContent":["input::file-selector-button {\n  background-color: transparent !important;\n  border: none !important;\n  border-right: 1px solid lightgray !important;\n}\n\nul {\n  list-style: none;\n}\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 50093:
/*!**********************************************************************************!*\
  !*** ./src/app/sites/components/sites-list/sites-list.component.scss?ngResource ***!
  \**********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 17466:
/*!**********************************************************************!*\
  !*** ./src/app/sites/pages/site-edit/site-edit.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 40699:
/*!***************************************************************************!*\
  !*** ./src/app/sites/pages/site-info/site-info.component.scss?ngResource ***!
  \***************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".slide-bg {\n  height: 25vh;\n  background-repeat: no-repeat;\n  background-size: contain;\n  background-position: center;\n}\n\n::ng-deep .theme-light #walkthrough-slider .is-active {\n  background: transparent !important;\n}\n\n::ng-deep .theme-dark #walkthrough-slider .is-active {\n  background: transparent !important;\n}", "",{"version":3,"sources":["webpack://./src/app/sites/pages/site-info/site-info.component.scss"],"names":[],"mappings":"AAAA;EACE,YAAA;EACA,4BAAA;EACA,wBAAA;EACA,2BAAA;AACF;;AAEA;EACE,kCAAA;AACF;;AACA;EACE,kCAAA;AAEF","sourcesContent":[".slide-bg {\n  height: 25vh;\n  background-repeat: no-repeat;\n  background-size: contain;\n  background-position: center;\n}\n\n::ng-deep .theme-light #walkthrough-slider .is-active {\n  background: transparent !important;\n}\n::ng-deep .theme-dark #walkthrough-slider .is-active {\n  background: transparent !important;\n}\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 87546:
/*!**************************************************************************!*\
  !*** ./src/app/sites/pages/site-wizard/site-wizard.page.scss?ngResource ***!
  \**************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 73963:
/*!**************************************************************!*\
  !*** ./src/app/sites/pages/sites/sites.page.scss?ngResource ***!
  \**************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 44000:
/*!******************************************************************************************************!*\
  !*** ./src/app/sites/components/access-point-address/access-point-address.component.html?ngResource ***!
  \******************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"content mt-0 mx-0\">\n  <h6 class=\"font-400 font-16 pb-3\">{{ 'sites.location' | translate }}</h6>\n\n  <div class=\"input-style input-style-always-active has-borders no-icon validate-field\">\n    <input #addressText type=\"text\" class=\"form-control validate-text\" [(ngModel)]=\"autocomplete.input\" />\n\n    <label class=\"color-theme text-uppercase font-400 font-10\">{{ 'common.address' | translate }}</label>\n    <em class=\"color-highlight opacity-75\" [class.disabled]=\"autocomplete.input !== ''\">{{\n      'common.required' | translate\n    }}</em>\n    <fa-icon\n      *ngIf=\"autocomplete.input !== ''\"\n      [icon]=\"['fas', 'xmark']\"\n      [size]=\"'xl'\"\n      class=\"color-red-dark\"\n      (click)=\"clear()\"></fa-icon>\n  </div>\n  <app-map-info\n    (editClick)=\"mapEditClick.emit()\"\n    [address]=\"selectedPlace?.formatted_address\"\n    [latitude]=\"Number(selectedPlaceCoords[0])\"\n    [longitude]=\"Number(selectedPlaceCoords[1])\"\n    [imgSrc]=\"imgString\"></app-map-info>\n</div>\n";

/***/ }),

/***/ 41394:
/*!************************************************************************************************!*\
  !*** ./src/app/sites/components/access-point-data/access-point-data.component.html?ngResource ***!
  \************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"content mb-6 mt-0 mx-0\">\n  <form [formGroup]=\"accessPointForm\">\n    <h6 class=\"font-400 font-16 pb-3\">Control</h6>\n    <div class=\"input-style input-style-always-active has-borders no-icon mt-3\">\n      <textarea type=\"name\" class=\"form-control validate-text h-150\" formControlName=\"noteAccess\"></textarea>\n      <label id=\"label\" class=\"color-theme text-uppercase font-400 font-10\">{{\n        'common.noteAccess' | translate\n      }}</label>\n      <em class=\"color-highlight opacity-75\">{{ 'common.optional' | translate }}</em>\n    </div>\n    <app-access-form\n      [title]=\"'common.questionTitle' | translate\"\n      [inputs]=\"inputsNew\"\n      [editable]=\"true\"\n      [isAdminOrOwner]=\"true\"\n      [fontClass]=\"'font-16'\"\n      (save)=\"saveForm.emit()\"\n      (saveDeleteInput)=\"deleteInput($event)\"\n      (saveEditInput)=\"editInput($event)\"\n      (saveNewInput)=\"addNewInput($event)\"></app-access-form>\n  </form>\n</div>\n";

/***/ }),

/***/ 96794:
/*!************************************************************************************************!*\
  !*** ./src/app/sites/components/access-point-date/access-point-date.component.html?ngResource ***!
  \************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"content mt-0 mx-0\" *ngIf=\"accessPointForm\">\n  <form [formGroup]=\"accessPointForm\">\n    <h6 class=\"font-400 font-16\">{{ 'sites.timeTitle' | translate }}</h6>\n    <div class=\"row position-relative mb-3\">\n      <div class=\"col-12 d-flex\">\n        <div class=\"pt-1 align-self-center\">\n          <label class=\"color-theme text-uppercase font-400 font-10\">{{ 'invite.allDayLabel' | translate }}</label>\n        </div>\n        <div class=\"ms-auto me-3 align-self-center pe-2\">\n          <app-toggle-switch [control]=\"$any(accessPointForm).controls['allDay']\"></app-toggle-switch>\n        </div>\n      </div>\n      <ng-container *ngIf=\"accessPointForm.get('allDay')?.value === false\">\n        <div class=\"col-6\">\n          <div class=\"input-date-time\">\n            <input type=\"time\" class=\"form-control\" formControlName=\"timeFrom\" />\n            <label class=\"color-theme text-uppercase font-400 font-10 custom-label-margin\">{{\n              'sites.timeFromInput' | translate\n            }}</label>\n            <em *ngIf=\"!accessPointForm.get('timeFrom')?.value\" class=\"color-highlight opacity-75\">{{\n              'common.required' | translate\n            }}</em>\n          </div>\n        </div>\n        <div class=\"col-6\">\n          <div class=\"input-date-time\">\n            <input type=\"time\" class=\"form-control\" formControlName=\"timeTo\" />\n            <label class=\"color-theme text-uppercase font-400 font-10 custom-label-margin\">{{\n              'sites.timeToInput' | translate\n            }}</label>\n            <em *ngIf=\"!accessPointForm.get('timeTo')?.value\" class=\"color-highlight opacity-75\">{{\n              'common.required' | translate\n            }}</em>\n          </div>\n        </div>\n      </ng-container>\n    </div>\n\n    <app-day-select-form [wizard]=\"'site'\"></app-day-select-form>\n  </form>\n</div>\n";

/***/ }),

/***/ 8227:
/*!******************************************************************************!*\
  !*** ./src/app/sites/components/new-site/new-site.component.html?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"content mb-6 mt-0 mx-0\">\n  <form [formGroup]=\"siteForm\" enterFocus>\n    <h6 class=\"font-400 font-16 pb-3\">{{ 'sites.newSiteTitle' | translate }}</h6>\n\n    <div class=\"input-style input-style-always-active has-borders no-icon validate-field\" #nextTab>\n      <input type=\"name\" class=\"form-control validate-text\" formControlName=\"name\" enterkeyhint=\"next\" />\n      <label class=\"color-theme text-uppercase font-400 font-10\">{{ 'common.nameInput' | translate }}</label>\n      <em class=\"color-highlight opacity-75\">{{ 'common.required' | translate }}</em>\n    </div>\n    <div class=\"input-style input-style-always-active has-borders no-icon validate-field mt-3\" #nextTab>\n      <select class=\"form-control\" formControlName=\"category\" enterkeyhint=\"next\">\n        <option *ngFor=\"let c of categoryList\" [value]=\"c.id\">{{ c.name }}</option>\n      </select>\n      <label class=\"color-theme text-uppercase font-400 font-10\">{{ 'common.categoryInput' | translate }}</label>\n      <em class=\"color-highlight opacity-75\">{{ 'common.required' | translate }}</em>\n    </div>\n    <div\n      class=\"input-style input-style-always-active has-borders no-icon\"\n      style=\"position: relative; margin-bottom: 15px\"\n      #nextTab\n      *ngIf=\"isEdit\">\n      <textarea class=\"form-control validate-text h-150\" formControlName=\"description\" rows=\"5\"></textarea>\n      <label class=\"color-theme text-uppercase font-400 font-10\">{{ 'common.descriptionInput' | translate }}</label>\n      <em class=\"color-highlight opacity-75\">{{ 'common.optional' | translate }}</em>\n    </div>\n    <app-img-preview [images]=\"images\" [deleteImages]=\"deleteImages\"></app-img-preview>\n  </form>\n</div>\n";

/***/ }),

/***/ 54780:
/*!**********************************************************************************!*\
  !*** ./src/app/sites/components/sites-list/sites-list.component.html?ngResource ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ng-template #accessTemplate let-s let-isLast=\"isLast\">\n  <app-list-item\n    [id]=\"s.id\"\n    [isLast]=\"isLast\"\n    [title]=\"[s.name]\"\n    [img]=\"s.presentationImg[0].url\"\n    [topTexts]=\"[s.category.name]\"\n    [subText]=\"s.description\"\n    [subTextClass]=\"'truncate-text'\"\n    (clicked)=\"siteClick.emit(s.id)\"\n    [badgeIcon]=\"getBagdeIcon(s)\"\n    [badgeText]=\"getBadgeText(s) | translate\"\n    [bottomButtonIcon]=\"['fas', 'envelope']\"\n    [bottomButtonText]=\"'sites.invitationsTitle' | translate\"\n    (bottomButtonClick)=\"invClick.emit(s.id)\">\n  </app-list-item>\n</ng-template>\n\n<ng-template #loaderTemplate>\n  <app-list-item-skeleton></app-list-item-skeleton>\n</ng-template>\n\n<app-list-container\n  [items]=\"getSitesSortedByAdministrator()\"\n  [itemTemplate]=\"accessTemplate\"\n  [itemLoaderTemplate]=\"loaderTemplate\">\n</app-list-container>\n";

/***/ }),

/***/ 42202:
/*!**********************************************************************!*\
  !*** ./src/app/sites/pages/site-edit/site-edit.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-modal-menu #modal [height]=\"'h-75'\" [static]=\"true\">\n  <ng-template #modalContent>\n    <div class=\"content mb-5\">\n      <a role=\"button\" (click)=\"tryClose()\" class=\"font-16 w-fit color-red-dark float-right position-relative\">\n        <fa-icon [icon]=\"['fas', 'times']\"></fa-icon\n      ></a>\n\n      <app-new-site [categoryList]=\"categoryList\" [isEdit]=\"true\" [hidden]=\"step !== 1\"></app-new-site>\n      <app-access-point-address [hidden]=\"step !== 2\"></app-access-point-address>\n      <app-access-point-data [hidden]=\"step !== 3\"></app-access-point-data>\n      <app-access-point-date-site [hidden]=\"step !== 4\"></app-access-point-date-site>\n\n      <div class=\"pt-3\"></div>\n      <ng-container *ngIf=\"!showKeyboard\">\n        <app-button\n          [status]=\"buttonState\"\n          [label]=\"'common.save' | translate\"\n          (onHide)=\"hide()\"\n          (buttonClick)=\"trySave()\"></app-button>\n      </ng-container>\n      <div class=\"pb-3\"></div>\n    </div>\n  </ng-template>\n</app-modal-menu>\n\n<app-modal-menu #confirmModal [shadow]=\"true\">\n  <ng-template #modalContent>\n    <div class=\"center w-100 p-3\">\n      <h6 class=\"font-400 font-14 pb-3 text-center\">{{ confirmModalTextKey | translate }}</h6>\n      <app-button\n        *ngIf=\"isClosing === false\"\n        class=\"w-fit\"\n        [label]=\"'common.accept' | translate\"\n        [status]=\"buttonState\"\n        (buttonClick)=\"confirmAccept(); confirmModal.hide()\"></app-button>\n      <app-button\n        *ngIf=\"isClosing\"\n        class=\"w-fit\"\n        [label]=\"'common.accept' | translate\"\n        (buttonClick)=\"confirmAccept(); confirmModal.hide()\"></app-button>\n      <div class=\"pt-2\"></div>\n      <app-button\n        class=\"w-fit\"\n        [bgClass]=\"'bg-transparent'\"\n        [customClass]=\"'w-100 border-highlight color-highlight'\"\n        [label]=\"'common.cancel' | translate\"\n        (buttonClick)=\"confirmModal.hide()\"></app-button>\n    </div>\n  </ng-template>\n</app-modal-menu>\n\n<ng-container *ngIf=\"showKeyboard\">\n  <app-button\n    [status]=\"buttonState\"\n    [label]=\"'common.save' | translate\"\n    [customClass]=\"'w-100 button-onkeyboard'\"\n    (onShow)=\"show()\"\n    (buttonClick)=\"trySave()\"></app-button>\n</ng-container>\n";

/***/ }),

/***/ 90055:
/*!***************************************************************************!*\
  !*** ./src/app/sites/pages/site-info/site-info.component.html?ngResource ***!
  \***************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-page-layout [footerSelectedOption]=\"footerOptions.sites\" (back)=\"back.emit()\" [title]=\"site?.name\">\n  <div class=\"card card-style\">\n    <app-carrousel [hidePagination]=\"true\" [(currentStep)]=\"currentStep\" *ngIf=\"site\">\n      <ng-template #slide *ngFor=\"let img of site?.presentationImg\">\n        <div class=\"vh-30\">\n          <app-category-badge\n            class=\"card-top p-3\"\n            [siteCategory]=\"true\"\n            [category]=\"site.category\"></app-category-badge>\n          <div class=\"card-overlay img-gradient\"></div>\n          <app-img [img]=\"img.url\" [imgClass]=\"'img-fluid rounded-0'\"></app-img>\n        </div>\n      </ng-template>\n    </app-carrousel>\n    <ng-container *ngIf=\"!site\">\n      <div class=\"vh-30\">\n        <ngx-skeleton-loader\n          [theme]=\"{\n            border: '1px solid white',\n            height: '100%',\n            width: '100%',\n            'margin-bottom': '0px'\n          }\"></ngx-skeleton-loader>\n      </div>\n    </ng-container>\n\n    <div\n      class=\"content mb-0\"\n      *ngIf=\"site?.description !== undefined && site?.description !== '' && site?.description !== null\">\n      <div class=\"d-flex mb-2\">\n        <p class=\"font-13 m-0\">\n          {{ site?.description }}\n        </p>\n      </div>\n    </div>\n  </div>\n  <div class=\"card card-style\" *ngIf=\"isAdmin || isOwner || isOperator\">\n    <div class=\"content mb-0\">\n      <app-button-panel\n        *ngIf=\"activeButtonPanel && buttonsConfig\"\n        [config]=\"buttonsConfig\"\n        [customClass]=\"buttonPanelClass\"></app-button-panel>\n    </div>\n  </div>\n  <ng-container *ngIf=\"!site\">\n    <div class=\"card card-style\">\n      <div class=\"content mb-0 w-75 align-self-center\">\n        <ngx-skeleton-loader\n          [theme]=\"{\n            border: '1px solid white',\n            height: '100px',\n            width: '100%',\n            'margin-bottom': '0px'\n          }\"></ngx-skeleton-loader>\n      </div>\n    </div>\n  </ng-container>\n  <div class=\"card card-style\" *ngIf=\"invitations && invitations.length > 0\">\n    <div class=\"content\">\n      <h1 class=\"font-400 ls-1\">{{ 'common.invitationsTitle' | translate }}</h1>\n\n      <app-invitation-list\n        [invitations]=\"invitations\"\n        (invClick)=\"guestsClick.emit($event)\"\n        (navigateClick)=\"accessClick.emit($event)\"></app-invitation-list>\n    </div>\n  </div>\n\n  <div class=\"card card-style\">\n    <div class=\"content\">\n      <h1 class=\"font-400 ls-1\">{{ 'sites.siteInfoDoors' | translate }}</h1>\n\n      <ng-container *ngIf=\"accessPoints\">\n        <app-list-item\n          *ngFor=\"let a of accessPoints; let isLast = last\"\n          [id]=\"a.id\"\n          [isLast]=\"isLast\"\n          [topTexts]=\"getRecurrence(a)\"\n          (clicked)=\"accessPointClick.emit($event)\"\n          [title]=\"[a.name]\"\n          [img]=\"a.presentationImg[0]?.url\"\n          [subTextIcon]=\"['fas', 'map-marker']\"\n          [subText]=\"a.address\"\n          [subTextClass]=\"'lh-lg text-truncate vw-text-ellipsis'\">\n        </app-list-item>\n      </ng-container>\n      <ng-container *ngIf=\"!accessPoints\">\n        <app-list-item-skeleton *ngFor=\"let item of [1, 2]\"></app-list-item-skeleton>\n      </ng-container>\n    </div>\n  </div>\n</app-page-layout>\n\n<app-access-selection\n  #selection\n  [invitations]=\"invitations\"\n  (newInvitation)=\"newInvitation.emit()\"\n  (newInvite)=\"newInvite.emit($event)\"></app-access-selection>\n";

/***/ }),

/***/ 66974:
/*!**************************************************************************!*\
  !*** ./src/app/sites/pages/site-wizard/site-wizard.page.html?ngResource ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-page-layout\n  [footerSelectedOption]=\"footerOptions.sites\"\n  [title]=\"'common.sitesTitle'|translate\"\n  (back)=\"backStep()\"\n  [hideFooter]=\"true\">\n  <app-wizard-steps [steps]=\"steps\" [currentStep]=\"currentStep\" (stepClick)=\"backStep($event)\"></app-wizard-steps>\n\n  <div class=\"card card-style min-vh-70\">\n    <div class=\"content mb-5\" [@animSlider]=\"currentStep\">\n      <app-new-site [categoryList]=\"categoryList\" [hidden]=\"currentStep !== 1\"></app-new-site>\n      <app-access-point-address [hidden]=\"currentStep !== 2\"></app-access-point-address>\n      <!-- <app-access-point-data [hidden]=\"currentStep !== 3\"></app-access-point-data> -->\n      <!-- <app-access-point-date-site [hidden]=\"currentStep !== 3\"></app-access-point-date-site> -->\n    </div>\n    <div class=\"card-bottom pb-3 px-3\">\n      <ng-container *ngIf=\"!showKeyboard\">\n        <app-button\n          [status]=\"buttonState\"\n          (buttonClick)=\"nextStep()\"\n          (onHide)=\"hide()\"\n          [label]=\"currentStep !== steps.length ? ('common.nextStep' | translate) : ('common.newAccessSave' | translate)\"></app-button>\n      </ng-container>\n    </div>\n  </div>\n  <ng-container *ngIf=\"showKeyboard\">\n    <app-button\n      [status]=\"buttonState\"\n      [customClass]=\"'w-100 button-onkeyboard'\"\n      (buttonClick)=\"nextStep()\"\n      (onShow)=\"show()\"\n      [label]=\"currentStep !== steps.length ? ('common.nextStep' | translate) : ('common.newAccessSave' | translate)\"></app-button>\n  </ng-container>\n</app-page-layout>\n";

/***/ }),

/***/ 93497:
/*!**************************************************************!*\
  !*** ./src/app/sites/pages/sites/sites.page.html?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-page-layout [footerSelectedOption]=\"footerOptions.sites\" [hideBack]=\"true\" [title]=\"'common.sitesTitle'|translate\">\n  <app-searchbox [placeholder]=\"'common.searchdotdotdot'|translate\" (search)=\"search.emit($event)\"></app-searchbox>\n  <app-banner\n    [title]=\"'sites.bannerTitle'|translate\"\n    [descrip]=\"'sites.bannerDescription'|translate\"\n    [faClass]=\"'star'\"\n    [iconColor]=\"'color-highlight'\"\n    [iconSize]=\"'xl'\"\n    (bannerClick)=\"bannerClick.emit()\"></app-banner>\n  <app-sites-list\n    [sites]=\"sites\"\n    (invClick)=\"invClick.emit($event)\"\n    (siteClick)=\"siteClick.emit($event)\"></app-sites-list>\n</app-page-layout>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_sites_sites_module_ts.js.map