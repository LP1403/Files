(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_onboarding_onboarding_module_ts"],{

/***/ 59307:
/*!************************************************************************!*\
  !*** ./src/app/onboarding/components/pin-input/pin-input.component.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PinInputComponent": () => (/* binding */ PinInputComponent)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _pin_input_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pin-input.component.html?ngResource */ 86413);
/* harmony import */ var _pin_input_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pin-input.component.scss?ngResource */ 63415);
/* harmony import */ var _pin_input_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pin_input_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var _capacitor_keyboard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor/keyboard */ 60971);
/* harmony import */ var src_app_shared_services_template_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/services/template.service */ 9101);

var _class;







let PinInputComponent = (_class = class PinInputComponent {
  constructor(fb, templateService) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "fb", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "templateService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "pinCode", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "pinInvalid", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "pinCodeChange", new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "enterKey", new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "inputs", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "numOfDigits", 6);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "confirmCodeForm", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "digits", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "faClass", ['far', 'message']);
    this.fb = fb;
    this.templateService = templateService;
    this.digits = this.fb.array([]);
    this.confirmCodeForm = this.fb.group({
      digits: this.digits
    });
  }
  get showPinInvalidMsg() {
    return this.pinInvalid && !this.showPinEmptyMsg;
  }
  get showPinEmptyMsg() {
    return this.digits.getRawValue().join('').length < this.numOfDigits;
  }
  ngOnInit() {
    this.initForm();
  }
  initForm() {
    this.digits = this.fb.array([]);
    this.confirmCodeForm = this.fb.group({
      digits: this.digits
    });
    for (let i = 0; i < this.numOfDigits; i++) {
      if (i < this.numOfDigits / 2) this.digits.push(this.fb.control({
        value: Number(this.pinCode[i]),
        disabled: true
      }));else this.digits.push(this.fb.control(null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required));
    }
  }
  check(index, field, event) {
    if (event.data !== null) {
      if (isNaN(parseInt(event.data, 10)) && event.data !== 'undefined') {
        event.preventDefault();
        return;
      }
    }
    if (field.value) {
      if (index < this.inputs.toArray().length - 1) {
        this.inputs.toArray()[index + 1].nativeElement.focus();
      }
      if (field.value !== event.data) {
        field.setValue(event.data);
      }
    }
    this.pinCodeChange.emit(this.digits.getRawValue().join(''));
  }
  checkKey(index, field, event) {
    if (event.key === 'Enter') {
      this.onEnter();
    }
    if (event.key === 'Backspace') {
      if (index > 0) {
        field.setValue(null);
        this.inputs.toArray()[index - 1].nativeElement.focus();
      }
    }
  }
  onEnter() {
    if (this.templateService.isPlatformMobile()) {
      _capacitor_keyboard__WEBPACK_IMPORTED_MODULE_3__.Keyboard.hide();
      setTimeout(() => {
        this.enterKey.emit();
      }, 250);
    } else {
      this.enterKey.emit();
    }
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder
}, {
  type: src_app_shared_services_template_service__WEBPACK_IMPORTED_MODULE_4__.TemplateService
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  pinCode: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input
  }],
  pinInvalid: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input
  }],
  pinCodeChange: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output
  }],
  enterKey: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output
  }],
  inputs: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.ViewChildren,
    args: ['inputs']
  }]
}), _class);
PinInputComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
  selector: 'app-pin-input',
  template: _pin_input_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_pin_input_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], PinInputComponent);


/***/ }),

/***/ 54947:
/*!********************************************************************************!*\
  !*** ./src/app/onboarding/components/splash-button/splash-button.component.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SplashButtonComponent": () => (/* binding */ SplashButtonComponent)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _splash_button_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./splash-button.component.html?ngResource */ 43036);
/* harmony import */ var _splash_button_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./splash-button.component.scss?ngResource */ 41915);
/* harmony import */ var _splash_button_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_splash_button_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51197);

var _class;




let SplashButtonComponent = (_class = class SplashButtonComponent {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "label", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "class", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "disabled", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "buttonClick", new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter());
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => []), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  label: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input
  }],
  class: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input
  }],
  disabled: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input
  }],
  buttonClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output
  }]
}), _class);
SplashButtonComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
  selector: 'app-splash-button',
  template: _splash_button_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_splash_button_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], SplashButtonComponent);


/***/ }),

/***/ 45006:
/*!*********************************************************!*\
  !*** ./src/app/onboarding/onboarding-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OnboardingRoutingModule": () => (/* binding */ OnboardingRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _pages_name_login_name_login_business__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pages/name-login/name-login.business */ 82245);
/* harmony import */ var _pages_no_pin_splash_no_pin_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pages/no-pin/splash-no-pin.page */ 47428);
/* harmony import */ var _pages_phone_login_phone_login_business__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pages/phone-login/phone-login.business */ 62511);
/* harmony import */ var _pages_phone_validation_phone_validation_business__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/phone-validation/phone-validation.business */ 31313);
/* harmony import */ var _pages_terms_conditions_terms_conditions_business__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/terms-conditions/terms-conditions.business */ 47954);
/* harmony import */ var _pages_splash_splash_business__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages/splash/splash.business */ 78380);









const routes = [{
  path: '',
  redirectTo: 'splash',
  pathMatch: 'full'
}, {
  path: 'splash',
  component: _pages_splash_splash_business__WEBPACK_IMPORTED_MODULE_5__.SplashBusiness
}, {
  path: 'no-pin',
  component: _pages_no_pin_splash_no_pin_page__WEBPACK_IMPORTED_MODULE_1__.SplashNoPinPage
}, {
  path: 'phone',
  component: _pages_phone_login_phone_login_business__WEBPACK_IMPORTED_MODULE_2__.PhoneLoginBusiness
}, {
  path: 'validate',
  component: _pages_phone_validation_phone_validation_business__WEBPACK_IMPORTED_MODULE_3__.PhoneValidationBusiness
}, {
  path: 'name',
  component: _pages_name_login_name_login_business__WEBPACK_IMPORTED_MODULE_0__.NameLoginBusiness
}, {
  path: 'terms',
  component: _pages_terms_conditions_terms_conditions_business__WEBPACK_IMPORTED_MODULE_4__.TermsConditionsBusiness
}];
let OnboardingRoutingModule = class OnboardingRoutingModule {};
OnboardingRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.NgModule)({
  imports: [_angular_router__WEBPACK_IMPORTED_MODULE_8__.RouterModule.forChild(routes)],
  exports: [_angular_router__WEBPACK_IMPORTED_MODULE_8__.RouterModule]
})], OnboardingRoutingModule);


/***/ }),

/***/ 68207:
/*!*************************************************!*\
  !*** ./src/app/onboarding/onboarding.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OnboardingModule": () => (/* binding */ OnboardingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 89650);
/* harmony import */ var _pages_splash_splash_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pages/splash/splash.page */ 10759);
/* harmony import */ var _pages_no_pin_splash_no_pin_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pages/no-pin/splash-no-pin.page */ 47428);
/* harmony import */ var _onboarding_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./onboarding-routing.module */ 45006);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../shared/shared.module */ 56208);
/* harmony import */ var _pages_phone_login_phone_login_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/phone-login/phone-login.page */ 98253);
/* harmony import */ var _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @fortawesome/angular-fontawesome */ 30708);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var _pages_phone_login_phone_login_business__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages/phone-login/phone-login.business */ 62511);
/* harmony import */ var _pages_name_login_name_login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pages/name-login/name-login.page */ 97802);
/* harmony import */ var _pages_name_login_name_login_business__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./pages/name-login/name-login.business */ 82245);
/* harmony import */ var _pages_phone_validation_phone_validation_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./pages/phone-validation/phone-validation.page */ 54274);
/* harmony import */ var _components_pin_input_pin_input_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/pin-input/pin-input.component */ 59307);
/* harmony import */ var _pages_phone_validation_phone_validation_business__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./pages/phone-validation/phone-validation.business */ 31313);
/* harmony import */ var _components_splash_button_splash_button_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./components/splash-button/splash-button.component */ 54947);
/* harmony import */ var _pages_splash_splash_business__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./pages/splash/splash.business */ 78380);


















let OnboardingModule = class OnboardingModule {};
OnboardingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.NgModule)({
  declarations: [_pages_splash_splash_page__WEBPACK_IMPORTED_MODULE_0__.SplashPage, _pages_no_pin_splash_no_pin_page__WEBPACK_IMPORTED_MODULE_1__.SplashNoPinPage, _pages_phone_login_phone_login_page__WEBPACK_IMPORTED_MODULE_4__.PhoneLoginPage, _pages_phone_login_phone_login_business__WEBPACK_IMPORTED_MODULE_5__.PhoneLoginBusiness, _pages_name_login_name_login_page__WEBPACK_IMPORTED_MODULE_6__.NameLoginPage, _pages_name_login_name_login_business__WEBPACK_IMPORTED_MODULE_7__.NameLoginBusiness, _pages_phone_validation_phone_validation_page__WEBPACK_IMPORTED_MODULE_8__.PhoneValidationPage, _components_pin_input_pin_input_component__WEBPACK_IMPORTED_MODULE_9__.PinInputComponent, _pages_phone_validation_phone_validation_business__WEBPACK_IMPORTED_MODULE_10__.PhoneValidationBusiness, _components_splash_button_splash_button_component__WEBPACK_IMPORTED_MODULE_11__.SplashButtonComponent, _pages_splash_splash_business__WEBPACK_IMPORTED_MODULE_12__.SplashBusiness],
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_15__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.FormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.ReactiveFormsModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_3__.SharedModule, _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_17__.FontAwesomeModule],
  exports: [_onboarding_routing_module__WEBPACK_IMPORTED_MODULE_2__.OnboardingRoutingModule, _pages_phone_login_phone_login_page__WEBPACK_IMPORTED_MODULE_4__.PhoneLoginPage, _pages_name_login_name_login_page__WEBPACK_IMPORTED_MODULE_6__.NameLoginPage, _components_pin_input_pin_input_component__WEBPACK_IMPORTED_MODULE_9__.PinInputComponent, _pages_phone_validation_phone_validation_page__WEBPACK_IMPORTED_MODULE_8__.PhoneValidationPage, _components_splash_button_splash_button_component__WEBPACK_IMPORTED_MODULE_11__.SplashButtonComponent, _pages_splash_splash_page__WEBPACK_IMPORTED_MODULE_0__.SplashPage, _pages_no_pin_splash_no_pin_page__WEBPACK_IMPORTED_MODULE_1__.SplashNoPinPage]
})], OnboardingModule);


/***/ }),

/***/ 82245:
/*!********************************************************************!*\
  !*** ./src/app/onboarding/pages/name-login/name-login.business.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NameLoginBusiness": () => (/* binding */ NameLoginBusiness)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _capacitor_device__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/device */ 1793);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 51547);
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/auth/auth.service */ 75148);
/* harmony import */ var src_app_shared_components_floating_msg_floating_msg_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/components/floating-msg/floating-msg.component */ 50983);
/* harmony import */ var src_app_shared_models_MsgConfig__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/models/MsgConfig */ 34391);
/* harmony import */ var src_app_shared_models_UserViewModel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/models/UserViewModel */ 17065);
/* harmony import */ var src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/user.service */ 31880);


var _class;













let NameLoginBusiness = (_class = class NameLoginBusiness {
  constructor(traslate, navController, userService, route, authService) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "traslate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "route", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "authService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "toast", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "name", new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl(null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required));
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "phone", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "hasErrors", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "loading", false);
    this.traslate = traslate;
    this.navController = navController;
    this.userService = userService;
    this.route = route;
    this.authService = authService;
  }
  ngOnInit() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.route.queryParams.subscribe(params => {
        _this.phone = params.phone;
      });
    })();
  }
  continue() {
    var _this2 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log(_this2.name);
      if (_this2.name.valid) {
        _this2.loading = true;
        const term = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.lastValueFrom)(_this2.userService.getTerm());
        const info = yield _capacitor_device__WEBPACK_IMPORTED_MODULE_2__.Device.getInfo();
        const userData = new src_app_shared_models_UserViewModel__WEBPACK_IMPORTED_MODULE_6__.UserViewModel();
        userData.name = _this2.name.value;
        userData.termId = term?.data.id;
        userData.phone = _this2.phone;
        userData.deviceFingerPrint = JSON.stringify(info);
        userData.userId = crypto.randomUUID();
        const user = yield _this2.userService.saveUser(userData).toPromise();
        if (user?.error === null) {
          _this2.authService.saveToken(user.data.sessionToken.token);
          _this2.authService.saveRefreshToken(user.data.sessionToken.refreshToken);
          _this2.userService.setUserLoggedIn(user.data.user, true);
          _this2.navController.navigateRoot('access');
        } else {
          _this2.showErrorToast('ERROR');
        }
      } else {
        _this2.showErrorToast();
      }
    })();
  }
  back() {
    this.navController.navigateForward('onboarding/validate');
  }
  showErrorToast(msg) {
    const config = new src_app_shared_models_MsgConfig__WEBPACK_IMPORTED_MODULE_5__.MsgConfig();
    config.message = msg !== null ? msg : this.traslate.instant('onboarding.nameToastMsg');
    config.bgClass = 'bg-red-light';
    config.faaClass = 'circle-exclamation';
    this.toast.show(config);
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__.TranslateService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.NavController
}, {
  type: src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_7__.UserService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.ActivatedRoute
}, {
  type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "propDecorators", {
  toast: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_13__.ViewChild,
    args: [src_app_shared_components_floating_msg_floating_msg_component__WEBPACK_IMPORTED_MODULE_4__.FloatingMsgComponent]
  }]
}), _class);
NameLoginBusiness = (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.Component)({
  selector: 'app-name-login-business',
  template: ` <app-name-login
      [name]="name"
      [loading]="loading"
      (continue)="continue()"
      (back)="back()"></app-name-login>
    <app-floating-msg></app-floating-msg>`
})], NameLoginBusiness);


/***/ }),

/***/ 97802:
/*!****************************************************************!*\
  !*** ./src/app/onboarding/pages/name-login/name-login.page.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NameLoginPage": () => (/* binding */ NameLoginPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _name_login_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./name-login.page.html?ngResource */ 976);
/* harmony import */ var _name_login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./name-login.page.scss?ngResource */ 98794);
/* harmony import */ var _name_login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_name_login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var src_app_shared_services_template_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/services/template.service */ 9101);
/* harmony import */ var src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/components/button/button.component */ 62490);

var _class;






let NameLoginPage = (_class = class NameLoginPage {
  constructor(template, cdRef) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "template", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "cdRef", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "name", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "loading", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "nameChange", new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "continue", new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "back", new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "hideButton", false);
    this.template = template;
    this.cdRef = cdRef;
  }
  get buttonState() {
    if (this.name.invalid) {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_4__.ButtonState.disabled;
    } else if (!this.loading) {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_4__.ButtonState.enabled;
    } else {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_4__.ButtonState.loading;
    }
  }
  ngOnInit() {
    this.template.cardExtender();
  }
  hide() {
    this.hideButton = true;
    this.cdRef.detectChanges();
  }
  show() {
    this.hideButton = false;
    this.cdRef.detectChanges();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_services_template_service__WEBPACK_IMPORTED_MODULE_3__.TemplateService
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.ChangeDetectorRef
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  name: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input
  }],
  loading: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input
  }],
  nameChange: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output
  }],
  continue: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output
  }],
  back: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output
  }]
}), _class);
NameLoginPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
  selector: 'app-name-login',
  template: _name_login_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_name_login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], NameLoginPage);


/***/ }),

/***/ 47428:
/*!***************************************************************!*\
  !*** ./src/app/onboarding/pages/no-pin/splash-no-pin.page.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SplashNoPinPage": () => (/* binding */ SplashNoPinPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _splash_no_pin_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./splash-no-pin.page.html?ngResource */ 68315);
/* harmony import */ var _splash_no_pin_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./splash-no-pin.page.scss?ngResource */ 9955);
/* harmony import */ var _splash_no_pin_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_splash_no_pin_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var src_app_shared_services_template_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/services/template.service */ 9101);

var _class;





let SplashNoPinPage = (_class = class SplashNoPinPage {
  constructor(template) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "template", void 0);
    this.template = template;
  }
  ngOnInit() {
    this.template.cardExtender();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_services_template_service__WEBPACK_IMPORTED_MODULE_3__.TemplateService
}]), _class);
SplashNoPinPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
  selector: 'app-splash-no-pin',
  template: _splash_no_pin_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_splash_no_pin_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], SplashNoPinPage);


/***/ }),

/***/ 62511:
/*!**********************************************************************!*\
  !*** ./src/app/onboarding/pages/phone-login/phone-login.business.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PhoneLoginBusiness": () => (/* binding */ PhoneLoginBusiness)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var src_app_shared_components_floating_msg_floating_msg_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/components/floating-msg/floating-msg.component */ 50983);
/* harmony import */ var src_app_shared_models_MsgConfig__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/models/MsgConfig */ 34391);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/services/user.service */ 31880);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var google_libphonenumber__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! google-libphonenumber */ 62922);
/* harmony import */ var google_libphonenumber__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(google_libphonenumber__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/auth/auth.service */ 75148);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 51547);
/* harmony import */ var src_app_shared_services_firebase_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/services/firebase.service */ 11750);


var _class;













const phoneNumberUtil = google_libphonenumber__WEBPACK_IMPORTED_MODULE_7__.PhoneNumberUtil.getInstance();
let PhoneLoginBusiness = (_class = class PhoneLoginBusiness {
  constructor(traslate, navController, userService, router, authService, firebaseService) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "traslate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "router", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "authService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "firebaseService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "toast", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "phone", new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl(null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required));
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "terms", new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl(false, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.requiredTrue));
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "hasErrors", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "loading", false);
    this.traslate = traslate;
    this.navController = navController;
    this.userService = userService;
    this.router = router;
    this.authService = authService;
    this.firebaseService = firebaseService;
  }
  ngOnInit() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      //Levanto la configuracion del remote config
      yield _this.firebaseService.initializeConfig();
      //Ahora que ya tengo configuracion puedo empezar a hablar con el backend.
      if (!_this.authService.hasUserDataSnapshot()) {
        const ret = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.lastValueFrom)(_this.authService.getAnomToken());
        if (ret.error === null) {
          _this.authService.saveAnomToken(ret.data.token);
          _this.authService.saveRefreshToken(ret.data.refreshToken);
        } else {
          console.log(ret.error);
        }
      }
    })();
  }
  ionViewWillEnter() {
    this.loading = false;
  }
  continue() {
    var _this2 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let phone;
      _this2.phone.markAllAsTouched();
      if (_this2.phone.valid && _this2.terms.valid) {
        _this2.loading = true;
        if (_this2.phone.value) {
          phone = _this2.formatArgPhones(_this2.phone.value);
          console.log(phone);
          const parsedPhoneNumber = phoneNumberUtil.parseAndKeepRawInput(phone.number, phone.countryCode);
          if (phoneNumberUtil.isValidNumber(parsedPhoneNumber)) {
            const e164FormattedNumber = phoneNumberUtil.format(parsedPhoneNumber, google_libphonenumber__WEBPACK_IMPORTED_MODULE_7__.PhoneNumberFormat.E164);
            _this2.userService.savePhoneInfo(phone);
            _this2.router.navigate(['onboarding/validate'], {
              queryParams: {
                numberPhone: e164FormattedNumber
              }
            });
          } else {
            console.log('Invalid phone number.');
          }
        }
      } else {
        if (_this2.phone.hasError('required') || _this2.phone.hasError('validatePhoneNumber')) {
          _this2.showErrorToast('onboarding.phoneToastMsg');
        }
        if (_this2.terms.invalid) {
          _this2.showErrorToast('onboarding.termsToastMsg');
        }
      }
    })();
  }
  back() {
    this.navController.navigateForward('onboarding/splash');
  }
  showErrorToast(desc) {
    const config = new src_app_shared_models_MsgConfig__WEBPACK_IMPORTED_MODULE_3__.MsgConfig();
    config.message = this.traslate.instant(desc);
    config.bgClass = 'bg-red-light';
    config.faaClass = 'circle-exclamation';
    this.toast.show(config);
  }
  formatArgPhones(phone) {
    if (phone.countryCode === 'AR') {
      if (!phone.number.startsWith('9')) {
        phone.number = `9 ${phone.number}`;
      }
    }
    return phone;
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__.TranslateService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.NavController
}, {
  type: src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_4__.UserService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.Router
}, {
  type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_5__.AuthService
}, {
  type: src_app_shared_services_firebase_service__WEBPACK_IMPORTED_MODULE_6__.FirebaseService
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "propDecorators", {
  toast: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_13__.ViewChild,
    args: [src_app_shared_components_floating_msg_floating_msg_component__WEBPACK_IMPORTED_MODULE_2__.FloatingMsgComponent]
  }]
}), _class);
PhoneLoginBusiness = (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.Component)({
  selector: 'app-phone-login-business',
  template: `<app-phone-login
      [phone]="phone"
      [terms]="terms"
      [loading]="loading"
      (continue)="continue()"
      (back)="back()"></app-phone-login>
    <app-floating-msg></app-floating-msg> `
})], PhoneLoginBusiness);


/***/ }),

/***/ 98253:
/*!******************************************************************!*\
  !*** ./src/app/onboarding/pages/phone-login/phone-login.page.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PhoneLoginPage": () => (/* binding */ PhoneLoginPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _phone_login_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./phone-login.page.html?ngResource */ 86618);
/* harmony import */ var _phone_login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./phone-login.page.scss?ngResource */ 98702);
/* harmony import */ var _phone_login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_phone_login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/button/button.component */ 62490);
/* harmony import */ var src_app_shared_services_template_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/services/template.service */ 9101);

var _class;






let PhoneLoginPage = (_class = class PhoneLoginPage {
  constructor(template, cdRef) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "template", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "cdRef", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "phone", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "terms", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "loading", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "termsChange", new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "continue", new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "back", new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "hideButton", false);
    this.template = template;
    this.cdRef = cdRef;
  }
  get buttonState() {
    if (this.phone.invalid || this.terms.invalid) {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_3__.ButtonState.disabled;
    } else if (!this.loading) {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_3__.ButtonState.enabled;
    } else {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_3__.ButtonState.loading;
    }
  }
  ngOnInit() {
    this.template.cardExtender();
  }
  hide() {
    this.hideButton = true;
    this.cdRef.detectChanges();
  }
  show() {
    this.hideButton = false;
    this.cdRef.detectChanges();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_services_template_service__WEBPACK_IMPORTED_MODULE_4__.TemplateService
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.ChangeDetectorRef
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  phone: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input
  }],
  terms: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input
  }],
  loading: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input
  }],
  termsChange: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output
  }],
  continue: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output
  }],
  back: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output
  }]
}), _class);
PhoneLoginPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
  selector: 'app-phone-login',
  template: _phone_login_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_phone_login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], PhoneLoginPage);


/***/ }),

/***/ 31313:
/*!********************************************************************************!*\
  !*** ./src/app/onboarding/pages/phone-validation/phone-validation.business.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PhoneValidationBusiness": () => (/* binding */ PhoneValidationBusiness)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var src_app_shared_components_floating_msg_floating_msg_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/components/floating-msg/floating-msg.component */ 50983);
/* harmony import */ var src_app_shared_models_MsgConfig__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/models/MsgConfig */ 34391);
/* harmony import */ var src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/services/user.service */ 31880);
/* harmony import */ var _phone_validation_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./phone-validation.page */ 54274);
/* harmony import */ var src_app_shared_models_TempPhoneCodeViewModel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/models/TempPhoneCodeViewModel */ 35312);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var src_app_shared_models_UserViewModel__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/models/UserViewModel */ 17065);
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/auth/auth.service */ 75148);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 51547);
/* harmony import */ var _capacitor_firebase_analytics__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @capacitor-firebase/analytics */ 66081);


var _class;














let PhoneValidationBusiness = (_class = class PhoneValidationBusiness {
  constructor(traslate, navController, userService, route, router, authService) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "traslate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "route", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "router", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "authService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "toast", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "page", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "expiration", 60 * 2);
    //60 segs * 2 = 2 minutos
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "pinCode", '');
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "phoneNumber", '');
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "phoneCode", new src_app_shared_models_TempPhoneCodeViewModel__WEBPACK_IMPORTED_MODULE_6__.TempPhoneCodeViewModel());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "user", new src_app_shared_models_UserViewModel__WEBPACK_IMPORTED_MODULE_7__.UserViewModel());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "loading", false);
    this.traslate = traslate;
    this.navController = navController;
    this.userService = userService;
    this.route = route;
    this.router = router;
    this.authService = authService;
  }
  ngOnInit() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.route.queryParams.subscribe( /*#__PURE__*/function () {
        var _ref = (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (params) {
          _this.phoneNumber = params.numberPhone;
          const result = yield _this.userService.getPhoneCode(_this.phoneNumber).toPromise();
          if (result) {
            _this.phoneCode = result.data;
            _this.pinCode = _this.phoneCode.code;
          }
        });
        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }());
    })();
  }
  continue() {
    var _this2 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log(_this2.pinCode);
      if (_this2.pinCode !== null && _this2.pinCode.length === 6) {
        _this2.phoneCode.code = _this2.pinCode;
        _this2.loading = true;
        const result = yield _this2.userService.postPhoneValidate(_this2.phoneCode).toPromise();
        if (result?.error == null) {
          //Pruebo analytics
          yield _capacitor_firebase_analytics__WEBPACK_IMPORTED_MODULE_9__.FirebaseAnalytics.setUserId({
            userId: _this2.phoneNumber
          });
          if (result?.data.user == null) {
            _this2.loading = false;
            _this2.router.navigate(['onboarding/name'], {
              queryParams: {
                phone: _this2.phoneNumber
              }
            });
          } else {
            if (result?.data.sessionToken != null) {
              _this2.authService.saveToken(result?.data.sessionToken.token);
              _this2.authService.saveRefreshToken(result?.data.sessionToken.refreshToken);
            }
            _this2.userService.setUserLoggedIn(result.data.user, false);
            _this2.loading = false;
            _this2.navController.navigateRoot('access');
          }
        } else {
          if (result.code === 800) {
            _this2.showErrorToast(_this2.traslate.instant('onboarding.pinIncorrect'));
          }
          if (result.code === 801) {
            _this2.showErrorToast(_this2.traslate.instant('onboarding.pinIncorrect'));
          }
          _this2.loading = false;
        }
      } else {
        _this2.showErrorToast(_this2.traslate.instant('onboarding.pinEmptyToastMsg'));
      }
    })();
  }
  resend() {
    var _this3 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this3.pinCode = '';
      const result = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.lastValueFrom)(_this3.userService.getPhoneCode(_this3.phoneNumber));
      if (result.error === null) {
        _this3.phoneCode = result.data;
        _this3.pinCode = _this3.phoneCode.code;
        _this3.showSuccessToast(_this3.traslate.instant('onboarding.validateSuccessToastMsg'));
      }
    })();
  }
  back() {
    this.navController.navigateForward('onboarding/phone');
  }
  showErrorToast(message) {
    const config = new src_app_shared_models_MsgConfig__WEBPACK_IMPORTED_MODULE_3__.MsgConfig();
    config.message = message;
    config.bgClass = 'bg-red-light';
    config.faaClass = 'circle-exclamation';
    this.toast.show(config);
  }
  showSuccessToast(message) {
    const config = new src_app_shared_models_MsgConfig__WEBPACK_IMPORTED_MODULE_3__.MsgConfig();
    config.message = message;
    config.bgClass = 'bg-green-light';
    config.faaClass = 'circle-check';
    this.toast.show(config);
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__.TranslateService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.NavController
}, {
  type: src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_4__.UserService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_13__.ActivatedRoute
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_13__.Router
}, {
  type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_8__.AuthService
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "propDecorators", {
  toast: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_14__.ViewChild,
    args: [src_app_shared_components_floating_msg_floating_msg_component__WEBPACK_IMPORTED_MODULE_2__.FloatingMsgComponent]
  }],
  page: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_14__.ViewChild,
    args: [_phone_validation_page__WEBPACK_IMPORTED_MODULE_5__.PhoneValidationPage]
  }]
}), _class);
PhoneValidationBusiness = (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_14__.Component)({
  selector: 'app-phone-validation-business',
  template: `<app-phone-validation
      [secondsExpiration]="expiration"
      [(pinCode)]="pinCode"
      [loading]="loading"
      (back)="back()"
      (continue)="continue()"
      (resendCode)="resend()"></app-phone-validation>
    <app-floating-msg></app-floating-msg>`
})], PhoneValidationBusiness);


/***/ }),

/***/ 54274:
/*!****************************************************************************!*\
  !*** ./src/app/onboarding/pages/phone-validation/phone-validation.page.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PhoneValidationPage": () => (/* binding */ PhoneValidationPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _phone_validation_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./phone-validation.page.html?ngResource */ 96839);
/* harmony import */ var _phone_validation_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./phone-validation.page.scss?ngResource */ 6670);
/* harmony import */ var _phone_validation_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_phone_validation_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var src_app_shared_services_template_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/services/template.service */ 9101);
/* harmony import */ var _components_pin_input_pin_input_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/pin-input/pin-input.component */ 59307);
/* harmony import */ var src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/components/button/button.component */ 62490);

var _class;







let PhoneValidationPage = (_class = class PhoneValidationPage {
  constructor(template, cdRef) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "template", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "cdRef", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "pinCode", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "pinInvalid", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "secondsExpiration", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "loading", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "pinCodeChange", new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "continue", new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "resendCode", new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "back", new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "pinInput", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "expirationCounter", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "timeExpired", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "hideCounter", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "hideButton", false);
    this.template = template;
    this.cdRef = cdRef;
  }
  get buttonState() {
    if (this.pinCode === null || this.pinCode.length !== 6) {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_5__.ButtonState.disabled;
    } else if (!this.loading) {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_5__.ButtonState.enabled;
    } else {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_5__.ButtonState.loading;
    }
  }
  ngOnInit() {
    this.template.cardExtender();
  }
  ngAfterViewInit() {
    if (this.timeExpired === false) this.startTimer();
  }
  resetForm() {
    this.pinInput.initForm();
  }
  hide() {
    this.hideButton = true;
    this.hideCounter = true;
    this.cdRef.detectChanges();
  }
  show() {
    this.hideButton = false;
    this.hideCounter = false;
    this.cdRef.detectChanges();
  }
  startTimer() {
    let start = this.secondsExpiration;
    let h;
    let m;
    let s;
    let temp;
    const timer = setInterval(() => {
      h = Math.floor(start / 60 / 60);
      // remove the hours
      temp = start - h * 60 * 60;
      m = Math.floor(temp / 60);
      // remove the minutes
      temp = temp - m * 60;
      // what left is the seconds
      s = temp;
      // add leading zeros for aesthetics
      const minute = m < 10 ? '0' + m : m;
      const second = s < 10 ? '0' + s : s;
      this.expirationCounter = minute + ':' + second;
      if (start <= 0) {
        // Time elapsed
        clearInterval(timer);
        // Make here changes in gui when time elapsed
        this.timeExpired = true;
      }
      start--;
    }, 1000);
  }
  resend() {
    this.startTimer();
    setTimeout(() => {
      this.timeExpired = false;
    }, 1000);
    this.resendCode.emit();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_services_template_service__WEBPACK_IMPORTED_MODULE_3__.TemplateService
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ChangeDetectorRef
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  pinCode: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Input
  }],
  pinInvalid: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Input
  }],
  secondsExpiration: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Input
  }],
  loading: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Input
  }],
  pinCodeChange: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Output
  }],
  continue: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Output
  }],
  resendCode: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Output
  }],
  back: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Output
  }],
  pinInput: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild,
    args: [_components_pin_input_pin_input_component__WEBPACK_IMPORTED_MODULE_4__.PinInputComponent]
  }]
}), _class);
PhoneValidationPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
  selector: 'app-phone-validation',
  template: _phone_validation_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_phone_validation_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], PhoneValidationPage);


/***/ }),

/***/ 78380:
/*!************************************************************!*\
  !*** ./src/app/onboarding/pages/splash/splash.business.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SplashBusiness": () => (/* binding */ SplashBusiness)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _capacitor_clipboard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/clipboard */ 24721);
/* harmony import */ var src_app_app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/app.component */ 66401);
/* harmony import */ var _capacitor_firebase_analytics__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor-firebase/analytics */ 66081);


var _class;






let SplashBusiness = (_class = class SplashBusiness {
  constructor(navController) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "imageClickCount", 0);
    this.navController = navController;
  }
  imageClick() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.imageClickCount++;
      if (_this.imageClickCount > 4) {
        yield _capacitor_firebase_analytics__WEBPACK_IMPORTED_MODULE_4__.FirebaseAnalytics.logEvent({
          name: 'GetInstallationID'
        });
        _capacitor_clipboard__WEBPACK_IMPORTED_MODULE_2__.Clipboard.write({
          string: src_app_app_component__WEBPACK_IMPORTED_MODULE_3__.AppComponent.installationID ?? 'no installation id'
        });
      }
    })();
  }
  continue() {
    console.log('next');
  }
  start() {
    var _this2 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // if (!this.authService.hasUserDataSnapshot()) {
      //   const ret = await lastValueFrom(this.authService.getAnomToken());
      //   if (ret.error === null) {
      //     this.authService.saveAnomToken(ret.data.token);
      //     this.authService.saveRefreshToken(ret.data.refreshToken);
      //   } else {
      //     console.log(ret.error);
      //   }
      // }
      _this2.navController.navigateForward('onboarding/phone');
    })();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController
}]), _class);
SplashBusiness = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
  selector: 'app-splash-business',
  template: `<app-splash (startClick)="start()" (next)="continue()" (imageClick)="imageClick()"></app-splash>`
})], SplashBusiness);


/***/ }),

/***/ 10759:
/*!********************************************************!*\
  !*** ./src/app/onboarding/pages/splash/splash.page.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SplashPage": () => (/* binding */ SplashPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _splash_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./splash.page.html?ngResource */ 66163);
/* harmony import */ var _splash_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./splash.page.scss?ngResource */ 38267);
/* harmony import */ var _splash_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_splash_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51197);

var _class;




let SplashPage = (_class = class SplashPage {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "startClick", new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "next", new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "imageClick", new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "currentStep", 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "errorSecurity", false);
  }
  image() {
    this.imageClick.emit();
  }
  start() {
    this.startClick.emit();
  }
  continue() {
    this.next.emit();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => []), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  startClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output
  }],
  next: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output
  }],
  imageClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output
  }]
}), _class);
SplashPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
  selector: 'app-splash',
  template: _splash_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_splash_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], SplashPage);


/***/ }),

/***/ 35312:
/*!*********************************************************!*\
  !*** ./src/app/shared/models/TempPhoneCodeViewModel.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TempPhoneCodeViewModel": () => (/* binding */ TempPhoneCodeViewModel)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);

class TempPhoneCodeViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "id", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "code", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "phone", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "expiration", void 0);
  }
}

/***/ }),

/***/ 17065:
/*!************************************************!*\
  !*** ./src/app/shared/models/UserViewModel.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserViewModel": () => (/* binding */ UserViewModel)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);

class UserViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "userId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "phone", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "name", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "termId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "deviceFingerPrint", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "qrSeed", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "image", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "nightMode", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "notifyInvitations", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "notifyArrivals", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "notifyConfirmations", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "remainingSites", void 0);
  }
}

/***/ }),

/***/ 63415:
/*!*************************************************************************************!*\
  !*** ./src/app/onboarding/components/pin-input/pin-input.component.scss?ngResource ***!
  \*************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".pin-code {\n  position: absolute;\n  left: 50px;\n  right: 50px;\n  justify-content: center;\n}\n\n.pin-code input {\n  border: none;\n  text-align: center;\n  width: 25px;\n  height: 27px;\n  font-weight: 400;\n  font-size: 14px !important;\n  line-height: 26px;\n  border: 1px solid #0078d7 !important;\n  background-color: transparent;\n  margin-right: 8px;\n  color: #0078d7;\n}\n\n.pin-code input:focus {\n  -webkit-appearance: inherit !important;\n  outline: none;\n}\n\n.pin-label {\n  position: absolute;\n  left: 5vw;\n}\n\n.invalid {\n  position: absolute;\n}", "",{"version":3,"sources":["webpack://./src/app/onboarding/components/pin-input/pin-input.component.scss"],"names":[],"mappings":"AAAA;EACE,kBAAA;EACA,UAAA;EACA,WAAA;EACA,uBAAA;AACF;;AAEA;EACE,YAAA;EACA,kBAAA;EACA,WAAA;EACA,YAAA;EACA,gBAAA;EACA,0BAAA;EACA,iBAAA;EACA,oCAAA;EACA,6BAAA;EACA,iBAAA;EACA,cAAA;AACF;;AAEA;EACE,sCAAA;EACA,aAAA;AACF;;AAEA;EACE,kBAAA;EACA,SAAA;AACF;;AAEA;EACE,kBAAA;AACF","sourcesContent":[".pin-code {\n  position: absolute;\n  left: 50px;\n  right: 50px;\n  justify-content: center;\n}\n\n.pin-code input {\n  border: none;\n  text-align: center;\n  width: 25px;\n  height: 27px;\n  font-weight: 400;\n  font-size: 14px !important;\n  line-height: 26px;\n  border: 1px solid #0078d7 !important;\n  background-color: transparent;\n  margin-right: 8px;\n  color: #0078d7;\n}\n\n.pin-code input:focus {\n  -webkit-appearance: inherit !important;\n  outline: none;\n}\n\n.pin-label {\n  position: absolute;\n  left: 5vw;\n}\n\n.invalid {\n  position: absolute;\n}\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 41915:
/*!*********************************************************************************************!*\
  !*** ./src/app/onboarding/components/splash-button/splash-button.component.scss?ngResource ***!
  \*********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 98794:
/*!*****************************************************************************!*\
  !*** ./src/app/onboarding/pages/name-login/name-login.page.scss?ngResource ***!
  \*****************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 9955:
/*!****************************************************************************!*\
  !*** ./src/app/onboarding/pages/no-pin/splash-no-pin.page.scss?ngResource ***!
  \****************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 98702:
/*!*******************************************************************************!*\
  !*** ./src/app/onboarding/pages/phone-login/phone-login.page.scss?ngResource ***!
  \*******************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 6670:
/*!*****************************************************************************************!*\
  !*** ./src/app/onboarding/pages/phone-validation/phone-validation.page.scss?ngResource ***!
  \*****************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 38267:
/*!*********************************************************************!*\
  !*** ./src/app/onboarding/pages/splash/splash.page.scss?ngResource ***!
  \*********************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".h-170p {\n  height: 170px !important;\n}\n\n.card {\n  border-radius: 0px !important;\n}", "",{"version":3,"sources":["webpack://./src/app/onboarding/pages/splash/splash.page.scss"],"names":[],"mappings":"AAAA;EACE,wBAAA;AACF;;AACA;EACE,6BAAA;AAEF","sourcesContent":[".h-170p {\n  height: 170px !important;\n}\n.card {\n  border-radius: 0px !important;\n}\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 86413:
/*!*************************************************************************************!*\
  !*** ./src/app/onboarding/components/pin-input/pin-input.component.html?ngResource ***!
  \*************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<form [formGroup]=\"confirmCodeForm\">\r\n  <label class=\"color-highlight font-11 float-left d-block pin-label\">\r\n    <fa-icon [icon]=\"faClass\" [size]=\"'xl'\" class=\"p-2\"></fa-icon>\r\n    <!-- {{ 'onboarding.labelValidate' | translate }} -->\r\n  </label>\r\n\r\n  <div class=\"pin-code text-center\" formArrayName=\"digits\" *ngIf=\"digits.controls.length > 0\">\r\n    <ng-container *ngFor=\"let field of digits.controls; let i = index\">\r\n      <input\r\n        type=\"number\"\r\n        class=\"focus-color\"\r\n        maxlength=\"1\"\r\n        #inputs\r\n        [formControlName]=\"i\"\r\n        inputmode=\"numeric\"\r\n        (keyup)=\"checkKey(i, field, $event)\"\r\n        (input)=\"check(i, field, $event)\" />\r\n    </ng-container>\r\n    <span *ngIf=\"showPinEmptyMsg && digits.touched\" class=\"invalid d-block text-center w-100\">{{\r\n      'onboarding.pinEmptyToastMsg' | translate\r\n    }}</span>\r\n    <span *ngIf=\"showPinInvalidMsg && digits.touched\" class=\"invalid d-block text-center w-100\">{{\r\n      'onboarding.pinInvalidToastMsg' | translate\r\n    }}</span>\r\n  </div>\r\n  <div *ngIf=\"digits.controls.length === 0\">\r\n    <ngx-skeleton-loader\r\n      [theme]=\"{\r\n        width: '25px',\r\n        height: '27px',\r\n        border: '1px solid white',\r\n        'vertical-align': 'middle'\r\n      }\"></ngx-skeleton-loader>\r\n  </div>\r\n</form>\r\n";

/***/ }),

/***/ 43036:
/*!*********************************************************************************************!*\
  !*** ./src/app/onboarding/components/splash-button/splash-button.component.html?ngResource ***!
  \*********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<a\n  class=\"slider-next bg-blue2-light btn btn-m mt-5 btn-center-l rounded-l shadow-xl font-400 font-12 text-uppercase\"\n  (click)=\"buttonClick.emit()\"\n  [ngClass]=\"class\"\n  [class.disabled]=\"disabled\"\n  >{{ label }}</a\n>\n";

/***/ }),

/***/ 976:
/*!*****************************************************************************!*\
  !*** ./src/app/onboarding/pages/name-login/name-login.page.html?ngResource ***!
  \*****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-header-transparent\n  [faClass]=\"'arrow-left'\"\n  [iconColor]=\"'color-highlight'\"\n  (action)=\"back.emit()\"></app-header-transparent>\n<div class=\"page-content pb-0\">\n  <div data-card-height=\"cover\" class=\"card\">\n    <div class=\"card-center text-center\">\n      <div class=\"content mt-n5\">\n        <app-img-title\n          [imgSrc]=\"'assets/onboarding/phone.png'\"\n          [title]=\"'onboarding.labelName' | translate\"\n          [subtitle]=\"'onboarding.nameLoginTitle' | translate\"\n          [subtitleClass]=\"'login-subtitle'\"></app-img-title>\n\n        <div class=\"row\">\n          <app-input-login\n            (enterKey)=\"continue.emit()\"\n            [label]=\"'onboarding.labelName' | translate\"\n            [control]=\"name\"\n            [type]=\"'name'\"\n            [faClass]=\"['far','user']\"\n            [textRequired]=\"'onboarding.nameRequired' | translate\"\n            [textInvalid]=\"'onboarding.nameInvalid' | translate\"></app-input-login>\n        </div>\n      </div>\n    </div>\n  </div>\n  <div [class.cover-button-bottom]=\"!hideButton\">\n    <app-button\n      [status]=\"buttonState\"\n      (onHide)=\"hide()\"\n      (onShow)=\"show()\"\n      [label]=\"'common.continue'|translate\"\n      (buttonClick)=\"continue.emit()\"></app-button>\n  </div>\n</div>\n";

/***/ }),

/***/ 68315:
/*!****************************************************************************!*\
  !*** ./src/app/onboarding/pages/no-pin/splash-no-pin.page.html?ngResource ***!
  \****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"page-content pb-0\">\n  <div data-card-height=\"cover\" class=\"card bg-highlight\">\n    <div class=\"card-center text-center\">\n      <div class=\"content mt-n5\">\n        <app-img-title\n          [imgSrc]=\"'assets/onboarding/splash/splash-error.svg'\"\n          [imgHeight]=\"'170'\"\n          [title]=\"'common.sorry'|translate\"\n          [titleClass]=\"'color-white m-3 font-30 font-400'\"\n          [subtitle]=\"'onboarding.NoPinBody'|translate\"\n          [subtitleClass]=\"'color-white m-5 pt-10 font-20 font-400'\"></app-img-title>\n      </div>\n    </div>\n  </div>\n</div>\n";

/***/ }),

/***/ 86618:
/*!*******************************************************************************!*\
  !*** ./src/app/onboarding/pages/phone-login/phone-login.page.html?ngResource ***!
  \*******************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-header-transparent\n  [faClass]=\"'arrow-left'\"\n  [iconColor]=\"'color-highlight'\"\n  (action)=\"back.emit()\"></app-header-transparent>\n<div class=\"page-content pb-0\">\n  <div data-card-height=\"cover\" class=\"card\">\n    <div class=\"card-center text-center\">\n      <div class=\"content mt-n5\">\n        <app-img-title\n          [imgSrc]=\"'assets/onboarding/phone.png'\"\n          [title]=\"'onboarding.labelPhone' | translate\"\n          [titleClass]=\"'pt-3'\"\n          [subtitle]=\"'onboarding.phoneLoginTitle' | translate\"\n          [subtitleClass]=\"'login-subtitle'\"></app-img-title>\n\n        <div class=\"row\">\n          <app-input-login\n            (enterKey)=\"continue.emit()\"\n            [label]=\"'onboarding.labelPhone' | translate\"\n            [control]=\"phone\"\n            [type]=\"'phone'\"\n            [faClass]=\"['fas','mobile-screen-button']\"\n            [textRequired]=\"'onboarding.phoneRequired' | translate\"\n            [textInvalid]=\"'onboarding.phoneInvalid' | translate\"\n            [check]=\"terms\"\n            [showInvalid]=\"phone.touched\"\n            (checkChange)=\"termsChange.emit($event)\"></app-input-login>\n        </div>\n      </div>\n    </div>\n  </div>\n  <div [class.cover-button-bottom]=\"!hideButton\">\n    <app-button\n      [status]=\"buttonState\"\n      [label]=\"'common.continue'|translate\"\n      (onHide)=\"hide()\"\n      (onShow)=\"show()\"\n      (buttonClick)=\"continue.emit()\"></app-button>\n  </div>\n</div>\n";

/***/ }),

/***/ 96839:
/*!*****************************************************************************************!*\
  !*** ./src/app/onboarding/pages/phone-validation/phone-validation.page.html?ngResource ***!
  \*****************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-header-transparent\r\n  [faClass]=\"'arrow-left'\"\r\n  [iconColor]=\"'color-highlight'\"\r\n  (action)=\"back.emit()\"></app-header-transparent>\r\n<div class=\"page-content pb-0\">\r\n  <div data-card-height=\"cover\" class=\"card\">\r\n    <div class=\"card-center text-center\">\r\n      <div class=\"content mt-n5\">\r\n        <app-img-title\r\n          [imgSrc]=\"'assets/onboarding/phone.png'\"\r\n          [title]=\"'onboarding.validateTitle' | translate\"\r\n          [titleClass]=\"'pt-3'\"\r\n          [subtitle]=\"'onboarding.validateSubtitle' | translate\"\r\n          [subtitleClass]=\"'login-subtitle'\"></app-img-title>\r\n        <div class=\"row\">\r\n          <app-pin-input\r\n            *ngIf=\"pinCode\"\r\n            [(pinCode)]=\"pinCode\"\r\n            [pinInvalid]=\"pinInvalid\"\r\n            (enterKey)=\"continue.emit()\"\r\n            (pinCodeChange)=\"pinCodeChange.emit($event)\"></app-pin-input>\r\n\r\n          <ng-container *ngIf=\"!pinCode\">\r\n            <div class=\"px-5\">\r\n              <ngx-skeleton-loader\r\n                class=\"float-left d-block\"\r\n                [theme]=\"{\r\n                width: '25px',\r\n                height: '25px',\r\n                border: '1px solid white',\r\n                'vertical-align': 'middle'\r\n              }\"></ngx-skeleton-loader>\r\n\r\n              <ngx-skeleton-loader\r\n                *ngFor=\"let i of [0,1,2,3,4,5]\"\r\n                [theme]=\"{\r\n                  width: '25px',\r\n                  height: '25px',\r\n                  border: '1px solid white',\r\n                  'vertical-align': 'middle',\r\n                  'margin-right': '8px'\r\n                }\">\r\n              </ngx-skeleton-loader>\r\n            </div>\r\n          </ng-container>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div [class.cover-button-bottom]=\"!hideButton\">\r\n    <app-button\r\n      [status]=\"buttonState\"\r\n      [label]=\"'common.continue' | translate\"\r\n      (onHide)=\"hide()\"\r\n      (onShow)=\"show()\"\r\n      (buttonClick)=\"continue.emit()\"></app-button>\r\n    <ng-container *ngIf=\"!hideCounter\">\r\n      <div class=\"color-highlight text-center pt-3\" *ngIf=\"!timeExpired\">\r\n        {{ 'onboarding.validateRemaining'|translate}} {{expirationCounter}}\r\n      </div>\r\n      <div class=\"color-highlight text-center pt-3\" *ngIf=\"timeExpired\">\r\n        <a role=\"button\" (click)=\"resend()\">{{ 'common.resend'|translate}}</a>\r\n      </div>\r\n    </ng-container>\r\n  </div>\r\n</div>\r\n";

/***/ }),

/***/ 66163:
/*!*********************************************************************!*\
  !*** ./src/app/onboarding/pages/splash/splash.page.html?ngResource ***!
  \*********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"page-content pb-0\">\n  <app-carrousel [(currentStep)]=\"currentStep\">\n    <ng-template #slide>\n      <div data-card-height=\"cover\" class=\"card bg-highlight\">\n        <div class=\"card-center text-center\">\n          <div class=\"content mt-n5\" (click)=\"image()\">\n            <app-img-title\n              [imgClass]=\"'vh-35'\"\n              [imgSrc]=\"'assets/icons/iconbanner.svg'\"\n              [subtitle]=\"'onboarding.MainBody'|translate\"\n              [subtitleClass]=\"'color-white m-5 pt-10 font-14 font-400 lh-lg'\"></app-img-title>\n          </div>\n        </div>\n      </div>\n    </ng-template>\n    <ng-template #slide>\n      <div data-card-height=\"cover\" class=\"card bg-highlight\">\n        <div class=\"card-center text-center\">\n          <div class=\"content mt-n5\">\n            <app-img-title\n              [imgSrc]=\"'assets/onboarding/splash/splash02.svg'\"\n              [imgHeight]=\"'180'\"\n              [title]=\"'onboarding.AccessTitle'|translate\"\n              [titleClass]=\"'color-white m-3 font-400'\"\n              [subtitle]=\"'onboarding.AccessBody'|translate\"\n              [subtitleClass]=\"'color-white mx-5 pt-10 font-14 font-400 lh-lg'\"></app-img-title>\n          </div>\n        </div>\n      </div>\n    </ng-template>\n    <ng-template #slide>\n      <div data-card-height=\"cover\" class=\"card bg-highlight\">\n        <div class=\"card-center text-center\">\n          <div class=\"content mt-n5\">\n            <app-img-title\n              [imgSrc]=\"'assets/onboarding/splash/splash03.svg'\"\n              [imgHeight]=\"'180'\"\n              [title]=\"'onboarding.FastTitle'|translate\"\n              [titleClass]=\"'color-white m-3 font-400'\"\n              [subtitle]=\"'onboarding.FastBody'|translate\"\n              [subtitleClass]=\"'color-white mx-5 pt-10 font-14 font-400 lh-lg'\"></app-img-title>\n          </div>\n        </div>\n      </div>\n    </ng-template>\n    <ng-template #slide>\n      <div data-card-height=\"cover\" class=\"card bg-highlight\">\n        <div class=\"card-center text-center\">\n          <div class=\"content mt-n5\">\n            <app-img-title\n              [imgSrc]=\"'assets/onboarding/splash/splash04.svg'\"\n              [imgHeight]=\"'180'\"\n              [title]=\"'onboarding.OrganizedTitle'|translate\"\n              [titleClass]=\"'color-white m-3 font-400'\"\n              [subtitle]=\"'onboarding.OrganizedBody'|translate\"\n              [subtitleClass]=\"'color-white mx-5 pt-10 font-14 font-400 lh-lg'\"></app-img-title>\n          </div>\n        </div>\n      </div>\n    </ng-template>\n  </app-carrousel>\n\n  <div class=\"cover-button-bottom\">\n    <app-splash-button\n      [hidden]=\"currentStep === 3\"\n      [label]=\"'common.next'|translate\"\n      [class]=\"'slider-next'\"\n      (buttonClick)=\"continue()\"></app-splash-button>\n    <app-splash-button\n      [hidden]=\"currentStep !== 3\"\n      [label]=\"'common.start'|translate\"\n      (buttonClick)=\"start()\"></app-splash-button>\n  </div>\n\n  <a\n    (click)=\"start()\"\n    [hidden]=\"currentStep === 3\"\n    role=\"button\"\n    class=\"cover-next slider-next color-white mx-3 font-12\"\n    >{{'common.start'|translate}}</a\n  >\n  <a [hidden]=\"currentStep === 0\" role=\"button\" class=\"cover-prev slider-prev color-white mx-3 font-12\"\n    >{{'common.previous'|translate}}</a\n  >\n</div>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_onboarding_onboarding_module_ts.js.map