(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_profile_profile_module_ts"],{

/***/ 60359:
/*!***************************************************************************!*\
  !*** ./src/app/profile/components/edit-profile/edit-profile.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditProfileComponent": () => (/* binding */ EditProfileComponent)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _edit_profile_component_html_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./edit-profile.component.html?ngResource */ 31264);
/* harmony import */ var _edit_profile_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./edit-profile.component.scss?ngResource */ 78995);
/* harmony import */ var _edit_profile_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_edit_profile_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/components/button/button.component */ 62490);
/* harmony import */ var src_app_shared_models_Image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/models/Image */ 90925);
/* harmony import */ var src_app_shared_models_UpdateUserViewModel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/models/UpdateUserViewModel */ 70569);
/* harmony import */ var src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/user.service */ 31880);
/* harmony import */ var src_app_shared_services_file_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/services/file.service */ 30038);
/* harmony import */ var src_app_shared_components_img_preview_img_preview_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/components/img-preview/img-preview.component */ 5648);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ 89650);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 51547);


var _class;













let EditProfileComponent = (_class = class EditProfileComponent {
  constructor(fb, userService, fileService, titleCasePipe, cdRef) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "fb", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "fileService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "titleCasePipe", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "cdRef", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "modalC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "imgPreview", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "time", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "formSaved", new _angular_core__WEBPACK_IMPORTED_MODULE_10__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "vm", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "profileForm", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "image", []);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "loading", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "showKeyboard", false);
    this.fb = fb;
    this.userService = userService;
    this.fileService = fileService;
    this.titleCasePipe = titleCasePipe;
    this.cdRef = cdRef;
  }
  get buttonState() {
    if (this.loading) {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_4__.ButtonState.loading;
    } else if (this.profileForm.valid) {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_4__.ButtonState.enabled;
    } else {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_4__.ButtonState.disabled;
    }
  }
  ngOnInit() {
    this.initForm();
  }
  setForm(vm) {
    if (!vm) return;
    this.profileForm.get('name')?.setValue(vm.name);
    if (vm.image) {
      const image = new src_app_shared_models_Image__WEBPACK_IMPORTED_MODULE_5__.Image();
      image.image64 = vm.image.url + '&thumb=true&cached' + vm.image.id;
      image.name = 'profile.png';
      image.id = vm.image.id;
      this.image[0] = image;
    } else {
      this.imgPreview.loading = false;
    }
    this.vm = vm;
  }
  initForm() {
    this.profileForm = this.fb.group({
      name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_11__.Validators.required]
    });
  }
  save() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.loading = true;
      const updateVM = new src_app_shared_models_UpdateUserViewModel__WEBPACK_IMPORTED_MODULE_6__.UpdateUserViewModel();
      updateVM.notifyArrivals = _this.vm.notifyArrivals ?? false;
      updateVM.notifyInvitations = _this.vm.notifyInvitations ?? false;
      updateVM.notifyConfirmations = _this.vm.notifyConfirmations ?? false;
      updateVM.picture = _this.vm.image?.id;
      const name = _this.profileForm.get('name')?.value.toLowerCase();
      updateVM.name = _this.titleCasePipe.transform(name);
      const deleteIms = _this.imgPreview?.deleteImages;
      if (deleteIms && deleteIms.length > 0) {
        yield (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.lastValueFrom)(_this.userService.deleteImage());
        updateVM.picture = undefined;
        localStorage.removeItem('userPicture');
      }
      const imgs = _this.imgPreview?.images.filter(x => x.file !== null && x.file !== undefined && (x.id === undefined || x.id === null));
      if (imgs && imgs.length > 0) {
        const img = imgs[0];
        console.log(img);
        const res = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.lastValueFrom)(_this.fileService.upload(img));
        if (res.error === null) {
          updateVM.picture = res.data[0];
          localStorage.setItem('userPicture', img.image64);
          _this.updateUser(updateVM);
        }
      } else {
        _this.updateUser(updateVM);
      }
    })();
  }
  updateUser(updateVM) {
    this.userService.update(updateVM).subscribe(res => {
      this.vm = res.data;
      this.loading = false;
      this.formSaved.emit(this.vm);
      this.modalC?.hide();
    });
  }
  close() {
    this.modalC?.hide();
    this.imgPreview.loading = true;
  }
  hide() {
    this.showKeyboard = true;
    this.cdRef.detectChanges();
  }
  show() {
    this.showKeyboard = false;
    this.cdRef.detectChanges();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormBuilder
}, {
  type: src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_7__.UserService
}, {
  type: src_app_shared_services_file_service__WEBPACK_IMPORTED_MODULE_8__.FileService
}, {
  type: _angular_common__WEBPACK_IMPORTED_MODULE_13__.TitleCasePipe
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ChangeDetectorRef
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "propDecorators", {
  modalC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ViewChild,
    args: ['modal']
  }],
  imgPreview: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ViewChild,
    args: [src_app_shared_components_img_preview_img_preview_component__WEBPACK_IMPORTED_MODULE_9__.ImgPreviewComponent]
  }],
  time: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input
  }],
  formSaved: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output
  }]
}), _class);
EditProfileComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
  selector: 'app-edit-profile',
  template: _edit_profile_component_html_ngResource__WEBPACK_IMPORTED_MODULE_2__,
  styles: [(_edit_profile_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_3___default())]
})], EditProfileComponent);


/***/ }),

/***/ 46789:
/*!***************************************************!*\
  !*** ./src/app/profile/profile-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfilePageRoutingModule": () => (/* binding */ ProfilePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _profile_business__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profile.business */ 78271);
/* harmony import */ var _onboarding_pages_terms_conditions_terms_conditions_business__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../onboarding/pages/terms-conditions/terms-conditions.business */ 47954);





const routes = [{
  path: '',
  component: _profile_business__WEBPACK_IMPORTED_MODULE_0__.ProfileBusiness
}, {
  path: 'terms',
  component: _onboarding_pages_terms_conditions_terms_conditions_business__WEBPACK_IMPORTED_MODULE_1__.TermsConditionsBusiness
}];
let ProfilePageRoutingModule = class ProfilePageRoutingModule {};
ProfilePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
  imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)],
  exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
})], ProfilePageRoutingModule);


/***/ }),

/***/ 78271:
/*!*********************************************!*\
  !*** ./src/app/profile/profile.business.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfileBusiness": () => (/* binding */ ProfileBusiness)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _shared_services_template_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../shared/services/template.service */ 9101);
/* harmony import */ var _shared_services_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../shared/services/user.service */ 31880);
/* harmony import */ var _profile_components_edit_profile_edit_profile_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../profile/components/edit-profile/edit-profile.component */ 60359);
/* harmony import */ var _profile_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./profile.page */ 82342);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 51547);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../app.component */ 66401);
/* harmony import */ var _capacitor_clipboard__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @capacitor/clipboard */ 24721);


var _class;










let ProfileBusiness = (_class = class ProfileBusiness {
  constructor(userService, templateService, navController, cdRef) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "templateService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "cdRef", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "editP", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "profileC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userViewModel", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "loading", true);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "installationID", '');
    this.userService = userService;
    this.templateService = templateService;
    this.navController = navController;
    this.cdRef = cdRef;
    this.installationID = _app_component__WEBPACK_IMPORTED_MODULE_6__.AppComponent.installationID;
  }
  ionViewWillEnter() {
    this.fetchUser();
  }
  fetchUser() {
    this.userService.getUser().subscribe(res => {
      if (res.error === null) {
        this.userViewModel = res.data;
        console.log(this.userViewModel);
        this.cdRef.detectChanges();
        this.userViewModel.nightMode = localStorage.getItem('theme') === 'dark';
        if (this.userViewModel.nightMode === false && localStorage.getItem('theme') === 'auto') {
          this.userViewModel.nightMode = undefined;
        }
        this.profileC?.setForm(this.userViewModel);
        this.loading = false;
      } else {
        this.navController.navigateRoot('error');
      }
    });
  }
  back() {
    this.navController.back();
  }
  editUser() {
    console.log('User edit click!');
    this.editP?.setForm(this.userViewModel);
    this.editP?.modalC?.show();
  }
  nightMode(value) {
    if (value === true) {
      this.templateService.activateDarkMode();
    } else if (value === false) {
      this.templateService.activateLightMode();
    } else {
      this.templateService.activateAutoMode();
    }
  }
  notify() {
    const updateVM = this.profileC?.updateModel;
    if (updateVM === undefined) return;
    updateVM.picture = this.userViewModel?.image?.id;
    updateVM.name = this.userViewModel?.name;
    this.save(updateVM);
  }
  installationClick() {
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _capacitor_clipboard__WEBPACK_IMPORTED_MODULE_7__.Clipboard.write({
        string: _app_component__WEBPACK_IMPORTED_MODULE_6__.AppComponent.installationID ?? 'no installation id'
      });
    })();
  }
  save(updateVM) {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const res = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.lastValueFrom)(_this.userService.update(updateVM));
      if (res.error === null) {
        _this.userViewModel = res.data;
        _this.editP?.setForm(_this.userViewModel);
        console.log(_this.userViewModel);
      } else {
        _this.navController.navigateRoot('error');
      }
    })();
  }
  editProfileSave(vm) {
    this.userViewModel = undefined;
    this.profileC?.reload();
    this.userViewModel = vm;
    this.cdRef.detectChanges();
  }
  goTerms() {
    const navigationExtras = {
      state: {
        returnUrl: 'profile',
        component: 'profile'
      }
    };
    this.navController.navigateForward('profile/terms', navigationExtras);
  }
  goFaq() {
    this.navController.navigateForward('faq');
  }
  logout() {
    this.userService.logout();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: _shared_services_user_service__WEBPACK_IMPORTED_MODULE_3__.UserService
}, {
  type: _shared_services_template_service__WEBPACK_IMPORTED_MODULE_2__.TemplateService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.NavController
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ChangeDetectorRef
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "propDecorators", {
  editP: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ViewChild,
    args: [_profile_components_edit_profile_edit_profile_component__WEBPACK_IMPORTED_MODULE_4__.EditProfileComponent]
  }],
  profileC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ViewChild,
    args: [_profile_page__WEBPACK_IMPORTED_MODULE_5__.ProfilePage]
  }]
}), _class);
ProfileBusiness = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
  selector: 'app-profile-business',
  template: `<app-profile
      *ngIf="userViewModel"
      class="scroll-content"
      [userProfile]="userViewModel"
      [installationID]="installationID"
      (installationClick)="installationClick()"
      (back)="back()"
      (editUserClick)="editUser()"
      (nightModeClick)="nightMode($event)"
      (notifyClick)="notify()"
      (checkTermsClick)="goTerms()"
      (faqClick)="goFaq()"
      (logoutClick)="logout()"></app-profile>
    <app-edit-profile *ngIf="!loading" (formSaved)="editProfileSave($event)"></app-edit-profile>
    <div *ngIf="!userViewModel" class="center">
      <div class="spinner-border color-blue-dark" role="status"></div>
    </div>`
})], ProfileBusiness);


/***/ }),

/***/ 96239:
/*!*******************************************!*\
  !*** ./src/app/profile/profile.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfilePageModule": () => (/* binding */ ProfilePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 89650);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _profile_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profile-routing.module */ 46789);
/* harmony import */ var _profile_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profile.page */ 82342);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../shared/shared.module */ 56208);
/* harmony import */ var _profile_business__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./profile.business */ 78271);
/* harmony import */ var _components_edit_profile_edit_profile_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/edit-profile/edit-profile.component */ 60359);










let ProfilePageModule = class ProfilePageModule {};
ProfilePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule, _profile_routing_module__WEBPACK_IMPORTED_MODULE_0__.ProfilePageRoutingModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.ReactiveFormsModule],
  declarations: [_profile_page__WEBPACK_IMPORTED_MODULE_1__.ProfilePage, _profile_business__WEBPACK_IMPORTED_MODULE_3__.ProfileBusiness, _components_edit_profile_edit_profile_component__WEBPACK_IMPORTED_MODULE_4__.EditProfileComponent],
  exports: [_profile_page__WEBPACK_IMPORTED_MODULE_1__.ProfilePage]
})], ProfilePageModule);


/***/ }),

/***/ 82342:
/*!*****************************************!*\
  !*** ./src/app/profile/profile.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfilePage": () => (/* binding */ ProfilePage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _profile_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profile.page.html?ngResource */ 8907);
/* harmony import */ var _profile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./profile.page.scss?ngResource */ 680);
/* harmony import */ var _profile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_profile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var _shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../shared/components/footer/footer.component */ 68014);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var _shared_services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../shared/services/user.service */ 31880);
/* harmony import */ var _shared_models_UpdateUserViewModel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../shared/models/UpdateUserViewModel */ 70569);
/* harmony import */ var _shared_components_three_state_switch_three_state_switch_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../shared/components/three-state-switch/three-state-switch.component */ 75688);
/* harmony import */ var _capacitor_app__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @capacitor/app */ 61596);

var _class;











let ProfilePage = (_class = class ProfilePage {
  constructor(translate, userService) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "userService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "themeSwitch", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "userProfile", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "installationID", '');
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "back", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "editUserClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "nightModeClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "notifyClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "installationClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "checkTermsClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "faqClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "logoutClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "modeToggle", new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControl(null));
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "everythingCheck", new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControl(false));
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "invitationsCheck", new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControl(false));
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "arrivalsCheck", new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControl(false));
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "confirmsCheck", new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControl(false));
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "modeDescription", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "modeTitle", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "footerOptions", _shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__.FooterSelectedOption);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "displayBanner", true);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "avatarApi", 'https://api.dicebear.com/5.x/initials/svg?backgroundColor=0078d7&seed=');
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "appVersion", void 0);
    this.translate = translate;
    this.userService = userService;
    this.modeDescription = this.translate.instant('profile.autoModeDesc');
    this.modeTitle = this.translate.instant('profile.autoModeTitle');
    _capacitor_app__WEBPACK_IMPORTED_MODULE_7__.App.getInfo().then(x => {
      this.appVersion = x.version + '(' + x.build + ')';
    });
  }
  get userName() {
    if (this.userService.userData?.name === '' || this.userService.userData?.name === undefined) return this.userProfile?.name;
    return this.userService.userData.name;
  }
  get hasPicture() {
    return this.userProfile?.image?.url !== undefined;
  }
  get userImage() {
    if (this.userProfile?.image?.url !== undefined) return this.userProfile?.image?.url + '&thumb=true&cached=' + this.userProfile.image.id;else {
      if (this.userProfile?.name !== undefined) return this.avatarApi + this.userProfile.name?.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]|[\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD10-\uDDFF]/gi, '');else return 'assets/icons/avatar.png';
    }
  }
  get aboutLabel() {
    return this.translate.instant('profile.aboutLabel', {
      version: this.appVersion
    });
  }
  get installationLabel() {
    return this.translate.instant('common.installationID', {
      installationID: this.installationID
    });
  }
  get updateModel() {
    const updateVM = new _shared_models_UpdateUserViewModel__WEBPACK_IMPORTED_MODULE_5__.UpdateUserViewModel();
    updateVM.notifyInvitations = this.invitationsCheck.value ?? false;
    updateVM.notifyArrivals = this.arrivalsCheck.value ?? false;
    updateVM.notifyConfirmations = this.confirmsCheck.value ?? false;
    return updateVM;
  }
  ngOnInit() {
    this.initSubscriptions();
  }
  initSubscriptions() {
    this.everythingCheck.valueChanges.subscribe(value => {
      if (value) {
        this.invitationsCheck.setValue(true, {
          emitEvent: false
        });
        this.arrivalsCheck.setValue(true, {
          emitEvent: false
        });
        this.confirmsCheck.setValue(true, {
          emitEvent: false
        });
      } else {
        this.invitationsCheck.setValue(false, {
          emitEvent: false
        });
        this.arrivalsCheck.setValue(false, {
          emitEvent: false
        });
        this.confirmsCheck.setValue(false, {
          emitEvent: false
        });
      }
    });
    this.invitationsCheck.valueChanges.subscribe(value => {
      if (value === false) {
        this.everythingCheck.setValue(false, {
          emitEvent: false
        });
      } else {
        let allSelected = true;
        if (this.arrivalsCheck.value === false) allSelected = false;
        if (this.confirmsCheck.value === false) allSelected = false;
        if (allSelected) this.everythingCheck.setValue(true, {
          emitEvent: false
        });
      }
    });
    this.arrivalsCheck.valueChanges.subscribe(value => {
      if (value === false) {
        this.everythingCheck.setValue(false, {
          emitEvent: false
        });
      } else {
        let allSelected = true;
        if (this.invitationsCheck.value === false) allSelected = false;
        if (this.confirmsCheck.value === false) allSelected = false;
        if (allSelected) this.everythingCheck.setValue(true, {
          emitEvent: false
        });
      }
    });
    this.confirmsCheck.valueChanges.subscribe(value => {
      if (value === false) {
        this.everythingCheck.setValue(false, {
          emitEvent: false
        });
      } else {
        let allSelected = true;
        if (this.invitationsCheck.value === false) allSelected = false;
        if (this.arrivalsCheck.value === false) allSelected = false;
        if (allSelected) this.everythingCheck.setValue(true, {
          emitEvent: false
        });
      }
    });
    this.modeToggle.valueChanges.subscribe(value => {
      if (value === true) {
        this.modeDescription = this.translate.instant('profile.nightModeDesc');
        this.modeTitle = this.translate.instant('profile.nightModeTitle');
      } else if (value === false) {
        this.modeDescription = this.translate.instant('profile.lightModeDesc');
        this.modeTitle = this.translate.instant('profile.lightModeTitle');
      } else {
        this.modeDescription = this.translate.instant('profile.autoModeDesc');
        this.modeTitle = this.translate.instant('profile.autoModeTitle');
      }
      this.nightModeClick.emit(value);
    });
  }
  setForm(vm) {
    if (this.userProfile) {
      this.modeToggle.setValue(this.userProfile.nightMode ?? null);
      this.invitationsCheck.setValue(this.userProfile.notifyInvitations ?? false);
      this.arrivalsCheck.setValue(this.userProfile.notifyArrivals ?? false);
      this.confirmsCheck.setValue(this.userProfile.notifyConfirmations ?? false);
    } else {
      this.modeToggle.setValue(vm.nightMode ?? null);
      this.invitationsCheck.setValue(vm.notifyInvitations ?? false);
      this.arrivalsCheck.setValue(vm.notifyArrivals ?? false);
      this.confirmsCheck.setValue(vm.notifyConfirmations ?? false);
    }
    this.themeSwitch?.update();
  }
  reload() {
    this.displayBanner = false;
    setTimeout(() => {
      this.displayBanner = true;
    }, 500);
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__.TranslateService
}, {
  type: _shared_services_user_service__WEBPACK_IMPORTED_MODULE_4__.UserService
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  themeSwitch: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild,
    args: [_shared_components_three_state_switch_three_state_switch_component__WEBPACK_IMPORTED_MODULE_6__.ThreeStateSwitchComponent]
  }],
  userProfile: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input
  }],
  installationID: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input
  }],
  back: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  editUserClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  nightModeClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  notifyClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  installationClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  checkTermsClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  faqClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  logoutClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }]
}), _class);
ProfilePage = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
  selector: 'app-profile',
  template: _profile_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_profile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], ProfilePage);


/***/ }),

/***/ 70569:
/*!******************************************************!*\
  !*** ./src/app/shared/models/UpdateUserViewModel.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UpdateUserViewModel": () => (/* binding */ UpdateUserViewModel)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);

class UpdateUserViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "name", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "picture", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "nightMode", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "notifyInvitations", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "notifyArrivals", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "notifyConfirmations", void 0);
  }
}

/***/ }),

/***/ 30038:
/*!*************************************************!*\
  !*** ./src/app/shared/services/file.service.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FileService": () => (/* binding */ FileService)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 74048);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 13045);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 56997);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _base_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./base.service */ 15127);


var _class;






let FileService = (_class = class FileService extends _base_service__WEBPACK_IMPORTED_MODULE_2__.BaseService {
  constructor(http, toast, navController) {
    super(toast, navController);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "http", void 0);
    this.http = http;
  }
  upload(file) {
    const formData = new FormData();
    formData.append('file', file.file, file.name);
    return this.http.post(`${_base_service__WEBPACK_IMPORTED_MODULE_2__.BaseService.apiUrl}File/Upload`, formData).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.catchError)(error => this.handleError(error)));
  }
  uploadFiles(files) {
    const formData = new FormData();
    files.forEach(file => {
      formData.append('file', file.file, file.name);
    });
    return this.http.post(`${_base_service__WEBPACK_IMPORTED_MODULE_2__.BaseService.apiUrl}File/Upload`, formData).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.catchError)(error => this.handleError(error)));
  }
  uploadFileString(fileSrc) {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const file = yield _this.dataUrlToFile(fileSrc, 'map.png');
      const formData = new FormData();
      formData.append('file', file, file.name);
      return _this.http.post(`${_base_service__WEBPACK_IMPORTED_MODULE_2__.BaseService.apiUrl}File/Upload`, formData).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.map)(x => {
        const result = _this.checkResult(x);
        return result;
      }), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.catchError)(error => _this.handleError(error)));
    })();
  }
  dataUrlToFile(dataUrl, fileName) {
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const res = yield fetch(dataUrl);
      const blob = yield res.blob();
      return new File([blob], fileName, {
        type: 'image/png'
      });
    })();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClient
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController
}]), _class);
FileService = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Injectable)({
  providedIn: 'root'
})], FileService);


/***/ }),

/***/ 78995:
/*!****************************************************************************************!*\
  !*** ./src/app/profile/components/edit-profile/edit-profile.component.scss?ngResource ***!
  \****************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 680:
/*!******************************************************!*\
  !*** ./src/app/profile/profile.page.scss?ngResource ***!
  \******************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".divider {\n  margin-top: 5px !important;\n  margin-bottom: 5px !important;\n}\n\n.icon-container {\n  justify-content: center;\n  display: flex;\n  min-width: 8vw !important;\n}", "",{"version":3,"sources":["webpack://./src/app/profile/profile.page.scss"],"names":[],"mappings":"AAAA;EACE,0BAAA;EACA,6BAAA;AACF;;AAEA;EACE,uBAAA;EACA,aAAA;EACA,yBAAA;AACF","sourcesContent":[".divider {\n  margin-top: 5px !important;\n  margin-bottom: 5px !important;\n}\n\n.icon-container {\n  justify-content: center;\n  display: flex;\n  min-width: 8vw !important;\n}\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 31264:
/*!****************************************************************************************!*\
  !*** ./src/app/profile/components/edit-profile/edit-profile.component.html?ngResource ***!
  \****************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-modal-menu #modal [height]=\"'h-75'\" [static]=\"true\">\n  <ng-template #modalContent>\n    <div class=\"content mb-5\">\n      <a role=\"button\" (click)=\"close()\" class=\"font-16 w-fit color-red-dark float-end\">\n        <fa-icon [icon]=\"['fas', 'times']\"></fa-icon\n      ></a>\n\n      <div class=\"content mb-6 mt-0 mx-0\">\n        <form [formGroup]=\"profileForm\" enterFocus>\n          <h6 class=\"font-400 font-16 pb-3\">{{ 'common.profileEdit' | translate }}</h6>\n          <div class=\"input-style input-style-always-active has-borders no-icon validate-field\" #nextTab>\n            <input type=\"name\" class=\"form-control validate-text\" formControlName=\"name\" />\n            <label class=\"color-theme text-uppercase font-400 font-10\">{{ 'common.nameInput' | translate }}</label>\n            <em class=\"color-highlight opacity-75\">{{ 'common.required' | translate }}</em>\n          </div>\n          <app-img-preview [images]=\"image\" [allowMultiple]=\"false\" [edit]=\"true\"></app-img-preview>\n        </form>\n      </div>\n\n      <div class=\"pt-3 pb-3\">\n        <ng-container *ngIf=\"!showKeyboard\">\n          <app-button\n            [status]=\"buttonState\"\n            [label]=\"'common.save' | translate\"\n            (onHide)=\"hide()\"\n            (buttonClick)=\"save()\"></app-button>\n        </ng-container>\n      </div>\n    </div>\n  </ng-template>\n</app-modal-menu>\n\n<ng-container *ngIf=\"showKeyboard\">\n  <app-button\n    [status]=\"buttonState\"\n    [label]=\"'common.save' | translate\"\n    [customClass]=\"'w-100 button-onkeyboard'\"\n    (onShow)=\"show()\"\n    (buttonClick)=\"save()\"></app-button>\n</ng-container>\n";

/***/ }),

/***/ 8907:
/*!******************************************************!*\
  !*** ./src/app/profile/profile.page.html?ngResource ***!
  \******************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-page-layout\n  (back)=\"back.emit()\"\n  [footerSelectedOption]=\"footerOptions.more\"\n  [title]=\"'common.profileTitle'|translate\">\n  <app-banner\n    [title]=\"userProfile?.name\"\n    [titleClass]=\"'font-bold'\"\n    [descrip]=\"' '\"\n    [faClass]=\"'pen-to-square'\"\n    [buttonLabel]=\"'common.edit' | translate\"\n    [iconColor]=\"'color-highlight'\"\n    [hasImg]=\"true\"\n    [profileImg]=\"userImage\"\n    [defaultImg]=\"!hasPicture\"\n    (iconClick)=\"editUserClick.emit()\"></app-banner>\n\n  <div class=\"card card-style night-card\">\n    <div class=\"content\">\n      <div class=\"d-flex\">\n        <div class=\"me-2 icon-container align-self-center\">\n          <fa-icon class=\"color-highlight font-16\" [icon]=\"['fas','mobile-screen-button']\" [size]=\"'lg'\"></fa-icon>\n        </div>\n        <div class=\"me-1 flex-fill align-self-center row mb-0\">\n          <strong class=\"color-theme font-14 d-block lh-sm\"><span>{{ modeTitle }}</span></strong>\n          <span class=\"font-11 font-400 mb-n1 color-theme opacity-70 lh-sm\"> {{ modeDescription }}</span>\n        </div>\n        <div class=\"align-self-center\">\n          <app-triple-switch\n            [leftIcon]=\"['fas','moon']\"\n            [rightIcon]=\"['far','lightbulb']\"\n            [centerIcon]=\"['fas','gear']\"\n            [control]=\"modeToggle\"\n            (leftClick)=\"nightModeClick.emit(true)\"\n            (centerClick)=\"nightModeClick.emit(null)\"\n            (rightClick)=\"nightModeClick.emit(false)\"></app-triple-switch>\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class=\"card card-style\">\n    <div class=\"content\">\n      <div class=\"d-flex py-2\">\n        <div class=\"me-2 icon-container align-self-center\">\n          <fa-icon class=\"color-highlight font-16\" [icon]=\"['fas','envelope']\" [size]=\"'lg'\"></fa-icon>\n        </div>\n        <div class=\"flex-fill align-self-center row mb-0\">\n          <strong class=\"color-theme font-14 d-block lh-sm\"\n            ><span>{{ 'profile.notifyEverything' | translate }}</span></strong\n          >\n          <span class=\"font-11 font-400 mb-n1 color-theme opacity-70 lh-sm\">\n            {{ 'profile.notifyEverythingDesc' | translate }}</span\n          >\n        </div>\n        <div class=\"ms-auto me-3 align-self-center pe-2\">\n          <app-toggle-switch [control]=\"everythingCheck\" (switchClick)=\"notifyClick.emit()\"></app-toggle-switch>\n        </div>\n      </div>\n\n      <div class=\"divider\"></div>\n\n      <div class=\"d-flex py-2\">\n        <div class=\"me-2 icon-container align-self-center\">\n          <fa-icon class=\"color-highlight font-16\" [icon]=\"['fas','envelope-open-text']\" [size]=\"'lg'\"></fa-icon>\n        </div>\n        <div class=\"flex-fill align-self-center row mb-0\">\n          <strong class=\"color-theme font-14 d-block lh-sm\"\n            ><span>{{ 'profile.notifyInvitation' | translate }}</span></strong\n          >\n          <span class=\"font-11 font-400 mb-n1 color-theme opacity-70 lh-sm\">\n            {{ 'profile.notifyInvitationDesc' | translate }}</span\n          >\n        </div>\n        <div class=\"ms-auto me-3 align-self-center pe-2\">\n          <app-toggle-switch [control]=\"invitationsCheck\" (switchClick)=\"notifyClick.emit()\"></app-toggle-switch>\n        </div>\n      </div>\n\n      <div class=\"divider\"></div>\n\n      <div class=\"d-flex py-2\">\n        <div class=\"me-2 icon-container align-self-center\">\n          <fa-icon class=\"color-highlight font-16\" [icon]=\"['fas','door-open']\" [size]=\"'lg'\"></fa-icon>\n        </div>\n        <div class=\"flex-fill align-self-center row mb-0\">\n          <strong class=\"color-theme font-14 d-block lh-sm\"\n            ><span>{{ 'profile.notifyArrival' | translate }}</span></strong\n          >\n          <span class=\"font-11 font-400 mb-n1 color-theme opacity-70 lh-sm\">\n            {{ 'profile.notifyArrivalDesc' | translate }}</span\n          >\n        </div>\n        <div class=\"ms-auto me-3 align-self-center pe-2\">\n          <app-toggle-switch [control]=\"arrivalsCheck\" (switchClick)=\"notifyClick.emit()\"></app-toggle-switch>\n        </div>\n      </div>\n\n      <div class=\"divider\"></div>\n\n      <div class=\"d-flex py-2\">\n        <div class=\"me-2 icon-container align-self-center\">\n          <fa-icon class=\"color-highlight font-16\" [icon]=\"['fas','clipboard-check']\" [size]=\"'lg'\"></fa-icon>\n        </div>\n        <div class=\"flex-fill align-self-center row mb-0\">\n          <strong class=\"color-theme font-14 d-block lh-sm\"\n            ><span>{{ 'profile.notifyConfirm' | translate }}</span></strong\n          >\n          <span class=\"font-11 font-400 mb-n1 color-theme opacity-70 lh-sm\">\n            {{ 'profile.notifyConfirmDesc' | translate }}</span\n          >\n        </div>\n        <div class=\"ms-auto me-3 align-self-center pe-2\">\n          <app-toggle-switch [control]=\"confirmsCheck\" (switchClick)=\"notifyClick.emit()\"></app-toggle-switch>\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class=\"card card-style\" (click)=\"faqClick.emit()\">\n    <div class=\"content\">\n      <div class=\"d-flex\">\n        <div class=\"me-2 icon-container align-self-center\">\n          <fa-icon class=\"color-highlight font-16\" [icon]=\"['fas','circle-question']\" [size]=\"'lg'\"></fa-icon>\n        </div>\n        <div class=\"flex-fill align-self-center row mb-0\">\n          <strong class=\"color-theme font-21 font-400 d-block lh-sm\"\n            ><span>{{ 'profile.faqTitle' | translate }}</span></strong\n          >\n          <span class=\"font-11 font-400 mb-n1 color-theme opacity-70 lh-sm\"> {{ 'profile.faqDesc' | translate }}</span>\n        </div>\n        <div class=\"ms-auto me-4 align-self-center\">\n          <fa-icon [icon]=\"['fas', 'chevron-right']\" class=\"color-theme opacity-75\"></fa-icon>\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <app-banner\n    [title]=\"'profile.bannerTitle' | translate\"\n    [descrip]=\"\"\n    [contact]=\"true\"\n    [bgColor]=\"'bg-highlight py-3'\"\n    [bodyColor]=\"'color-white'\"\n    [titleClass]=\"'color-white pt-0'\"></app-banner>\n\n  <div class=\"card card-style\" (click)=\"installationClick.emit()\">\n    <div class=\"content\">\n      <div class=\"d-flex\">\n        <div class=\"me-2 icon-container align-self-center\">\n          <fa-icon class=\"color-highlight font-16\" [icon]=\"['fas','file-circle-check']\" [size]=\"'lg'\"></fa-icon>\n        </div>\n        <div class=\"flex-fill align-self-center row mb-0\">\n          <span class=\"color-theme font-14 d-block lh-sm\">{{aboutLabel}}</span>\n          <span class=\"color-theme font-14 d-block lh-sm\">{{installationLabel}}</span>\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class=\"card card-style\" (click)=\"checkTermsClick.emit()\">\n    <div class=\"content\">\n      <div class=\"d-flex\">\n        <div class=\"me-2 icon-container align-self-center\">\n          <fa-icon class=\"color-highlight font-16\" [icon]=\"['fas','book-open']\" [size]=\"'lg'\"></fa-icon>\n        </div>\n        <div class=\"flex-fill align-self-center row mb-0\">\n          <span class=\"color-theme font-14 d-block lh-sm\">{{ 'profile.consultTermsLabel' | translate }}</span>\n        </div>\n        <div class=\"ms-auto me-4 align-self-center\">\n          <fa-icon [icon]=\"['fas', 'chevron-right']\" class=\"color-theme opacity-75\"></fa-icon>\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class=\"card card-style\" (click)=\"confirmModal.show()\">\n    <div class=\"content\">\n      <div class=\"d-flex\">\n        <div class=\"me-2 icon-container align-self-center\">\n          <fa-icon class=\"color-highlight font-16\" [icon]=\"['fas','xmark']\" [size]=\"'lg'\"></fa-icon>\n        </div>\n        <div class=\"flex-fill align-self-center row mb-0\">\n          <span class=\"color-theme font-14 d-block lh-sm\">{{ 'profile.logoutTitle' | translate }}</span>\n        </div>\n        <div class=\"ms-auto me-4 align-self-center\">\n          <fa-icon [icon]=\"['fas', 'chevron-right']\" class=\"color-theme opacity-75\"></fa-icon>\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class=\"card card-style\" (click)=\"closeModal.show()\">\n    <div class=\"content\">\n      <div class=\"d-flex\">\n        <div class=\"me-2 icon-container align-self-center\">\n          <fa-icon class=\"color-highlight font-16\" [icon]=\"['fas','ban']\" [size]=\"'lg'\"></fa-icon>\n        </div>\n        <div class=\"flex-fill align-self-center row mb-0\">\n          <span class=\"color-theme font-14 d-block lh-sm\">{{ 'profile.closeAccountTitle' | translate }}</span>\n        </div>\n        <div class=\"ms-auto me-4 align-self-center\">\n          <fa-icon [icon]=\"['fas', 'chevron-right']\" class=\"color-theme opacity-75\"></fa-icon>\n        </div>\n      </div>\n    </div>\n  </div>\n</app-page-layout>\n\n<app-modal-menu id=\"confirmModal\" #confirmModal [height]=\"'h-25'\">\n  <ng-template #modalContent>\n    <div class=\"center w-100 p-3\">\n      <h6 class=\"font-400 font-16 pb-3 lh-sm\">{{ 'profile.confirmLogout' | translate }}</h6>\n      <app-button\n        [label]=\"'common.confirm' | translate\"\n        (buttonClick)=\"logoutClick.emit(); confirmModal.hide()\"></app-button>\n      <div class=\"pt-2\"></div>\n      <app-button\n        [bgClass]=\"'bg-transparent'\"\n        [customClass]=\"'w-100 border-highlight color-highlight'\"\n        [label]=\"'common.cancel' | translate\"\n        (buttonClick)=\"confirmModal.hide()\"></app-button>\n    </div>\n  </ng-template>\n</app-modal-menu>\n\n<app-modal-menu id=\"closeModal\" #closeModal [height]=\"'h-25'\">\n  <ng-template #modalContent>\n    <div class=\"center w-100 p-3\">\n      <h6 class=\"font-400 font-16 pb-3 lh-sm\">{{ 'profile.confirmClose' | translate }}</h6>\n      <app-button [label]=\"'common.accept' | translate\" (buttonClick)=\"closeModal.hide()\"></app-button>\n    </div>\n  </ng-template>\n</app-modal-menu>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_profile_profile_module_ts.js.map