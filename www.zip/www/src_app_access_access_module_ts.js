(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_access_access_module_ts"],{

/***/ 71750:
/*!*************************************************!*\
  !*** ./src/app/access/access-routing.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccessRoutingModule": () => (/* binding */ AccessRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _pages_access_info_access_info_business__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pages/access-info/access-info.business */ 12860);
/* harmony import */ var _pages_access_point_access_point_business__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pages/access-point/access-point.business */ 33953);
/* harmony import */ var _pages_access_access_business__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pages/access/access.business */ 88941);
/* harmony import */ var _pages_access_point_wizard_new_access_point_business__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/access-point-wizard/new-access-point.business */ 11942);
/* harmony import */ var _pages_no_access_no_access_business__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/no-access/no-access.business */ 52733);
/* harmony import */ var _src_app_shared_pages_attendance_attendance_business__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../src/app/shared/pages/attendance/attendance.business */ 99353);
/* harmony import */ var _sites_pages_users_users_business__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../sites/pages/users/users.business */ 17558);










const routes = [{
  path: '',
  component: _pages_access_access_business__WEBPACK_IMPORTED_MODULE_2__.AccessBusiness
}, {
  path: 'access-info/:id',
  component: _pages_access_info_access_info_business__WEBPACK_IMPORTED_MODULE_0__.AccessInfoBusiness
}, {
  path: 'no-access',
  component: _pages_no_access_no_access_business__WEBPACK_IMPORTED_MODULE_4__.NoAccessBusiness
}, {
  path: 'access-point/:id',
  component: _pages_access_point_access_point_business__WEBPACK_IMPORTED_MODULE_1__.AccessPointBusiness
}, {
  path: 'access-point/users/:id',
  component: _sites_pages_users_users_business__WEBPACK_IMPORTED_MODULE_6__.UsersBusiness
}, {
  path: 'attendance/:id',
  component: _src_app_shared_pages_attendance_attendance_business__WEBPACK_IMPORTED_MODULE_5__.AttendanceBusiness
}, {
  path: 'new-access-point/:id',
  component: _pages_access_point_wizard_new_access_point_business__WEBPACK_IMPORTED_MODULE_3__.NewAccessPointBusiness
}];
let AccessRoutingModule = class AccessRoutingModule {};
AccessRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.NgModule)({
  imports: [_angular_router__WEBPACK_IMPORTED_MODULE_9__.RouterModule.forChild(routes)],
  exports: [_angular_router__WEBPACK_IMPORTED_MODULE_9__.RouterModule]
})], AccessRoutingModule);


/***/ }),

/***/ 85356:
/*!*****************************************!*\
  !*** ./src/app/access/access.module.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccessModule": () => (/* binding */ AccessModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/common */ 89650);
/* harmony import */ var _access_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./access-routing.module */ 71750);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../shared/shared.module */ 56208);
/* harmony import */ var _pages_access_access_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pages/access/access.page */ 17369);
/* harmony import */ var _components_access_list_access_list_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/access-list/access-list.component */ 28809);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var _pages_access_access_business__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/access/access.business */ 88941);
/* harmony import */ var _pages_access_info_access_info_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages/access-info/access-info.page */ 57278);
/* harmony import */ var _pages_access_info_access_info_business__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pages/access-info/access-info.business */ 12860);
/* harmony import */ var _pages_no_access_no_access_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./pages/no-access/no-access.page */ 64325);
/* harmony import */ var _pages_no_access_no_access_business__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./pages/no-access/no-access.business */ 52733);
/* harmony import */ var _pages_access_point_access_point_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./pages/access-point/access-point.page */ 31797);
/* harmony import */ var _pages_access_point_access_point_business__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./pages/access-point/access-point.business */ 33953);
/* harmony import */ var _pages_access_point_wizard_new_access_point_page__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./pages/access-point-wizard/new-access-point.page */ 83810);
/* harmony import */ var _pages_access_point_wizard_new_access_point_business__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./pages/access-point-wizard/new-access-point.business */ 11942);
/* harmony import */ var _components_access_point_name_access_point_name_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./components/access-point-name/access-point-name.component */ 60295);
/* harmony import */ var _components_access_point_date_access_point_date_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./components/access-point-date/access-point-date.component */ 262);
/* harmony import */ var _components_access_point_control_access_point_control_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./components/access-point-control/access-point-control.component */ 52403);
/* harmony import */ var _components_access_point_address_access_point_address_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./components/access-point-address/access-point-address.component */ 42439);
/* harmony import */ var _components_access_point_edit_access_point_edit_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./components/access-point-edit/access-point-edit.component */ 20805);
/* harmony import */ var _invite_invite_module__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../invite/invite.module */ 26723);
























let AccessModule = class AccessModule {};
AccessModule = (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_20__.NgModule)({
  declarations: [_pages_access_access_page__WEBPACK_IMPORTED_MODULE_2__.AccessPage, _pages_access_access_business__WEBPACK_IMPORTED_MODULE_4__.AccessBusiness, _components_access_list_access_list_component__WEBPACK_IMPORTED_MODULE_3__.AccessListComponent, _pages_access_info_access_info_page__WEBPACK_IMPORTED_MODULE_5__.AccessInfoPage, _pages_access_info_access_info_business__WEBPACK_IMPORTED_MODULE_6__.AccessInfoBusiness, _pages_no_access_no_access_page__WEBPACK_IMPORTED_MODULE_7__.NoAccessPage, _pages_no_access_no_access_business__WEBPACK_IMPORTED_MODULE_8__.NoAccessBusiness, _pages_access_point_access_point_page__WEBPACK_IMPORTED_MODULE_9__.AccessPointPage, _pages_access_point_access_point_business__WEBPACK_IMPORTED_MODULE_10__.AccessPointBusiness, _pages_access_point_wizard_new_access_point_page__WEBPACK_IMPORTED_MODULE_11__.NewAccessPointPage, _pages_access_point_wizard_new_access_point_business__WEBPACK_IMPORTED_MODULE_12__.NewAccessPointBusiness, _components_access_point_name_access_point_name_component__WEBPACK_IMPORTED_MODULE_13__.AccessPointNameComponent, _components_access_point_date_access_point_date_component__WEBPACK_IMPORTED_MODULE_14__.AccessPointDateComponent, _components_access_point_control_access_point_control_component__WEBPACK_IMPORTED_MODULE_15__.AccessPointControlComponent, _components_access_point_address_access_point_address_component__WEBPACK_IMPORTED_MODULE_16__.AccessPointAddressComponent, _components_access_point_edit_access_point_edit_component__WEBPACK_IMPORTED_MODULE_17__.AccessPointEditComponent],
  exports: [_access_routing_module__WEBPACK_IMPORTED_MODULE_0__.AccessRoutingModule, _pages_access_access_page__WEBPACK_IMPORTED_MODULE_2__.AccessPage, _pages_access_info_access_info_page__WEBPACK_IMPORTED_MODULE_5__.AccessInfoPage, _pages_no_access_no_access_page__WEBPACK_IMPORTED_MODULE_7__.NoAccessPage, _pages_access_point_access_point_page__WEBPACK_IMPORTED_MODULE_9__.AccessPointPage, _pages_access_point_access_point_business__WEBPACK_IMPORTED_MODULE_10__.AccessPointBusiness, _pages_access_point_wizard_new_access_point_page__WEBPACK_IMPORTED_MODULE_11__.NewAccessPointPage, _pages_access_point_wizard_new_access_point_business__WEBPACK_IMPORTED_MODULE_12__.NewAccessPointBusiness, _components_access_point_name_access_point_name_component__WEBPACK_IMPORTED_MODULE_13__.AccessPointNameComponent, _components_access_point_date_access_point_date_component__WEBPACK_IMPORTED_MODULE_14__.AccessPointDateComponent, _components_access_point_control_access_point_control_component__WEBPACK_IMPORTED_MODULE_15__.AccessPointControlComponent, _components_access_point_address_access_point_address_component__WEBPACK_IMPORTED_MODULE_16__.AccessPointAddressComponent, _components_access_point_edit_access_point_edit_component__WEBPACK_IMPORTED_MODULE_17__.AccessPointEditComponent],
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_21__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_23__.IonicModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule, _access_routing_module__WEBPACK_IMPORTED_MODULE_0__.AccessRoutingModule, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.ReactiveFormsModule, _invite_invite_module__WEBPACK_IMPORTED_MODULE_18__.InviteModule]
})], AccessModule);


/***/ }),

/***/ 28809:
/*!************************************************************************!*\
  !*** ./src/app/access/components/access-list/access-list.component.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccessListComponent": () => (/* binding */ AccessListComponent)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _access_list_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./access-list.component.html?ngResource */ 25483);
/* harmony import */ var _access_list_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./access-list.component.scss?ngResource */ 32073);
/* harmony import */ var _access_list_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_access_list_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var src_app_shared_helpers_business__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/helpers/business */ 92237);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 67690);

var _class;







let AccessListComponent = (_class = class AccessListComponent {
  constructor(business, navController, translate) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "business", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "access", void 0);
    this.business = business;
    this.navController = navController;
    this.translate = translate;
  }
  accessClick(apId) {
    const navigationExtras = {
      state: {
        component: 'access'
      }
    };
    console.log('Click! ' + apId);
    this.navController.navigateForward('access/access-info/' + apId, navigationExtras);
  }
  getTitle(title) {
    const array = [];
    const splitString = title.split('-');
    array.push(splitString[0]);
    array.push(splitString[1]);
    return array;
  }
  getTopTexts(ap) {
    const dateRange = ap.dateTo === null && ap.recurrency ? `${this.translate.instant('recurence.from')} ` + this.business.getDateRange(ap) : this.business.getDateRange(ap);
    const recurrence = this.business.getRecurrence(ap);
    const timeRange = this.translate.instant('recurence.entry') + ' ' + this.business.getTimeRange(ap);
    const array = [];
    array.push(dateRange);
    array.push(recurrence);
    array.push(timeRange);
    return array;
  }
  getBadgeText(i) {
    if (i.roles?.find(x => x === 'Owner')) {
      return 'common.roles.owner';
    }
    return '';
  }
  getBagdeIcon(i) {
    if (i.roles?.find(x => x === 'Owner')) {
      return 'key';
    }
    return undefined;
  }
  sortByOwnerRole(access) {
    return access.sort((a, b) => {
      const aIsOwner = a.invitation.roles?.includes('Owner') || false;
      const bIsOwner = b.invitation.roles?.includes('Owner') || false;
      if (aIsOwner && !bIsOwner) {
        return -1;
      } else if (!aIsOwner && bIsOwner) {
        return 1;
      } else {
        return 0;
      }
    });
  }
  getAccessSortedByOwner() {
    if (this.access) {
      return this.sortByOwnerRole(this.access);
    }
    return undefined;
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_helpers_business__WEBPACK_IMPORTED_MODULE_3__["default"]
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController
}, {
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslateService
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  access: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Input
  }]
}), _class);
AccessListComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
  selector: 'app-access-list',
  template: _access_list_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_access_list_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], AccessListComponent);


/***/ }),

/***/ 12860:
/*!******************************************************************!*\
  !*** ./src/app/access/pages/access-info/access-info.business.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccessInfoBusiness": () => (/* binding */ AccessInfoBusiness)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var src_app_invite_pages_invitation_wizard_invitation_wizard_business__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/invite/pages/invitation-wizard/invitation-wizard.business */ 8393);
/* harmony import */ var src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/models/Enums */ 6452);
/* harmony import */ var src_app_shared_services_access_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/services/access.service */ 46554);
/* harmony import */ var _components_access_point_selection_access_point_selection_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/access-point-selection/access-point-selection.component */ 2583);
/* harmony import */ var src_app_shared_services_invitation_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/services/invitation.service */ 21178);
/* harmony import */ var src_app_sites_pages_users_users_business__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/sites/pages/users/users.business */ 17558);
/* harmony import */ var src_app_shared_services_access_point_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/services/access-point.service */ 58838);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 51547);


var _class;












let AccessInfoBusiness = (_class = class AccessInfoBusiness {
  constructor(accessService, accessPointService, invitationService, navController, route, router) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPointService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitationService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "route", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "router", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "apSelection", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "edit", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "access", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitations", []);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "apList", []);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "urlBack", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "componentText", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "data", void 0);
    this.accessService = accessService;
    this.accessPointService = accessPointService;
    this.invitationService = invitationService;
    this.navController = navController;
    this.route = route;
    this.router = router;
    this.route.queryParams.subscribe(() => {
      if (this.router?.getCurrentNavigation()?.extras.state) {
        const state = this.router.getCurrentNavigation()?.extras.state;
        if (state) {
          const guests = state.contacts;
          console.table(guests);
          console.log('save confirm');
        }
      }
    });
  }
  get isOwner() {
    if (this.access?.invitation.roles?.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_3__.AccessPointRole.owner)) {
      return true;
    } else {
      return false;
    }
  }
  get isAdmin() {
    if (this.access?.invitation.roles?.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_3__.AccessPointRole.administrator)) {
      return true;
    } else {
      return false;
    }
  }
  ngOnInit() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this.route.snapshot.params.id != null) {
        _this.accessId = _this.route.snapshot.params.id;
        _this.route.queryParams.subscribe(params => {
          if (_this.router.getCurrentNavigation()?.extras.state) {
            _this.data = _this.router.getCurrentNavigation()?.extras.state?.component;
          }
        });
        _this.accessService.getAccess(_this.accessId).subscribe(response => {
          if (response.error == null) {
            _this.access = response.data;
            console.log(_this.access);
          } else _this.navController.navigateRoot('error');
        });
      }
    })();
  }
  backClick() {
    this.navController.back();
  }
  locationClick() {
    this.apList = [];
    this.invitationService.getInvitationAccessPoints(this.access.invitationId).subscribe(response => {
      if (response.error == null) {
        this.apList = response.data;
        if (this.apList.length !== 0) {
          if (this.apList.length > 1) this.apSelection?.modal?.show();else {
            const isMainDoor = true;
            const navigationExtras = {
              state: {
                component: 'site',
                accessId: this.accessId,
                title: this.access.invitation.motive,
                mainDoor: isMainDoor
              }
            };
            this.navController.navigateForward('access/access-point/' + this.apList[0].id, navigationExtras);
          }
        }
      } else this.navController.navigateRoot('error');
    });
  }
  hostsButtonClick() {
    var _this2 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const role = src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_3__.AccessPointRole.owner;
      let users;
      const vm = new src_app_sites_pages_users_users_business__WEBPACK_IMPORTED_MODULE_7__.ContactParameters();
      vm.id = _this2.access.accessPointId;
      vm.role = role;
      const gResponse = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.lastValueFrom)(_this2.accessPointService.getUsers(vm));
      if (gResponse.error == null) {
        users = gResponse.data;
        _this2.navController.navigateForward('access/access-point/users/' + _this2.access.accessPointId, {
          state: {
            siteName: _this2.access.accessPointName,
            contacts: users,
            role
          }
        });
      } else _this2.navController.navigateRoot('error');
    })();
  }
  assistSwitchClick(value) {
    var _this3 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('Assist switch Click!');
      yield _this3.accessService.updateAttendance(_this3.access.id, value).subscribe();
    })();
  }
  newAccess() {
    this.navController.navigateForward('access/new-access-point/' + this.access.invitation?.siteId);
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_services_access_service__WEBPACK_IMPORTED_MODULE_4__.AccessService
}, {
  type: src_app_shared_services_access_point_service__WEBPACK_IMPORTED_MODULE_8__.AccessPointService
}, {
  type: src_app_shared_services_invitation_service__WEBPACK_IMPORTED_MODULE_6__.InvitationService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.NavController
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_11__.ActivatedRoute
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_11__.Router
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "propDecorators", {
  apSelection: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.ViewChild,
    args: [_components_access_point_selection_access_point_selection_component__WEBPACK_IMPORTED_MODULE_5__.AccessPointSelectionComponent]
  }],
  edit: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.ViewChild,
    args: [src_app_invite_pages_invitation_wizard_invitation_wizard_business__WEBPACK_IMPORTED_MODULE_2__.InvitationWizardBusiness]
  }]
}), _class);
AccessInfoBusiness = (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Component)({
  selector: 'app-access-info-component',
  template: `<app-access-info
      class="scroll-content"
      *ngIf="access"
      [access]="access"
      [invitations]="invitations"
      (back)="backClick()"
      (bannerClick)="locationClick()"
      (locationBadgeClick)="locationClick()"
      (hostsButtonClick)="hostsButtonClick()"
      (assistSwitchClick)="assistSwitchClick($event)"></app-access-info>
    <app-access-point-selection
      *ngIf="access"
      [accessPointList]="apList"
      [invitation]="access.invitation"
      [showNewAccess]="isAdmin"
      (newAccess)="newAccess()"></app-access-point-selection>
    <app-invitation-wizard-business [isEdit]="true"></app-invitation-wizard-business>`
})], AccessInfoBusiness);


/***/ }),

/***/ 57278:
/*!**************************************************************!*\
  !*** ./src/app/access/pages/access-info/access-info.page.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccessInfoPage": () => (/* binding */ AccessInfoPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _access_info_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./access-info.page.html?ngResource */ 64810);
/* harmony import */ var _access_info_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./access-info.page.scss?ngResource */ 94407);
/* harmony import */ var _access_info_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_access_info_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var src_app_shared_components_button_panel_button_panel_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/button-panel/button-panel.component */ 35081);
/* harmony import */ var src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/components/footer/footer.component */ 68014);
/* harmony import */ var src_app_shared_components_modal_menu_modal_menu_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/components/modal-menu/modal-menu.component */ 77098);
/* harmony import */ var src_app_shared_helpers_business__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/helpers/business */ 92237);
/* harmony import */ var src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/models/Enums */ 6452);

var _class;











let AccessInfoPage = (_class = class AccessInfoPage {
  constructor(business, translate) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "business", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "confirmModal", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "access", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "invitations", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "back", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "bannerClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "locationBadgeClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "hostsButtonClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "assistSwitchClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "footerOptions", src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_4__.FooterSelectedOption);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "buttonsConfig", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "stylePanel", 'mb-n2 justify-content-center');
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "cardStyle", 'mb-0');
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "locationClass", ['fas', 'location-pin']);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "currentStep", 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "rows", 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "role", src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_7__.AccessPointRole);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "avatarApi", 'https://api.dicebear.com/5.x/initials/svg?backgroundColor=0078d7&seed=');
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "assistSwitchControl", new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControl(false));
    this.business = business;
    this.translate = translate;
  }
  get isAdmin() {
    return this.access.invitation.roles?.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_7__.AccessPointRole.administrator);
  }
  get isOwner() {
    return this.access.invitation.roles?.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_7__.AccessPointRole.owner);
  }
  get isGuest() {
    return this.access.invitation.roles?.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_7__.AccessPointRole.guest);
  }
  get ownerImg() {
    if (this.access.invitation.ownerImg) {
      return this.access.invitation.ownerImg.url;
    } else if (this.access.invitation.ownerName) {
      return this.avatarApi + this.access.invitation.ownerName.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]|[\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD10-\uDDFF]/gi, '');
    } else {
      return 'assets/icons/avatar.png';
    }
  }
  get hasPicture() {
    return this.access.invitation?.ownerImg !== undefined && this.access.invitation?.ownerImg !== null;
  }
  get invitationDescription() {
    return this.access.invitation.description !== '' && this.access.invitation.description !== undefined ? this.access.invitation.description : this.access.invitation.motive;
  }
  ngOnInit() {
    this.getButtonsConfig();
    this.assistSwitchControl.setValue(this.access.attendance);
  }
  getButtonsConfig() {
    if (!this.isGuest) {
      this.buttonsConfig = new src_app_shared_components_button_panel_button_panel_component__WEBPACK_IMPORTED_MODULE_3__.ButtonPanelConfig();
      this.stylePanel = 'justify-content-center';
      this.rows = 1;
      const button = {
        click: () => {
          this.hostsButtonClick.emit(this.access.invitationId);
        },
        label: this.translate.instant('common.hostButton'),
        faClass: ['fas', 'user-gear']
      };
      this.buttonsConfig.buttons = [button];
    } else {
      this.cardStyle = 'mb-1';
      this.locationClass = ['fas', 'location-pin'];
    }
  }
  tryUnassist() {
    if (this.assistSwitchControl.value === true) {
      this.assistSwitchClick.emit(true);
    } else {
      this.confirmModal?.show();
    }
  }
  confirm() {
    this.confirmModal?.hide();
    this.assistSwitchClick.emit(false);
  }
  cancel() {
    this.confirmModal?.hide();
    this.assistSwitchControl.setValue(true);
  }
  getTitle() {
    const dateRange = this.access.invitation.dateTo === null && this.access.invitation.recurrency ? `${this.translate.instant('recurence.from')} ` + this.business.getDateRange(this.access.invitation) : this.business.getDateRange(this.access.invitation);
    const recurrence = this.business.getRecurrence(this.access.invitation);
    const array = [];
    array.push(dateRange);
    array.push(recurrence);
    return array;
  }
  getSubtitle() {
    return this.translate.instant('recurence.entry') + ' ' + this.business.getTimeRange(this.access.invitation);
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_helpers_business__WEBPACK_IMPORTED_MODULE_6__["default"]
}, {
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__.TranslateService
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  confirmModal: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild,
    args: [src_app_shared_components_modal_menu_modal_menu_component__WEBPACK_IMPORTED_MODULE_5__.ModalMenuComponent]
  }],
  access: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input
  }],
  invitations: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input
  }],
  back: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  bannerClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  locationBadgeClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  hostsButtonClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  assistSwitchClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }]
}), _class);
AccessInfoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
  selector: 'app-access-info',
  template: _access_info_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_access_info_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], AccessInfoPage);


/***/ }),

/***/ 83810:
/*!***************************************************************************!*\
  !*** ./src/app/access/pages/access-point-wizard/new-access-point.page.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewAccessPointPage": () => (/* binding */ NewAccessPointPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _new_access_point_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./new-access-point.page.html?ngResource */ 3083);
/* harmony import */ var _new_access_point_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./new-access-point.page.scss?ngResource */ 35167);
/* harmony import */ var _new_access_point_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_new_access_point_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/button/button.component */ 62490);
/* harmony import */ var src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/components/footer/footer.component */ 68014);
/* harmony import */ var _components_access_point_control_access_point_control_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/access-point-control/access-point-control.component */ 52403);
/* harmony import */ var _components_access_point_date_access_point_date_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../components/access-point-date/access-point-date.component */ 262);
/* harmony import */ var _components_access_point_name_access_point_name_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../components/access-point-name/access-point-name.component */ 60295);
/* harmony import */ var _components_access_point_address_access_point_address_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../components/access-point-address/access-point-address.component */ 42439);
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/animations */ 66400);

var _class;











const left = [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.query)(':enter, :leave', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({
  position: 'fixed',
  width: '100%'
}), {
  optional: true
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.group)([(0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.query)(':enter', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({
  transform: 'translateX(-100%)'
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.animate)('.3s ease-out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({
  transform: 'translateX(0%)'
}))], {
  optional: true
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.query)(':leave', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({
  transform: 'translateX(0%)'
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.animate)('.3s ease-out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({
  transform: 'translateX(100%)'
}))], {
  optional: true
})])];
const right = [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.query)(':enter, :leave', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({
  position: 'fixed',
  width: '100%'
}), {
  optional: true
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.group)([(0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.query)(':enter', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({
  transform: 'translateX(100%)'
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.animate)('.3s ease-out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({
  transform: 'translateX(0%)'
}))], {
  optional: true
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.query)(':leave', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({
  transform: 'translateX(0%)'
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.animate)('.3s ease-out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({
  transform: 'translateX(-100%)'
}))], {
  optional: true
})])];
let NewAccessPointPage = (_class = class NewAccessPointPage {
  constructor(cdRef) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "cdRef", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "nameC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "addressC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "dateC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "controlC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "loading", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "site", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "apList", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "saveAccess", new _angular_core__WEBPACK_IMPORTED_MODULE_10__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "back", new _angular_core__WEBPACK_IMPORTED_MODULE_10__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "nextClick", new _angular_core__WEBPACK_IMPORTED_MODULE_10__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "steps", [1, 2, 3]);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "currentStep", 1);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "footerOptions", src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_4__.FooterSelectedOption);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "buttonsConfig", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "titleLabel", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "showKeyboard", false);
    this.cdRef = cdRef;
  }
  get currentStepValid() {
    switch (this.currentStep) {
      case 1:
        return this.nameC?.formValid;
      case 2:
        return this.addressC?.formValid;
      case 3:
        return this.dateC?.formValid;
      // case 4:
      //   return this.controlC?.formValid;
    }
  }

  get buttonState() {
    if (!this.currentStepValid) {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_3__.ButtonState.disabled;
    } else if (!this.loading) {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_3__.ButtonState.enabled;
    } else {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_3__.ButtonState.loading;
    }
  }
  nextStep() {
    let currentStepModel;
    switch (this.currentStep) {
      case 1:
        currentStepModel = this.nameC?.viewModel;
        if (this.site?.address) {
          this.addressC?.getAutocomplete(this.site?.address);
        }
        break;
      case 2:
        currentStepModel = this.addressC?.viewModel;
        break;
      case 3:
        currentStepModel = this.dateC?.viewModel;
        break;
      // case 4:
      //   currentStepModel = this.controlC?.viewModel;
      //   break;
    }

    if (this.currentStep !== this.steps.length) {
      this.nextClick.emit(currentStepModel);
      this.currentStep++;
    } else {
      this.loading = true;
      this.saveAccess.emit(currentStepModel);
    }
    this.cdRef.detectChanges();
  }
  getState() {
    return this.buttonState;
  }
  backStep(step) {
    if (step) {
      this.currentStep = step;
    } else {
      if (this.currentStep === 1) {
        this.back.emit();
      }
      this.currentStep--;
    }
  }
  hide() {
    this.showKeyboard = true;
    this.cdRef.detectChanges();
  }
  show() {
    this.showKeyboard = false;
    this.cdRef.detectChanges();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ChangeDetectorRef
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  nameC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ViewChild,
    args: [_components_access_point_name_access_point_name_component__WEBPACK_IMPORTED_MODULE_7__.AccessPointNameComponent]
  }],
  addressC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ViewChild,
    args: [_components_access_point_address_access_point_address_component__WEBPACK_IMPORTED_MODULE_8__.AccessPointAddressComponent]
  }],
  dateC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ViewChild,
    args: [_components_access_point_date_access_point_date_component__WEBPACK_IMPORTED_MODULE_6__.AccessPointDateComponent]
  }],
  controlC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ViewChild,
    args: [_components_access_point_control_access_point_control_component__WEBPACK_IMPORTED_MODULE_5__.AccessPointControlComponent]
  }],
  loading: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input
  }],
  site: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input
  }],
  apList: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input
  }],
  saveAccess: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output
  }],
  back: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output
  }],
  nextClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output
  }]
}), _class);
NewAccessPointPage = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
  selector: 'app-new-access-point',
  template: _new_access_point_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  animations: [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.trigger)('animSlider', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.transition)(':increment', right), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.transition)(':decrement', left)])],
  styles: [(_new_access_point_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], NewAccessPointPage);


/***/ }),

/***/ 33953:
/*!********************************************************************!*\
  !*** ./src/app/access/pages/access-point/access-point.business.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccessPointBusiness": () => (/* binding */ AccessPointBusiness)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var src_app_shared_components_floating_msg_floating_msg_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/components/floating-msg/floating-msg.component */ 50983);
/* harmony import */ var src_app_shared_models_MsgConfig__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/models/MsgConfig */ 34391);
/* harmony import */ var src_app_shared_services_access_point_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/services/access-point.service */ 58838);
/* harmony import */ var _access_point_wizard_new_access_point_business__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../access-point-wizard/new-access-point.business */ 11942);
/* harmony import */ var src_app_shared_models_PostAccessPointAnswerViewModel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/models/PostAccessPointAnswerViewModel */ 67356);
/* harmony import */ var src_app_shared_models_PostAccessPointQuestionViewModel__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/models/PostAccessPointQuestionViewModel */ 71590);
/* harmony import */ var src_app_shared_components_profile_selection_profile_selection_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/components/profile-selection/profile-selection.component */ 10763);
/* harmony import */ var src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/models/Enums */ 6452);
/* harmony import */ var src_app_sites_pages_users_users_business__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/sites/pages/users/users.business */ 17558);
/* harmony import */ var src_app_shared_services_invitation_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/shared/services/invitation.service */ 21178);
/* harmony import */ var _components_access_point_control_access_point_control_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../components/access-point-control/access-point-control.component */ 52403);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 51547);


var _class;

















let AccessPointBusiness = (_class = class AccessPointBusiness {
  constructor(accessPointService, invitationService, translate, route, router, navController) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPointService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitationService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "route", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "router", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "toast", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "apEditC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "profileModal", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "confirmModalC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPoint", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPointId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "mainDoor", true);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitations", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "title", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "loading", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "isLoaded", false);
    this.accessPointService = accessPointService;
    this.invitationService = invitationService;
    this.translate = translate;
    this.route = route;
    this.router = router;
    this.navController = navController;
  }
  get userRoles() {
    if (this.accessPoint?.roles.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_9__.AccessPointRole.administrator)) return src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_9__.AccessPointRole.administrator;
    if (this.accessPoint?.roles.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_9__.AccessPointRole.owner)) return src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_9__.AccessPointRole.owner;else return src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_9__.AccessPointRole.operator;
  }
  ngOnInit() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.getNavigation();
      if (_this.route.snapshot.params.id != null) {
        _this.accessPointId = _this.route.snapshot.params.id;
        _this.accessPointService.getAccessPointById(_this.accessPointId).subscribe(response => {
          if (response.error == null) {
            _this.accessPoint = response.data;
            if (_this.accessPoint.roles.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_9__.AccessPointRole.owner) || _this.accessPoint.roles.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_9__.AccessPointRole.administrator) || _this.accessPoint.roles.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_9__.AccessPointRole.operator)) {
              _this.invitationService.getInvitationsByAccessPoint(_this.accessPointId).subscribe(apResponse => {
                if (apResponse.error == null) _this.invitations = apResponse.data;else _this.navController.navigateRoot('error');
              });
            }
            _this.isLoaded = true;
          } else _this.navController.navigateRoot('error');
        });
      }
    })();
  }
  getNavigation() {
    const current = this.router.getCurrentNavigation();
    if (current?.extras.state !== undefined) {
      this.accessId = current.extras.state.accessId;
      this.mainDoor = current.extras.state.mainDoor;
      console.log(this.mainDoor);
      if (current.extras.state.title !== undefined) {
        this.title = current.extras.state.title;
      } else {
        this.backClick();
      }
    } else {
      this.backClick();
    }
  }
  backClick() {
    this.navController.back();
  }
  nameEdit() {
    console.log('Name edit Click!');
    this.apEditC?.openModal(this.accessPointId, 1);
  }
  locationEdit() {
    console.log('Location edit Click!');
    this.apEditC?.openModal(this.accessPointId, 2);
  }
  timeEdit() {
    console.log('Time edit Click!');
    this.apEditC?.openModal(this.accessPointId, 3);
  }
  formEdit(notes) {
    console.log('Form edit Click!');
    const vm = new _components_access_point_control_access_point_control_component__WEBPACK_IMPORTED_MODULE_12__.UpdateAccessPointControlViewModel();
    vm.id = this.accessPointId;
    vm.noteAccess = notes;
    this.accessPointService.updateNotes(vm).subscribe(res => {
      if (res.error === null) {
        this.navController.back();
      } else {
        this.navController.navigateRoot('error');
      }
    });
  }
  newInvitation() {
    console.log('New Invitation click!');
    this.navController.navigateForward('invite/new-invitation/' + this.accessPoint.siteId);
  }
  newInvite(i) {
    var _this2 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('Invite click: ' + i.invitationId);
      _this2.navController.navigateForward('invite/guests/' + i.invitationId, {
        state: {
          contacts: [],
          invDescription: i.description
        }
      });
    })();
  }
  doorClick() {
    console.log('Door button Click!');
  }
  assistanceClick() {
    const navigationExtras = {
      state: {
        component: 'access-point'
      }
    };
    this.navController.navigateForward('access/attendance/' + this.accessPoint.id, navigationExtras);
  }
  rolesClick() {
    this.profileModal?.modal?.show();
  }
  roleSelected(role) {
    var _this3 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('Role selected: ' + role);
      let users;
      const vm = new src_app_sites_pages_users_users_business__WEBPACK_IMPORTED_MODULE_10__.ContactParameters();
      vm.id = _this3.accessPointId;
      vm.role = role;
      const gResponse = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.lastValueFrom)(_this3.accessPointService.getUsers(vm));
      if (gResponse.error == null) {
        users = gResponse.data;
        _this3.profileModal?.modal?.hide();
        _this3.navController.navigateForward('access/access-point/users/' + _this3.accessPointId, {
          state: {
            siteName: _this3.accessPoint?.name,
            contacts: users,
            role
          }
        });
      } else _this3.navController.navigateRoot('error');
    })();
  }
  deleteClick() {
    this.confirmModalC?.show();
  }
  confirmDelete() {
    var _this4 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this4.accessPointService.delete(_this4.accessPointId).subscribe(r => {
        if (r.error == null) {
          _this4.navController.navigateForward('sites/site-info/' + _this4.accessPoint.siteId);
        } else _this4.navController.navigateRoot('error');
      });
    })();
  }
  editClick() {
    console.log('Edit button Click!');
    this.apEditC?.openModal(this.accessPointId, 1);
  }
  addNewInput(label) {
    const newInput = {
      label,
      value: '',
      questionId: ''
    };
    this.accessPoint.inputs?.push(newInput);
    this.loading = true;
    const vm = new src_app_shared_models_PostAccessPointQuestionViewModel__WEBPACK_IMPORTED_MODULE_7__.PostAccessPointQuestionViewModel();
    vm.accessPointId = this.accessPointId;
    vm.question = label;
    vm.id = crypto.randomUUID();
    this.accessPointService.addQuestion(vm).subscribe(res => {
      if (res.error === null) {
        this.accessPoint.inputs = res.data.inputs;
        this.loading = false;
        this.showSuccessToast(this.translate.instant('access.questionAdd'));
      } else {
        this.navController.navigateRoot('error');
      }
    });
  }
  editInput(input) {
    this.accessPoint.inputs?.forEach(i => {
      if (i.questionId === input.questionId) {
        i.label = input.label;
      }
    });
    const vm = new src_app_shared_models_PostAccessPointQuestionViewModel__WEBPACK_IMPORTED_MODULE_7__.PostAccessPointQuestionViewModel();
    vm.accessPointId = this.accessPointId;
    vm.question = input.label;
    vm.id = input.questionId;
    this.accessPointService.updateQuestion(vm).subscribe(res => {
      if (res.error === null) {
        this.accessPoint.inputs = res.data.inputs;
        this.loading = false;
        this.showSuccessToast(this.translate.instant('access.questionEdit'));
      } else {
        this.navController.navigateRoot('error');
      }
    });
  }
  deleteInput(input) {
    if (this.accessPoint.inputs) {
      const index = this.accessPoint.inputs?.findIndex(x => x.questionId === input.label);
      this.accessPoint.inputs?.splice(index, 1);
    }
    const vm = new src_app_shared_models_PostAccessPointQuestionViewModel__WEBPACK_IMPORTED_MODULE_7__.PostAccessPointQuestionViewModel();
    vm.accessPointId = this.accessPointId;
    vm.question = input.label;
    vm.id = input.questionId;
    this.accessPointService.deleteQuestion(vm).subscribe(res => {
      if (res.error === null) {
        this.accessPoint.inputs = res.data.inputs;
        this.loading = false;
        this.showSuccessToast(this.translate.instant('access.questionDelete'));
      } else {
        this.navController.navigateRoot('error');
      }
    });
  }
  saveForm() {
    var _this5 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log(_this5.accessPoint.inputs);
      _this5.loading = true;
      if (_this5.accessId != null) {
        const vm = new src_app_shared_models_PostAccessPointAnswerViewModel__WEBPACK_IMPORTED_MODULE_6__.PostAccessPointAnswerViewModel();
        vm.accessId = _this5.accessId;
        vm.accessPoint = _this5.accessPoint;
        _this5.accessPointService.saveFormAnswers(vm).subscribe(res => {
          if (res.error === null) {
            _this5.accessPoint.inputs = res.data.inputs;
            _this5.loading = false;
            _this5.showSuccessToast(_this5.translate.instant('access.formSave'));
          } else {
            _this5.navController.navigateRoot('error');
          }
        });
      } else {
        _this5.backClick();
      }
    })();
  }
  showSuccessToast(message) {
    const config = new src_app_shared_models_MsgConfig__WEBPACK_IMPORTED_MODULE_3__.MsgConfig();
    config.message = message;
    config.bgClass = 'bg-green-light';
    config.faaClass = 'circle-check';
    this.toast.show(config);
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_services_access_point_service__WEBPACK_IMPORTED_MODULE_4__.AccessPointService
}, {
  type: src_app_shared_services_invitation_service__WEBPACK_IMPORTED_MODULE_11__.InvitationService
}, {
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__.TranslateService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_15__.ActivatedRoute
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_15__.Router
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_16__.NavController
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "propDecorators", {
  toast: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_17__.ViewChild,
    args: [src_app_shared_components_floating_msg_floating_msg_component__WEBPACK_IMPORTED_MODULE_2__.FloatingMsgComponent]
  }],
  apEditC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_17__.ViewChild,
    args: [_access_point_wizard_new_access_point_business__WEBPACK_IMPORTED_MODULE_5__.NewAccessPointBusiness]
  }],
  profileModal: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_17__.ViewChild,
    args: [src_app_shared_components_profile_selection_profile_selection_component__WEBPACK_IMPORTED_MODULE_8__.ProfileSelectionComponent]
  }],
  confirmModalC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_17__.ViewChild,
    args: ['confirmModal']
  }]
}), _class);
AccessPointBusiness = (0,tslib__WEBPACK_IMPORTED_MODULE_18__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_17__.Component)({
  selector: 'app-access-info-component',
  template: `<app-access-point
      class="scroll-content"
      *ngIf="accessPoint"
      [accessPoint]="accessPoint"
      [mainDoor]="mainDoor"
      [invitations]="invitations"
      [title]="title"
      [loading]="loading"
      (nameEditClick)="nameEdit()"
      (mapEditClick)="locationEdit()"
      (back)="backClick()"
      (timeEditClick)="timeEdit()"
      (formEditClick)="formEdit($event)"
      (saveForm)="saveForm()"
      (newInput)="addNewInput($event)"
      (editInput)="editInput($event)"
      (deleteInput)="deleteInput($event)"
      (newInvitation)="newInvitation()"
      (newInvite)="newInvite($event)"
      (doorButtonClick)="doorClick()"
      (assistButtonClick)="assistanceClick()"
      (rolesButtonClick)="rolesClick()"
      (deleteButtonClick)="deleteClick()"
      (editButtonClick)="editClick()"></app-access-point>
    <app-new-access-point-business [edit]="true"></app-new-access-point-business>
    <app-floating-msg></app-floating-msg>
    <app-profile-selection
      *ngIf="isLoaded"
      [userRole]="userRoles"
      (roleClick)="roleSelected($event)"></app-profile-selection>
    <app-modal-menu #confirmModal>
      <ng-template #modalContent>
        <div class="center w-100 p-3">
          <h6 class="font-400 font-14 pb-3 text-center">{{ 'access.accessPointConfirmDelete' | translate }}</h6>
          <app-button
            class="w-fit"
            [label]="'common.accept' | translate"
            (buttonClick)="confirmDelete(); confirmModal.hide()"></app-button>
          <div class="pt-2"></div>
          <app-button
            class="w-fit"
            [bgClass]="'bg-transparent'"
            [customClass]="'w-100 border-highlight color-highlight'"
            [label]="'common.cancel' | translate"
            (buttonClick)="confirmModal.hide()"></app-button>
        </div>
      </ng-template>
    </app-modal-menu>`
})], AccessPointBusiness);


/***/ }),

/***/ 31797:
/*!****************************************************************!*\
  !*** ./src/app/access/pages/access-point/access-point.page.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccessPointPage": () => (/* binding */ AccessPointPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _access_point_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./access-point.page.html?ngResource */ 8687);
/* harmony import */ var _access_point_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./access-point.page.scss?ngResource */ 48821);
/* harmony import */ var _access_point_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_access_point_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var src_app_shared_components_button_panel_button_panel_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/button-panel/button-panel.component */ 35081);
/* harmony import */ var src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/components/footer/footer.component */ 68014);
/* harmony import */ var src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/models/Enums */ 6452);
/* harmony import */ var src_app_shared_helpers_business__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/helpers/business */ 92237);
/* harmony import */ var _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../shared/components/button/button.component */ 62490);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var src_app_shared_components_access_selection_access_selection_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/components/access-selection/access-selection.component */ 70239);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngx-translate/core */ 67690);

var _class;












let AccessPointPage = (_class = class AccessPointPage {
  constructor(business, translate) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "business", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "formEditModal", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "confirmModalC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessModal", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessPoint", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "mainDoor", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "invitations", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "title", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "loading", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "back", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "nameEditClick", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "mapEditClick", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "timeEditClick", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "formEditClick", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "saveForm", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "deleteInput", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "editInput", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "newInput", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "newInvitation", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "newInvite", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "doorButtonClick", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "assistButtonClick", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "rolesButtonClick", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "deleteButtonClick", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "editButtonClick", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "footerOptions", src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_4__.FooterSelectedOption);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "buttonsConfig", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "currentStep", 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "noteAccess", new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(''));
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "confirmModalTextKey", 'common.confirmChanges');
    this.business = business;
    this.translate = translate;
  }
  get isOwner() {
    return this.accessPoint?.roles?.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_5__.AccessPointRole.owner);
  }
  get isAdmin() {
    return this.accessPoint?.roles?.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_5__.AccessPointRole.administrator);
  }
  get isOperator() {
    return this.accessPoint?.roles?.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_5__.AccessPointRole.operator);
  }
  get buttonState() {
    if (!this.loading) {
      return _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_7__.ButtonState.enabled;
    } else {
      return _shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_7__.ButtonState.loading;
    }
  }
  get showFormCard() {
    return this.accessPoint.inputs !== undefined && this.accessPoint.inputs.length > 0 || this.accessPoint?.notes !== '' && this.accessPoint?.notes !== undefined;
  }
  get carrouselImages() {
    const images = [];
    images.push(this.accessPoint?.mapImage.url);
    if (this.accessPoint?.presentationImg?.length > 0) {
      this.accessPoint?.presentationImg?.forEach(image => {
        images.push(image.url);
      });
    }
    return images;
  }
  ngOnInit() {
    this.getButtonsConfig();
  }
  getButtonsConfig() {
    if (this.isAdmin) {
      this.buttonsConfig = new src_app_shared_components_button_panel_button_panel_component__WEBPACK_IMPORTED_MODULE_3__.ButtonPanelConfig();
      const buttons = [];
      let button = {
        click: () => {
          this.accessModal?.modal?.show();
        },
        label: this.translate.instant('common.invite'),
        faClass: ['fas', 'envelope']
      };
      buttons.push(button);
      button = {
        click: () => {
          this.editButtonClick.emit();
        },
        label: this.translate.instant('common.editButton'),
        faClass: ['fas', 'pencil']
      };
      buttons.push(button);
      button = {
        click: () => {
          this.rolesButtonClick.emit();
        },
        label: this.translate.instant('common.permissionButton'),
        faClass: ['fas', 'user-gear']
      };
      buttons.push(button);
      button = {
        click: () => {
          this.assistButtonClick.emit();
        },
        label: this.translate.instant('common.attendanceButton'),
        faClass: ['fas', 'users']
      };
      buttons.push(button);
      if (this.mainDoor === false) {
        button = {
          click: () => {
            this.deleteButtonClick.emit();
          },
          label: this.translate.instant('common.deleteButton'),
          faClass: ['fas', 'trash-can']
        };
        buttons.push(button);
      }
      this.buttonsConfig.buttons = buttons;
    } else if (this.isOperator) {
      this.buttonsConfig = new src_app_shared_components_button_panel_button_panel_component__WEBPACK_IMPORTED_MODULE_3__.ButtonPanelConfig();
      const buttons = [];
      let button = {
        click: () => {
          this.accessModal?.modal?.show();
        },
        label: this.translate.instant('common.invite'),
        faClass: ['fas', 'envelope']
      };
      buttons.push(button);
      button = {
        click: () => {
          this.rolesButtonClick.emit();
        },
        label: this.translate.instant('common.permissionButton'),
        faClass: ['fas', 'user-gear']
      };
      buttons.push(button);
      button = {
        click: () => {
          this.assistButtonClick.emit();
        },
        label: this.translate.instant('common.attendanceButton'),
        faClass: ['fas', 'users']
      };
      buttons.push(button);
      this.buttonsConfig.buttons = buttons;
    } else if (this.isOwner) {
      this.buttonsConfig = new src_app_shared_components_button_panel_button_panel_component__WEBPACK_IMPORTED_MODULE_3__.ButtonPanelConfig();
      const buttons = [];
      let button = {
        click: () => {
          this.accessModal?.modal?.show();
        },
        label: this.translate.instant('common.invite'),
        faClass: ['fas', 'envelope']
      };
      buttons.push(button);
      button = {
        click: () => {
          this.rolesButtonClick.emit();
        },
        label: this.translate.instant('common.permissionButton'),
        faClass: ['fas', 'user-gear']
      };
      buttons.push(button);
      this.buttonsConfig.buttons = buttons;
    }
  }
  getScheduleDays() {
    return this.business.getRecurrence(this.accessPoint);
  }
  getScheduleHours() {
    return this.business.getTimeRange(this.accessPoint);
  }
  openFormEditModal() {
    this.noteAccess.setValue(this.accessPoint?.notes ?? '');
    this.formEditModal?.show();
  }
  trySave() {
    if (this.noteAccess.dirty) {
      this.confirmModalTextKey = 'common.confirmChanges';
      this.confirmModalC?.show();
    } else {
      this.saveNotes();
    }
  }
  tryClose() {
    if (this.noteAccess.dirty) {
      this.confirmModalTextKey = 'common.confirmCancel';
      this.confirmModalC?.show();
    } else {
      this.cancel();
    }
  }
  saveNotes() {
    this.formEditModal?.hide();
    this.formEditClick.emit(this.noteAccess.value);
  }
  confirmAccept() {
    if (this.confirmModalTextKey === 'common.confirmCancel') {
      this.cancel();
    } else {
      this.saveNotes();
    }
  }
  cancel() {
    this.formEditModal?.hide();
  }
  openMap() {
    const url = `https://maps.google.com/?q=${this.accessPoint?.latitude},${this.accessPoint?.longitude}`;
    window.open(url, '_blank')?.focus();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_helpers_business__WEBPACK_IMPORTED_MODULE_6__["default"]
}, {
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__.TranslateService
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  formEditModal: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild,
    args: ['formEditModal']
  }],
  confirmModalC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild,
    args: ['confirmModal']
  }],
  accessModal: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild,
    args: [src_app_shared_components_access_selection_access_selection_component__WEBPACK_IMPORTED_MODULE_8__.AccessSelectionComponent]
  }],
  accessPoint: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Input
  }],
  mainDoor: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Input
  }],
  invitations: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Input
  }],
  title: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Input
  }],
  loading: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Input
  }],
  back: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  nameEditClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  mapEditClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  timeEditClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  formEditClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  saveForm: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  deleteInput: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  editInput: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  newInput: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  newInvitation: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  newInvite: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  doorButtonClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  assistButtonClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  rolesButtonClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  deleteButtonClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  editButtonClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }]
}), _class);
AccessPointPage = (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-access-point',
  template: _access_point_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_access_point_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], AccessPointPage);


/***/ }),

/***/ 88941:
/*!********************************************************!*\
  !*** ./src/app/access/pages/access/access.business.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccessBusiness": () => (/* binding */ AccessBusiness)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var src_app_shared_services_access_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/services/access.service */ 46554);
/* harmony import */ var src_app_shared_services_site_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/services/site.service */ 19886);
/* harmony import */ var src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/services/user.service */ 31880);
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/auth/auth.service */ 75148);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 51547);
/* harmony import */ var src_app_shared_components_plans_modal_plans_modal_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/components/plans-modal/plans-modal.component */ 78726);


var _class;









let AccessBusiness = (_class = class AccessBusiness {
  constructor(accessService, siteService, navController, userService, cdRef, authService) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "siteService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "cdRef", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "authService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "plansModal", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "aps", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "filteredList", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "mySites", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userViewModel", void 0);
    this.accessService = accessService;
    this.siteService = siteService;
    this.navController = navController;
    this.userService = userService;
    this.cdRef = cdRef;
    this.authService = authService;
  }
  get userData() {
    return this.userService.userData;
  }
  ionViewWillEnter() {
    this.filteredList = this.aps = undefined;
    this.fetchAccesses();
    this.fetchUser();
  }
  fetchAccesses() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const accessRes = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.lastValueFrom)(_this.accessService.getAccesses());
      if (accessRes.error === null) {
        if (accessRes.data.length === 0) {
          _this.navController.navigateForward('access/no-access');
        } else {
          _this.siteService.getSites().subscribe(siteRes => {
            _this.mySites = siteRes.data;
          });
        }
        _this.filteredList = _this.aps = accessRes.data;
      } else _this.navController.navigateRoot('error');
    })();
  }
  fetchUser() {
    var _this2 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const res = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.lastValueFrom)(_this2.userService.getUser());
      if (res.error === null) {
        _this2.userViewModel = res.data;
      }
    })();
  }
  bannerClick() {
    this.userService.closeBanner();
  }
  search(t) {
    this.filteredList = this.aps?.filter(ap => ap.invitation.description.toLowerCase().includes(t.toLowerCase()));
    this.cdRef.detectChanges();
  }
  newSite() {
    if (this.userViewModel?.remainingSites !== null && this.userViewModel?.remainingSites !== undefined && this.userViewModel?.remainingSites <= 0) {
      this.plansModal?.modal?.show();
    } else {
      this.navController.navigateForward('sites/new-site');
    }
  }
  newInvitation(siteId) {
    console.log('New invitation ' + siteId);
    this.navController.navigateForward('invite/new-invitation/' + siteId);
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_services_access_service__WEBPACK_IMPORTED_MODULE_2__.AccessService
}, {
  type: src_app_shared_services_site_service__WEBPACK_IMPORTED_MODULE_3__.SiteService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController
}, {
  type: src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_4__.UserService
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ChangeDetectorRef
}, {
  type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_5__.AuthService
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "propDecorators", {
  plansModal: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild,
    args: [src_app_shared_components_plans_modal_plans_modal_component__WEBPACK_IMPORTED_MODULE_6__.PlansModalComponent]
  }]
}), _class);
AccessBusiness = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-access-business',
  template: `<app-access-page
      class="scroll-content"
      [aps]="filteredList"
      [sites]="mySites"
      [initialBanner]="this.userData?.initialBanner"
      (bannerClick)="bannerClick()"
      (search)="search($event)"
      (newSite)="newSite()"
      (newInvite)="newInvitation($event)"></app-access-page>
    <app-plans-modal></app-plans-modal>`
})], AccessBusiness);


/***/ }),

/***/ 17369:
/*!****************************************************!*\
  !*** ./src/app/access/pages/access/access.page.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccessPage": () => (/* binding */ AccessPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _access_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./access.page.html?ngResource */ 78883);
/* harmony import */ var _access_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./access.page.scss?ngResource */ 36620);
/* harmony import */ var _access_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_access_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/footer/footer.component */ 68014);

var _class;





let AccessPage = (_class = class AccessPage {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "aps", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "sites", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "initialBanner", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "bannerClick", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "search", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "newSite", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "newInvite", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "footerOptions", src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__.FooterSelectedOption);
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  aps: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input
  }],
  sites: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input
  }],
  initialBanner: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input
  }],
  bannerClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }],
  search: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }],
  newSite: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }],
  newInvite: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }]
}), _class);
AccessPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
  selector: 'app-access-page',
  template: _access_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_access_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], AccessPage);


/***/ }),

/***/ 52733:
/*!**************************************************************!*\
  !*** ./src/app/access/pages/no-access/no-access.business.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NoAccessBusiness": () => (/* binding */ NoAccessBusiness)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var src_app_shared_services_site_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/services/site.service */ 19886);
/* harmony import */ var src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/services/user.service */ 31880);


var _class;





let NoAccessBusiness = (_class = class NoAccessBusiness {
  constructor(siteService, navController, userService) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "siteService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "mySites", void 0);
    this.siteService = siteService;
    this.navController = navController;
    this.userService = userService;
  }
  get userData() {
    return this.userService.userData;
  }
  ngOnInit() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.siteService.getSites().subscribe(response => {
        _this.mySites = response.data;
      });
    })();
  }
  bannerClick() {
    this.userService.closeBanner();
  }
  search(e) {
    console.log('Search Click! ' + e);
  }
  newSite() {
    this.navController.navigateForward('sites/new-site');
  }
  newInvitation(siteId) {
    console.log('New invitation ' + siteId);
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_services_site_service__WEBPACK_IMPORTED_MODULE_2__.SiteService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController
}, {
  type: src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_3__.UserService
}]), _class);
NoAccessBusiness = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
  selector: 'app-no-access-component',
  template: `<app-no-access
    [sites]="mySites"
    [initialBanner]="this.userData?.initialBanner"
    (bannerClick)="bannerClick()"
    (newSite)="newSite()"
    (newInvite)="newInvitation($event)"></app-no-access>`
})], NoAccessBusiness);


/***/ }),

/***/ 64325:
/*!**********************************************************!*\
  !*** ./src/app/access/pages/no-access/no-access.page.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NoAccessPage": () => (/* binding */ NoAccessPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _no_access_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./no-access.page.html?ngResource */ 24880);
/* harmony import */ var _no_access_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./no-access.page.scss?ngResource */ 43102);
/* harmony import */ var _no_access_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_no_access_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/footer/footer.component */ 68014);
/* harmony import */ var src_app_shared_components_modal_menu_modal_menu_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/components/modal-menu/modal-menu.component */ 77098);

var _class;






let NoAccessPage = (_class = class NoAccessPage {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "modal", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "sites", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "initialBanner", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "back", new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "newSite", new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "newInvite", new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "bannerClick", new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "footerOptions", src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__.FooterSelectedOption);
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  modal: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.ViewChild,
    args: [src_app_shared_components_modal_menu_modal_menu_component__WEBPACK_IMPORTED_MODULE_4__.ModalMenuComponent]
  }],
  sites: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input
  }],
  initialBanner: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input
  }],
  back: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output
  }],
  newSite: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output
  }],
  newInvite: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output
  }],
  bannerClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output
  }]
}), _class);
NoAccessPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
  selector: 'app-no-access',
  template: _no_access_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_no_access_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], NoAccessPage);


/***/ }),

/***/ 67356:
/*!*****************************************************************!*\
  !*** ./src/app/shared/models/PostAccessPointAnswerViewModel.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PostAccessPointAnswerViewModel": () => (/* binding */ PostAccessPointAnswerViewModel)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);

class PostAccessPointAnswerViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessPoint", void 0);
  }
}

/***/ }),

/***/ 71590:
/*!*******************************************************************!*\
  !*** ./src/app/shared/models/PostAccessPointQuestionViewModel.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PostAccessPointQuestionViewModel": () => (/* binding */ PostAccessPointQuestionViewModel)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);

class PostAccessPointQuestionViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "id", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessPointId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "question", void 0);
  }
}

/***/ }),

/***/ 32073:
/*!*************************************************************************************!*\
  !*** ./src/app/access/components/access-list/access-list.component.scss?ngResource ***!
  \*************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 94407:
/*!***************************************************************************!*\
  !*** ./src/app/access/pages/access-info/access-info.page.scss?ngResource ***!
  \***************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "::ng-deep .theme-light #walkthrough-slider .is-active {\n  background: transparent !important;\n}\n\n::ng-deep .theme-dark #walkthrough-slider .is-active {\n  background: transparent !important;\n}", "",{"version":3,"sources":["webpack://./src/app/access/pages/access-info/access-info.page.scss"],"names":[],"mappings":"AAAA;EACE,kCAAA;AACF;;AACA;EACE,kCAAA;AAEF","sourcesContent":["::ng-deep .theme-light #walkthrough-slider .is-active {\n  background: transparent !important;\n}\n::ng-deep .theme-dark #walkthrough-slider .is-active {\n  background: transparent !important;\n}\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 35167:
/*!****************************************************************************************!*\
  !*** ./src/app/access/pages/access-point-wizard/new-access-point.page.scss?ngResource ***!
  \****************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 48821:
/*!*****************************************************************************!*\
  !*** ./src/app/access/pages/access-point/access-point.page.scss?ngResource ***!
  \*****************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "::ng-deep .theme-light #walkthrough-slider .is-active {\n  background: transparent !important;\n}\n\n::ng-deep .theme-dark #walkthrough-slider .is-active {\n  background: transparent !important;\n}\n\n.title {\n  padding-bottom: 0.5rem;\n  margin-bottom: 0px;\n}\n\nem.disabled {\n  display: none !important;\n}", "",{"version":3,"sources":["webpack://./src/app/access/pages/access-point/access-point.page.scss"],"names":[],"mappings":"AAAA;EACE,kCAAA;AACF;;AACA;EACE,kCAAA;AAEF;;AACA;EACE,sBAAA;EACA,kBAAA;AAEF;;AAAA;EACE,wBAAA;AAGF","sourcesContent":["::ng-deep .theme-light #walkthrough-slider .is-active {\n  background: transparent !important;\n}\n::ng-deep .theme-dark #walkthrough-slider .is-active {\n  background: transparent !important;\n}\n\n.title {\n  padding-bottom: 0.5rem;\n  margin-bottom: 0px;\n}\nem.disabled {\n  display: none !important;\n}\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 36620:
/*!*****************************************************************!*\
  !*** ./src/app/access/pages/access/access.page.scss?ngResource ***!
  \*****************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 43102:
/*!***********************************************************************!*\
  !*** ./src/app/access/pages/no-access/no-access.page.scss?ngResource ***!
  \***********************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 25483:
/*!*************************************************************************************!*\
  !*** ./src/app/access/components/access-list/access-list.component.html?ngResource ***!
  \*************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<!-- List -->\n<ng-template #accessTemplate let-ap let-isLast=\"isLast\">\n  <app-list-item\n    [id]=\"ap.id\"\n    [isLast]=\"isLast\"\n    [title]=\"getTitle(ap.invitation.motive)\"\n    [img]=\"\n      ap.invitation.presentationImg !== null && ap.invitation.presentationImg.length > 0\n        ? ap.invitation.presentationImg[0].url\n        : ''\n    \"\n    [topTexts]=\"getTopTexts(ap.invitation)\"\n    [subText]=\"ap.invitation.place\"\n    [subTextIcon]=\"['fas', 'map-marker']\"\n    (clicked)=\"accessClick($event)\"\n    [badgeIcon]=\"getBagdeIcon(ap.invitation)\"\n    [badgeText]=\"getBadgeText(ap.invitation) | translate\">\n  </app-list-item>\n</ng-template>\n\n<ng-template #loaderTemplate>\n  <app-list-item-skeleton></app-list-item-skeleton>\n</ng-template>\n\n<app-list-container [items]=\"access\" [itemTemplate]=\"accessTemplate\" [itemLoaderTemplate]=\"loaderTemplate\">\n</app-list-container>\n";

/***/ }),

/***/ 64810:
/*!***************************************************************************!*\
  !*** ./src/app/access/pages/access-info/access-info.page.html?ngResource ***!
  \***************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-page-layout [footerSelectedOption]=\"footerOptions.access\" (back)=\"back.emit()\" [title]=\"access.invitation.motive\">\n  <div class=\"card card-style\" *ngIf=\"access\">\n    <app-carrousel [hidePagination]=\"true\" [(currentStep)]=\"currentStep\">\n      <ng-template #slide *ngFor=\"let img of access.invitation?.presentationImg\">\n        <div class=\"vh-30\">\n          <app-category-badge\n            class=\"card-top p-3\"\n            *ngIf=\"access.invitation.category\"\n            [category]=\"access.invitation.category\"></app-category-badge>\n          <div class=\"card-overlay img-gradient\"></div>\n          <app-img [img]=\"img.url\" [imgClass]=\"'rounded-sm'\"></app-img>\n        </div>\n      </ng-template>\n    </app-carrousel>\n    <div class=\"d-flex content justify-content-between\" *ngIf=\"isGuest\">\n      <div class=\"border-right pe-3 border-red-dark\">\n        <app-avatar [img]=\"ownerImg\" [defaultImg]=\"!hasPicture\" [width]=\"80\" [height]=\"80\"></app-avatar>\n        <h6 class=\"font-13 font-400 mt-2 text-center\">{{access.invitation.ownerName}}</h6>\n        <p class=\"color-highlight mt-n2 font-9 font-400 text-center\">{{'access.hostLabel'|translate}}</p>\n      </div>\n      <div class=\"w-fill ps-3\">\n        <p class=\"font-13 m-0 float-left\">{{invitationDescription}}</p>\n      </div>\n    </div>\n  </div>\n\n  <div *ngIf=\"!isGuest\" class=\"card card-style\">\n    <div class=\"content\">\n      <app-button-panel *ngIf=\"buttonsConfig\" [config]=\"buttonsConfig\" [customClass]=\"stylePanel\"></app-button-panel>\n    </div>\n  </div>\n  <div class=\"card card-style\">\n    <div class=\"content ms-0 d-flex justify-content-between\" [ngClass]=\"cardStyle\">\n      <div>\n        <app-info-section\n          [titles]=\"getTitle()\"\n          [subText]=\"getSubtitle()\"\n          [leftIcon]=\"['far', 'calendar']\"\n          [assistConfirmed]=\"access.attendance\"\n          [badgeTextClass]=\"'square bg-blue font-400'\"\n          [badgeText]=\"'access.assistInfoLabel'|translate\"></app-info-section>\n      </div>\n\n      <div *ngIf=\"isGuest\" style=\"text-align: end\">\n        <div class=\"ms-auto me-3 align-self-center pe-2\">\n          <app-toggle-switch [control]=\"assistSwitchControl\" (switchClick)=\"tryUnassist()\"></app-toggle-switch>\n        </div>\n        <label class=\"color-highlight text-uppercase font-10\">{{'onboarding.confirmAssist'|translate}}</label>\n      </div>\n    </div>\n  </div>\n  <div>\n    <div class=\"card card-style\" (click)=\"!isAdmin && locationBadgeClick.emit()\">\n      <div class=\"content mb-0 ms-0 d-flex justify-content-between\">\n        <div>\n          <app-info-section\n            [titles]=\"[access.invitation.siteName]\"\n            [subText]=\"access.invitation.place\"\n            [leftIcon]=\"locationClass\"\n            [badgeTextClass]=\"'square bg-blue font-400'\"\n            [badgeText]=\"'access.siteInfoLabel'|translate\"></app-info-section>\n        </div>\n\n        <div *ngIf=\"!isAdmin\">\n          <div class=\"ms-auto align-self-center px-2\">\n            <fa-icon\n              role=\"button\"\n              [icon]=\"['fas', 'chevron-right']\"\n              [size]=\"'xl'\"\n              class=\"color-theme opacity-75\"></fa-icon>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <!-- <app-banner\n    *ngIf=\"isGuest\"\n    [title]=\"'Completá el cuestionario'\"\n    [descrip]=\"'Asi accederás de manera más rápida'\"\n    [faClass]=\"'circle-exclamation'\"\n    [iconColor]=\"'color-highlight'\"\n    [iconSize]=\"'xl'\"\n    (bannerClick)=\"bannerClick.emit()\"></app-banner> -->\n</app-page-layout>\n\n<app-modal-menu id=\"confirmModal\" #confirmModal [height]=\"'h-25'\" [static]=\"true\">\n  <ng-template #modalContent>\n    <div class=\"center w-100 p-3\">\n      <h6 class=\"font-400 font-16 pb-3 lh-sm\">{{ 'access.confirmRefuseAssist' | translate }}</h6>\n      <app-button [label]=\"'common.confirm' | translate\" (buttonClick)=\"confirm()\"></app-button>\n      <div class=\"pt-2\"></div>\n      <app-button\n        [bgClass]=\"'bg-transparent'\"\n        [customClass]=\"'w-100 border-highlight color-highlight'\"\n        [label]=\"'common.cancel' | translate\"\n        (buttonClick)=\"cancel()\"></app-button>\n    </div>\n  </ng-template>\n</app-modal-menu>\n";

/***/ }),

/***/ 3083:
/*!****************************************************************************************!*\
  !*** ./src/app/access/pages/access-point-wizard/new-access-point.page.html?ngResource ***!
  \****************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-page-layout\n  [footerSelectedOption]=\"footerOptions.access\"\n  (back)=\"backStep()\"\n  [title]=\"site?.name\"\n  [hideFooter]=\"true\">\n  <app-wizard-steps [steps]=\"steps\" [currentStep]=\"currentStep\" (stepClick)=\"backStep($event)\"></app-wizard-steps>\n\n  <div class=\"card card-style min-vh-70\">\n    <div class=\"content mb-5\" [@animSlider]=\"currentStep\">\n      <app-access-point-name [apList]=\"apList\" [hidden]=\"currentStep !== 1\"></app-access-point-name>\n      <app-new-access-point-address\n        [siteAddress]=\"site?.address\"\n        [hidden]=\"currentStep !== 2\"></app-new-access-point-address>\n      <app-access-point-date [hidden]=\"currentStep !== 3\"></app-access-point-date>\n      <!-- <app-access-point-control [hidden]=\"currentStep !== 4\" (placeClick)=\"getState()\"></app-access-point-control> -->\n    </div>\n    <div class=\"card-bottom pb-3 px-3\">\n      <ng-container *ngIf=\"!showKeyboard\">\n        <app-button\n          [status]=\"buttonState\"\n          (buttonClick)=\"nextStep()\"\n          (onHide)=\"hide()\"\n          [label]=\"currentStep !== steps.length ? ('common.nextStep' | translate) : ('common.save' | translate)\"></app-button>\n      </ng-container>\n    </div>\n  </div>\n  <ng-container *ngIf=\"showKeyboard\">\n    <app-button\n      [status]=\"buttonState\"\n      [customClass]=\"'w-100 button-onkeyboard'\"\n      (buttonClick)=\"nextStep()\"\n      (onShow)=\"show()\"\n      [label]=\"currentStep !== steps.length ? ('common.nextStep' | translate) : ('common.save' | translate)\"></app-button>\n  </ng-container>\n</app-page-layout>\n";

/***/ }),

/***/ 8687:
/*!*****************************************************************************!*\
  !*** ./src/app/access/pages/access-point/access-point.page.html?ngResource ***!
  \*****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-page-layout [footerSelectedOption]=\"footerOptions.access\" (back)=\"back.emit()\" [title]=\"title\" *ngIf=\"accessPoint\">\n  <div class=\"card card-style\">\n    <div class=\"content mx-0 mb-0\">\n      <div class=\"d-flex m-content\">\n        <div class=\"me-3\">\n          <h1 class=\"title font-400\">{{accessPoint.name}}</h1>\n        </div>\n      </div>\n      <div class=\"d-flex m-content\">\n        <div class=\"me-3\">\n          <p *ngIf=\"accessPoint.address\" class=\"font-11 mb-2 color-theme\">\n            <fa-icon class=\"me-1 color-highlight font-13\" [icon]=\"['fas', 'location-pin']\"></fa-icon>\n            {{ accessPoint.address }}\n          </p>\n        </div>\n        <div class=\"ms-auto pb-3 d-flex color-highlight\" *ngIf=\"isAdmin\">\n          <span class=\"font-10\">Editar</span>\n          <a\n            class=\"d-flex font-16 flex-flown pl-1\"\n            style=\"padding-top: 0px\"\n            role=\"button\"\n            (click)=\"mapEditClick.emit()\">\n            <fa-icon [icon]=\"['fas', 'pencil']\"></fa-icon>\n          </a>\n        </div>\n      </div>\n\n      <app-carrousel [hidePagination]=\"true\" [(currentStep)]=\"currentStep\">\n        <ng-template #slide *ngFor=\"let img of carrouselImages\">\n          <div class=\"vh-30\" *ngIf=\"accessPoint\">\n            <app-img\n              [img]=\"img\"\n              [imgClass]=\"'rounded-0'\"\n              (click)=\"img === accessPoint.mapImage.url ? openMap() : ''\"></app-img>\n          </div>\n        </ng-template>\n      </app-carrousel>\n\n      <div class=\"pt-3 pb-3 px-3\" *ngIf=\"buttonsConfig\">\n        <app-button-panel [customClass]=\"'justify-content-center'\" [config]=\"buttonsConfig\"></app-button-panel>\n      </div>\n    </div>\n  </div>\n\n  <div class=\"card card-style\">\n    <div class=\"content\">\n      <div class=\"d-flex\">\n        <div class=\"me-3\">\n          <h1 class=\"title font-400\">{{'access.scheduleTitle'|translate}}</h1>\n        </div>\n        <div class=\"ms-auto pb-3\">\n          <div class=\"icon-button\" *ngIf=\"isAdmin\">\n            <a class=\"d-flex font-16 flex-flown\" style=\"padding-top: 0px\" role=\"button\" (click)=\"timeEditClick.emit()\">\n              <fa-icon [icon]=\"['fas', 'pencil']\"></fa-icon>\n              <span class=\"font-10\">Editar</span>\n            </a>\n          </div>\n        </div>\n      </div>\n      <div class=\"content my-0\">\n        <div class=\"col-6 d-inline-flex\">\n          <fa-icon [icon]=\"['far', 'calendar']\" class=\"px-2 font-15 color-highlight\"></fa-icon>\n          <div class=\"d-grid font-400 color-theme\">\n            <span class=\"font-12 text-capitalize\">{{getScheduleDays()}}</span>\n          </div>\n        </div>\n        <div class=\"col-6 d-inline-flex\">\n          <fa-icon [icon]=\"['far', 'clock']\" class=\"px-2 font-15 color-highlight\"></fa-icon>\n          <div class=\"d-grid font-400 color-theme\">\n            <span class=\"font-12\">{{getScheduleHours()}}</span>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <!-- <div class=\"card card-style\" *ngIf=\"showFormCard || isAdmin\">\n    <div class=\"content\">\n      <div class=\"d-flex\">\n        <div class=\"me-3\">\n          <h1 class=\"mb-0 font-400\">{{'access.controlTitle'|translate}}</h1>\n        </div>\n        <div class=\"ms-auto pb-3\">\n          <div class=\"icon-button\" *ngIf=\"isAdmin\">\n            <a class=\"d-flex font-16 flex-flown\" style=\"padding-top: 0px\" role=\"button\" (click)=\"openFormEditModal()\">\n              <fa-icon [icon]=\"['fas', 'pencil']\"></fa-icon>\n              <span class=\"font-10\">Editar</span>\n            </a>\n          </div>\n        </div>\n      </div>\n      <p class=\"font-12\">\n        <ng-container *ngIf=\"accessPoint?.notes !== '' && accessPoint?.notes !== undefined\">\n          {{accessPoint.notes}}\n        </ng-container>\n        <ng-container *ngIf=\"(accessPoint?.notes === '' || accessPoint?.notes === undefined) && isAdmin\">\n          {{'access.emptyNotes' | translate}}\n        </ng-container>\n      </p>\n\n      <div class=\"clearfix\"></div>\n      <div\n        *ngIf=\"(accessPoint?.notes !== '' && accessPoint?.notes !== undefined) && (accessPoint.inputs !== undefined && accessPoint.inputs.length > 0)\"\n        class=\"divider mt-2 mb-3\"></div>\n\n      <ng-container *ngIf=\"(accessPoint.inputs !== undefined && accessPoint.inputs.length > 0) || isAdmin\">\n        <app-access-form\n          [title]=\"'access.formDefaultTitle'|translate\"\n          [inputs]=\"accessPoint.inputs\"\n          [editable]=\"isAdmin\"\n          [readOnly]=\"isAdmin || isOwner || isOperator\"\n          (save)=\"saveForm.emit()\"\n          [isAdminOrOwner]=\"isAdmin || isOwner\"\n          [loading]=\"buttonState\"\n          (saveDeleteInput)=\"deleteInput.emit($event)\"\n          (saveEditInput)=\"editInput.emit($event)\"\n          (saveNewInput)=\"newInput.emit($event)\"></app-access-form>\n      </ng-container>\n    </div>\n  </div> -->\n</app-page-layout>\n\n<app-modal-menu #formEditModal [height]=\"'h-fit'\" [shadow]=\"true\" [static]=\"true\">\n  <ng-template #modalContent>\n    <div class=\"content\">\n      <a role=\"button\" (click)=\"tryClose()\" class=\"font-16 w-fit color-red-dark float-end\">\n        <fa-icon [icon]=\"['fas', 'times']\"></fa-icon\n      ></a>\n      <h6 class=\"font-400 font-14 pb-3\">{{'access.editNotes' | translate}}</h6>\n\n      <div class=\"input-style input-style-always-active has-borders no-icon mt-3\">\n        <textarea class=\"form-control validate-text h-25\" rows=\"5\" [formControl]=\"noteAccess\"></textarea>\n        <label class=\"color-theme text-uppercase font-400 font-10\">{{ 'common.noteAccess' | translate }}</label>\n        <em class=\"color-highlight opacity-75\" [class.disabled]=\"noteAccess.value !== ''\"\n          >{{ 'common.optional' | translate }}</em\n        >\n      </div>\n\n      <app-button\n        class=\"w-fit\"\n        [label]=\"'common.save' | translate\"\n        [status]=\"buttonState\"\n        (buttonClick)=\"trySave()\"></app-button>\n      <div class=\"pb-3\"></div>\n    </div>\n  </ng-template>\n</app-modal-menu>\n\n<app-modal-menu #confirmModal [shadow]=\"true\">\n  <ng-template #modalContent>\n    <div class=\"center w-100 p-3\">\n      <h6 class=\"font-400 font-14 pb-3 text-center\">{{ confirmModalTextKey | translate }}</h6>\n      <app-button\n        class=\"w-fit\"\n        [label]=\"'common.accept' | translate\"\n        [status]=\"buttonState\"\n        (buttonClick)=\"confirmAccept(); confirmModal.hide()\"></app-button>\n      <div class=\"pt-2\"></div>\n      <app-button\n        class=\"w-fit\"\n        [bgClass]=\"'bg-transparent'\"\n        [customClass]=\"'w-100 border-highlight color-highlight'\"\n        [label]=\"'common.cancel' | translate\"\n        (buttonClick)=\"confirmModal.hide()\"></app-button>\n    </div>\n  </ng-template>\n</app-modal-menu>\n\n<app-access-selection\n  #selection\n  [invitations]=\"invitations\"\n  (newInvitation)=\"newInvitation.emit()\"\n  (newInvite)=\"newInvite.emit($event)\"></app-access-selection>\n";

/***/ }),

/***/ 78883:
/*!*****************************************************************!*\
  !*** ./src/app/access/pages/access/access.page.html?ngResource ***!
  \*****************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-page-layout\n  [footerSelectedOption]=\"footerOptions.access\"\n  [hideBack]=\"true\"\n  [title]=\"'common.accessTitle'|translate\">\n  <app-searchbox [placeholder]=\"'common.searchdotdotdot'|translate\" (search)=\"search.emit($event)\"></app-searchbox>\n  <app-welcome-banner *ngIf=\"initialBanner\" (iconClick)=\"bannerClick.emit()\"></app-welcome-banner>\n  <app-banner\n    [title]=\"'access.bannerTitle'|translate\"\n    [descrip]=\"'access.bannerDesc'|translate\"\n    [descripClass]=\"'line-height-sm'\"\n    [faClass]=\"'star'\"\n    [iconColor]=\"'color-highlight'\"\n    [iconSize]=\"'xl'\"\n    (bannerClick)=\"modal.show()\"></app-banner>\n  <app-access-list [access]=\"aps\"></app-access-list>\n</app-page-layout>\n\n<app-modal-menu #modal [height]=\"'h-fit'\">\n  <ng-template #modalContent>\n    <h3 class=\"color-highlight font-400 mb-3\">{{ 'sites.modalTitle' | translate }}</h3>\n    <div *ngIf=\"sites\">\n      <app-small-card\n        [bgIcon]=\"true\"\n        [bgIconSmall]=\"true\"\n        [title]=\"'common.newSite'|translate\"\n        [img]=\"'assets/icons/site-icon.svg'\"\n        (selectEvent)=\"newSite.emit()\"></app-small-card>\n      <hr class=\"mb-2 mt-2\" />\n      <ng-container *ngFor=\"let s of sites\">\n        <app-small-card\n          [title]=\"s.name\"\n          [desc]=\"s.category.name\"\n          [img]=\"s.presentationImg[0]?.url\"\n          (selectEvent)=\"newInvite.emit(s.id)\"></app-small-card>\n        <hr class=\"mb-2 mt-2\" />\n      </ng-container>\n    </div>\n    <div *ngIf=\"!sites\">\n      <ng-container *ngFor=\"let item of [1, 2, 3]\">\n        <app-small-card-skeleton></app-small-card-skeleton>\n        <hr class=\"mb-2 mt-2\" />\n      </ng-container>\n    </div>\n  </ng-template>\n</app-modal-menu>\n";

/***/ }),

/***/ 24880:
/*!***********************************************************************!*\
  !*** ./src/app/access/pages/no-access/no-access.page.html?ngResource ***!
  \***********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-page-layout\n  [footerSelectedOption]=\"footerOptions.access\"\n  [hideBack]=\"true\"\n  [title]=\"'common.accessTitle'|translate\">\n  <app-welcome-banner *ngIf=\"initialBanner\" (iconClick)=\"bannerClick.emit()\"></app-welcome-banner>\n  <div class=\"card card-style p-4\">\n    <app-img-title\n      [faClass]=\"['fas','circle-exclamation']\"\n      [title]=\"'access.noAccessTitle'|translate\"\n      [titleClass]=\"'pt-3'\"\n      [subtitle]=\"'access.noAccessSubtitle'|translate\"\n      [subtitleClass]=\"'font-400 font-13 lh-lg text-center pt-2'\"></app-img-title>\n  </div>\n  <app-banner\n    [title]=\"'access.bannerTitle'|translate\"\n    [descrip]=\"'access.bannerDesc'|translate\"\n    [descripClass]=\"'line-height-sm'\"\n    [faClass]=\"'star'\"\n    [iconColor]=\"'color-highlight'\"\n    [iconSize]=\"'xl'\"\n    (bannerClick)=\"modal.show()\"></app-banner>\n</app-page-layout>\n\n<app-modal-menu #modal [height]=\"'h-fit'\">\n  <ng-template #modalContent>\n    <h3 class=\"color-highlight font-400 mb-3\">{{ 'sites.modalTitle' | translate }}</h3>\n    <div *ngIf=\"sites\">\n      <app-small-card\n        [bgIcon]=\"true\"\n        [bgIconSmall]=\"true\"\n        [title]=\"'common.newSite'|translate\"\n        [img]=\"'assets/icons/site-icon.svg'\"\n        (selectEvent)=\"newSite.emit()\"></app-small-card>\n      <hr class=\"mb-2 mt-2\" />\n      <ng-container *ngFor=\"let s of sites\">\n        <app-small-card\n          [title]=\"s.name\"\n          [desc]=\"s.category.name\"\n          [img]=\"s.presentationImg[0]?.url\"\n          (selectEvent)=\"newInvite.emit(s.id)\"></app-small-card>\n        <hr class=\"mb-2 mt-2\" />\n      </ng-container>\n    </div>\n    <div *ngIf=\"!sites\">\n      <ng-container *ngFor=\"let item of [1, 2, 3]\">\n        <app-small-card-skeleton></app-small-card-skeleton>\n        <hr class=\"mb-2 mt-2\" />\n      </ng-container>\n    </div>\n  </ng-template>\n</app-modal-menu>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_access_access_module_ts.js.map