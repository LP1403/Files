(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_invite_invite_module_ts"],{

/***/ 3111:
/*!*************************************************************************************!*\
  !*** ./src/app/invite/components/invitation-date-step/invitation-date.component.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InvitationDateComponent": () => (/* binding */ InvitationDateComponent),
/* harmony export */   "InvitationDateViewModel": () => (/* binding */ InvitationDateViewModel),
/* harmony export */   "UpdateInvitationScheduleViewModel": () => (/* binding */ UpdateInvitationScheduleViewModel)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _invitation_date_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./invitation-date.component.html?ngResource */ 46576);
/* harmony import */ var _invitation_date_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./invitation-date.component.scss?ngResource */ 51085);
/* harmony import */ var _invitation_date_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_invitation_date_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var src_app_shared_components_day_select_form_day_select_form_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/day-select-form/day-select-form.component */ 84599);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var bootstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! bootstrap */ 88716);
/* harmony import */ var src_app_shared_helpers_business__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/helpers/business */ 92237);

var _class;









let InvitationDateComponent = (_class = class InvitationDateComponent {
  constructor(fb, translate, cdRef, business) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "fb", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "cdRef", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "business", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "daySelect", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "recurrencyAccordion", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "dateAccordion", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "timeAccordion", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "selectedDoor", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessPointForm", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "open", [true, false, false]);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "recurrencyCollapse", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "dateCollapse", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "timeCollapse", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "today", new Date().toISOString().split('T')[0]);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "allDaySwitch", true);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "vm", void 0);
    this.fb = fb;
    this.translate = translate;
    this.cdRef = cdRef;
    this.business = business;
  }
  get formDirty() {
    return this.accessPointForm.dirty;
  }
  get formValid() {
    const isUnique = this.accessPointForm.get('isUnique')?.value;
    const noEndDate = this.accessPointForm.get('noEnd')?.value;
    return (isUnique === false ? this.daySelect?.formValid : true) && this.timeValid && (noEndDate ? !this.dateInvalid : !this.dateRangeInvalid) && !this.outOfDoorTime && this.isDayContained('dateFrom') && this.isDayContained('dateTo');
  }
  get viewModel() {
    this.vm = new InvitationDateViewModel();
    if (this.daySelect) this.vm.daysVM = this.daySelect.viewModel;
    Object.assign(this.vm, this.accessPointForm.getRawValue());
    return this.vm;
  }
  get timeValid() {
    const allDay = this.accessPointForm.get('allDay')?.value;
    return allDay || this.accessPointForm.get('timeFrom').value !== '' && this.accessPointForm.get('timeTo').value !== '';
  }
  get dateInvalid() {
    if (this.accessPointForm.get('dateFrom')?.value === '' || this.accessPointForm.get('dateFrom')?.value === null) {
      return true;
    }
    const dateFrom = new Date(this.accessPointForm.get('dateFrom').value + 'T12:00:00');
    const today = new Date();
    today.setHours(0, 0, 0);
    return dateFrom.getTime() <= today.getTime();
  }
  get dateRangeInvalid() {
    if (this.accessPointForm.get('dateFrom')?.value === '' || this.accessPointForm.get('dateFrom')?.value === null) {
      return true;
    }
    if (this.accessPointForm.get('dateTo')?.value === '' || this.accessPointForm.get('dateTo')?.value === null) {
      return true;
    }
    const dateTo = new Date(this.accessPointForm.get('dateTo').value + 'T12:00:00');
    const dateFrom = new Date(this.accessPointForm.get('dateFrom').value + 'T12:00:00');
    return dateFrom.getTime() > dateTo.getTime() && this.accessPointForm.get('dateFrom').touched && this.accessPointForm.get('dateTo').touched && this.accessPointForm.get('dateFrom').value !== '' && this.accessPointForm.get('dateTo').value !== '';
  }
  get timeToInvalid() {
    return this.accessPointForm.get('timeTo').value < this.accessPointForm.get('timeFrom').value && this.accessPointForm.get('timeTo').touched && this.accessPointForm.get('timeFrom').value !== '';
  }
  get timeFromInvalid() {
    return this.accessPointForm.get('timeFrom').value > this.accessPointForm.get('timeTo').value && this.accessPointForm.get('timeFrom').touched && this.accessPointForm.get('timeTo').value !== '';
  }
  get outOfDoorTime() {
    if (!this.selectedDoor) return false;
    const hourFrom = Number(this.accessPointForm.get('timeFrom')?.value.split(':')[0]);
    const hourTo = Number(this.accessPointForm.get('timeTo')?.value.split(':')[0]);
    const minFrom = Number(this.accessPointForm.get('timeFrom')?.value.split(':')[1]);
    const minTo = Number(this.accessPointForm.get('timeTo')?.value.split(':')[1]);
    let allDay = false;
    if (hourFrom === 0 && hourTo === 0 || isNaN(minFrom) && isNaN(minTo)) {
      allDay = true;
    }
    let outOfTime = false;
    this.selectedDoor.forEach(d => {
      if (d.selected) {
        const doorHourFrom = d.access.hourFrom;
        const doorHourTo = d.access.hourTo;
        const doorMinFrom = d.access.minuteFrom;
        const doorMinTo = d.access.minuteTo;
        const doorAllDay = doorHourFrom === 0 && doorHourTo === 0 && doorMinFrom === 0 && doorMinTo === 0 || doorHourFrom === undefined && doorHourTo === undefined && doorMinFrom === undefined && doorMinTo === undefined;
        if (allDay) {
          if (doorAllDay) {
            return false;
          } else {
            outOfTime = true;
          }
        } else {
          if (doorAllDay) {
            return true;
          } else {
            if (hourFrom < doorHourFrom || hourTo > doorHourTo) outOfTime = true;
            if (hourFrom === doorHourFrom && minFrom < doorMinFrom) outOfTime = true;
            if (hourTo === doorHourTo && minTo > doorMinTo) outOfTime = true;
          }
        }
      }
    });
    return outOfTime;
  }
  ngOnInit() {
    this.initForm();
  }
  ngAfterViewInit() {
    //Called after ngOnInit when the component's or directive's content has been initialized.
    //Add 'implements AfterContentInit' to the class.
    this.recurrencyCollapse = new bootstrap__WEBPACK_IMPORTED_MODULE_4__.Collapse(this.recurrencyAccordion?.nativeElement);
    this.dateCollapse = new bootstrap__WEBPACK_IMPORTED_MODULE_4__.Collapse(this.dateAccordion?.nativeElement, {
      toggle: false
    });
    this.timeCollapse = new bootstrap__WEBPACK_IMPORTED_MODULE_4__.Collapse(this.timeAccordion?.nativeElement, {
      toggle: false
    });
  }
  setForm(vm) {
    if (!vm) return;
    // this.accessPointForm.get('allDays')?.setValue(vm.daysVM.allDays, { emitEvent: false });
    this.accessPointForm.get('isUnique')?.setValue(vm.isUnique);
    this.accessPointForm.get('dateFrom')?.setValue(vm.dateFrom, {
      emitEvent: false
    });
    this.accessPointForm.get('noEnd')?.setValue(vm.noEnd);
    if (vm.dateTo !== undefined) this.accessPointForm.get('dateTo')?.setValue(vm.dateTo, {
      emitEvent: false
    });
    this.daySelect?.setForm(vm.daysVM);
    this.accessPointForm.get('timeFrom')?.setValue(vm.timeFrom);
    this.accessPointForm.get('timeTo')?.setValue(vm.timeTo);
    this.accessPointForm.get('allDay')?.setValue(vm.allDay);
    this.cdRef.detectChanges();
  }
  resetForm(opt) {
    switch (opt) {
      case 0:
        this.accessPointForm.get('noEnd')?.setValue(true, {
          emitEvent: false
        });
        this.accessPointForm.get('dateFrom')?.setValue('', {
          emitEvent: false
        });
        this.accessPointForm.get('dateTo')?.setValue('', {
          emitEvent: false
        });
        return;
      case 1:
        this.accessPointForm.get('allDay')?.setValue(true, {
          emitEvent: false
        });
        this.accessPointForm.get('timeFrom')?.setValue('', {
          emitEvent: false
        });
        this.accessPointForm.get('timeTo')?.setValue('', {
          emitEvent: false
        });
        return;
    }
  }
  initForm() {
    this.accessPointForm = this.fb.group({
      isUnique: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      noEnd: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      dateFrom: [new Date().toISOString().substring(0, 10), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      dateTo: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      allDay: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      timeFrom: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      timeTo: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required]
    });
    this.accessPointForm.get('isUnique')?.valueChanges.subscribe(value => {
      this.resetForm(0);
      this.resetForm(1);
      this.open[0] = false;
      this.open[1] = true;
      this.recurrencyCollapse?.hide();
      this.dateCollapse?.show();
    });
    this.accessPointForm.get('noEnd')?.valueChanges.subscribe(value => {
      if (value === false) {
        if (this.accessPointForm.get('dateFrom')?.value !== '' && this.accessPointForm.get('dateFrom')?.value !== null) {
          const dateFrom = new Date(this.accessPointForm.get('dateFrom')?.value + 'T12:00:00');
          dateFrom.setDate(dateFrom.getDate() + 1);
          this.accessPointForm.get('dateTo')?.setValue(dateFrom.toISOString().substring(0, 10));
        }
      } else {
        if (this.accessPointForm.get('dateFrom')?.value !== '' && this.accessPointForm.get('dateFrom')?.value !== null) {
          this.daySelect?.allDaysEnable();
        }
      }
      this.resetForm(1);
    });
    this.accessPointForm.get('dateFrom')?.valueChanges.subscribe(value => {
      if (value) {
        this.resetForm(1);
        if (this.accessPointForm.get('dateTo')?.value !== '' && this.accessPointForm.get('dateTo')?.value !== null) {
          this.daySelect?.dateSelected(value, this.accessPointForm.get('dateTo')?.value);
        }
      }
    });
    this.accessPointForm.get('dateTo')?.valueChanges.subscribe(value => {
      if (value) {
        this.resetForm(1);
        if (this.accessPointForm.get('dateFrom')?.value !== '' && this.accessPointForm.get('dateFrom')?.value !== null) {
          this.daySelect?.dateSelected(this.accessPointForm.get('dateFrom')?.value, value);
        }
      }
    });
    this.accessPointForm.get('allDay')?.valueChanges.subscribe(value => {
      if (value) {
        this.resetForm(1);
      }
    });
    this.accessPointForm.get('timeFrom')?.valueChanges.subscribe(value => {
      if (value) {
        const timeFrom = this.accessPointForm.get('timeFrom')?.value;
        const timeArray = timeFrom.split(':');
        const today = new Date();
        const date = new Date(today.getFullYear(), today.getMonth(), today.getDate(), timeArray[0], timeArray[1]);
        const newDateObj = new Date(date.getTime() + 30 * 60000);
        const minutes = newDateObj.getMinutes();
        const hours = newDateObj.getHours();
        this.accessPointForm.get('timeTo')?.setValue((hours < 10 ? '0' + hours.toString() : hours.toString()) + ':' + (minutes < 10 ? '0' + minutes.toString() : minutes.toString()));
      }
    });
  }
  getRecurrency() {
    const isUnique = this.accessPointForm.get('isUnique')?.value;
    if (isUnique === true) {
      return this.translate.instant('invite.eventType') + ' ' + this.translate.instant('invite.uniqueLabel');
    } else {
      return this.translate.instant('invite.eventType') + ' ' + this.translate.instant('invite.recurrentLabel');
    }
  }
  formatDate(value) {
    return new Date(value + 'T12:00:00').toLocaleDateString();
  }
  stepDisabled(n) {
    const isUnique = this.accessPointForm.get('isUnique')?.value;
    const noEndDate = this.accessPointForm.get('noEnd')?.value;
    switch (n) {
      case 2:
        return isUnique === '';
      case 3:
        if (noEndDate) {
          return this.dateInvalid || (isUnique === false ? !this.daySelect?.formValid : false);
        } else {
          return this.dateRangeInvalid || (isUnique === false ? !this.daySelect?.formValid : false);
        }
    }
  }
  setValue(value, control) {
    this.accessPointForm.get(control)?.setValue(value);
  }
  getDays(irecurrence) {
    const days = new src_app_shared_components_day_select_form_day_select_form_component__WEBPACK_IMPORTED_MODULE_3__.DaysViewModel();
    days.monday = irecurrence.monday;
    days.tuesday = irecurrence.tuesday;
    days.wednesday = irecurrence.wednesday;
    days.thursday = irecurrence.thursday;
    days.friday = irecurrence.friday;
    days.saturday = irecurrence.saturday;
    days.sunday = irecurrence.sunday;
    days.allDays = days.monday && days.tuesday && days.wednesday && days.thursday && days.friday && days.saturday && days.sunday;
    return days;
  }
  isDayContained(control) {
    let result = true;
    const weekday = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    if (this.accessPointForm.get('noEnd')?.value === true && control === 'dateTo') return true;
    const d = new Date(this.accessPointForm.get(control)?.value + 'T12:00:00');
    const day = weekday[d.getDay()];
    if (day === undefined) return true;
    const dayIndex = weekday.indexOf(day);
    this.selectedDoor?.forEach(door => {
      const daysSelected = this.getDays(door.access);
      if (daysSelected.allDays) {
        result = true;
      }
      const selectedDays = [door.access.sunday, door.access.monday, door.access.tuesday, door.access.wednesday, door.access.thursday, door.access.friday, door.access.saturday];
      result = selectedDays[dayIndex];
    });
    return result;
  }
  getAccessPointSchedule() {
    const d = this.selectedDoor?.find(d => d.selected);
    if (!d) return '';
    const doorHourFrom = d.access.hourFrom;
    const doorHourTo = d.access.hourTo;
    const doorMinFrom = d.access.minuteFrom;
    const doorMinTo = d.access.minuteTo;
    const doorAllDay = doorHourFrom === 0 && doorHourTo === 0 && doorMinFrom === 0 && doorMinTo === 0 || doorHourFrom === undefined && doorHourTo === undefined && doorMinFrom === undefined && doorMinTo === undefined;
    const schedule = this.business.getTimeRange(d?.access);
    const message = this.translate.instant('invite.locationSchedule', {
      door: d.access.name
    });
    if (doorAllDay) {
      return message + ' ' + schedule;
    }
    return message + this.translate.instant('invite.from') + schedule;
  }
  getAccessPointRecurrence() {
    const d = this.selectedDoor?.find(d => d.selected);
    if (!d) return '';
    const daysSelected = this.getDays(d.access);
    const recurrence = this.business.getRecurrence(d?.access);
    const message = this.translate.instant('invite.locationSchedule', {
      door: d.access.name
    });
    if (daysSelected.allDays) {
      return message + ' ' + recurrence;
    }
    return message + this.translate.instant('recurence.from') + recurrence;
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder
}, {
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslateService
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ChangeDetectorRef
}, {
  type: src_app_shared_helpers_business__WEBPACK_IMPORTED_MODULE_5__["default"]
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  daySelect: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild,
    args: [src_app_shared_components_day_select_form_day_select_form_component__WEBPACK_IMPORTED_MODULE_3__.DaySelectFormComponent]
  }],
  recurrencyAccordion: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild,
    args: ['recurrency']
  }],
  dateAccordion: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild,
    args: ['date']
  }],
  timeAccordion: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild,
    args: ['time']
  }],
  selectedDoor: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input
  }]
}), _class);
InvitationDateComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
  selector: 'app-invitation-date',
  template: _invitation_date_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_invitation_date_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], InvitationDateComponent);

class InvitationDateViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "isUnique", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "noEnd", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "dateFrom", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "dateTo", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "allDay", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "timeFrom", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "timeTo", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "daysVM", void 0);
  }
}
class UpdateInvitationScheduleViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "id", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "hourFrom", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "hourTo", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "minuteFrom", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "minuteTo", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "dateFrom", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "dateTo", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "recurrency", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "monday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "tuesday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "wednesday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "thursday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "friday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "saturday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "sunday", void 0);
  }
}

/***/ }),

/***/ 81127:
/*!********************************************************************************************!*\
  !*** ./src/app/invite/components/invitation-edit-modal/invitation-edit-modal.component.ts ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InvitationEditModalComponent": () => (/* binding */ InvitationEditModalComponent)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _invitation_edit_modal_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./invitation-edit-modal.component.html?ngResource */ 99238);
/* harmony import */ var _invitation_edit_modal_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./invitation-edit-modal.component.scss?ngResource */ 57662);
/* harmony import */ var _invitation_edit_modal_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_invitation_edit_modal_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _pages_invitation_wizard_invitation_wizard_business__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../pages/invitation-wizard/invitation-wizard.business */ 8393);
/* harmony import */ var _invitation_date_step_invitation_date_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../invitation-date-step/invitation-date.component */ 3111);
/* harmony import */ var _new_invitation_place_step_new_invitation_place_step_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../new-invitation-place-step/new-invitation-place-step.component */ 18342);
/* harmony import */ var _new_invitation_step_new_invitation_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../new-invitation-step/new-invitation.component */ 65262);
/* harmony import */ var src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/components/button/button.component */ 62490);

var _class;









let InvitationEditModalComponent = (_class = class InvitationEditModalComponent {
  constructor(cdRef) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "cdRef", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "modal", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "confirmModalC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "newInvitationC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "invitationDateC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "invitationPlaceC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "newInvitation", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "newInvitationDate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "newInvitationPlace", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "categoryList", []);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "loading", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "saveClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "closeClick", new _angular_core__WEBPACK_IMPORTED_MODULE_8__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "steps", [1, 2, 3, 4]);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "viewModel", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "currentStep", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "labelModal", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "isClosing", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "selectedDoor", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "invitationPlace", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "showKeyboard", false);
    this.cdRef = cdRef;
    this.viewModel = new _pages_invitation_wizard_invitation_wizard_business__WEBPACK_IMPORTED_MODULE_3__.InvitationWizardViewModel();
  }
  get stepValid() {
    switch (this.currentStep) {
      case 1:
        return this.newInvitationC?.formValid;
      case 2:
        return this.invitationPlaceC?.formValid;
      case 3:
        return this.invitationDateC?.formValid;
    }
  }
  get buttonState() {
    if (!this.stepValid) {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_7__.ButtonState.disabled;
    } else if (!this.loading) {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_7__.ButtonState.enabled;
    } else {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_7__.ButtonState.loading;
    }
  }
  get hasChanges() {
    switch (this.currentStep) {
      case 1:
        return this.newInvitationC?.formDirty ?? false;
      case 2:
        return this.invitationPlaceC?.formDirty ?? false;
      case 3:
        return this.invitationDateC?.formDirty ?? false;
      default:
        return false;
    }
  }
  setAccessPointList(ap) {
    if (ap) {
      this.invitationPlace = new _new_invitation_place_step_new_invitation_place_step_component__WEBPACK_IMPORTED_MODULE_5__.NewInvitationPlaceViewModel();
      this.invitationPlace.accessPoints = ap;
    }
  }
  fillForms(currentStep, viewModel) {
    this.currentStep = currentStep;
    if (viewModel) {
      switch (currentStep) {
        case 1:
          this.newInvitationC?.setForm(viewModel.newInvitationStep);
          break;
        case 2:
          this.invitationPlaceC?.setForm(viewModel.invitationPlaceStep);
          break;
        case 3:
          if (viewModel.invitationPlaceStep?.accessPoints) {
            this.selectedDoor = viewModel.invitationPlaceStep?.accessPoints;
            const location = this.invitationPlace?.accessPoints.find(x => x.access.id === viewModel.invitationPlaceStep?.place);
            if (location) {
              location.selected = true;
              this.selectedDoor.push(location);
            }
          }
          this.invitationDateC?.setForm(viewModel.invitationDateStep);
          break;
      }
    }
  }
  confirm() {
    let stepModel;
    switch (this.currentStep) {
      case 1:
        stepModel = this.newInvitationC?.viewModel;
        break;
      case 2:
        stepModel = this.invitationPlaceC?.viewModel;
        break;
      case 3:
        stepModel = this.invitationDateC?.viewModel;
        break;
    }
    if (!this.isClosing) {
      this.loading = true;
      this.saveClick.emit(stepModel);
    } else {
      this.closeClick.emit();
    }
  }
  close() {
    if (this.hasChanges) {
      this.labelModal = 'common.confirmCancel';
      this.isClosing = true;
      this.confirmModalC?.show();
    } else {
      this.closeClick.emit();
    }
  }
  save() {
    if (this.hasChanges) {
      this.labelModal = 'common.confirmChanges';
      this.isClosing = false;
      this.confirmModalC?.show();
    } else {
      this.confirm();
    }
  }
  hide() {
    this.showKeyboard = true;
    this.cdRef.detectChanges();
  }
  show() {
    this.showKeyboard = false;
    this.cdRef.detectChanges();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ChangeDetectorRef
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  modal: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild,
    args: ['modal']
  }],
  confirmModalC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild,
    args: ['confirmModal']
  }],
  newInvitationC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild,
    args: [_new_invitation_step_new_invitation_component__WEBPACK_IMPORTED_MODULE_6__.NewInvitationComponent]
  }],
  invitationDateC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild,
    args: [_invitation_date_step_invitation_date_component__WEBPACK_IMPORTED_MODULE_4__.InvitationDateComponent]
  }],
  invitationPlaceC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild,
    args: [_new_invitation_place_step_new_invitation_place_step_component__WEBPACK_IMPORTED_MODULE_5__.NewInvitationPlaceStepComponent]
  }],
  newInvitation: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input
  }],
  newInvitationDate: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input
  }],
  newInvitationPlace: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input
  }],
  categoryList: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input
  }],
  loading: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input
  }],
  saveClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }],
  closeClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Output
  }]
}), _class);
InvitationEditModalComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
  selector: 'app-invitation-edit-modal',
  template: _invitation_edit_modal_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_invitation_edit_modal_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], InvitationEditModalComponent);


/***/ }),

/***/ 84052:
/*!********************************************************************************!*\
  !*** ./src/app/invite/components/invitation-list/invitation-list.component.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InvitationListComponent": () => (/* binding */ InvitationListComponent)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _invitation_list_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./invitation-list.component.html?ngResource */ 74912);
/* harmony import */ var _invitation_list_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./invitation-list.component.scss?ngResource */ 7864);
/* harmony import */ var _invitation_list_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_invitation_list_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var src_app_shared_helpers_business__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/helpers/business */ 92237);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 67690);

var _class;







let InvitationListComponent = (_class = class InvitationListComponent {
  constructor(business, navController, translate) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "business", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "invitations", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "invClick", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "navigateClick", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    this.business = business;
    this.navController = navController;
    this.translate = translate;
  }
  accessClick(apId) {
    const navigationExtras = {
      state: {
        component: 'invitation'
      }
    };
    this.navigateClick.emit(apId);
    this.navController.navigateForward('invite/invitation/' + apId, navigationExtras);
  }
  getTitle(title) {
    const array = [];
    const splitString = title.split('-');
    array.push(splitString[0]);
    array.push(splitString[1]);
    return array;
  }
  getTopTexts(i) {
    const dateRange = i.dateTo === null && i.recurrency ? `${this.translate.instant('recurence.from')} ` + this.business.getDateRange(i) : this.business.getDateRange(i);
    const recurrence = this.business.getRecurrence(i);
    const array = [];
    array.push(dateRange);
    array.push(recurrence);
    return array;
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_helpers_business__WEBPACK_IMPORTED_MODULE_3__["default"]
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController
}, {
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateService
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  invitations: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input
  }],
  invClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }],
  navigateClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }]
}), _class);
InvitationListComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
  selector: 'app-invitation-list',
  template: _invitation_list_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_invitation_list_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], InvitationListComponent);


/***/ }),

/***/ 18342:
/*!****************************************************************************************************!*\
  !*** ./src/app/invite/components/new-invitation-place-step/new-invitation-place-step.component.ts ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewInvitationPlaceStepComponent": () => (/* binding */ NewInvitationPlaceStepComponent),
/* harmony export */   "NewInvitationPlaceViewModel": () => (/* binding */ NewInvitationPlaceViewModel),
/* harmony export */   "UpdateInvitationAddressViewModel": () => (/* binding */ UpdateInvitationAddressViewModel)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _new_invitation_place_step_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./new-invitation-place-step.component.html?ngResource */ 23762);
/* harmony import */ var _new_invitation_place_step_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./new-invitation-place-step.component.scss?ngResource */ 21461);
/* harmony import */ var _new_invitation_place_step_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_new_invitation_place_step_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var src_app_shared_components_door_select_form_door_select_form_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/door-select-form/door-select-form.component */ 6980);
/* harmony import */ var src_app_shared_components_map_info_map_info_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/components/map-info/map-info.component */ 47975);

var _class;







let NewInvitationPlaceStepComponent = (_class = class NewInvitationPlaceStepComponent {
  constructor(fb, cdRef) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "fb", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "cdRef", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "doorSelect", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "mapC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "invitationForm", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "vm", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "selectedPlace", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "selectedPlaceDoors", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "onlyOneWay", false);
    this.fb = fb;
    this.cdRef = cdRef;
  }
  get formDirty() {
    return this.invitationForm.dirty;
  }
  get formValid() {
    return this.invitationForm?.valid && (this.doorSelect?.formValid || this.hasOneOrNoneParent) || this.onlyOneWay;
  }
  get hasOneOrNoneParent() {
    return this.selectedPlaceDoors !== undefined && this.selectedPlaceDoors.length <= 1;
  }
  get viewModel() {
    this.vm = new NewInvitationPlaceViewModel();
    if (this.doorSelect) this.vm.accessPoints = this.doorSelect.viewModel;
    Object.assign(this.vm, this.invitationForm.getRawValue());
    if (!this.vm.accessPoints) this.vm.accessPoints = this.selectedPlaceDoors || [];
    return this.vm;
  }
  ngOnInit() {
    this.invitationForm = this.fb.group({
      place: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required]
    });
    this.invitationForm.valueChanges.subscribe(x => {
      if (x.place === '') return;
      this.selectedPlace = this.vm?.accessPoints.find(ap => ap.access.id === x.place)?.access;
      this.selectedPlaceDoors = this.selectedPlace?.accessPointParent?.map(y => {
        const door = new src_app_shared_components_door_select_form_door_select_form_component__WEBPACK_IMPORTED_MODULE_3__.DoorsViewModel();
        door.selected = false;
        door.access = y;
        return door;
      });
      this.mapC?.reload();
    });
    if (this.vm?.accessPoints.length === 1) this.invitationForm.get('place')?.setValue(this.vm?.accessPoints[0].access.id);
  }
  setForm(vm) {
    if (!vm) return;
    this.vm = vm;
    this.invitationForm.get('place')?.setValue(vm?.place);
    this.cdRef.detectChanges();
  }
  checkIfOnlyOneWay() {
    if (this.vm?.accessPoints.length === 1 && this.vm?.accessPoints[0].access.accessPointParent?.length === 0) {
      this.invitationForm.get('place')?.setValue(this.vm?.accessPoints[0].access.id);
      this.onlyOneWay = true;
      this.invitationForm.updateValueAndValidity();
      this.invitationForm.disable();
    }
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ChangeDetectorRef
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  doorSelect: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild,
    args: [src_app_shared_components_door_select_form_door_select_form_component__WEBPACK_IMPORTED_MODULE_3__.DoorSelectFormComponent]
  }],
  mapC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild,
    args: [src_app_shared_components_map_info_map_info_component__WEBPACK_IMPORTED_MODULE_4__.MapInfoComponent]
  }]
}), _class);
NewInvitationPlaceStepComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
  selector: 'app-new-invitation-place',
  template: _new_invitation_place_step_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_new_invitation_place_step_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], NewInvitationPlaceStepComponent);

class NewInvitationPlaceViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "place", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessPoints", void 0);
  }
}
class UpdateInvitationAddressViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "id", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "place", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessPointId", void 0);
  }
}

/***/ }),

/***/ 65262:
/*!***********************************************************************************!*\
  !*** ./src/app/invite/components/new-invitation-step/new-invitation.component.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewInvitationComponent": () => (/* binding */ NewInvitationComponent),
/* harmony export */   "NewInvitationViewModel": () => (/* binding */ NewInvitationViewModel),
/* harmony export */   "UpdateInvitationViewModel": () => (/* binding */ UpdateInvitationViewModel)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _new_invitation_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./new-invitation.component.html?ngResource */ 87212);
/* harmony import */ var _new_invitation_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./new-invitation.component.scss?ngResource */ 7201);
/* harmony import */ var _new_invitation_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_new_invitation_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var src_app_shared_models_NotDefaultValueValidator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/models/NotDefaultValueValidator */ 86317);
/* harmony import */ var src_app_shared_models_SelectListItem__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/models/SelectListItem */ 75987);

var _class;







let NewInvitationComponent = (_class = class NewInvitationComponent {
  constructor(fb) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "fb", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "categoryList", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "siteList", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "isEdit", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "invitationForm", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "images", []);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "deleteImages", []);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "vm", void 0);
    this.fb = fb;
  }
  get formDirty() {
    return this.invitationForm.dirty;
  }
  get formValid() {
    return this.invitationForm.valid;
  }
  get viewModel() {
    this.vm = new NewInvitationViewModel();
    this.vm.place = this.invitationForm.get('place')?.value;
    this.vm.title = this.invitationForm.get('title')?.value;
    this.vm.description = this.invitationForm.get('description')?.value;
    this.vm.category = new src_app_shared_models_SelectListItem__WEBPACK_IMPORTED_MODULE_4__.SelectListItem();
    this.vm.category.id = this.invitationForm.get('category')?.value;
    this.vm.image = this.images.filter(x => x.file !== null && x.file !== undefined);
    this.vm.deleteImage = this.deleteImages;
    return this.vm;
  }
  ngOnInit() {
    this.initForm();
  }
  setForm(vm) {
    if (!vm) return;
    this.invitationForm.get('place')?.setValue(vm.place);
    this.invitationForm.get('title')?.setValue(vm.title);
    this.invitationForm.get('category')?.setValue(vm.category?.id);
    this.invitationForm.get('description')?.setValue(vm.description);
    if (vm?.image) {
      this.images = vm.image.filter(x => x.id !== null && x.id !== undefined);
    }
  }
  initForm() {
    this.invitationForm = this.fb.group({
      place: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      title: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      category: ['0', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required, src_app_shared_models_NotDefaultValueValidator__WEBPACK_IMPORTED_MODULE_3__.notDefaultValueValidator]],
      description: ['']
    });
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  categoryList: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Input
  }],
  siteList: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Input
  }],
  isEdit: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Input
  }]
}), _class);
NewInvitationComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
  selector: 'app-new-invitation',
  template: _new_invitation_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_new_invitation_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], NewInvitationComponent);

class NewInvitationViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "place", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "title", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "category", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "description", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "image", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "deleteImage", void 0);
  }
}
class UpdateInvitationViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "id", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "place", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "motive", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "description", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "siteId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "categoryId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "externalFileId", void 0);
  }
}

/***/ }),

/***/ 53216:
/*!*************************************************!*\
  !*** ./src/app/invite/invite-routing.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InviteRoutingModule": () => (/* binding */ InviteRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _pages_guest_guests_business__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pages/guest/guests.business */ 41754);
/* harmony import */ var _pages_invitation_wizard_invitation_wizard_business__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pages/invitation-wizard/invitation-wizard.business */ 8393);
/* harmony import */ var _pages_invitations_invitations_business__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pages/invitations/invitations.business */ 50815);
/* harmony import */ var _pages_invitation_info_invitation_info_business__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/invitation-info/invitation-info.business */ 8445);







const routes = [{
  path: 'guests/:id',
  component: _pages_guest_guests_business__WEBPACK_IMPORTED_MODULE_0__.GuestsBusiness
}, {
  path: 'invitation/:id',
  component: _pages_invitation_info_invitation_info_business__WEBPACK_IMPORTED_MODULE_3__.InvitationInfoBusiness
}, {
  path: 'invitations/:id',
  component: _pages_invitations_invitations_business__WEBPACK_IMPORTED_MODULE_2__.InvitationsBusiness
}, {
  path: 'new-invitation/:id',
  component: _pages_invitation_wizard_invitation_wizard_business__WEBPACK_IMPORTED_MODULE_1__.InvitationWizardBusiness
}];
let InviteRoutingModule = class InviteRoutingModule {};
InviteRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
  imports: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule.forChild(routes)],
  exports: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule]
})], InviteRoutingModule);


/***/ }),

/***/ 26723:
/*!*****************************************!*\
  !*** ./src/app/invite/invite.module.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InviteModule": () => (/* binding */ InviteModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common */ 89650);
/* harmony import */ var _invite_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./invite-routing.module */ 53216);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../shared/shared.module */ 56208);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _pages_guest_guests_business__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pages/guest/guests.business */ 41754);
/* harmony import */ var _pages_invitations_invitations_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/invitations/invitations.page */ 36564);
/* harmony import */ var _components_invitation_list_invitation_list_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/invitation-list/invitation-list.component */ 84052);
/* harmony import */ var _components_new_invitation_step_new_invitation_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/new-invitation-step/new-invitation.component */ 65262);
/* harmony import */ var _pages_invitations_invitations_business__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pages/invitations/invitations.business */ 50815);
/* harmony import */ var _pages_invitation_wizard_invitation_wizard_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./pages/invitation-wizard/invitation-wizard.page */ 40034);
/* harmony import */ var _pages_invitation_wizard_invitation_wizard_business__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./pages/invitation-wizard/invitation-wizard.business */ 8393);
/* harmony import */ var _components_invitation_date_step_invitation_date_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/invitation-date-step/invitation-date.component */ 3111);
/* harmony import */ var _components_new_invitation_place_step_new_invitation_place_step_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./components/new-invitation-place-step/new-invitation-place-step.component */ 18342);
/* harmony import */ var _components_invitation_edit_modal_invitation_edit_modal_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./components/invitation-edit-modal/invitation-edit-modal.component */ 81127);
/* harmony import */ var _pages_invitation_info_invitation_info_page__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./pages/invitation-info/invitation-info.page */ 44409);
/* harmony import */ var _pages_invitation_info_invitation_info_business__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./pages/invitation-info/invitation-info.business */ 8445);



















let InviteModule = class InviteModule {};
InviteModule = (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_15__.NgModule)({
  declarations: [_pages_guest_guests_business__WEBPACK_IMPORTED_MODULE_2__.GuestsBusiness, _pages_invitations_invitations_page__WEBPACK_IMPORTED_MODULE_3__.InvitationsPage, _components_invitation_list_invitation_list_component__WEBPACK_IMPORTED_MODULE_4__.InvitationListComponent, _pages_invitations_invitations_business__WEBPACK_IMPORTED_MODULE_6__.InvitationsBusiness, _pages_invitation_wizard_invitation_wizard_page__WEBPACK_IMPORTED_MODULE_7__.InvitationWizardPage, _pages_invitation_wizard_invitation_wizard_business__WEBPACK_IMPORTED_MODULE_8__.InvitationWizardBusiness, _components_new_invitation_step_new_invitation_component__WEBPACK_IMPORTED_MODULE_5__.NewInvitationComponent, _components_invitation_date_step_invitation_date_component__WEBPACK_IMPORTED_MODULE_9__.InvitationDateComponent, _components_new_invitation_place_step_new_invitation_place_step_component__WEBPACK_IMPORTED_MODULE_10__.NewInvitationPlaceStepComponent, _components_invitation_edit_modal_invitation_edit_modal_component__WEBPACK_IMPORTED_MODULE_11__.InvitationEditModalComponent, _pages_invitation_info_invitation_info_business__WEBPACK_IMPORTED_MODULE_13__.InvitationInfoBusiness, _pages_invitation_info_invitation_info_page__WEBPACK_IMPORTED_MODULE_12__.InvitationInfoPage],
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_16__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.FormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_17__.ReactiveFormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_18__.IonicModule, _invite_routing_module__WEBPACK_IMPORTED_MODULE_0__.InviteRoutingModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule],
  exports: [_invite_routing_module__WEBPACK_IMPORTED_MODULE_0__.InviteRoutingModule, _pages_invitations_invitations_page__WEBPACK_IMPORTED_MODULE_3__.InvitationsPage, _pages_invitation_wizard_invitation_wizard_page__WEBPACK_IMPORTED_MODULE_7__.InvitationWizardPage, _components_new_invitation_step_new_invitation_component__WEBPACK_IMPORTED_MODULE_5__.NewInvitationComponent, _components_invitation_date_step_invitation_date_component__WEBPACK_IMPORTED_MODULE_9__.InvitationDateComponent, _components_new_invitation_place_step_new_invitation_place_step_component__WEBPACK_IMPORTED_MODULE_10__.NewInvitationPlaceStepComponent, _components_invitation_edit_modal_invitation_edit_modal_component__WEBPACK_IMPORTED_MODULE_11__.InvitationEditModalComponent, _pages_invitation_wizard_invitation_wizard_business__WEBPACK_IMPORTED_MODULE_8__.InvitationWizardBusiness, _components_invitation_list_invitation_list_component__WEBPACK_IMPORTED_MODULE_4__.InvitationListComponent]
})], InviteModule);


/***/ }),

/***/ 41754:
/*!*******************************************************!*\
  !*** ./src/app/invite/pages/guest/guests.business.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddContactViewModel": () => (/* binding */ AddContactViewModel),
/* harmony export */   "DeleteContactViewModel": () => (/* binding */ DeleteContactViewModel),
/* harmony export */   "GuestsBusiness": () => (/* binding */ GuestsBusiness)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var src_app_shared_services_invitation_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/services/invitation.service */ 21178);
/* harmony import */ var src_app_shared_components_contact_modal_contact_modal_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/contact-modal/contact-modal.component */ 29069);
/* harmony import */ var src_app_shared_helpers_business__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/helpers/business */ 92237);
/* harmony import */ var src_app_shared_components_contact_page_contact_page_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/components/contact-page/contact-page.component */ 64155);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 51547);
/* harmony import */ var src_app_shared_components_plans_modal_plans_modal_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/components/plans-modal/plans-modal.component */ 78726);
/* harmony import */ var src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/components/button/button.component */ 62490);


var _class;












let GuestsBusiness = (_class = class GuestsBusiness {
  constructor(route, router, navController, translate, invitationService, business) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "route", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "router", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitationService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "business", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "contactPage", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "contactModal", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "plansModal", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "inv", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitationId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invDescription", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "removePage", true);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitedList", void 0);
    this.route = route;
    this.router = router;
    this.navController = navController;
    this.translate = translate;
    this.invitationService = invitationService;
    this.business = business;
  }
  get listTitle() {
    if (this.removePage) {
      return this.translate.instant('common.guestsTitle');
    } else {
      return this.translate.instant('common.addGuestsTitle');
    }
  }
  get buttonLabel() {
    if (this.removePage) {
      return this.translate.instant('common.delete');
    } else {
      return this.translate.instant('common.invite');
    }
  }
  get buttonLabelConfirmed() {
    if (this.removePage) {
      return this.translate.instant('common.delete');
    } else {
      return this.translate.instant('common.inviteConfirmed');
    }
  }
  get confirmMessage() {
    if (this.removePage) {
      return this.translate.instant('users.confirmRemoveTitle');
    } else {
      return this.translate.instant('invite.confirmInviteTitle');
    }
  }
  ngOnInit() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this.route.snapshot.params.id != null) {
        _this.invitationId = _this.route.snapshot.params.id;
      }
      _this.getNavigation();
    })();
  }
  ionViewDidEnter() {
    this.fetchInvitation();
    if (this.contactPage?.contacts?.length === 0) {
      this.contactPage?.change();
    }
  }
  getNavigation() {
    const current = this.router.getCurrentNavigation();
    if (current) {
      if (current.extras.state !== undefined) {
        this.invDescription = current.extras.state?.invDescription;
      } else {
        this.navController.back();
      }
    }
  }
  fetchInvitation() {
    var _this2 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const result = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.lastValueFrom)(_this2.invitationService.getInvitationById(_this2.invitationId));
      if (result.error == null) {
        _this2.inv = result.data;
        _this2.invDescription = _this2.inv.motive;
      } else _this2.navController.navigateRoot('error');
    })();
  }
  confirm(list) {
    var _this3 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this3.invitedList = list;
      const vm = new AddContactViewModel();
      vm.invitationId = _this3.invitationId;
      vm.phones = list.map(x => {
        const e164FormattedNumber = _this3.business.getFormattedPhoneNumber(x.userPhone);
        return e164FormattedNumber;
      });
      vm.phones = vm.phones.filter(x => x !== '');
      _this3.contactPage?.emptyList();
      const result = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.lastValueFrom)(_this3.invitationService.addGuests(vm));
      if (result.error == null) {
        _this3.removePage = true;
        _this3.contactPage?.refresh(result.data);
        _this3.fetchInvitation();
        _this3.contactModal?.modal?.show();
      } else {
        if (result.code === 820) {
          _this3.handleLimitError();
        } else _this3.navController.navigateRoot('error');
      }
    })();
  }
  confirmRemove(list) {
    var _this4 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const vm = new DeleteContactViewModel();
      vm.invitationId = _this4.invitationId;
      vm.userIds = list.map(x => x.userId);
      _this4.contactPage?.emptyList();
      const result = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.lastValueFrom)(_this4.invitationService.deleteGuests(vm));
      if (result.error == null) {
        _this4.contactPage?.refresh(result.data);
        _this4.fetchInvitation();
      } else {
        _this4.navController.navigateRoot('error');
      }
    })();
  }
  modalClose() {
    // this.navController.navigateBack('invite/invitation/' + this.invitationId, {
    //   state: {
    //     contacts: this.invitedList,
    //   },
    // });
  }
  handleLimitError() {
    this.plansModal?.modal?.show();
    this.contactPage.getNavigation();
    this.contactPage.getContactsMobile();
    this.contactPage.disableButton = src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_7__.ButtonState.disabled;
    this.removePage = true;
  }
  bannerClick() {
    if (this.inv.siteRemainingGuests !== null && this.inv.siteRemainingGuests !== undefined && this.inv.siteRemainingGuests <= 0) this.plansModal?.modal?.show();else this.removePage = !this.removePage;
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.ActivatedRoute
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.Router
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.NavController
}, {
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__.TranslateService
}, {
  type: src_app_shared_services_invitation_service__WEBPACK_IMPORTED_MODULE_2__.InvitationService
}, {
  type: src_app_shared_helpers_business__WEBPACK_IMPORTED_MODULE_4__["default"]
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "propDecorators", {
  contactPage: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.ViewChild,
    args: [src_app_shared_components_contact_page_contact_page_component__WEBPACK_IMPORTED_MODULE_5__.ContactPageComponent]
  }],
  contactModal: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.ViewChild,
    args: [src_app_shared_components_contact_modal_contact_modal_component__WEBPACK_IMPORTED_MODULE_3__.ContactModalComponent]
  }],
  plansModal: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.ViewChild,
    args: [src_app_shared_components_plans_modal_plans_modal_component__WEBPACK_IMPORTED_MODULE_6__.PlansModalComponent]
  }]
}), _class);
GuestsBusiness = (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Component)({
  template: `<app-contact-page
      class="scroll-content"
      [title]="invDescription"
      [invitationId]="invitationId"
      [listTitle]="listTitle"
      [removePage]="removePage"
      [bannerTitle]="'invite.bannerTitle' | translate"
      [bannerDesc]="'invite.bannerDesc' | translate"
      [emptyTitle]="'invite.noGuests' | translate"
      [emptyDesc]="'invite.noGuestsSubtitle' | translate"
      [buttonLabel]="buttonLabel"
      [buttonLabelConfirmed]="buttonLabelConfirmed"
      [confirmMessage]="confirmMessage"
      (confirmAddClick)="confirm($event)"
      (confirmRemoveClick)="confirmRemove($event)"
      (bannerClick)="bannerClick()"></app-contact-page>
    <app-contact-modal [eventTitle]="invDescription" (confirmEvent)="modalClose()"></app-contact-modal>
    <app-plans-modal></app-plans-modal>`
})], GuestsBusiness);

class AddContactViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitationId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "phones", void 0);
  }
}
class DeleteContactViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitationId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userIds", void 0);
  }
}

/***/ }),

/***/ 8445:
/*!**************************************************************************!*\
  !*** ./src/app/invite/pages/invitation-info/invitation-info.business.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InvitationInfoBusiness": () => (/* binding */ InvitationInfoBusiness)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var src_app_invite_pages_invitation_wizard_invitation_wizard_business__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/invite/pages/invitation-wizard/invitation-wizard.business */ 8393);
/* harmony import */ var src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/models/Enums */ 6452);
/* harmony import */ var src_app_shared_services_access_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/services/access.service */ 46554);
/* harmony import */ var _access_components_access_point_selection_access_point_selection_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../access/components/access-point-selection/access-point-selection.component */ 2583);
/* harmony import */ var src_app_shared_services_invitation_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/services/invitation.service */ 21178);
/* harmony import */ var src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/user.service */ 31880);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 51547);
/* harmony import */ var _invitation_info_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./invitation-info.page */ 44409);
/* harmony import */ var src_app_shared_components_confirm_modal_confirm_modal_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/components/confirm-modal/confirm-modal.component */ 4562);


var _class;













let InvitationInfoBusiness = (_class = class InvitationInfoBusiness {
  constructor(accessService, invitationService, navController, route, router, userService, cdRef) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitationService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "route", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "router", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "cdRef", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invInfoC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "apSelection", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "edit", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "confirmModalC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitation", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "apList", []);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitationId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "urlBack", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "componentText", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "initiate", true);
    this.accessService = accessService;
    this.invitationService = invitationService;
    this.navController = navController;
    this.route = route;
    this.router = router;
    this.userService = userService;
    this.cdRef = cdRef;
    this.route.queryParams.subscribe(() => {
      if (this.router?.getCurrentNavigation()?.extras.state) {
        const state = this.router.getCurrentNavigation()?.extras.state;
        if (state) {
          const guests = state.contacts;
          console.table(guests);
          console.log('save confirm');
        }
      }
    });
  }
  get isOwner() {
    if (this.invitation?.roles?.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_3__.AccessPointRole.owner) && this.invitation.createBy === this.userService.userData?.userId) {
      return true;
    } else {
      return false;
    }
  }
  get isAdmin() {
    if (this.invitation?.roles?.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_3__.AccessPointRole.administrator)) {
      return true;
    } else {
      return false;
    }
  }
  ionViewWillEnter() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.invitation = undefined;
      if (_this.route.snapshot.params.id != null) {
        _this.invitationId = _this.route.snapshot.params.id;
        _this.fetchInvitation();
      }
    })();
  }
  ionViewWillLeave() {
    this.invitation = undefined;
  }
  fetchInvitation() {
    var _this2 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const response = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.lastValueFrom)(_this2.invitationService.getInvitationById(_this2.invitationId));
      if (response.error == null) {
        _this2.invitation = response.data;
        _this2.invInfoC?.getButtonsConfig(_this2.invitation);
        console.log(_this2.invitation);
      } else _this2.navController.navigateRoot('error');
    })();
  }
  refresh() {
    this.invitation = undefined;
    this.invInfoC.buttonsConfig = undefined;
    this.cdRef.detectChanges();
    this.fetchInvitation();
  }
  backClick() {
    this.navController.back();
  }
  accessClick() {
    const navigationExtras = {
      state: {
        component: 'invitation'
      }
    };
    console.log('Assist banner Click!');
    this.navController.navigateForward('access/attendance/' + this.invitationId, navigationExtras);
  }
  accessEdit() {
    console.log('Assist edit Click!');
    this.edit?.openModal(this.invitationId, 3);
  }
  locationEdit() {
    this.edit?.openModal(this.invitationId, 2);
  }
  locationClick() {
    this.apList = [];
    if (this.invitation?.siteId) {
      this.invitationService.getInvitationAccessPoints(this.invitation.invitationId).subscribe(response => {
        if (response.error == null) {
          this.apList = response.data;
          if (this.apList.length !== 0) {
            if (this.apList.length > 1) this.apSelection?.modal?.show();else {
              const isMainDoor = true;
              const navigationExtras = {
                state: {
                  title: this.invitation?.motive,
                  mainDoor: isMainDoor
                }
              };
              this.navController.navigateForward('access/access-point/' + this.apList[0].id, navigationExtras);
            }
          }
        } else this.navController.navigateRoot('error');
      });
    }
  }
  descriptionEdit() {
    console.log('Description edit Click!');
    this.edit?.openModal(this.invitationId, 1);
  }
  deleteClick() {
    this.confirmModalC?.show();
  }
  confirmDelete() {
    var _this3 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('Delete button Click!');
      yield _this3.invitationService.delete(_this3.invitationId).subscribe(r => {
        if (r.error == null) {
          _this3.backClick();
          console.log('Delete button Click!');
        } else _this3.navController.navigateRoot('error');
      });
    })();
  }
  inviteClick(id) {
    var _this4 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this4.invitationService.getContacts(id).subscribe(gResponse => {
        if (gResponse.error == null) {
          const guests = gResponse.data;
          _this4.navController.navigateForward('invite/guests/' + id, {
            state: {
              contacts: guests,
              invDescription: _this4.invitation?.description
            }
          });
        } else _this4.navController.navigateRoot('error');
      });
    })();
  }
  editImg() {
    console.log('Img edit Click!');
  }
  newInvitation() {
    console.log('New Invitation click!');
    this.navController.navigateForward('invite/new-invitation/' + this.invitation?.siteId);
  }
  newInvite(i) {
    var _this5 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('Invite click: ' + i.invitationId);
      yield _this5.invitationService.getContacts(i.invitationId).subscribe(gResponse => {
        if (gResponse.error == null) {
          const guests = gResponse.data;
          _this5.navController.navigateForward('invite/guests/' + i.invitationId, {
            state: {
              contacts: guests,
              invDescription: i.motive
            }
          });
        } else _this5.navController.navigateRoot('error');
      });
    })();
  }
  newAccess() {
    this.navController.navigateForward('access/new-access-point/' + this.invitation?.siteId);
  }
  assistSwitchClick(value) {
    var _this6 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('Assist switch Click!');
      yield _this6.accessService.updateAttendance(_this6.invitationId, value).subscribe(r => {
        if (r.error == null) {
          console.log('Assist switch Click!');
        } else _this6.navController.navigateRoot('error');
      });
    })();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_services_access_service__WEBPACK_IMPORTED_MODULE_4__.AccessService
}, {
  type: src_app_shared_services_invitation_service__WEBPACK_IMPORTED_MODULE_6__.InvitationService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.NavController
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.ActivatedRoute
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.Router
}, {
  type: src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_7__.UserService
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_13__.ChangeDetectorRef
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "propDecorators", {
  invInfoC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_13__.ViewChild,
    args: [_invitation_info_page__WEBPACK_IMPORTED_MODULE_8__.InvitationInfoPage]
  }],
  apSelection: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_13__.ViewChild,
    args: [_access_components_access_point_selection_access_point_selection_component__WEBPACK_IMPORTED_MODULE_5__.AccessPointSelectionComponent]
  }],
  edit: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_13__.ViewChild,
    args: [src_app_invite_pages_invitation_wizard_invitation_wizard_business__WEBPACK_IMPORTED_MODULE_2__.InvitationWizardBusiness]
  }],
  confirmModalC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_13__.ViewChild,
    args: [src_app_shared_components_confirm_modal_confirm_modal_component__WEBPACK_IMPORTED_MODULE_9__.ConfirmModalComponent]
  }]
}), _class);
InvitationInfoBusiness = (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.Component)({
  selector: 'app-inv-info-component',
  template: ` <app-invitation-info
      class="scroll-content"
      [invitation]="invitation"
      (back)="backClick()"
      (newInvitation)="newInvitation()"
      (bannerClick)="locationClick()"
      (newInvite)="newInvite($event)"
      (accessBadgeClick)="accessClick()"
      (accessEditClick)="accessEdit()"
      (locationBadgeClick)="locationClick()"
      (locationEditClick)="locationEdit()"
      (descriptionEditClick)="descriptionEdit()"
      (deleteButtonClick)="deleteClick()"
      (inviteButtonClick)="inviteClick($event)"
      (assistSwitchClick)="assistSwitchClick($event)"
      (imgEditClick)="editImg()"></app-invitation-info>
    <app-access-point-selection
      *ngIf="invitation"
      [accessPointList]="apList"
      [invitation]="invitation"
      [showNewAccess]="isAdmin"
      (newAccess)="newAccess()"></app-access-point-selection>
    <app-invitation-wizard-business
      *ngIf="invitation"
      (refresh)="refresh()"
      [isEdit]="true"></app-invitation-wizard-business>
    <app-confirm-modal
      [title]="'invite.confirmDelete' | translate"
      (confirmClick)="confirmDelete()"></app-confirm-modal>`
})], InvitationInfoBusiness);


/***/ }),

/***/ 44409:
/*!**********************************************************************!*\
  !*** ./src/app/invite/pages/invitation-info/invitation-info.page.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InvitationInfoPage": () => (/* binding */ InvitationInfoPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _invitation_info_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./invitation-info.page.html?ngResource */ 17493);
/* harmony import */ var _invitation_info_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./invitation-info.page.scss?ngResource */ 33911);
/* harmony import */ var _invitation_info_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_invitation_info_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var src_app_shared_components_button_panel_button_panel_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/button-panel/button-panel.component */ 35081);
/* harmony import */ var src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/components/footer/footer.component */ 68014);
/* harmony import */ var src_app_shared_components_modal_menu_modal_menu_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/components/modal-menu/modal-menu.component */ 77098);
/* harmony import */ var src_app_shared_helpers_business__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/helpers/business */ 92237);
/* harmony import */ var src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/models/Enums */ 6452);
/* harmony import */ var src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/services/user.service */ 31880);

var _class;












let InvitationInfoPage = (_class = class InvitationInfoPage {
  constructor(business, translate, userService) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "business", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "userService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "confirmModal", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "invitation", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "back", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "bannerClick", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "imgEditClick", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "descriptionEditClick", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessBadgeClick", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessEditClick", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "locationBadgeClick", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "locationEditClick", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "deleteButtonClick", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "inviteButtonClick", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "newInvitation", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "newInvite", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "assistSwitchClick", new _angular_core__WEBPACK_IMPORTED_MODULE_9__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "footerOptions", src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_4__.FooterSelectedOption);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "buttonsConfig", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "stylePanel", 'mb-n2 justify-content-center');
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "cardStyle", 'mb-0');
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "locationClass", ['fas', 'location-pin']);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "currentStep", 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "rows", 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "role", src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_7__.AccessPointRole);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "avatarApi", 'https://api.dicebear.com/5.x/initials/svg?backgroundColor=0078d7&seed=');
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "assistSwitchControl", new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(false));
    this.business = business;
    this.translate = translate;
    this.userService = userService;
  }
  get isAdmin() {
    return this.invitation?.roles?.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_7__.AccessPointRole.administrator);
  }
  get isOwner() {
    return this.invitation?.roles?.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_7__.AccessPointRole.owner);
  }
  get isOwnerCreated() {
    return this.invitation?.roles?.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_7__.AccessPointRole.owner) && this.invitation?.createBy === this.userService.userData?.userId;
  }
  get isGuest() {
    return this.invitation?.roles?.includes(src_app_shared_models_Enums__WEBPACK_IMPORTED_MODULE_7__.AccessPointRole.guest);
  }
  get hasPicture() {
    return this.invitation?.ownerImg !== undefined && this.invitation?.ownerImg !== null;
  }
  get ownerImg() {
    if (this.invitation?.ownerImg) {
      return this.invitation?.ownerImg.url;
    } else if (this.invitation?.ownerName) {
      return this.avatarApi + this.invitation?.ownerName.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]|[\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD10-\uDDFF]/gi, '');
    } else {
      return 'assets/icons/avatar.png';
    }
  }
  get invitationDescription() {
    return this.invitation?.description !== '' && this.invitation?.description !== undefined ? this.invitation?.description : this.invitation?.motive;
  }
  ngOnInit() {
    if (this.invitation) this.getButtonsConfig(this.invitation);
  }
  getButtonsConfig(inv) {
    this.invitation = inv;
    if (this.isAdmin || this.isOwnerCreated) {
      this.buttonsConfig = new src_app_shared_components_button_panel_button_panel_component__WEBPACK_IMPORTED_MODULE_3__.ButtonPanelConfig();
      this.stylePanel = 'mb-3 justify-content-center';
      this.rows = 1;
      const buttons = [];
      let button = {
        click: () => {
          this.inviteButtonClick.emit(this.invitation?.invitationId);
        },
        label: this.translate.instant('common.invite'),
        faClass: ['fas', 'envelope-open-text']
      };
      buttons.push(button);
      button = {
        click: () => {
          this.accessBadgeClick.emit();
        },
        label: this.translate.instant('common.attendanceButton'),
        faClass: ['fas', 'users']
      };
      buttons.push(button);
      button = {
        click: () => {
          this.deleteButtonClick.emit();
        },
        label: this.translate.instant('common.deleteButton'),
        faClass: ['fas', 'trash-can']
      };
      buttons.push(button);
      this.buttonsConfig.buttons = buttons;
    } else if (this.isOwner) {
      this.buttonsConfig = new src_app_shared_components_button_panel_button_panel_component__WEBPACK_IMPORTED_MODULE_3__.ButtonPanelConfig();
      const buttons = [];
      let button = {
        click: () => {
          this.inviteButtonClick.emit(this.invitation?.invitationId);
        },
        label: this.translate.instant('common.invite'),
        faClass: ['fas', 'envelope-open-text']
      };
      buttons.push(button);
      button = {
        click: () => {
          this.accessBadgeClick.emit();
        },
        label: this.translate.instant('common.attendanceButton'),
        faClass: ['fas', 'users']
      };
      buttons.push(button);
      this.buttonsConfig.buttons = buttons;
    } else if (this.isGuest) {
      this.cardStyle = 'mb-1';
      this.locationClass = ['fas', 'location-pin'];
    }
  }
  getTitle() {
    const array = [];
    if (this.invitation) {
      const dateRange = this.invitation?.dateTo === null && this.invitation?.recurrency ? `${this.translate.instant('recurence.from')} ` + this.business.getDateRange(this.invitation) : this.business.getDateRange(this.invitation);
      const recurrence = this.business.getRecurrence(this.invitation);
      array.push(dateRange);
      array.push(recurrence);
    }
    return array;
  }
  tryUnassist() {
    if (this.assistSwitchControl.value === true) {
      this.confirmModal?.show();
    } else {
      this.assistSwitchClick.emit(true);
    }
  }
  confirm() {
    // this.assistSwitchControl.setValue(false, { emitEvent: false })
    this.confirmModal?.hide();
    this.assistSwitchClick.emit(false);
  }
  cancel() {
    this.confirmModal?.hide();
    this.assistSwitchControl.setValue(true);
  }
  getSubtitle() {
    if (this.invitation) return this.translate.instant('recurence.entry') + ' ' + this.business.getTimeRange(this.invitation);
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_helpers_business__WEBPACK_IMPORTED_MODULE_6__["default"]
}, {
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__.TranslateService
}, {
  type: src_app_shared_services_user_service__WEBPACK_IMPORTED_MODULE_8__.UserService
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  confirmModal: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild,
    args: [src_app_shared_components_modal_menu_modal_menu_component__WEBPACK_IMPORTED_MODULE_5__.ModalMenuComponent]
  }],
  invitation: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Input
  }],
  back: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  bannerClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  imgEditClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  descriptionEditClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  accessBadgeClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  accessEditClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  locationBadgeClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  locationEditClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  deleteButtonClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  inviteButtonClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  newInvitation: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  newInvite: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }],
  assistSwitchClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Output
  }]
}), _class);
InvitationInfoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-invitation-info',
  template: _invitation_info_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_invitation_info_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], InvitationInfoPage);


/***/ }),

/***/ 8393:
/*!******************************************************************************!*\
  !*** ./src/app/invite/pages/invitation-wizard/invitation-wizard.business.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InvitationWizardBusiness": () => (/* binding */ InvitationWizardBusiness),
/* harmony export */   "InvitationWizardViewModel": () => (/* binding */ InvitationWizardViewModel),
/* harmony export */   "PostInvitationViewModel": () => (/* binding */ PostInvitationViewModel)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var src_app_shared_models_Image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/models/Image */ 90925);
/* harmony import */ var src_app_shared_services_site_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/services/site.service */ 19886);
/* harmony import */ var src_app_shared_services_file_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/services/file.service */ 30038);
/* harmony import */ var _components_invitation_date_step_invitation_date_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/invitation-date-step/invitation-date.component */ 3111);
/* harmony import */ var _components_new_invitation_place_step_new_invitation_place_step_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../components/new-invitation-place-step/new-invitation-place-step.component */ 18342);
/* harmony import */ var _components_new_invitation_step_new_invitation_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../components/new-invitation-step/new-invitation.component */ 65262);
/* harmony import */ var _invitation_wizard_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./invitation-wizard.page */ 40034);
/* harmony import */ var src_app_shared_components_door_select_form_door_select_form_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/components/door-select-form/door-select-form.component */ 6980);
/* harmony import */ var _components_invitation_edit_modal_invitation_edit_modal_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../components/invitation-edit-modal/invitation-edit-modal.component */ 81127);
/* harmony import */ var src_app_shared_services_invitation_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/shared/services/invitation.service */ 21178);
/* harmony import */ var src_app_shared_components_day_select_form_day_select_form_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/shared/components/day-select-form/day-select-form.component */ 84599);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs */ 51547);
/* harmony import */ var src_app_shared_services_access_point_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/shared/services/access-point.service */ 58838);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var ionicons_icons__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ionicons/icons */ 64047);


var _class;




















let InvitationWizardBusiness = (_class = class InvitationWizardBusiness {
  constructor(siteService, translate, accessPointService, invitationService, route, navController, fileService, toastr) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "siteService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPointService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitationService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "route", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "fileService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "toastr", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "wizardC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "editC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "isEdit", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "refresh", new _angular_core__WEBPACK_IMPORTED_MODULE_15__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "categoryList", []);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "siteList", []);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitation", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "viewModel", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "siteId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "site", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "isLoaded", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "loading", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "apList", void 0);
    this.siteService = siteService;
    this.translate = translate;
    this.accessPointService = accessPointService;
    this.invitationService = invitationService;
    this.route = route;
    this.navController = navController;
    this.fileService = fileService;
    this.toastr = toastr;
    this.viewModel = new InvitationWizardViewModel();
  }
  ngOnInit() {
    if (this.route.snapshot.params.id != null) {
      this.siteId = this.route.snapshot.params.id;
      if (this.siteId && !this.isEdit) {
        this.siteService.getSiteById(this.siteId).subscribe(response => {
          if (response.error == null) {
            this.site = response.data;
            this.wizardC?.fillForms(this.site);
          } else this.navController.navigateRoot('error');
        });
        this.accessPointService.getMyAccessPoints(this.siteId).subscribe(response => {
          if (response.error == null) {
            this.apList = response.data;
            const list = response.data.map(x => {
              const door = new src_app_shared_components_door_select_form_door_select_form_component__WEBPACK_IMPORTED_MODULE_9__.DoorsViewModel();
              door.selected = false;
              door.access = x;
              return door;
            });
            this.wizardC?.setAccessPointList(list);
          } else this.navController.navigateRoot('error');
        });
      }
    }
    this.getCategoryList();
    // this.getSiteList();
  }

  ngAfterViewInit() {
    this.isLoaded = true;
  }
  getCategoryList() {
    this.invitationService.getInvitationCategories().subscribe(response => {
      if (response.error === null) {
        this.categoryList = response.data;
        this.categoryList.unshift({
          id: '0',
          name: this.translate.instant('common.selectCategory'),
          image: ''
        });
      } else {
        this.navController.navigateRoot('error');
      }
    });
  }
  getSiteList() {
    this.siteService.getSitesListItem().subscribe(response => {
      if (response.error === null) {
        this.siteList = response.data;
      } else {
        this.navController.navigateRoot('error');
      }
    });
  }
  back() {
    if (!this.isEdit) {
      this.navController.back();
    } else {
      this.editC?.modal?.hide();
    }
  }
  nextClick(model) {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.fillVM(model);
    })();
  }
  save(model) {
    var _this2 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const step = _this2.fillVM(model);
      if (_this2.isEdit) {
        if (step === 1) {
          _this2.saveStep(1);
        } else if (step === 2) {
          _this2.saveStep(2);
        } else if (step === 3) {
          _this2.saveStep(3);
        }
      } else {
        const vm = _this2.getPostViewModel();
        yield _this2.deleteImages(_this2.viewModel.newInvitationStep);
        if (_this2.viewModel.newInvitationStep?.image?.length === 0) {
          _this2.invitationService.postInvitation(vm).subscribe(ret => {
            _this2.loading = false;
            _this2.navController.back();
          });
        } else {
          yield _this2.fileService.uploadFiles(_this2.viewModel.newInvitationStep.image).subscribe(res => {
            if (res.error === null) {
              vm.externalFileId = res.data;
            } else {
              _this2.toastr.create({
                message: _this2.translate.instant('error.fileUpload'),
                duration: 3000,
                icon: ionicons_icons__WEBPACK_IMPORTED_MODULE_14__.alertCircleOutline,
                color: 'warning'
              }).then(t => t.present());
            }
            _this2.invitationService.postInvitation(vm).subscribe(ret => {
              if (ret.error === null) {
                _this2.loading = false;
                _this2.navController.back();
              } else {
                _this2.navController.navigateRoot('error');
              }
            });
          });
        }
      }
    })();
  }
  getPostViewModel() {
    const vm = new PostInvitationViewModel();
    vm.id = crypto.randomUUID();
    vm.categoryId = this.viewModel.newInvitationStep?.category.id;
    vm.description = this.viewModel.newInvitationStep?.description;
    vm.motive = this.viewModel.newInvitationStep?.title;
    vm.place = this.viewModel.newInvitationStep?.place;
    vm.siteId = this.siteId;
    vm.location = this.viewModel.invitationPlaceStep?.place;
    // vm.accessPointIds = this.viewModel.invitationPlaceStep?.accessPoints
    //   ?.filter((x) => x.selected)
    //   .map((x) => x.access.id)!;
    vm.dateFrom = this.formatDate(this.viewModel.invitationDateStep?.dateFrom);
    if (this.viewModel.invitationDateStep?.noEnd === false) vm.dateTo = this.formatDate(this.viewModel.invitationDateStep?.dateTo);
    if (!this.viewModel.invitationDateStep?.allDay) {
      if (this.viewModel.invitationDateStep?.timeFrom) {
        const time = this.viewModel.invitationDateStep?.timeFrom.split(':');
        vm.hourFrom = Number(time[0]);
        vm.minuteFrom = Number(time[1]);
      }
      if (this.viewModel.invitationDateStep?.timeTo) {
        const time = this.viewModel.invitationDateStep?.timeTo.split(':');
        vm.hourTo = Number(time[0]);
        vm.minuteTo = Number(time[1]);
      }
    }
    vm.recurrency = !this.viewModel.invitationDateStep?.isUnique;
    if (vm.recurrency) {
      vm.monday = this.viewModel.invitationDateStep?.daysVM.monday;
      vm.tuesday = this.viewModel.invitationDateStep?.daysVM.tuesday;
      vm.wednesday = this.viewModel.invitationDateStep?.daysVM.wednesday;
      vm.thursday = this.viewModel.invitationDateStep?.daysVM.thursday;
      vm.friday = this.viewModel.invitationDateStep?.daysVM.friday;
      vm.saturday = this.viewModel.invitationDateStep?.daysVM.saturday;
      vm.sunday = this.viewModel.invitationDateStep?.daysVM.sunday;
    }
    return vm;
  }
  deleteImages(model) {
    var _this3 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      model.deleteImage?.forEach( /*#__PURE__*/function () {
        var _ref = (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (img) {
          if (img) {
            yield (0,rxjs__WEBPACK_IMPORTED_MODULE_16__.lastValueFrom)(_this3.invitationService.deleteImage(img));
          }
        });
        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }());
    })();
  }
  getUpdateViewModel(step) {
    let ret;
    switch (step) {
      case 1:
        ret = new _components_new_invitation_step_new_invitation_component__WEBPACK_IMPORTED_MODULE_7__.UpdateInvitationViewModel();
        ret.categoryId = this.viewModel.newInvitationStep?.category.id;
        ret.description = this.viewModel.newInvitationStep?.description;
        ret.motive = this.viewModel.newInvitationStep?.title;
        ret.place = this.viewModel.newInvitationStep?.place;
        ret.id = this.invitation?.invitationId;
        ret.siteId = this.siteId;
        break;
      case 2:
        ret = new _components_new_invitation_place_step_new_invitation_place_step_component__WEBPACK_IMPORTED_MODULE_6__.UpdateInvitationAddressViewModel();
        ret.id = this.invitation?.invitationId;
        ret.place = this.viewModel.invitationPlaceStep?.place;
        ret.accessPointId = this.viewModel.invitationPlaceStep?.accessPoints?.filter(x => x.selected).map(x => x.access.id);
        break;
      case 3:
        ret = new _components_invitation_date_step_invitation_date_component__WEBPACK_IMPORTED_MODULE_5__.UpdateInvitationScheduleViewModel();
        ret.id = this.invitation?.invitationId;
        ret.recurrency = !this.viewModel.invitationDateStep?.isUnique;
        if (ret.recurrency) {
          ret.friday = this.viewModel.invitationDateStep?.daysVM.friday;
          ret.monday = this.viewModel.invitationDateStep?.daysVM.monday;
          ret.saturday = this.viewModel.invitationDateStep?.daysVM.saturday;
          ret.sunday = this.viewModel.invitationDateStep?.daysVM.sunday;
          ret.thursday = this.viewModel.invitationDateStep?.daysVM.thursday;
          ret.tuesday = this.viewModel.invitationDateStep?.daysVM.tuesday;
          ret.wednesday = this.viewModel.invitationDateStep?.daysVM.wednesday;
        }
        ret.dateFrom = this.formatDate(this.viewModel.invitationDateStep?.dateFrom);
        if (this.viewModel.invitationDateStep?.noEnd === false) ret.dateTo = this.formatDate(this.viewModel.invitationDateStep?.dateTo);
        if (!this.viewModel.invitationDateStep?.allDay) {
          if (this.viewModel.invitationDateStep?.timeFrom) {
            const time = this.viewModel.invitationDateStep?.timeFrom.split(':');
            ret.hourFrom = Number(time[0]);
            ret.minuteFrom = Number(time[1]);
          }
          if (this.viewModel.invitationDateStep?.timeTo) {
            const time = this.viewModel.invitationDateStep?.timeTo.split(':');
            ret.hourTo = Number(time[0]);
            ret.minuteTo = Number(time[1]);
          }
        }
        break;
    }
    return ret;
  }
  formatDate(value) {
    return value + 'T12:00:00';
  }
  saveStep(step) {
    var _this4 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      switch (step) {
        case 1:
          const firstVM = _this4.getUpdateViewModel(1);
          yield _this4.deleteImages(_this4.viewModel.newInvitationStep);
          if (_this4.viewModel.newInvitationStep?.image?.length === 0) {
            _this4.invitationService.updateInvitation(firstVM).subscribe(as => {
              if (as.error === null) {
                _this4.invitationRefresh();
              } else {
                _this4.navController.navigateRoot('error');
              }
            });
          } else {
            _this4.fileService.uploadFiles(_this4.viewModel.newInvitationStep.image).subscribe(res => {
              if (res.error === null) {
                firstVM.externalFileId = res.data;
              } else {
                _this4.toastr.create({
                  message: _this4.translate.instant('error.fileUpload'),
                  duration: 3000,
                  icon: ionicons_icons__WEBPACK_IMPORTED_MODULE_14__.alertCircleOutline,
                  color: 'warning'
                }).then(t => t.present());
              }
              _this4.invitationService.updateInvitation(firstVM).subscribe(as => {
                if (as.error === null) {
                  _this4.invitationRefresh();
                } else {
                  _this4.navController.navigateRoot('error');
                }
              });
            });
          }
          break;
        case 3:
          const thirdVM = _this4.getUpdateViewModel(3);
          console.log(thirdVM);
          _this4.invitationService.updateSchedule(thirdVM).subscribe(res => {
            if (res.error === null) {
              _this4.invitationRefresh();
            } else {
              _this4.navController.navigateRoot('error');
            }
          });
          break;
        case 2:
          const secVM = _this4.getUpdateViewModel(2);
          _this4.invitationService.updateAddress(secVM).subscribe(res => {
            if (res.error === null) {
              _this4.invitationRefresh();
            } else {
              _this4.navController.navigateRoot('error');
            }
          });
          break;
      }
    })();
  }
  fillVM(model) {
    if (model instanceof _components_new_invitation_step_new_invitation_component__WEBPACK_IMPORTED_MODULE_7__.NewInvitationViewModel) {
      this.viewModel.newInvitationStep = model;
      return 1;
    }
    if (model instanceof _components_invitation_date_step_invitation_date_component__WEBPACK_IMPORTED_MODULE_5__.InvitationDateViewModel) {
      this.viewModel.invitationDateStep = model;
      return 3;
    }
    if (model instanceof _components_new_invitation_place_step_new_invitation_place_step_component__WEBPACK_IMPORTED_MODULE_6__.NewInvitationPlaceViewModel) {
      this.viewModel.invitationPlaceStep = model;
      return 2;
    }
  }
  fetchInvitationById(id) {
    var _this5 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const r = yield _this5.invitationService.getInvitationById(id).toPromise();
      if (r) _this5.invitation = r.data;
    })();
  }
  openModal(siteId, step) {
    var _this6 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this6.fetchInvitationById(siteId);
      if (step === 3) yield _this6.getViewModel(siteId, 2);
      yield _this6.getViewModel(siteId, step);
      _this6.editC?.modal?.show();
      _this6.editC?.fillForms(step, _this6.viewModel);
    })();
  }
  getViewModel(id, step) {
    var _this7 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      switch (step) {
        case 1:
          const invVM = new _components_new_invitation_step_new_invitation_component__WEBPACK_IMPORTED_MODULE_7__.NewInvitationViewModel();
          invVM.category = {
            name: _this7.invitation.category.name,
            id: _this7.invitation.category.id
          };
          invVM.description = _this7.invitation.description;
          invVM.title = _this7.invitation.motive;
          invVM.place = _this7.invitation.siteName;
          if (_this7.invitation.presentationImg) {
            invVM.image = [];
            let i = 0;
            _this7.invitation.presentationImg.forEach(img => {
              if (img.id == null) return;
              const image = new src_app_shared_models_Image__WEBPACK_IMPORTED_MODULE_2__.Image();
              image.id = img.id;
              image.image64 = img.url;
              image.name = `invitationImg${i}.png`;
              invVM.image.push(image);
              i++;
            });
          }
          _this7.viewModel.newInvitationStep = invVM;
          break;
        case 2:
          const placeVM = new _components_new_invitation_place_step_new_invitation_place_step_component__WEBPACK_IMPORTED_MODULE_6__.NewInvitationPlaceViewModel();
          placeVM.accessPoints = [];
          placeVM.place = _this7.invitation?.locationId;
          const apResult = yield _this7.accessPointService.getMyAccessPointChilds(_this7.invitation?.siteId).toPromise();
          if (apResult) {
            placeVM.accessPoints = apResult.data.map(x => {
              const door = new src_app_shared_components_door_select_form_door_select_form_component__WEBPACK_IMPORTED_MODULE_9__.DoorsViewModel();
              door.selected = _this7.invitation?.accessPointIds.some(y => y === x.id) ?? false;
              door.access = x;
              return door;
            });
            _this7.editC?.setAccessPointList(placeVM.accessPoints);
          }
          _this7.viewModel.invitationPlaceStep = placeVM;
          break;
        case 3:
          const dateVM = new _components_invitation_date_step_invitation_date_component__WEBPACK_IMPORTED_MODULE_5__.InvitationDateViewModel();
          dateVM.dateFrom = _this7.getDateString(new Date(_this7.invitation.dateFrom));
          if (_this7.invitation?.dateTo !== null) dateVM.dateTo = _this7.getDateString(new Date(_this7.invitation.dateTo));
          if (_this7.invitation?.hourFrom !== null && _this7.invitation?.minuteFrom !== null) {
            dateVM.timeFrom = (_this7.invitation?.hourFrom < 10 ? '0' + _this7.invitation?.hourFrom.toString() : _this7.invitation?.hourFrom.toString()) + ':' + (_this7.invitation?.minuteFrom < 10 ? '0' + _this7.invitation?.minuteFrom.toString() : _this7.invitation?.minuteFrom.toString());
          }
          if (_this7.invitation?.minuteTo !== null && _this7.invitation?.hourTo !== null) {
            dateVM.timeTo = (_this7.invitation?.hourTo < 10 ? '0' + _this7.invitation?.hourTo.toString() : _this7.invitation?.hourTo.toString()) + ':' + (_this7.invitation?.minuteTo < 10 ? '0' + _this7.invitation?.minuteTo.toString() : _this7.invitation?.minuteTo.toString());
          }
          dateVM.isUnique = !_this7.invitation?.recurrency ?? false;
          if (dateVM.dateTo === null || dateVM.dateTo === undefined) {
            dateVM.noEnd = true;
          } else {
            dateVM.noEnd = false;
          }
          if ((dateVM.timeFrom === null || dateVM.timeFrom === '' || dateVM.timeFrom === undefined) && (dateVM.timeTo === null || dateVM.timeTo === '' || dateVM.timeTo === undefined) || dateVM.timeFrom === '00:00' && dateVM.timeTo === '00:00') {
            dateVM.allDay = true;
          } else {
            dateVM.allDay = false;
          }
          dateVM.daysVM = new src_app_shared_components_day_select_form_day_select_form_component__WEBPACK_IMPORTED_MODULE_12__.DaysViewModel();
          dateVM.daysVM.monday = _this7.invitation.monday;
          dateVM.daysVM.tuesday = _this7.invitation.tuesday;
          dateVM.daysVM.wednesday = _this7.invitation.wednesday;
          dateVM.daysVM.thursday = _this7.invitation.thursday;
          dateVM.daysVM.friday = _this7.invitation.friday;
          dateVM.daysVM.saturday = _this7.invitation.saturday;
          dateVM.daysVM.sunday = _this7.invitation.sunday;
          if (dateVM.daysVM.monday && dateVM.daysVM.tuesday && dateVM.daysVM.wednesday && dateVM.daysVM.thursday && dateVM.daysVM.friday && dateVM.daysVM.saturday && dateVM.daysVM.sunday) {
            dateVM.daysVM.allDays = true;
          } else {
            dateVM.daysVM.allDays = false;
          }
          _this7.viewModel.invitationDateStep = dateVM;
          break;
      }
    })();
  }
  getDateString(d) {
    const date = d.getUTCDate();
    const month = d.getUTCMonth() + 1; // Since getUTCMonth() returns month from 0-11 not 1-12
    const year = d.getUTCFullYear();
    return year + '-' + (month < 10 ? '0' + month : month) + '-' + (date < 10 ? '0' + date : date);
  }
  getTimeString(d) {
    const min = d.getMinutes();
    const sec = d.getSeconds();
    return (min < 10 ? '0' + min : min) + ':' + (sec < 10 ? '0' + sec : sec);
  }
  invitationRefresh() {
    this.editC.loading = false;
    this.editC?.modal?.hide();
    this.refresh.emit();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_services_site_service__WEBPACK_IMPORTED_MODULE_3__.SiteService
}, {
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_17__.TranslateService
}, {
  type: src_app_shared_services_access_point_service__WEBPACK_IMPORTED_MODULE_13__.AccessPointService
}, {
  type: src_app_shared_services_invitation_service__WEBPACK_IMPORTED_MODULE_11__.InvitationService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_18__.ActivatedRoute
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.NavController
}, {
  type: src_app_shared_services_file_service__WEBPACK_IMPORTED_MODULE_4__.FileService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.ToastController
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "propDecorators", {
  wizardC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_15__.ViewChild,
    args: [_invitation_wizard_page__WEBPACK_IMPORTED_MODULE_8__.InvitationWizardPage]
  }],
  editC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_15__.ViewChild,
    args: [_components_invitation_edit_modal_invitation_edit_modal_component__WEBPACK_IMPORTED_MODULE_10__.InvitationEditModalComponent]
  }],
  isEdit: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_15__.Input
  }],
  refresh: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_15__.Output
  }]
}), _class);
InvitationWizardBusiness = (0,tslib__WEBPACK_IMPORTED_MODULE_20__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_15__.Component)({
  selector: 'app-invitation-wizard-business',
  template: `<app-invitation-wizard
      class="scroll-content"
      *ngIf="isLoaded && !isEdit"
      [categoryList]="categoryList"
      [siteList]="siteList"
      [loading]="loading"
      (backClick)="back()"
      (nextClick)="nextClick($event)"
      (saveClick)="save($event)"></app-invitation-wizard>
    <app-invitation-edit-modal
      *ngIf="isEdit"
      [categoryList]="categoryList"
      [loading]="loading"
      (closeClick)="back()"
      (saveClick)="save($event)"></app-invitation-edit-modal>`
})], InvitationWizardBusiness);

class InvitationWizardViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "newInvitationStep", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitationDateStep", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitationPlaceStep", void 0);
  }
}
class PostInvitationViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "id", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "siteId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "categoryId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "description", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "motive", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "externalFileId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "place", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "location", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPointIds", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "dateFrom", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "dateTo", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "hourFrom", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "minuteFrom", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "hourTo", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "minuteTo", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "monday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "tuesday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "wednesday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "thursday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "friday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "saturday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "sunday", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "recurrency", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "default", void 0);
  }
}

/***/ }),

/***/ 40034:
/*!**************************************************************************!*\
  !*** ./src/app/invite/pages/invitation-wizard/invitation-wizard.page.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InvitationWizardPage": () => (/* binding */ InvitationWizardPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _invitation_wizard_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./invitation-wizard.page.html?ngResource */ 76319);
/* harmony import */ var _invitation_wizard_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./invitation-wizard.page.scss?ngResource */ 9798);
/* harmony import */ var _invitation_wizard_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_invitation_wizard_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/footer/footer.component */ 68014);
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/animations */ 66400);
/* harmony import */ var _components_new_invitation_step_new_invitation_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/new-invitation-step/new-invitation.component */ 65262);
/* harmony import */ var _components_invitation_date_step_invitation_date_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/invitation-date-step/invitation-date.component */ 3111);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var _components_new_invitation_place_step_new_invitation_place_step_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../components/new-invitation-place-step/new-invitation-place-step.component */ 18342);
/* harmony import */ var src_app_shared_models_SelectListItem__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/models/SelectListItem */ 75987);
/* harmony import */ var src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/components/button/button.component */ 62490);

var _class;












const left = [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.query)(':enter, :leave', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({
  position: 'fixed',
  width: '100%'
}), {
  optional: true
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.group)([(0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.query)(':enter', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({
  transform: 'translateX(-100%)'
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.animate)('.3s ease-out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({
  transform: 'translateX(0%)'
}))], {
  optional: true
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.query)(':leave', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({
  transform: 'translateX(0%)'
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.animate)('.3s ease-out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({
  transform: 'translateX(100%)'
}))], {
  optional: true
})])];
const right = [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.query)(':enter, :leave', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({
  position: 'fixed',
  width: '100%'
}), {
  optional: true
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.group)([(0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.query)(':enter', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({
  transform: 'translateX(100%)'
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.animate)('.3s ease-out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({
  transform: 'translateX(0%)'
}))], {
  optional: true
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.query)(':leave', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({
  transform: 'translateX(0%)'
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.animate)('.3s ease-out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.style)({
  transform: 'translateX(-100%)'
}))], {
  optional: true
})])];
let InvitationWizardPage = (_class = class InvitationWizardPage {
  constructor(translate, cdRef) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "cdRef", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "newInvitationC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "invitationDateC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "invitationPlaceC", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "categoryList", []);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "siteList", []);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "loading", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "nextClick", new _angular_core__WEBPACK_IMPORTED_MODULE_10__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "backClick", new _angular_core__WEBPACK_IMPORTED_MODULE_10__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "saveClick", new _angular_core__WEBPACK_IMPORTED_MODULE_10__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "site", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "invitationPlace", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "steps", [1, 2, 3]);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "currentStep", 1);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "footerOptions", src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__.FooterSelectedOption);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "invitationTitle", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "selectedDoor", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "showKeyboard", false);
    this.translate = translate;
    this.cdRef = cdRef;
  }
  get wizardTitle() {
    if (this.invitationTitle) {
      return this.invitationTitle;
    } else {
      return this.translate.instant('common.newInvite');
    }
  }
  get buttonState() {
    if (!this.currentStepValid()) {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_8__.ButtonState.disabled;
    } else if (!this.loading) {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_8__.ButtonState.enabled;
    } else {
      return src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_8__.ButtonState.loading;
    }
  }
  fillForms(site) {
    if (site) {
      this.site = site;
      const vm = new _components_new_invitation_step_new_invitation_component__WEBPACK_IMPORTED_MODULE_4__.NewInvitationViewModel();
      vm.place = this.site.name;
      vm.title = '';
      vm.description = '';
      vm.category = new src_app_shared_models_SelectListItem__WEBPACK_IMPORTED_MODULE_7__.SelectListItem();
      vm.category.id = '0';
      this.newInvitationC?.setForm(vm);
    }
  }
  setAccessPointList(ap) {
    if (ap) {
      this.invitationPlace = new _components_new_invitation_place_step_new_invitation_place_step_component__WEBPACK_IMPORTED_MODULE_6__.NewInvitationPlaceViewModel();
      this.invitationPlace.accessPoints = ap;
    }
  }
  nextStep() {
    let currentStepModel;
    switch (this.currentStep) {
      case 1:
        currentStepModel = this.newInvitationC?.viewModel;
        this.invitationTitle = currentStepModel?.title;
        this.invitationPlaceC?.setForm(this.invitationPlace);
        this.invitationPlaceC?.checkIfOnlyOneWay();
        break;
      case 2:
        currentStepModel = this.invitationPlaceC?.viewModel;
        this.selectedDoor = [];
        if (this.invitationPlaceC && this.invitationPlaceC?.viewModel.accessPoints.length > 0) {
          this.selectedDoor = this.invitationPlaceC?.viewModel.accessPoints;
        }
        const ap = this.invitationPlace?.accessPoints.find(x => x.access.id === this.invitationPlaceC?.viewModel.place);
        if (ap) {
          ap.selected = true;
          this.selectedDoor.push(ap);
        }
        break;
      case 3:
        currentStepModel = this.invitationDateC?.viewModel;
        break;
    }
    if (this.currentStep !== this.steps.length) {
      this.nextClick.emit(currentStepModel);
      this.currentStep++;
    } else {
      this.loading = true;
      this.saveClick.emit(currentStepModel);
    }
    this.cdRef.detectChanges();
  }
  backStep(step) {
    if (step) {
      this.currentStep = step;
    } else {
      if (this.currentStep === 1) {
        this.backClick.emit();
      }
      this.currentStep--;
    }
    switch (this.currentStep) {
      case 2:
        this.invitationPlace.place = this.invitationPlaceC?.viewModel.place;
        this.invitationPlaceC.setForm(this.invitationPlace);
        this.invitationPlaceC.mapC.loading = false;
        break;
    }
  }
  currentStepValid() {
    switch (this.currentStep) {
      case 1:
        return this.newInvitationC?.formValid;
      case 2:
        return this.invitationPlaceC?.formValid;
      case 3:
        return this.invitationDateC?.formValid;
      case 4:
        return true;
    }
  }
  hide() {
    this.showKeyboard = true;
    this.cdRef.detectChanges();
  }
  show() {
    this.showKeyboard = false;
    this.cdRef.detectChanges();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__.TranslateService
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ChangeDetectorRef
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  newInvitationC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ViewChild,
    args: [_components_new_invitation_step_new_invitation_component__WEBPACK_IMPORTED_MODULE_4__.NewInvitationComponent]
  }],
  invitationDateC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ViewChild,
    args: [_components_invitation_date_step_invitation_date_component__WEBPACK_IMPORTED_MODULE_5__.InvitationDateComponent]
  }],
  invitationPlaceC: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ViewChild,
    args: [_components_new_invitation_place_step_new_invitation_place_step_component__WEBPACK_IMPORTED_MODULE_6__.NewInvitationPlaceStepComponent]
  }],
  categoryList: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input
  }],
  siteList: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input
  }],
  loading: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input
  }],
  nextClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output
  }],
  backClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output
  }],
  saveClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output
  }]
}), _class);
InvitationWizardPage = (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
  selector: 'app-invitation-wizard',
  template: _invitation_wizard_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  animations: [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.trigger)('animSlider', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.transition)(':increment', right), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_9__.transition)(':decrement', left)])],
  styles: [(_invitation_wizard_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], InvitationWizardPage);


/***/ }),

/***/ 50815:
/*!******************************************************************!*\
  !*** ./src/app/invite/pages/invitations/invitations.business.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InvitationsBusiness": () => (/* binding */ InvitationsBusiness)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var src_app_shared_services_invitation_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/services/invitation.service */ 21178);
/* harmony import */ var src_app_shared_services_site_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/services/site.service */ 19886);


var _class;






let InvitationsBusiness = (_class = class InvitationsBusiness {
  constructor(invitationService, siteService, route, navController) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitationService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "siteService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "route", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitations", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "filteredList", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "site", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "siteId", void 0);
    this.invitationService = invitationService;
    this.siteService = siteService;
    this.route = route;
    this.navController = navController;
  }
  ngOnInit() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this.route.snapshot.params.id != null) {
        _this.siteId = _this.route.snapshot.params.id;
      }
    })();
  }
  ionViewDidEnter() {
    this.invitations = this.filteredList = undefined;
    this.siteService.getSiteById(this.siteId).subscribe(response => {
      if (response.error == null) {
        this.site = response.data;
        this.invitationService.getInvitationsBySiteId(this.siteId).subscribe(apResponse => {
          if (apResponse.error == null) this.filteredList = this.invitations = apResponse.data;else this.navController.navigateRoot('error');
        });
      } else this.navController.navigateRoot('error');
    });
  }
  search(t) {
    this.filteredList = this.invitations?.filter(i => i.description.toLowerCase().includes(t.toLowerCase()));
  }
  backClick() {
    this.navController.back();
  }
  newInvitation() {
    this.navController.navigateForward('invite/new-invitation/' + this.siteId);
  }
  goToGuests(id) {
    var _this2 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this2.invitationService.getContacts(id).subscribe(gResponse => {
        if (gResponse.error == null) {
          const guests = gResponse.data;
          _this2.navController.navigateForward('invite/guests/' + id, {
            state: {
              contacts: guests
            }
          });
        } else _this2.navController.navigateRoot('error');
      });
    })();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_services_invitation_service__WEBPACK_IMPORTED_MODULE_2__.InvitationService
}, {
  type: src_app_shared_services_site_service__WEBPACK_IMPORTED_MODULE_3__.SiteService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.ActivatedRoute
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController
}]), _class);
InvitationsBusiness = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
  selector: 'app-invitations',
  template: `<app-invitations-page
    class="scroll-content"
    [siteName]="site?.name"
    [invitations]="filteredList"
    (back)="backClick()"
    (search)="search($event)"
    (guestsClick)="goToGuests($event)"
    (newInvite)="newInvitation()"></app-invitations-page>`
})], InvitationsBusiness);


/***/ }),

/***/ 36564:
/*!**************************************************************!*\
  !*** ./src/app/invite/pages/invitations/invitations.page.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InvitationsPage": () => (/* binding */ InvitationsPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _invitations_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./invitations.page.html?ngResource */ 94211);
/* harmony import */ var _invitations_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./invitations.page.scss?ngResource */ 6005);
/* harmony import */ var _invitations_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_invitations_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/footer/footer.component */ 68014);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 67690);

var _class;






let InvitationsPage = (_class = class InvitationsPage {
  constructor(translate) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "invitations", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "siteName", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "back", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "search", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "guestsClick", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessClick", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "newInvite", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "footerOptions", src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__.FooterSelectedOption);
    this.translate = translate;
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslateService
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  invitations: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input
  }],
  siteName: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input
  }],
  back: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }],
  search: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }],
  guestsClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }],
  accessClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }],
  newInvite: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }]
}), _class);
InvitationsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
  selector: 'app-invitations-page',
  template: _invitations_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_invitations_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], InvitationsPage);


/***/ }),

/***/ 86317:
/*!***********************************************************!*\
  !*** ./src/app/shared/models/NotDefaultValueValidator.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "notDefaultValueValidator": () => (/* binding */ notDefaultValueValidator)
/* harmony export */ });
function notDefaultValueValidator(control) {
  const valor = control.value;
  if (!valor) return null;
  if (valor === '0') {
    return {
      notDefaultValueValidator: true
    };
  }
  return null;
}

/***/ }),

/***/ 75987:
/*!*************************************************!*\
  !*** ./src/app/shared/models/SelectListItem.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SelectListItem": () => (/* binding */ SelectListItem)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);

class SelectListItem {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "id", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "name", void 0);
  }
}

/***/ }),

/***/ 30038:
/*!*************************************************!*\
  !*** ./src/app/shared/services/file.service.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FileService": () => (/* binding */ FileService)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 74048);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 13045);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 56997);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _base_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./base.service */ 15127);


var _class;






let FileService = (_class = class FileService extends _base_service__WEBPACK_IMPORTED_MODULE_2__.BaseService {
  constructor(http, toast, navController) {
    super(toast, navController);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "http", void 0);
    this.http = http;
  }
  upload(file) {
    const formData = new FormData();
    formData.append('file', file.file, file.name);
    return this.http.post(`${_base_service__WEBPACK_IMPORTED_MODULE_2__.BaseService.apiUrl}File/Upload`, formData).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.catchError)(error => this.handleError(error)));
  }
  uploadFiles(files) {
    const formData = new FormData();
    files.forEach(file => {
      formData.append('file', file.file, file.name);
    });
    return this.http.post(`${_base_service__WEBPACK_IMPORTED_MODULE_2__.BaseService.apiUrl}File/Upload`, formData).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.catchError)(error => this.handleError(error)));
  }
  uploadFileString(fileSrc) {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const file = yield _this.dataUrlToFile(fileSrc, 'map.png');
      const formData = new FormData();
      formData.append('file', file, file.name);
      return _this.http.post(`${_base_service__WEBPACK_IMPORTED_MODULE_2__.BaseService.apiUrl}File/Upload`, formData).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.map)(x => {
        const result = _this.checkResult(x);
        return result;
      }), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.catchError)(error => _this.handleError(error)));
    })();
  }
  dataUrlToFile(dataUrl, fileName) {
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const res = yield fetch(dataUrl);
      const blob = yield res.blob();
      return new File([blob], fileName, {
        type: 'image/png'
      });
    })();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClient
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController
}]), _class);
FileService = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Injectable)({
  providedIn: 'root'
})], FileService);


/***/ }),

/***/ 21178:
/*!*******************************************************!*\
  !*** ./src/app/shared/services/invitation.service.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InvitationService": () => (/* binding */ InvitationService)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 13045);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 56997);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 74048);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _base_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./base.service */ 15127);

var _class;






let InvitationService = (_class = class InvitationService extends _base_service__WEBPACK_IMPORTED_MODULE_1__.BaseService {
  constructor(http, toast, navController) {
    super(toast, navController);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "http", void 0);
    this.http = http;
  }
  getContacts(invitationId) {
    const queryParams = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams().append('invitationId', invitationId);
    return this.http.get(`${_base_service__WEBPACK_IMPORTED_MODULE_1__.BaseService.apiUrl}Invitation/GetContacts`, {
      params: queryParams
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.catchError)(error => this.handleError(error)));
  }
  deleteGuests(viewModel) {
    const options = {
      headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
        'Content-Type': 'application/json'
      }),
      body: viewModel
    };
    return this.http.delete(`${_base_service__WEBPACK_IMPORTED_MODULE_1__.BaseService.apiUrl}Invitation/DeleteGuests`, options).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.catchError)(error => this.handleError(error)));
  }
  addGuests(viewModel) {
    return this.http.post(`${_base_service__WEBPACK_IMPORTED_MODULE_1__.BaseService.apiUrl}Invitation/AddGuests`, viewModel).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.catchError)(error => this.handleError(error)));
  }
  getInvitationAccessPoints(invitationId) {
    const queryParams = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams().append('invId', invitationId);
    return this.http.get(`${_base_service__WEBPACK_IMPORTED_MODULE_1__.BaseService.apiUrl}Invitation/GetAccessPointsByInvitation`, {
      params: queryParams
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.catchError)(error => this.handleError(error)));
  }
  getInvitationCategories() {
    return this.http.get(`${_base_service__WEBPACK_IMPORTED_MODULE_1__.BaseService.apiUrl}Invitation/GetCategories`).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.catchError)(error => this.handleError(error)));
  }
  delete(id) {
    const queryParams = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams().append('invitationId', id);
    return this.http.delete(`${_base_service__WEBPACK_IMPORTED_MODULE_1__.BaseService.apiUrl}Invitation/Delete`, {
      params: queryParams
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.catchError)(error => this.handleError(error)));
  }
  getInvitationById(id) {
    const queryParams = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams().append('invitationId', id);
    return this.http.get(`${_base_service__WEBPACK_IMPORTED_MODULE_1__.BaseService.apiUrl}Invitation/GetById`, {
      params: queryParams
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.catchError)(error => this.handleError(error)));
  }
  updateInvitation(invitation) {
    return this.http.post(`${_base_service__WEBPACK_IMPORTED_MODULE_1__.BaseService.apiUrl}Invitation/UpdateInvitation`, invitation).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.catchError)(error => this.handleError(error)));
  }
  updateSchedule(invitation) {
    return this.http.post(`${_base_service__WEBPACK_IMPORTED_MODULE_1__.BaseService.apiUrl}Invitation/UpdateSchedule`, invitation).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.catchError)(error => this.handleError(error)));
  }
  updateAddress(invitation) {
    return this.http.post(`${_base_service__WEBPACK_IMPORTED_MODULE_1__.BaseService.apiUrl}Invitation/UpdateAddress`, invitation).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.catchError)(error => this.handleError(error)));
  }
  deleteImage(id) {
    const queryParams = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams().append('id', id);
    return this.http.delete(`${_base_service__WEBPACK_IMPORTED_MODULE_1__.BaseService.apiUrl}Invitation/DeleteImage`, {
      params: queryParams
    });
  }
  postInvitation(invitation) {
    return this.http.post(`${_base_service__WEBPACK_IMPORTED_MODULE_1__.BaseService.apiUrl}Invitation/PostInvitation`, invitation).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.catchError)(error => this.handleError(error)));
  }
  getInvitationsBySiteId(id) {
    const queryParams = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams().append('siteId', id);
    return this.http.get(`${_base_service__WEBPACK_IMPORTED_MODULE_1__.BaseService.apiUrl}Invitation/GetBySite`, {
      params: queryParams
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.catchError)(error => this.handleError(error)));
  }
  getInvitationsByAccessPoint(accessPointId) {
    const queryParams = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams().append('id', accessPointId);
    return this.http.get(`${_base_service__WEBPACK_IMPORTED_MODULE_1__.BaseService.apiUrl}Invitation/GetByAccessPoint`, {
      params: queryParams
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.map)(x => {
      const result = this.checkResult(x);
      return result;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.catchError)(error => this.handleError(error)));
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ToastController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController
}]), _class);
InvitationService = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Injectable)({
  providedIn: 'root'
})], InvitationService);


/***/ }),

/***/ 51085:
/*!**************************************************************************************************!*\
  !*** ./src/app/invite/components/invitation-date-step/invitation-date.component.scss?ngResource ***!
  \**************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "input[type=date] {\n  position: relative;\n}\n\n/* create a new arrow, because we are going to mess up the native one\nsee \"List of symbols\" below if you want another, you could also try to add a font-awesome icon.. */\ninput[type=date]:after {\n  color: transparent;\n  padding: 0 5px;\n}\n\n/* change color of symbol on hover */\ninput[type=date]:hover:after {\n  color: transparent;\n}\n\n/* make the native arrow invisible and stretch it over the whole field\n so you can click anywhere in the input field to trigger the native datepicker*/\ninput[type=date]::-webkit-calendar-picker-indicator {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  width: auto;\n  height: auto;\n  color: transparent;\n  background: transparent;\n}\n\n/* adjust increase/decrease button */\ninput[type=date]::-webkit-inner-spin-button {\n  z-index: 1;\n}\n\n/* adjust clear button */\ninput[type=date]::-webkit-clear-button {\n  z-index: 1;\n}\n\ninput::-webkit-calendar-picker-indicator {\n  display: block;\n  top: 0;\n  left: 0;\n  background: rgba(0, 0, 0, 0);\n  position: absolute;\n  transform: scale(10);\n}\n\n.input-style.has-borders.input-style-always-active label {\n  margin-left: 10px !important;\n}\n\n.input-style input[type=date] {\n  width: 100%;\n}\n\n.input-style {\n  margin-bottom: 0 !important;\n}\n\n.pos-bottom {\n  position: absolute;\n  bottom: -1.5rem;\n}\n\n@media (max-width: 329px) {\n  .col-6 {\n    width: 100%;\n    margin-bottom: 1rem;\n  }\n  .row {\n    margin-bottom: 2rem;\n  }\n  .pos-bottom {\n    bottom: -3.1rem;\n  }\n}\na.disabled {\n  pointer-events: none;\n  opacity: 0.1;\n}\n\n.custom-position {\n  position: absolute;\n  right: 0;\n  margin-top: 1px;\n}", "",{"version":3,"sources":["webpack://./src/app/invite/components/invitation-date-step/invitation-date.component.scss"],"names":[],"mappings":"AAAA;EACE,kBAAA;AACF;;AAEA;kGAAA;AAEA;EAEE,kBAAA;EACA,cAAA;AAAF;;AAGA,oCAAA;AACA;EACE,kBAAA;AAAF;;AAGA;+EAAA;AAEA;EACE,kBAAA;EACA,MAAA;EACA,OAAA;EACA,QAAA;EACA,SAAA;EACA,WAAA;EACA,YAAA;EACA,kBAAA;EACA,uBAAA;AAAF;;AAGA,oCAAA;AACA;EACE,UAAA;AAAF;;AAGA,wBAAA;AACA;EACE,UAAA;AAAF;;AAGA;EACE,cAAA;EACA,MAAA;EACA,OAAA;EACA,4BAAA;EACA,kBAAA;EACA,oBAAA;AAAF;;AAGA;EACE,4BAAA;AAAF;;AAEA;EACE,WAAA;AACF;;AAEA;EACE,2BAAA;AACF;;AAEA;EACE,kBAAA;EACA,eAAA;AACF;;AAEA;EACE;IACE,WAAA;IACA,mBAAA;EACF;EACA;IACE,mBAAA;EACF;EACA;IACE,eAAA;EACF;AACF;AACA;EACE,oBAAA;EACA,YAAA;AACF;;AAEA;EACE,kBAAA;EACA,QAAA;EACA,eAAA;AACF","sourcesContent":["input[type='date'] {\n  position: relative;\n}\n\n/* create a new arrow, because we are going to mess up the native one\nsee \"List of symbols\" below if you want another, you could also try to add a font-awesome icon.. */\ninput[type='date']:after {\n  // content: '\\25BC';\n  color: transparent;\n  padding: 0 5px;\n}\n\n/* change color of symbol on hover */\ninput[type='date']:hover:after {\n  color: transparent;\n}\n\n/* make the native arrow invisible and stretch it over the whole field\n so you can click anywhere in the input field to trigger the native datepicker*/\ninput[type='date']::-webkit-calendar-picker-indicator {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  width: auto;\n  height: auto;\n  color: transparent;\n  background: transparent;\n}\n\n/* adjust increase/decrease button */\ninput[type='date']::-webkit-inner-spin-button {\n  z-index: 1;\n}\n\n/* adjust clear button */\ninput[type='date']::-webkit-clear-button {\n  z-index: 1;\n}\n\ninput::-webkit-calendar-picker-indicator {\n  display: block;\n  top: 0;\n  left: 0;\n  background: #0000;\n  position: absolute;\n  transform: scale(10);\n}\n\n.input-style.has-borders.input-style-always-active label {\n  margin-left: 10px !important;\n}\n.input-style input[type='date'] {\n  width: 100%;\n}\n\n.input-style {\n  margin-bottom: 0 !important;\n}\n\n.pos-bottom {\n  position: absolute;\n  bottom: -1.5rem;\n}\n\n@media (max-width: 329px) {\n  .col-6 {\n    width: 100%;\n    margin-bottom: 1rem;\n  }\n  .row {\n    margin-bottom: 2rem;\n  }\n  .pos-bottom {\n    bottom: -3.1rem;\n  }\n}\na.disabled {\n  pointer-events: none;\n  opacity: 0.1;\n}\n\n.custom-position {\n  position: absolute;\n  right: 0;\n  margin-top: 1px;\n}\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 57662:
/*!*********************************************************************************************************!*\
  !*** ./src/app/invite/components/invitation-edit-modal/invitation-edit-modal.component.scss?ngResource ***!
  \*********************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 7864:
/*!*********************************************************************************************!*\
  !*** ./src/app/invite/components/invitation-list/invitation-list.component.scss?ngResource ***!
  \*********************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 21461:
/*!*****************************************************************************************************************!*\
  !*** ./src/app/invite/components/new-invitation-place-step/new-invitation-place-step.component.scss?ngResource ***!
  \*****************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".disabled {\n  color: #6c6c6c !important;\n  opacity: 70% !important;\n}\n.disabled select {\n  background-color: inherit !important;\n}", "",{"version":3,"sources":["webpack://./src/app/invite/components/new-invitation-place-step/new-invitation-place-step.component.scss"],"names":[],"mappings":"AAAA;EACE,yBAAA;EACA,uBAAA;AACF;AACE;EACE,oCAAA;AACJ","sourcesContent":[".disabled {\n  color: #6c6c6c !important;\n  opacity: 70% !important;\n\n  select {\n    background-color: inherit !important;\n  }\n}\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 7201:
/*!************************************************************************************************!*\
  !*** ./src/app/invite/components/new-invitation-step/new-invitation.component.scss?ngResource ***!
  \************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 33911:
/*!***********************************************************************************!*\
  !*** ./src/app/invite/pages/invitation-info/invitation-info.page.scss?ngResource ***!
  \***********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "::ng-deep .theme-light #walkthrough-slider .is-active {\n  background: transparent !important;\n}\n\n::ng-deep .theme-dark #walkthrough-slider .is-active {\n  background: transparent !important;\n}", "",{"version":3,"sources":["webpack://./src/app/invite/pages/invitation-info/invitation-info.page.scss"],"names":[],"mappings":"AAAA;EACE,kCAAA;AACF;;AACA;EACE,kCAAA;AAEF","sourcesContent":["::ng-deep .theme-light #walkthrough-slider .is-active {\n  background: transparent !important;\n}\n::ng-deep .theme-dark #walkthrough-slider .is-active {\n  background: transparent !important;\n}\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 9798:
/*!***************************************************************************************!*\
  !*** ./src/app/invite/pages/invitation-wizard/invitation-wizard.page.scss?ngResource ***!
  \***************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 6005:
/*!***************************************************************************!*\
  !*** ./src/app/invite/pages/invitations/invitations.page.scss?ngResource ***!
  \***************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 46576:
/*!**************************************************************************************************!*\
  !*** ./src/app/invite/components/invitation-date-step/invitation-date.component.html?ngResource ***!
  \**************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"content mt-0 mx-0\" *ngIf=\"accessPointForm\">\r\n  <form [formGroup]=\"accessPointForm\">\r\n    <div class=\"accordion mt-4\" id=\"accordion-2\">\r\n      <div class=\"card card-style shadow-0 m-0 bg-highlight mb-1\">\r\n        <button\r\n          (click)=\"open[0] = !open[0]\"\r\n          class=\"btn accordion-btn color-white no-effect\"\r\n          data-bs-toggle=\"collapse\"\r\n          data-bs-target=\"#recurrency\"\r\n          aria-expanded=\"true\">\r\n          <span *ngIf=\"accessPointForm.get('isUnique')?.value === ''\">{{ 'invite.eventTypeTitle' | translate }}</span>\r\n          <span *ngIf=\"accessPointForm.get('isUnique')?.value !== ''\"> {{ getRecurrency() }} </span>\r\n          <fa-icon class=\"font-10 float-end\" [icon]=\"['fas', open[0] ? 'chevron-up' : 'chevron-down']\"></fa-icon>\r\n        </button>\r\n\r\n        <div id=\"recurrency\" #recurrency class=\"bg-theme\" data-bs-parent=\"#accordion-2\">\r\n          <div class=\"p-3 row mb-0 justify-content-around\">\r\n            <div class=\"d-flex\">\r\n              <div class=\"pt-1 align-self-center\">\r\n                <label class=\"color-theme text-uppercase font-400 font-10\">{{\r\n                  'invite.uniqueLabel' | translate\r\n                }}</label>\r\n              </div>\r\n              <div class=\"ms-auto me-3 align-self-center pe-2\">\r\n                <app-toggle-switch [control]=\"$any(accessPointForm).controls['isUnique']\"></app-toggle-switch>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"card card-style shadow-0 bg-highlight m-0 mb-1\">\r\n        <button\r\n          (click)=\"open[1] = !open[1]\"\r\n          [class.disabled]=\"stepDisabled(2)\"\r\n          class=\"btn accordion-btn color-white no-effect\"\r\n          data-bs-toggle=\"collapse\"\r\n          data-bs-target=\"#date\"\r\n          aria-expanded=\"false\">\r\n          <span\r\n            *ngIf=\"\r\n              (accessPointForm.get('dateFrom')?.value === '' || accessPointForm.get('dateFrom')?.value === null) &&\r\n              (accessPointForm.get('dateTo')?.value === '' || accessPointForm.get('dateTo')?.value === null)\r\n            \">\r\n            {{ 'invite.dateTitle' | translate }}\r\n          </span>\r\n          <span\r\n            *ngIf=\"accessPointForm.get('dateFrom')?.value !== '' && accessPointForm.get('dateFrom')?.value !== null\">\r\n            {{ 'invite.dateTitle' | translate }}:\r\n          </span>\r\n          <span\r\n            *ngIf=\"accessPointForm.get('dateFrom')?.value !== '' && accessPointForm.get('dateFrom')?.value !== null\">\r\n            {{ formatDate(accessPointForm.get('dateFrom')?.value) }}\r\n          </span>\r\n          <span\r\n            *ngIf=\"\r\n              accessPointForm.get('noEnd')?.value === false &&\r\n              accessPointForm.get('dateTo')?.value !== '' &&\r\n              accessPointForm.get('dateTo')?.value !== null\r\n            \">\r\n            - {{ formatDate(accessPointForm.get('dateTo')?.value) }}\r\n          </span>\r\n          <fa-icon class=\"font-10 float-end\" [icon]=\"['fas', open[1] ? 'chevron-up' : 'chevron-down']\"></fa-icon>\r\n        </button>\r\n        <div id=\"date\" #date class=\"bg-theme collapse\" data-bs-parent=\"#accordion-2\">\r\n          <div class=\"p-3 row mb-0\">\r\n            <div class=\"input-date-time\">\r\n              <input\r\n                type=\"date\"\r\n                class=\"form-control\"\r\n                formControlName=\"dateFrom\"\r\n                [min]=\"today\"\r\n                placeholder=\"DD/MM/AAAA\" />\r\n              <label class=\"color-theme text-uppercase font-400 font-10 custom-label-margin align-self-center\">\r\n                {{\r\n                  accessPointForm.get('isUnique')?.value === true\r\n                    ? ('invite.dateFromInput' | translate)\r\n                    : ('invite.dateInput' | translate)\r\n                }}\r\n              </label>\r\n            </div>\r\n            <ng-container *ngIf=\"!isDayContained('dateFrom')\">\r\n              <span class=\"color-red-light\">{{ 'invite.outOfDoorDaysLabel' | translate }}</span>\r\n            </ng-container>\r\n\r\n            <!-- ES REPETITIVO -->\r\n            <ng-container *ngIf=\"accessPointForm.get('isUnique')?.value === false\">\r\n              <div class=\"mt-2 mb-3\">\r\n                <div class=\"d-flex\">\r\n                  <div class=\"pt-1 align-self-center\">\r\n                    <label class=\"color-theme text-uppercase font-400 font-10\">{{\r\n                      'invite.noEndLabel' | translate\r\n                    }}</label>\r\n                  </div>\r\n                  <div class=\"ms-auto me-3 align-self-center pe-2\">\r\n                    <app-toggle-switch [control]=\"$any(accessPointForm).controls['noEnd']\"></app-toggle-switch>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n              <div class=\"input-date-time pb-2\" *ngIf=\"accessPointForm.get('noEnd')?.value === false\">\r\n                <input\r\n                  type=\"date\"\r\n                  class=\"form-control\"\r\n                  formControlName=\"dateTo\"\r\n                  [min]=\"today\"\r\n                  placeholder=\"DD/MM/AAAA\" />\r\n                <label class=\"color-theme text-uppercase font-400 font-10 custom-label-margin align-self-center\">{{\r\n                  'invite.dateToInput' | translate\r\n                }}</label>\r\n              </div>\r\n              <ng-container *ngIf=\"!isDayContained('dateTo')\">\r\n                <span class=\"color-red-light\">{{ 'invite.outOfDoorDaysLabel' | translate }}</span>\r\n              </ng-container>\r\n              <app-day-select-form [wizard]=\"'inv'\" [selectedDoor]=\"selectedDoor\"></app-day-select-form>\r\n            </ng-container>\r\n            <div class=\"pt-3\">\r\n              <span class=\"color-highlight d-block lh-sm\">{{ getAccessPointRecurrence() }}</span>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"card card-style shadow-0 m-0 bg-highlight\">\r\n        <button\r\n          (click)=\"open[2] = !open[2]\"\r\n          [class.disabled]=\"stepDisabled(3)\"\r\n          class=\"btn accordion-btn color-white no-effect\"\r\n          data-bs-toggle=\"collapse\"\r\n          data-bs-target=\"#time\"\r\n          aria-expanded=\"false\">\r\n          <span\r\n            *ngIf=\"\r\n              !accessPointForm.get('allDay')?.value &&\r\n              (accessPointForm.get('timeTo')?.value === '' || accessPointForm.get('timeFrom')?.value === '')\r\n            \"\r\n            >{{ 'invite.timeTitle' | translate }}</span\r\n          >\r\n          <span *ngIf=\"accessPointForm.get('allDay')?.value\"> {{ 'invite.allDayLabel' | translate }}</span>\r\n          <ng-container *ngIf=\"!accessPointForm.get('allDay')?.value\">\r\n            <span *ngIf=\"accessPointForm.get('timeFrom')?.value !== '' || accessPointForm.get('timeTo')?.value !== ''\"\r\n              >{{ 'invite.timeTitle' | translate }} :</span\r\n            >\r\n            <span *ngIf=\"accessPointForm.get('timeFrom')?.value !== ''\">\r\n              {{ accessPointForm.get('timeFrom')?.value }}</span\r\n            >\r\n            <span *ngIf=\"accessPointForm.get('timeTo')?.value !== ''\">\r\n              {{ 'recurence.to' | translate }} {{ accessPointForm.get('timeTo')?.value }}\r\n            </span>\r\n          </ng-container>\r\n          <fa-icon class=\"font-10 float-end\" [icon]=\"['fas', open[2] ? 'chevron-up' : 'chevron-down']\"></fa-icon>\r\n        </button>\r\n        <div id=\"time\" #time class=\"bg-theme collapse\" data-bs-parent=\"#accordion-2\">\r\n          <div class=\"row mb-0 p-3\">\r\n            <div class=\"col-12\">\r\n              <div class=\"mt-2 mb-3\">\r\n                <div class=\"d-flex\">\r\n                  <div class=\"pt-1 align-self-center\">\r\n                    <label class=\"color-theme text-uppercase font-400 font-10\">{{\r\n                      'invite.allDayLabel' | translate\r\n                    }}</label>\r\n                  </div>\r\n                  <div class=\"ms-auto me-3 align-self-center pe-2\">\r\n                    <app-toggle-switch [control]=\"$any(accessPointForm).controls['allDay']\"></app-toggle-switch>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n            <ng-container *ngIf=\"accessPointForm.get('allDay')?.value === false\">\r\n              <div class=\"col-6\">\r\n                <div class=\"input-date-time\">\r\n                  <input type=\"time\" class=\"form-control\" formControlName=\"timeFrom\" />\r\n                  <label class=\"color-theme text-uppercase font-400 font-10 custom-label-margin\">{{\r\n                    'sites.timeFromInput' | translate\r\n                  }}</label>\r\n                  <em *ngIf=\"!accessPointForm.get('timeFrom')?.value\" class=\"color-highlight opacity-75\">{{\r\n                    'common.required' | translate\r\n                  }}</em>\r\n                </div>\r\n              </div>\r\n              <div class=\"col-6\">\r\n                <div class=\"input-date-time\">\r\n                  <input type=\"time\" class=\"form-control\" formControlName=\"timeTo\" />\r\n                  <label class=\"color-theme text-uppercase font-400 font-10 custom-label-margin\">{{\r\n                    'sites.timeToInput' | translate\r\n                  }}</label>\r\n                  <em *ngIf=\"!accessPointForm.get('timeTo')?.value\" class=\"color-highlight opacity-75\">{{\r\n                    'common.required' | translate\r\n                  }}</em>\r\n                </div>\r\n              </div>\r\n              <span class=\"color-red-light\" *ngIf=\"timeFromInvalid || timeToInvalid\">{{\r\n                'invite.nextDayLabel' | translate\r\n              }}</span>\r\n            </ng-container>\r\n            <span class=\"color-red-light\" *ngIf=\"outOfDoorTime\">{{ 'invite.outOfDoorTimeLabel' | translate }}</span>\r\n            <div class=\"pt-3\">\r\n              <span class=\"color-highlight d-block lh-sm\">{{ getAccessPointSchedule() }}</span>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </form>\r\n</div>\r\n";

/***/ }),

/***/ 99238:
/*!*********************************************************************************************************!*\
  !*** ./src/app/invite/components/invitation-edit-modal/invitation-edit-modal.component.html?ngResource ***!
  \*********************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-modal-menu #modal [height]=\"'h-75'\">\n  <ng-template #modalContent>\n    <a role=\"button\" (click)=\"close()\" class=\"font-16 w-fit color-red-dark float-right position-relative\">\n      <fa-icon [icon]=\"['fas', 'times']\"></fa-icon\n    ></a>\n    <div class=\"content mb-5 pt-1\">\n      <app-new-invitation\n        [isEdit]=\"true\"\n        [categoryList]=\"categoryList\"\n        [hidden]=\"currentStep !== 1\"></app-new-invitation>\n      <app-new-invitation-place [hidden]=\"currentStep !== 2\"></app-new-invitation-place>\n      <app-invitation-date [selectedDoor]=\"selectedDoor\" [hidden]=\"currentStep !== 3\"></app-invitation-date>\n      <div class=\"pb-3 pt-3\">\n        <ng-container *ngIf=\"!showKeyboard\">\n          <app-button\n            [status]=\"buttonState\"\n            [label]=\"'common.save' | translate\"\n            (onHide)=\"hide()\"\n            (buttonClick)=\"save()\"></app-button>\n        </ng-container>\n      </div>\n    </div>\n  </ng-template>\n</app-modal-menu>\n<app-modal-menu #confirmModal>\n  <ng-template #modalContent>\n    <div class=\"center w-100 p-3\">\n      <h6 class=\"font-400 font-14 pb-3 text-center\">{{ labelModal | translate }}</h6>\n      <app-button\n        class=\"w-fit\"\n        [label]=\"'common.accept' | translate\"\n        (buttonClick)=\"confirm(); confirmModal.hide()\"></app-button>\n      <div class=\"pt-2\"></div>\n      <app-button\n        class=\"w-fit\"\n        [bgClass]=\"'bg-transparent'\"\n        [customClass]=\"'w-100 border-highlight color-highlight'\"\n        [label]=\"'common.cancel' | translate\"\n        (buttonClick)=\"confirmModal.hide()\"></app-button>\n    </div>\n  </ng-template>\n</app-modal-menu>\n\n<ng-container *ngIf=\"showKeyboard\">\n  <app-button\n    [status]=\"buttonState\"\n    [label]=\"'common.save' | translate\"\n    [customClass]=\"'w-100 button-onkeyboard'\"\n    (onShow)=\"show()\"\n    (buttonClick)=\"save()\"></app-button>\n</ng-container>\n";

/***/ }),

/***/ 74912:
/*!*********************************************************************************************!*\
  !*** ./src/app/invite/components/invitation-list/invitation-list.component.html?ngResource ***!
  \*********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ng-container *ngIf=\"invitations\">\n  <app-list-item\n    *ngFor=\"let i of invitations; let isLast = last\"\n    [id]=\"i.invitationId\"\n    [isLast]=\"isLast\"\n    [title]=\"getTitle(i.motive)\"\n    [img]=\"i.presentationImg[0].url\"\n    [topTexts]=\"getTopTexts(i)\"\n    (clicked)=\"accessClick($event)\"\n    [bottomButtonIcon]=\"['fas', 'users']\"\n    [bottomButtonText]=\"'INVITADOS'\"\n    (bottomButtonClick)=\"invClick.emit(i.invitationId)\">\n  </app-list-item>\n</ng-container>\n<ng-container *ngIf=\"!invitations\">\n  <app-list-item-skeleton *ngFor=\"let item of [1, 2, 3]\"></app-list-item-skeleton>\n</ng-container>\n";

/***/ }),

/***/ 23762:
/*!*****************************************************************************************************************!*\
  !*** ./src/app/invite/components/new-invitation-place-step/new-invitation-place-step.component.html?ngResource ***!
  \*****************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"content mb-6 mt-0 mx-0\">\n  <div *ngIf=\"invitationForm\">\n    <form [formGroup]=\"invitationForm\">\n      <h6 class=\"font-400 font-16 pb-3\">{{ 'invite.location' | translate }}</h6>\n      <div\n        class=\"input-style input-style-always-active has-borders no-icon validate-field\"\n        [class.disabled]=\"onlyOneWay\">\n        <select class=\"form-control\" formControlName=\"place\" enterkeyhint=\"done\">\n          <option *ngFor=\"let ap of vm?.accessPoints\" [value]=\"ap.access.id\">{{ ap.access.name }}</option>\n        </select>\n        <label class=\"color-theme text-uppercase font-400 font-10\">{{ 'invite.whereText' | translate }}</label>\n        <em class=\"color-highlight opacity-75\">{{ 'common.required' | translate }}</em>\n      </div>\n      <app-map-info\n        *ngIf=\"selectedPlace !== undefined\"\n        [disable]=\"onlyOneWay\"\n        [address]=\"selectedPlace.address\"\n        [latitude]=\"selectedPlace.latitude\"\n        [longitude]=\"selectedPlace.longitude\"\n        [imgSrc]=\"selectedPlace.mapImage.url\"></app-map-info>\n\n      <!-- <h6 *ngIf=\"selectedPlaceDoors !== undefined && selectedPlaceDoors.length === 1\">\n        {{ 'ingreso por ' + selectedPlaceDoors[0].access.name }}\n      </h6> -->\n    </form>\n  </div>\n  <app-door-select-form\n    *ngIf=\"selectedPlaceDoors !== undefined && selectedPlaceDoors.length > 0\"\n    [accessPoints]=\"this.selectedPlaceDoors\"\n    [disable]=\"selectedPlaceDoors.length === 1\"></app-door-select-form>\n</div>\n";

/***/ }),

/***/ 87212:
/*!************************************************************************************************!*\
  !*** ./src/app/invite/components/new-invitation-step/new-invitation.component.html?ngResource ***!
  \************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"content mb-6 mt-0 mx-0\">\n  <form [formGroup]=\"invitationForm\" enterFocus>\n    <h6 class=\"font-400 font-16 pb-3\">{{ 'invite.newInvitationTitle' | translate }}</h6>\n\n    <div class=\"input-style input-style-always-active has-borders no-icon validate-field\" #nextTab>\n      <input\n        type=\"name\"\n        class=\"form-control validate-text\"\n        formControlName=\"place\"\n        enterkeyhint=\"next\"\n        [readonly]=\"isEdit\" />\n      <label class=\"color-theme text-uppercase font-400 font-10\">{{ 'invite.placeInput' | translate }}</label>\n      <em *ngIf=\"!isEdit\" class=\"color-highlight opacity-75\">{{ 'common.required' | translate }}</em>\n    </div>\n    <div class=\"input-style input-style-always-active has-borders no-icon validate-field\" #nextTab>\n      <input type=\"name\" class=\"form-control validate-text\" formControlName=\"title\" enterkeyhint=\"next\" />\n      <label class=\"color-theme text-uppercase font-400 font-10\">{{ 'invite.titleInput' | translate }}</label>\n      <em class=\"color-highlight opacity-75\">{{ 'common.required' | translate }}</em>\n    </div>\n    <div class=\"input-style input-style-always-active has-borders no-icon validate-field mt-3\" #nextTab>\n      <select class=\"form-control\" formControlName=\"category\" enterkeyhint=\"next\">\n        <option *ngFor=\"let c of categoryList\" [value]=\"c.id\">{{ c.name }}</option>\n      </select>\n      <label class=\"color-theme text-uppercase font-400 font-10\">{{ 'common.categoryInput' | translate }}</label>\n      <em class=\"color-highlight opacity-75\">{{ 'common.required' | translate }}</em>\n    </div>\n    <div class=\"input-style input-style-always-active has-borders no-icon mt-3\" #nextTab>\n      <textarea class=\"form-control validate-text h-150\" formControlName=\"description\" rows=\"5\"></textarea>\n      <label class=\"color-theme text-uppercase font-400 font-10\">{{ 'common.descriptionInput' | translate }}</label>\n      <em class=\"color-highlight opacity-75\">{{ 'common.optional' | translate }}</em>\n    </div>\n    <app-img-preview [images]=\"images\" [deleteImages]=\"deleteImages\"></app-img-preview>\n  </form>\n</div>\n";

/***/ }),

/***/ 17493:
/*!***********************************************************************************!*\
  !*** ./src/app/invite/pages/invitation-info/invitation-info.page.html?ngResource ***!
  \***********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-page-layout [footerSelectedOption]=\"footerOptions.sites\" (back)=\"back.emit()\" [title]=\"invitation?.motive\">\n  <div class=\"card card-style\">\n    <app-carrousel [hidePagination]=\"true\" [(currentStep)]=\"currentStep\" *ngIf=\"invitation\">\n      <ng-template style=\"width: 100%\" #slide *ngFor=\"let img of invitation?.presentationImg\">\n        <div class=\"vh-30\">\n          <app-category-badge\n            class=\"card-top p-3\"\n            *ngIf=\"invitation.category\"\n            [category]=\"invitation.category\"></app-category-badge>\n          <div class=\"card-overlay img-gradient\"></div>\n          <app-img [img]=\"img.url\" [imgClass]=\"'rounded-sm'\"></app-img>\n        </div>\n      </ng-template>\n    </app-carrousel>\n    <ng-container *ngIf=\"!invitation\">\n      <div class=\"vh-30\">\n        <ngx-skeleton-loader\n          [theme]=\"{\n              border: '1px solid white',\n              height: '100%',\n              width: '100%',\n              'margin-bottom': '0px'\n            }\">\n        </ngx-skeleton-loader>\n      </div>\n    </ng-container>\n    <div class=\"d-flex content justify-content-between\">\n      <div class=\"w-35 border-right pe-3 border-red-dark\">\n        <app-avatar [img]=\"ownerImg\" [defaultImg]=\"!hasPicture\" [width]=\"80\" [height]=\"80\"></app-avatar>\n        <h6 class=\"font-13 font-400 mt-2 text-center\">{{invitation?.ownerName}}</h6>\n        <p class=\"color-highlight mt-n2 font-9 font-400 text-center\">{{'access.hostLabel'|translate}}</p>\n      </div>\n      <div class=\"w-fill ps-3\">\n        <p class=\"font-13 m-0 float-left\">{{invitationDescription}}</p>\n      </div>\n      <div class=\"icon-button align-self-center float-right\" *ngIf=\"isAdmin || isOwnerCreated\">\n        <a\n          class=\"d-flex\"\n          style=\"flex-flow: column; padding-top: 0px\"\n          role=\"button\"\n          (click)=\"descriptionEditClick.emit()\">\n          <fa-icon [icon]=\"['fas', 'pencil']\"></fa-icon>\n          <span class=\"font-10\">Editar</span>\n        </a>\n      </div>\n    </div>\n  </div>\n\n  <div *ngIf=\"(isAdmin || isOwner)\" class=\"card card-style\">\n    <div class=\"content\">\n      <app-button-panel *ngIf=\"buttonsConfig\" [config]=\"buttonsConfig\" [customClass]=\"stylePanel\"></app-button-panel>\n    </div>\n  </div>\n  <ng-container *ngIf=\"!invitation\">\n    <div class=\"card card-style\">\n      <div class=\"content mb-0 w-75 align-self-center\">\n        <ngx-skeleton-loader\n          [theme]=\"{\n            border: '1px solid white',\n            height: '50px',\n            width: '100%',\n            'margin-bottom': '0px'\n          }\"></ngx-skeleton-loader>\n      </div>\n    </div>\n  </ng-container>\n  <div class=\"card card-style\" *ngIf=\"invitation\">\n    <div class=\"content ms-0 d-flex justify-content-between\" [ngClass]=\"cardStyle\">\n      <div>\n        <app-info-section\n          [titles]=\"getTitle()\"\n          [subText]=\"getSubtitle()\"\n          [leftIcon]=\"['far', 'calendar']\"\n          [badgeTextClass]=\"'square bg-blue font-400'\"\n          [badgeText]=\"'access.assistInfoLabel'|translate\"></app-info-section>\n      </div>\n\n      <div *ngIf=\"isAdmin || isOwner\" class=\"float-right\" style=\"margin-bottom: 1rem\" (click)=\"accessEditClick.emit()\">\n        <div class=\"icon-button color-highlight\">\n          <a role=\"button\">\n            <fa-icon [icon]=\"['fas', 'pencil']\"></fa-icon>\n            <span>Editar</span>\n          </a>\n        </div>\n      </div>\n      <div *ngIf=\"isGuest\" style=\"text-align: end\">\n        <div class=\"ms-auto me-3 align-self-center pe-2\">\n          <app-toggle-switch [control]=\"assistSwitchControl\" (switchClick)=\"tryUnassist()\"></app-toggle-switch>\n        </div>\n        <label class=\"color-highlight text-uppercase font-10\">{{'onboarding.confirmAssist'|translate}}</label>\n      </div>\n    </div>\n  </div>\n\n  <div class=\"card card-style\" *ngIf=\"!invitation\">\n    <div class=\"content mb-0 d-flex justify-content-between\">\n      <app-info-section-skeleton></app-info-section-skeleton>\n    </div>\n  </div>\n  <div class=\"card card-style\" *ngIf=\"invitation\">\n    <div class=\"content mb-0 ms-0 d-flex justify-content-between\">\n      <div>\n        <app-info-section\n          [titles]=\"[invitation.location]\"\n          [subText]=\"invitation.place\"\n          [leftIcon]=\"locationClass\"\n          [badgeTextClass]=\"'square bg-blue font-400'\"\n          [badgeText]=\"'access.siteInfoLabel'|translate\"></app-info-section>\n      </div>\n\n      <div\n        *ngIf=\"isAdmin || isOwner\"\n        class=\"float-right\"\n        (click)=\"locationEditClick.emit()\"\n        style=\"margin-bottom: 1rem\">\n        <div class=\"icon-button color-highlight\">\n          <a role=\"button\">\n            <fa-icon [icon]=\"['fas', 'pencil']\"></fa-icon>\n            <span>Editar</span>\n          </a>\n        </div>\n      </div>\n      <div *ngIf=\"isGuest\">\n        <div class=\"ms-auto align-self-center px-2\">\n          <fa-icon\n            role=\"button\"\n            [icon]=\"['fas', 'chevron-right']\"\n            [size]=\"'xl'\"\n            class=\"color-theme opacity-75\"></fa-icon>\n        </div>\n      </div>\n    </div>\n  </div>\n  <div class=\"card card-style\" *ngIf=\"!invitation\">\n    <div class=\"content mb-0 d-flex justify-content-between\">\n      <app-info-section-skeleton></app-info-section-skeleton>\n    </div>\n  </div>\n</app-page-layout>\n\n<app-modal-menu id=\"confirmModal\" #confirmModal [height]=\"'h-25'\" [static]=\"true\">\n  <ng-template #modalContent>\n    <div class=\"center w-100 p-3\">\n      <h6 class=\"font-400 font-16 pb-3 lh-sm\">{{ 'access.confirmRefuseAssist' | translate }}</h6>\n      <app-button [label]=\"'common.confirm' | translate\" (buttonClick)=\"confirm()\"></app-button>\n      <div class=\"pt-2\"></div>\n      <app-button\n        [bgClass]=\"'bg-transparent'\"\n        [customClass]=\"'w-100 border-highlight color-highlight'\"\n        [label]=\"'common.cancel' | translate\"\n        (buttonClick)=\"cancel()\"></app-button>\n    </div>\n  </ng-template>\n</app-modal-menu>\n";

/***/ }),

/***/ 76319:
/*!***************************************************************************************!*\
  !*** ./src/app/invite/pages/invitation-wizard/invitation-wizard.page.html?ngResource ***!
  \***************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-page-layout\n  [footerSelectedOption]=\"footerOptions.sites\"\n  [title]=\"wizardTitle\"\n  (back)=\"backStep()\"\n  [hideFooter]=\"true\">\n  <app-wizard-steps [steps]=\"steps\" [currentStep]=\"currentStep\" (stepClick)=\"backStep($event)\"></app-wizard-steps>\n\n  <div class=\"card card-style min-vh-70\">\n    <div class=\"content mb-5\" [@animSlider]=\"currentStep\">\n      <!-- ACA VAN LOS PASOS - STEPS HERE -->\n      <app-new-invitation\n        [categoryList]=\"categoryList\"\n        [siteList]=\"siteList\"\n        [hidden]=\"currentStep !== 1\"></app-new-invitation>\n      <app-new-invitation-place [hidden]=\"currentStep !== 2\"></app-new-invitation-place>\n      <app-invitation-date [selectedDoor]=\"selectedDoor\" [hidden]=\"currentStep !== 3\"></app-invitation-date>\n\n      <div class=\"card-bottom pb-3 px-3\">\n        <ng-container *ngIf=\"!showKeyboard\">\n          <app-button\n            [status]=\"buttonState\"\n            (buttonClick)=\"nextStep()\"\n            (onHide)=\"hide()\"\n            [label]=\"currentStep !== steps.length ? ('common.nextStep' | translate) : ('common.save' | translate)\"></app-button>\n        </ng-container>\n      </div>\n    </div>\n  </div>\n  <ng-container *ngIf=\"showKeyboard\">\n    <app-button\n      [status]=\"buttonState\"\n      [customClass]=\"'w-100 button-onkeyboard'\"\n      (buttonClick)=\"nextStep()\"\n      (onShow)=\"show()\"\n      [label]=\"currentStep !== steps.length ? ('common.nextStep' | translate) : ('common.save' | translate)\"></app-button>\n  </ng-container>\n</app-page-layout>\n";

/***/ }),

/***/ 94211:
/*!***************************************************************************!*\
  !*** ./src/app/invite/pages/invitations/invitations.page.html?ngResource ***!
  \***************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-page-layout [footerSelectedOption]=\"footerOptions.sites\" (back)=\"back.emit()\" [title]=\"siteName\">\n  <app-searchbox [placeholder]=\"'common.searchdotdotdot'|translate\" (search)=\"search.emit($event)\"></app-searchbox>\n\n  <app-banner\n    *ngIf=\"invitations && invitations.length > 0\"\n    [title]=\"'common.newInvite' | translate\"\n    [descrip]=\"'invite.bannerInvitationSubTitle' | translate: {siteName: siteName}\"\n    [faClass]=\"'star'\"\n    [iconColor]=\"'color-highlight'\"\n    [iconSize]=\"'xl'\"\n    (bannerClick)=\"newInvite.emit()\"></app-banner>\n\n  <div class=\"card card-style\">\n    <div class=\"content\">\n      <ng-container *ngIf=\"invitations && invitations.length > 0\">\n        <h4 class=\"font-400\">{{'common.invitationsTitle'|translate}}</h4>\n\n        <app-invitation-list\n          [invitations]=\"invitations\"\n          (invClick)=\"guestsClick.emit($event)\"\n          (navigateClick)=\"accessClick.emit($event)\"></app-invitation-list>\n      </ng-container>\n      <ng-container *ngIf=\"invitations?.length === 0\">\n        <app-img-title\n          [faClass]=\"['fas','circle-exclamation']\"\n          [title]=\"'invite.noInvitationsTitle'|translate\"\n          [titleClass]=\"'pt-3'\"\n          [subtitle]=\"'access.noAccessSubtitle'|translate\"\n          [subtitleClass]=\"'font-400 font-13 lh-lg text-center pt-2'\"></app-img-title>\n      </ng-container>\n      <ng-container *ngIf=\"!invitations\">\n        <app-list-item-skeleton *ngFor=\"let item of [1, 2, 3]\"></app-list-item-skeleton>\n      </ng-container>\n    </div>\n  </div>\n  <!-- <div class=\"card card-style p-4\">\n    \n  </div> -->\n  <app-banner\n    *ngIf=\"invitations?.length === 0\"\n    [title]=\"'invite.bannerNoInvitationTitle'|translate\"\n    [descrip]=\"'invite.bannerNoInvitationDesc'|translate\"\n    [faClass]=\"'star'\"\n    [iconColor]=\"'color-highlight'\"\n    [iconSize]=\"'xl'\"\n    (bannerClick)=\"newInvite.emit()\"></app-banner>\n</app-page-layout>\n";

/***/ })

}]);
//# sourceMappingURL=default-src_app_invite_invite_module_ts.js.map