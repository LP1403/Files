(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_shared_pages_pricing_pricing_module_ts"],{

/***/ 21485:
/*!****************************************************************!*\
  !*** ./src/app/shared/pages/pricing/pricing-routing.module.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PricingPageRoutingModule": () => (/* binding */ PricingPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _pricing_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pricing.page */ 8589);




const routes = [{
  path: '',
  component: _pricing_page__WEBPACK_IMPORTED_MODULE_0__.PricingPage
}];
let PricingPageRoutingModule = class PricingPageRoutingModule {};
PricingPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
  imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
  exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
})], PricingPageRoutingModule);


/***/ }),

/***/ 89177:
/*!********************************************************!*\
  !*** ./src/app/shared/pages/pricing/pricing.module.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PricingPageModule": () => (/* binding */ PricingPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 89650);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _pricing_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pricing-routing.module */ 21485);
/* harmony import */ var _pricing_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pricing.page */ 8589);
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/shared.module */ 56208);








let PricingPageModule = class PricingPageModule {};
PricingPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule, _pricing_routing_module__WEBPACK_IMPORTED_MODULE_0__.PricingPageRoutingModule, src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule],
  declarations: [_pricing_page__WEBPACK_IMPORTED_MODULE_1__.PricingPage]
})], PricingPageModule);


/***/ }),

/***/ 8589:
/*!******************************************************!*\
  !*** ./src/app/shared/pages/pricing/pricing.page.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Plan": () => (/* binding */ Plan),
/* harmony export */   "PricingPage": () => (/* binding */ PricingPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _pricing_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pricing.page.html?ngResource */ 73480);
/* harmony import */ var _pricing_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pricing.page.scss?ngResource */ 13728);
/* harmony import */ var _pricing_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pricing_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../components/footer/footer.component */ 68014);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _pricing_plans_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pricing-plans.json */ 67597);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var _components_modal_menu_modal_menu_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/modal-menu/modal-menu.component */ 77098);

var _class;









let PricingPage = (_class = class PricingPage {
  constructor(navController, translate) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "modalMenu", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "footerOptions", _components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__.FooterSelectedOption);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "plans", []);
    this.navController = navController;
    this.translate = translate;
    console.log(this.plans);
    this.plans.push(_pricing_plans_json__WEBPACK_IMPORTED_MODULE_4__.plans.free);
    this.plans.push(_pricing_plans_json__WEBPACK_IMPORTED_MODULE_4__.plans.pro);
    this.plans.push(_pricing_plans_json__WEBPACK_IMPORTED_MODULE_4__.plans.business);
  }
  back() {
    this.navController.back();
  }
  getTranslation(key) {
    return this.translate.instant('plans.' + key);
  }
  contact() {
    this.modalMenu?.hide();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController
}, {
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslateService
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  modalMenu: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild,
    args: [_components_modal_menu_modal_menu_component__WEBPACK_IMPORTED_MODULE_5__.ModalMenuComponent]
  }]
}), _class);
PricingPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
  selector: 'app-pricing',
  template: _pricing_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_pricing_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], PricingPage);

class Plan {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "title", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "price", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "expiration", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "maxSites", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "maxDoors", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "maxUsers", void 0);
  }
}

/***/ }),

/***/ 13728:
/*!*******************************************************************!*\
  !*** ./src/app/shared/pages/pricing/pricing.page.scss?ngResource ***!
  \*******************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".btn-disabled {\n  opacity: 0.5;\n  pointer-events: none !important;\n}", "",{"version":3,"sources":["webpack://./src/app/shared/pages/pricing/pricing.page.scss"],"names":[],"mappings":"AAAA;EACE,YAAA;EACA,+BAAA;AACF","sourcesContent":[".btn-disabled {\n  opacity: 0.5;\n  pointer-events: none !important;\n}\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 73480:
/*!*******************************************************************!*\
  !*** ./src/app/shared/pages/pricing/pricing.page.html?ngResource ***!
  \*******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-page-layout [footerSelectedOption]=\"footerOptions.more\" (back)=\"back()\" [title]=\"'plans.pricingTitle' | translate\">\n  <div class=\"pricing-1 rounded-m shadow-s bg-theme\" *ngIf=\"plans\">\n    <h1 class=\"pricing-icon text-center\">\n      <i class=\"pricing-icon fa fa-star color-yellow-light\"></i>\n    </h1>\n    <h1 class=\"pricing-title text-center text-uppercase\">{{getTranslation(plans[0].title)}}</h1>\n    <h2 class=\"pricing-subtitle text-center\">{{getTranslation(plans[0].expiration)}}</h2>\n    <ul class=\"pricing-list text-center\">\n      <li [innerHTML]=\"getTranslation(plans[0].maxSites)\"></li>\n      <li [innerHTML]=\"getTranslation(plans[0].maxDoors)\"></li>\n      <li [innerHTML]=\"getTranslation(plans[0].maxUsers)\"></li>\n    </ul>\n    <h3 class=\"pricing-value text-center color-green-dark mb-5\" [innerHTML]=\"getTranslation(plans[0].price)\"></h3>\n    <a class=\"btn btn-s bg-blue-dark btn-center-l text-uppercase rounded-s font-900 btn-disabled\"\n      >{{'plans.currentButton' | translate}}</a\n    >\n  </div>\n  <div class=\"divider divider-margins\"></div>\n  <div class=\"pricing-4 rounded-m shadow-m bg-theme\">\n    <h1 class=\"pricing-title text-center bg-red-dark text-uppercase\">{{getTranslation(plans[1].title)}}</h1>\n    <h3 class=\"pricing-value text-center bg-red-light color-white\" [innerHTML]=\"getTranslation(plans[1].price)\"></h3>\n    <h2 class=\"pricing-subtitle text-center bg-red-light\">{{getTranslation(plans[1].expiration)}}</h2>\n    <ul class=\"pricing-list text-center\">\n      <li [innerHTML]=\"getTranslation(plans[1].maxSites)\"></li>\n      <li [innerHTML]=\"getTranslation(plans[1].maxDoors)\"></li>\n      <li [innerHTML]=\"getTranslation(plans[1].maxUsers)\"></li>\n    </ul>\n    <a class=\"btn btn-s bg-red-dark btn-center-l text-uppercase rounded-s font-900 btn-disabled\"\n      >{{'common.comingSoon' | translate}}</a\n    >\n  </div>\n  <div class=\"divider divider-margins\"></div>\n\n  <div class=\"pricing-4 rounded-m shadow-m bg-theme\">\n    <h1 class=\"pricing-title text-center bg-blue-dark text-uppercase\">{{getTranslation(plans[2].title)}}</h1>\n    <h3 class=\"pricing-value text-center bg-blue-light color-white\" [innerHTML]=\"getTranslation(plans[2].price)\"></h3>\n    <h2 class=\"pricing-subtitle text-center bg-blue-light\">{{getTranslation(plans[2].expiration)}}</h2>\n    <ul class=\"pricing-list text-center\">\n      <li [innerHTML]=\"getTranslation(plans[2].maxSites)\"></li>\n      <li [innerHTML]=\"getTranslation(plans[2].maxDoors)\"></li>\n      <li [innerHTML]=\"getTranslation(plans[2].maxUsers)\"></li>\n    </ul>\n    <a (click)=\"contactModal.show()\" class=\"btn btn-s bg-blue-dark btn-center-l text-uppercase rounded-s font-900\"\n      >{{'plans.contactButton' | translate}}</a\n    >\n  </div>\n</app-page-layout>\n\n<app-modal-menu #contactModal>\n  <ng-template #modalContent>\n    <div class=\"center w-100 p-3\">\n      <h6 class=\"font-400 font-16 pb-3 text-center\" [innerHTML]=\"'plans.contactModal' | translate\"></h6>\n      <app-button class=\"w-fit\" [label]=\"'common.close' | translate\" (buttonClick)=\"contact()\"></app-button>\n    </div>\n  </ng-template>\n</app-modal-menu>\n";

/***/ }),

/***/ 67597:
/*!*********************************************************!*\
  !*** ./src/app/shared/pages/pricing/pricing-plans.json ***!
  \*********************************************************/
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"plans":{"free":{"title":"plan1Title","expiration":"plan1Expiration","price":"plan1Price","maxSites":"plan1Sites","maxDoors":"plan1Doors","maxUsers":"plan1Users"},"pro":{"title":"plan2Title","expiration":"plan2Expiration","price":"plan2Price","maxSites":"plan2Sites","maxDoors":"plan2Doors","maxUsers":"plan2Users"},"business":{"title":"plan3Title","expiration":"plan3Expiration","price":"plan3Price","maxSites":"plan3Sites","maxDoors":"plan3Doors","maxUsers":"plan3Users"}}}');

/***/ })

}]);
//# sourceMappingURL=src_app_shared_pages_pricing_pricing_module_ts.js.map