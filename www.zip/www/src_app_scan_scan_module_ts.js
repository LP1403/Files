(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_scan_scan_module_ts"],{

/***/ 66795:
/*!***********************************************************************************!*\
  !*** ./node_modules/@capacitor-community/barcode-scanner/dist/esm/definitions.js ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CameraDirection": () => (/* binding */ CameraDirection),
/* harmony export */   "SupportedFormat": () => (/* binding */ SupportedFormat)
/* harmony export */ });
const _SupportedFormat = {
  // BEGIN 1D Product
  /**
   * Android only, UPC_A is part of EAN_13 according to Apple docs
   */
  UPC_A: 'UPC_A',
  UPC_E: 'UPC_E',
  /**
   * Android only
   */
  UPC_EAN_EXTENSION: 'UPC_EAN_EXTENSION',
  EAN_8: 'EAN_8',
  EAN_13: 'EAN_13',
  // END 1D Product
  // BEGIN 1D Industrial
  CODE_39: 'CODE_39',
  /**
   * iOS only
   */
  CODE_39_MOD_43: 'CODE_39_MOD_43',
  CODE_93: 'CODE_93',
  CODE_128: 'CODE_128',
  /**
   * Android only
   */
  CODABAR: 'CODABAR',
  ITF: 'ITF',
  /**
   * iOS only
   */
  ITF_14: 'ITF_14',
  // END 1D Industrial
  // BEGIN 2D
  AZTEC: 'AZTEC',
  DATA_MATRIX: 'DATA_MATRIX',
  /**
   * Android only
   */
  MAXICODE: 'MAXICODE',
  PDF_417: 'PDF_417',
  QR_CODE: 'QR_CODE',
  /**
   * Android only
   */
  RSS_14: 'RSS_14',
  /**
   * Android only
   */
  RSS_EXPANDED: 'RSS_EXPANDED'
  // END 2D
};

const SupportedFormat = _SupportedFormat;
const CameraDirection = {
  FRONT: 'front',
  BACK: 'back'
};

/***/ }),

/***/ 58765:
/*!*****************************************************************************!*\
  !*** ./node_modules/@capacitor-community/barcode-scanner/dist/esm/index.js ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BarcodeScanner": () => (/* binding */ BarcodeScanner),
/* harmony export */   "CameraDirection": () => (/* reexport safe */ _definitions__WEBPACK_IMPORTED_MODULE_1__.CameraDirection),
/* harmony export */   "SupportedFormat": () => (/* reexport safe */ _definitions__WEBPACK_IMPORTED_MODULE_1__.SupportedFormat)
/* harmony export */ });
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 39734);
/* harmony import */ var _definitions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./definitions */ 66795);

const BarcodeScanner = (0,_capacitor_core__WEBPACK_IMPORTED_MODULE_0__.registerPlugin)('BarcodeScanner', {
  web: () => __webpack_require__.e(/*! import() */ "node_modules_capacitor-community_barcode-scanner_dist_esm_web_js").then(__webpack_require__.bind(__webpack_require__, /*! ./web */ 46364)).then(m => new m.BarcodeScannerWeb())
});



/***/ }),

/***/ 58588:
/*!****************************************************************!*\
  !*** ./node_modules/@capacitor/camera/dist/esm/definitions.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CameraDirection": () => (/* binding */ CameraDirection),
/* harmony export */   "CameraResultType": () => (/* binding */ CameraResultType),
/* harmony export */   "CameraSource": () => (/* binding */ CameraSource)
/* harmony export */ });
var CameraSource;
(function (CameraSource) {
  /**
   * Prompts the user to select either the photo album or take a photo.
   */
  CameraSource["Prompt"] = "PROMPT";
  /**
   * Take a new photo using the camera.
   */
  CameraSource["Camera"] = "CAMERA";
  /**
   * Pick an existing photo from the gallery or photo album.
   */
  CameraSource["Photos"] = "PHOTOS";
})(CameraSource || (CameraSource = {}));
var CameraDirection;
(function (CameraDirection) {
  CameraDirection["Rear"] = "REAR";
  CameraDirection["Front"] = "FRONT";
})(CameraDirection || (CameraDirection = {}));
var CameraResultType;
(function (CameraResultType) {
  CameraResultType["Uri"] = "uri";
  CameraResultType["Base64"] = "base64";
  CameraResultType["DataUrl"] = "dataUrl";
})(CameraResultType || (CameraResultType = {}));

/***/ }),

/***/ 12534:
/*!**********************************************************!*\
  !*** ./node_modules/@capacitor/camera/dist/esm/index.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Camera": () => (/* binding */ Camera),
/* harmony export */   "CameraDirection": () => (/* reexport safe */ _definitions__WEBPACK_IMPORTED_MODULE_1__.CameraDirection),
/* harmony export */   "CameraResultType": () => (/* reexport safe */ _definitions__WEBPACK_IMPORTED_MODULE_1__.CameraResultType),
/* harmony export */   "CameraSource": () => (/* reexport safe */ _definitions__WEBPACK_IMPORTED_MODULE_1__.CameraSource)
/* harmony export */ });
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 39734);
/* harmony import */ var _definitions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./definitions */ 58588);

const Camera = (0,_capacitor_core__WEBPACK_IMPORTED_MODULE_0__.registerPlugin)('Camera', {
  web: () => __webpack_require__.e(/*! import() */ "node_modules_capacitor_camera_dist_esm_web_js").then(__webpack_require__.bind(__webpack_require__, /*! ./web */ 69625)).then(m => new m.CameraWeb())
});



/***/ }),

/***/ 35449:
/*!*********************************************************************!*\
  !*** ./node_modules/@capacitor/geolocation/dist/esm/definitions.js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);


/***/ }),

/***/ 97961:
/*!***************************************************************!*\
  !*** ./node_modules/@capacitor/geolocation/dist/esm/index.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Geolocation": () => (/* binding */ Geolocation)
/* harmony export */ });
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 39734);
/* harmony import */ var _definitions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./definitions */ 35449);

const Geolocation = (0,_capacitor_core__WEBPACK_IMPORTED_MODULE_0__.registerPlugin)('Geolocation', {
  web: () => __webpack_require__.e(/*! import() */ "node_modules_capacitor_geolocation_dist_esm_web_js").then(__webpack_require__.bind(__webpack_require__, /*! ./web */ 41566)).then(m => new m.GeolocationWeb())
});



/***/ }),

/***/ 71943:
/*!****************************************************************************!*\
  !*** ./src/app/scan/components/door-selection/door-selection.component.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DoorSelectionComponent": () => (/* binding */ DoorSelectionComponent)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _door_selection_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./door-selection.component.html?ngResource */ 16363);
/* harmony import */ var _door_selection_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./door-selection.component.scss?ngResource */ 81516);
/* harmony import */ var _door_selection_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_door_selection_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var src_app_shared_components_modal_menu_modal_menu_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/modal-menu/modal-menu.component */ 77098);

var _class;





let DoorSelectionComponent = (_class = class DoorSelectionComponent {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "modal", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessPointList", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessPointSelected", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "accessPointUnselected", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "hideClick", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "checked", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "isLoaded", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "open", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "modalHeight", 'h-fit');
  }
  ngOnInit() {
    this.isLoaded = true;
  }
  accessClick(apId) {
    console.log('Clicked: ' + apId);
    const ap = this.accessPointList.find(x => x.access.id === apId);
    if (ap) this.checked = ap;
    console.log(this.checked);
    if (this.checked) {
      this.accessPointSelected.emit(this.checked.access);
      this.modal?.hide();
    }
  }
  viewMore(viewMore) {
    if (viewMore) {
      this.modalHeight = 'h-100';
    } else {
      this.modalHeight = 'h-fit';
    }
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => []), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  modal: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.ViewChild,
    args: [src_app_shared_components_modal_menu_modal_menu_component__WEBPACK_IMPORTED_MODULE_3__.ModalMenuComponent]
  }],
  accessPointList: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input
  }],
  accessPointSelected: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }],
  accessPointUnselected: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }],
  hideClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }]
}), _class);
DoorSelectionComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
  selector: 'app-door-selection',
  template: _door_selection_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_door_selection_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], DoorSelectionComponent);


/***/ }),

/***/ 42056:
/*!****************************************************************************!*\
  !*** ./src/app/scan/components/identification/identification.component.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IdentificationComponent": () => (/* binding */ IdentificationComponent)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _identification_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./identification.component.html?ngResource */ 38760);
/* harmony import */ var _identification_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./identification.component.scss?ngResource */ 40038);
/* harmony import */ var _identification_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_identification_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var src_app_shared_models_ScanResult__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/models/ScanResult */ 44690);

var _class;






let IdentificationComponent = (_class = class IdentificationComponent {
  constructor(traslate) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "traslate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "result", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "scanResult", src_app_shared_models_ScanResult__WEBPACK_IMPORTED_MODULE_3__.ScanResult);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "avatarApi", 'https://api.dicebear.com/5.x/initials/svg?seed=');
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "loading", true);
    this.traslate = traslate;
  }
  get denied() {
    return this.result.scanResult === src_app_shared_models_ScanResult__WEBPACK_IMPORTED_MODULE_3__.ScanResult.deny;
  }
  get authorized() {
    return this.result.scanResult === src_app_shared_models_ScanResult__WEBPACK_IMPORTED_MODULE_3__.ScanResult.success;
  }
  get notAuthorized() {
    return this.result.scanResult === src_app_shared_models_ScanResult__WEBPACK_IMPORTED_MODULE_3__.ScanResult.notAuthorized;
  }
  get hasPicture() {
    return this.result.userPicture?.url !== undefined;
  }
  get userImage() {
    if (this.result.userPicture == null || this.result.userPicture === undefined) {
      if (this.result.userName === undefined || this.result.userName === null) return 'assets/icons/avatar.png';else return this.avatarApi + this.result.userName?.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]|[\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD10-\uDDFF]/gi, '');
    }
    return this.result.userPicture.url;
  }
  hideLoader() {
    this.loading = false;
  }
  getResultTitle() {
    switch (this.result.scanResult) {
      case src_app_shared_models_ScanResult__WEBPACK_IMPORTED_MODULE_3__.ScanResult.success:
        return this.traslate.instant('scan.authorized');
      case src_app_shared_models_ScanResult__WEBPACK_IMPORTED_MODULE_3__.ScanResult.deny:
        return this.traslate.instant('scan.denied');
      case src_app_shared_models_ScanResult__WEBPACK_IMPORTED_MODULE_3__.ScanResult.notAuthorized:
        return this.traslate.instant('scan.denied');
    }
  }
  getCardBackground() {
    switch (this.result.scanResult) {
      case src_app_shared_models_ScanResult__WEBPACK_IMPORTED_MODULE_3__.ScanResult.success:
        return 'bg-green-dark';
      case src_app_shared_models_ScanResult__WEBPACK_IMPORTED_MODULE_3__.ScanResult.deny:
        return 'bg-red-dark';
      case src_app_shared_models_ScanResult__WEBPACK_IMPORTED_MODULE_3__.ScanResult.notAuthorized:
        return 'bg-yellow-light';
    }
  }
  getNextAccessTitle() {
    if (this.result.scanResult === src_app_shared_models_ScanResult__WEBPACK_IMPORTED_MODULE_3__.ScanResult.notAuthorized) {
      let nextAccessString = '';
      if (this.result.nextAccess) {
        const hours = Math.floor((new Date(this.result.nextAccess).getTime() - new Date().getTime()) / 1000 / 60 / 60);
        nextAccessString = this.traslate.instant('scan.nextAccess', {
          hours
        });
      }
      return [nextAccessString];
    }
  }
  getSubtitle() {
    return [this.result.userName];
  }
  getLastReported() {
    if (this.result.lastReported) {
      const wayText = this.result.lastReportedEntry ? this.traslate.instant('scan.lastEntryRecorded') : this.traslate.instant('scan.lastExitRecorded');
      return wayText + ' ' + new Date(this.result.lastReported).toLocaleString();
    }
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslateService
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  result: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input
  }]
}), _class);
IdentificationComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
  selector: 'app-identification',
  template: _identification_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_identification_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], IdentificationComponent);


/***/ }),

/***/ 62878:
/*!****************************************************************************************!*\
  !*** ./src/app/scan/components/manual-authorization/manual-authorization.component.ts ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ManualAuthorizationComponent": () => (/* binding */ ManualAuthorizationComponent)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _manual_authorization_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./manual-authorization.component.html?ngResource */ 5656);
/* harmony import */ var _manual_authorization_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./manual-authorization.component.scss?ngResource */ 81790);
/* harmony import */ var _manual_authorization_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_manual_authorization_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var src_app_shared_components_modal_menu_modal_menu_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/modal-menu/modal-menu.component */ 77098);

var _class;





let ManualAuthorizationComponent = (_class = class ManualAuthorizationComponent {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "modal", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "buttonState", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "buttonClick", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "nameValue", '');
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "docValue", '');
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "notesValue", '');
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => []), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  modal: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.ViewChild,
    args: [src_app_shared_components_modal_menu_modal_menu_component__WEBPACK_IMPORTED_MODULE_3__.ModalMenuComponent]
  }],
  buttonState: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input
  }],
  buttonClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }]
}), _class);
ManualAuthorizationComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
  selector: 'app-manual-authorization',
  template: _manual_authorization_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_manual_authorization_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], ManualAuthorizationComponent);


/***/ }),

/***/ 87541:
/*!************************************************************************!*\
  !*** ./src/app/scan/components/scan-confirm/scan-confirm.component.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ScanConfirmComponent": () => (/* binding */ ScanConfirmComponent)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _scan_confirm_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./scan-confirm.component.html?ngResource */ 92210);
/* harmony import */ var _scan_confirm_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./scan-confirm.component.scss?ngResource */ 83331);
/* harmony import */ var _scan_confirm_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_scan_confirm_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var src_app_shared_components_modal_menu_modal_menu_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/modal-menu/modal-menu.component */ 77098);

var _class;





let ScanConfirmComponent = (_class = class ScanConfirmComponent {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "modal", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "title", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "buttonLabel", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "buttonState", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "enterKey", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "buttonClick", new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "model", '');
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => []), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  modal: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.ViewChild,
    args: [src_app_shared_components_modal_menu_modal_menu_component__WEBPACK_IMPORTED_MODULE_3__.ModalMenuComponent]
  }],
  title: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input
  }],
  buttonLabel: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input
  }],
  buttonState: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input
  }],
  enterKey: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }],
  buttonClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output
  }]
}), _class);
ScanConfirmComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
  selector: 'app-scan-confirm',
  template: _scan_confirm_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_scan_confirm_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], ScanConfirmComponent);


/***/ }),

/***/ 27339:
/*!**********************************************************************!*\
  !*** ./src/app/scan/components/tabs-switch/tabs-switch.component.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabsSwitchComponent": () => (/* binding */ TabsSwitchComponent)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _tabs_switch_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tabs-switch.component.html?ngResource */ 96212);
/* harmony import */ var _tabs_switch_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tabs-switch.component.scss?ngResource */ 42855);
/* harmony import */ var _tabs_switch_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tabs_switch_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51197);

var _class;




let TabsSwitchComponent = (_class = class TabsSwitchComponent {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "entranceClick", new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "departureClick", new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "option", 0);
  }
  selectEntrance() {
    this.option = 0;
    this.entranceClick.emit();
  }
  selectDeparture() {
    this.option = 1;
    this.departureClick.emit();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => []), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  entranceClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output
  }],
  departureClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output
  }]
}), _class);
TabsSwitchComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
  selector: 'app-tabs-switch',
  template: _tabs_switch_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_tabs_switch_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], TabsSwitchComponent);


/***/ }),

/***/ 25002:
/*!****************************************************************!*\
  !*** ./src/app/scan/pages/scan-result/scan-result.business.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterControlViewModel": () => (/* binding */ RegisterControlViewModel),
/* harmony export */   "ScanResultBusiness": () => (/* binding */ ScanResultBusiness),
/* harmony export */   "ValidateQrParameters": () => (/* binding */ ValidateQrParameters)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 45667);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/components/button/button.component */ 62490);
/* harmony import */ var _components_manual_authorization_manual_authorization_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../components/manual-authorization/manual-authorization.component */ 62878);
/* harmony import */ var _components_scan_confirm_scan_confirm_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/scan-confirm/scan-confirm.component */ 87541);
/* harmony import */ var _scan_scan_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../scan/scan.page */ 74842);
/* harmony import */ var src_app_shared_services_access_point_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/services/access-point.service */ 58838);
/* harmony import */ var _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @capacitor/geolocation */ 97961);


var _class;











let ScanResultBusiness = (_class = class ScanResultBusiness {
  constructor(accessPointService, translate, navController, activatedRoute) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPointService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "activatedRoute", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "confirmModal", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "manualAuthModal", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "scanPage", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "formModal", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "result", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitationClickedId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "confirmTitle", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "confirmButtonLabel", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "confirmModalOption", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "confirmButtonState", src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_2__.ButtonState.enabled);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "saveButtonState", src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_2__.ButtonState.enabled);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "qrString", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPointId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "code", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "isEntry", true);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "position", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "message", void 0);
    this.accessPointService = accessPointService;
    this.translate = translate;
    this.navController = navController;
    this.activatedRoute = activatedRoute;
    this.activatedRoute.queryParams.subscribe(params => {
      this.accessPointId = params['accessPointId'];
      this.userId = params['userId'];
      this.code = params['tokenCode'];
    });
  }
  ngOnInit() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.validateQr();
    })();
  }
  backClick() {
    this.navController.back();
  }
  tabSwitch(option) {
    this.isEntry = option === 'entrance';
    console.log(this.isEntry);
  }
  checkPermission() {
    var _this2 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let status;
      try {
        status = yield _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_7__.Geolocation.checkPermissions();
        console.log('Status check permissions: ' + status.location);
        if (status.location === 'granted') {
          // user granted permission
          return true;
        } else if (status.location === 'denied' || status.location === 'prompt' || status.location === 'prompt-with-rationale') {
          const c = confirm(_this2.translate.instant('location.askPermission'));
          if (c) {
            const requestStatus = yield _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_7__.Geolocation.requestPermissions({
              permissions: ['location']
            });
            if (requestStatus.location === 'granted') {
              return true;
            }
          }
        }
        _this2.message = _this2.translate.instant('location.needPermission');
        return false;
      } catch (error) {
        if (error.message == 'Location services are not enabled') {
          _this2.message = _this2.translate.instant('location.notGranted');
          return false;
        }
      }
    })();
  }
  getLocation() {
    var _this3 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const allowed = yield _this3.checkPermission();
      if (allowed) {
        _this3.position = yield _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_7__.Geolocation.getCurrentPosition();
        return true;
      } else {
        if ((0,_ionic_angular__WEBPACK_IMPORTED_MODULE_8__.isPlatform)('capacitor')) {
          alert(_this3.message);
          _this3.navController.navigateBack('scan');
          return false;
        }
      }
    })();
  }
  validateQr() {
    var _this4 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const checkLocation = yield _this4.getLocation();
      if (checkLocation) {
        const vm = _this4.checkQr();
        if (vm !== undefined) {
          _this4.accessPointService.validateQR(vm).subscribe(response => {
            if (response.error == null) {
              _this4.result = response.data;
              console.log(_this4.result);
            } else {
              if (response.code === 803) {
                alert(_this4.translate.instant('scan.invalidQr'));
                _this4.navController.navigateRoot('scan');
              } else {
                _this4.navController.navigateRoot('error');
              }
            }
          });
        } else {
          _this4.navController.navigateBack('scan');
        }
      }
    })();
  }
  checkQr() {
    if (this.accessPointId === undefined || this.userId === undefined || this.code === undefined) return undefined;
    const vm = new ValidateQrParameters();
    vm.accessPointId = this.accessPointId;
    vm.userId = this.userId;
    vm.code = this.code;
    vm.latitude = this.position?.coords.latitude;
    vm.longitude = this.position?.coords.longitude;
    return vm;
  }
  deny() {
    this.confirmModalOption = 'deny';
    this.confirmTitle = this.translate.instant('scan.denyConfirmTitle');
    this.confirmButtonLabel = this.translate.instant('scan.deny');
    this.confirmModal.model = '';
    this.confirmModal.modal?.show();
  }
  manualAuthorization() {
    console.log('Manual auth: ' + this.manualAuthModal?.nameValue + ', ' + this.manualAuthModal?.docValue + ', ' + this.manualAuthModal?.notesValue);
    this.confirmButtonState = src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_2__.ButtonState.loading;
    const vm = new RegisterControlViewModel();
    vm.controlId = this.result.controlId;
    vm.hostUserId = this.result.accesses[0].invitation.createBy;
    vm.answers = this.result.inputs;
    vm.authorized = true;
    vm.isEntry = this.isEntry;
    vm.accesses = this.result.accesses.map(x => x.id);
    vm.comments = this.manualAuthModal?.notesValue;
    vm.name = this.manualAuthModal?.nameValue;
    vm.document = this.manualAuthModal?.docValue;
    this.accessPointService.registerControl(vm).subscribe(response => {
      if (response.error == null) {
        this.confirmButtonState = src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_2__.ButtonState.enabled;
        this.confirmModal?.modal?.hide();
        this.navController.navigateForward('scan');
      } else {
        this.navController.navigateRoot('error');
      }
    });
  }
  continue() {
    this.navController.navigateForward('scan');
  }
  confirm(value) {
    console.log('Confirmed with note: ' + value);
    this.confirmButtonState = src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_2__.ButtonState.loading;
    const vm = new RegisterControlViewModel();
    vm.controlId = this.result.controlId;
    vm.hostUserId = this.result.accesses[0].invitation.createBy;
    vm.answers = this.result.inputs;
    vm.authorized = true;
    vm.isEntry = this.isEntry;
    vm.accesses = this.result.accesses.map(x => x.id);
    vm.comments = value;
    this.accessPointService.registerControl(vm).subscribe(response => {
      if (response.error == null) {
        this.confirmButtonState = src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_2__.ButtonState.enabled;
        this.confirmModal?.modal?.hide();
        this.navController.navigateForward('scan');
      } else {
        this.navController.navigateRoot('error');
      }
    });
  }
  confirmDeny(value) {
    console.log('Denied with note: ' + value);
    this.confirmButtonState = src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_2__.ButtonState.loading;
    const vm = new RegisterControlViewModel();
    vm.controlId = this.result.controlId;
    vm.hostUserId = this.result.accesses[0].invitation.createBy;
    vm.answers = this.result.inputs;
    vm.authorized = false;
    vm.isEntry = this.isEntry;
    vm.accesses = this.result.accesses.map(x => x.id);
    vm.comments = value;
    this.accessPointService.registerControl(vm).subscribe(response => {
      if (response.error == null) {
        this.confirmButtonState = src_app_shared_components_button_button_component__WEBPACK_IMPORTED_MODULE_2__.ButtonState.enabled;
        this.confirmModal?.modal?.hide();
        this.navController.navigateForward('scan');
      } else {
        this.navController.navigateRoot('error');
      }
    });
  }
  // invitationClick(apId: string) {
  //   console.log('Click! ' + apId);
  //   this.invitationClickedId = apId;
  //   if (this.result.inputs && this.result.inputs?.length > 0) this.formModal?.show();
  // }
  saveForm() {
    this.formModal?.hide();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_services_access_point_service__WEBPACK_IMPORTED_MODULE_6__.AccessPointService
}, {
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.NavController
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_11__.ActivatedRoute
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "propDecorators", {
  confirmModal: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.ViewChild,
    args: [_components_scan_confirm_scan_confirm_component__WEBPACK_IMPORTED_MODULE_4__.ScanConfirmComponent]
  }],
  manualAuthModal: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.ViewChild,
    args: [_components_manual_authorization_manual_authorization_component__WEBPACK_IMPORTED_MODULE_3__.ManualAuthorizationComponent]
  }],
  scanPage: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.ViewChild,
    args: [_scan_scan_page__WEBPACK_IMPORTED_MODULE_5__.ScanPage]
  }],
  formModal: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.ViewChild,
    args: ['formModal']
  }]
}), _class);
ScanResultBusiness = (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Component)({
  template: `<app-scan-result
      class="scroll-content"
      *ngIf="result"
      [result]="result"
      (backClick)="backClick()"
      (tabsClick)="tabSwitch($event)"
      (registerClick)="confirm($event)"
      (denyClick)="deny()"
      (nextClick)="continue()"
      (manualAuthorizeClick)="authModal?.modal?.show()"></app-scan-result>

    <app-scan-confirm
      [title]="confirmTitle"
      [buttonLabel]="confirmButtonLabel"
      [buttonState]="confirmButtonState"
      (enterKey)="confirmDeny($event)"
      (buttonClick)="confirmDeny($event)"></app-scan-confirm>

    <app-manual-authorization
      #authModal
      [buttonState]="confirmButtonState"
      (buttonClick)="manualAuthorization()"></app-manual-authorization>

    <app-modal-menu *ngIf="result" #formModal [height]="'h-fit'">
      <ng-template #modalContent>
        <div class="mb-3">
          <fa-icon
            (click)="formModal.hide()"
            [icon]="['fas', 'xmark']"
            class="position-absolute right-10 top-10 color-highlight"
            [size]="'lg'"></fa-icon>

          <app-access-form
            [title]="'access.formDefaultTitle' | translate"
            [inputs]="result.inputs"
            [readOnly]="true"
            [editable]="false"></app-access-form>

          <app-button
            [status]="saveButtonState"
            [label]="'common.save' | translate"
            (buttonClick)="saveForm()"></app-button>
        </div>
      </ng-template>
    </app-modal-menu>`
})], ScanResultBusiness);

class ValidateQrParameters {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPointId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "code", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "latitude", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "longitude", void 0);
  }
}
class RegisterControlViewModel {
  constructor() {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "controlId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "hostUserId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accesses", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "isEntry", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "authorized", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "comments", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "answers", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "name", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "document", void 0);
  }
}

/***/ }),

/***/ 88231:
/*!************************************************************!*\
  !*** ./src/app/scan/pages/scan-result/scan-result.page.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ScanResultPage": () => (/* binding */ ScanResultPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _scan_result_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./scan-result.page.html?ngResource */ 86207);
/* harmony import */ var _scan_result_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./scan-result.page.scss?ngResource */ 62376);
/* harmony import */ var _scan_result_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_scan_result_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/footer/footer.component */ 68014);
/* harmony import */ var src_app_shared_helpers_business__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/helpers/business */ 92237);
/* harmony import */ var src_app_shared_models_ScanResult__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/models/ScanResult */ 44690);

var _class;








let ScanResultPage = (_class = class ScanResultPage {
  constructor(traslate, business) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "traslate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "business", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "result", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "backClick", new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "tabsClick", new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "registerClick", new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "denyClick", new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "nextClick", new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "manualAuthorizeClick", new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "invitationClick", new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "notesModel", '');
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "footerOptions", src_app_shared_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__.FooterSelectedOption);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, "scanResult", src_app_shared_models_ScanResult__WEBPACK_IMPORTED_MODULE_5__.ScanResult);
    this.traslate = traslate;
    this.business = business;
  }
  get denied() {
    return this.result.scanResult === src_app_shared_models_ScanResult__WEBPACK_IMPORTED_MODULE_5__.ScanResult.deny;
  }
  get authorized() {
    return this.result.scanResult === src_app_shared_models_ScanResult__WEBPACK_IMPORTED_MODULE_5__.ScanResult.success;
  }
  get notAuthorized() {
    return this.result.scanResult === src_app_shared_models_ScanResult__WEBPACK_IMPORTED_MODULE_5__.ScanResult.notAuthorized;
  }
  getTitle() {
    switch (this.result.scanResult) {
      case src_app_shared_models_ScanResult__WEBPACK_IMPORTED_MODULE_5__.ScanResult.success:
        return this.traslate.instant('scan.authorized');
      case src_app_shared_models_ScanResult__WEBPACK_IMPORTED_MODULE_5__.ScanResult.deny:
        return this.traslate.instant('scan.deny');
      case src_app_shared_models_ScanResult__WEBPACK_IMPORTED_MODULE_5__.ScanResult.notAuthorized:
        return this.traslate.instant('scan.deny');
    }
  }
  getInvTitle(title) {
    const array = [];
    const splitString = title.split('-');
    array.push(splitString[0]);
    array.push(splitString[1]);
    return array;
  }
  getRecurrenceText(ap) {
    const dateRange = ap.dateTo === null && ap.recurrency ? `${this.traslate.instant('recurence.from')} ` + this.business.getDateRange(ap) : this.business.getDateRange(ap);
    const recurrence = this.business.getRecurrence(ap);
    const timeRange = this.traslate.instant('recurence.entry') + ' ' + this.business.getTimeRange(ap);
    const array = [];
    array.push(dateRange);
    array.push(recurrence);
    array.push(timeRange);
    return array;
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "ctorParameters", () => [{
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslateService
}, {
  type: src_app_shared_helpers_business__WEBPACK_IMPORTED_MODULE_4__["default"]
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_class, "propDecorators", {
  result: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Input
  }],
  backClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Output
  }],
  tabsClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Output
  }],
  registerClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Output
  }],
  denyClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Output
  }],
  nextClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Output
  }],
  manualAuthorizeClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Output
  }],
  invitationClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Output
  }]
}), _class);
ScanResultPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
  selector: 'app-scan-result',
  template: _scan_result_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [(_scan_result_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2___default())]
})], ScanResultPage);


/***/ }),

/***/ 47695:
/*!*******************************************************!*\
  !*** ./src/app/scan/pages/scan/scan.page.business.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ScanPageBusiness": () => (/* binding */ ScanPageBusiness)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var src_app_shared_components_door_select_form_door_select_form_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/components/door-select-form/door-select-form.component */ 6980);
/* harmony import */ var src_app_shared_services_access_point_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/services/access-point.service */ 58838);
/* harmony import */ var _scan_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./scan.page */ 74842);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 82454);


var _class;








let ScanPageBusiness = (_class = class ScanPageBusiness {
  constructor(accessPointService, navController, translate, router, route) {
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPointService", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "router", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "route", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "scanPage", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "aps", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "apSelected", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitations", []);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "loaded", false);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "returnUrl", void 0);
    this.accessPointService = accessPointService;
    this.navController = navController;
    this.translate = translate;
    this.router = router;
    this.route = route;
    this.aps = [];
    this.route.queryParams.subscribe(params => {
      this.returnUrl = params.returnUrl;
    });
  }
  ionViewWillEnter() {
    var _this = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.fetchAps();
      _this.scanPage?.startScanner();
    })();
  }
  ionViewWillLeave() {
    this.scanPage?.stopScanner();
  }
  fetchAps() {
    var _this2 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this2.accessPointService.getUserAccessPoints().subscribe( /*#__PURE__*/function () {
        var _ref = (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (response) {
          if (response.error == null) {
            _this2.aps = response.data.map(x => {
              const door = new src_app_shared_components_door_select_form_door_select_form_component__WEBPACK_IMPORTED_MODULE_2__.DoorsViewModel();
              door.selected = false;
              door.access = x;
              return door;
            });
            console.log(_this2.aps);
            _this2.loaded = true;
            if (_this2.aps.length > 0) {
              if (!_this2.apSelected) {
                _this2.apSelected = _this2.aps[0].access;
              }
            }
          } else _this2.navController.navigateRoot('error');
        });
        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }());
    })();
  }
  backClick() {
    if (this.returnUrl) this.navController.navigateBack(this.returnUrl);else this.navController.navigateBack('credential');
  }
  scanSuccess(result) {
    console.log(result);
    if (result.content === 'qrTestResultDenied') {
      this.navController.navigateRoot('scan/denied');
    } else if (result.content === 'qrTestResultNotAuthorized') {
      this.navController.navigateRoot('scan/notauthorized');
    } else if (result.content === 'qrTestResultAuthorized') {
      this.navController.navigateRoot('scan/authorized');
    } else {
      alert(this.translate.instant('scan.invalidQr'));
      this.loaded = false;
      setTimeout(() => {
        this.loaded = true;
      }, 250);
    }
  }
  scanError(result) {
    console.log(result);
    this.navController.back();
  }
  accessPointSelected(ap) {
    var _this3 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this3.apSelected = ap;
      // const res = await lastValueFrom(this.invitationService.getInvitationsByAccessPoint(this.apSelected.id));
      // if (res.error == null) {
      //   this.invitations = res.data;
      //   console.log(this.invitations);
      //   this.loaded = true;
      // } else {
      //   this.navController.navigateRoot('error');;
      // }
    })();
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: src_app_shared_services_access_point_service__WEBPACK_IMPORTED_MODULE_3__.AccessPointService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController
}, {
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "propDecorators", {
  scanPage: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild,
    args: [_scan_page__WEBPACK_IMPORTED_MODULE_4__.ScanPage]
  }]
}), _class);
ScanPageBusiness = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
  template: `<app-scan
      *ngIf="loaded"
      [aps]="aps"
      [invitations]="invitations"
      [apSelected]="apSelected"
      (backClick)="backClick()"
      (scanSuccess)="scanSuccess($event)"
      (scanError)="scanError($event)"
      (accessPointClick)="accessPointSelected($event)"></app-scan>
    <div *ngIf="!loaded" class="center">
      <div class="spinner-border color-blue-dark" role="status"></div>
    </div>`
})], ScanPageBusiness);


/***/ }),

/***/ 74842:
/*!**********************************************!*\
  !*** ./src/app/scan/pages/scan/scan.page.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ScanPage": () => (/* binding */ ScanPage)
/* harmony export */ });
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 19369);
/* harmony import */ var C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 61861);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _scan_page_html_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./scan.page.html?ngResource */ 61087);
/* harmony import */ var _scan_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./scan.page.scss?ngResource */ 6300);
/* harmony import */ var _scan_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_scan_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 89650);
/* harmony import */ var _components_door_selection_door_selection_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/door-selection/door-selection.component */ 71943);
/* harmony import */ var _capacitor_community_barcode_scanner__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capacitor-community/barcode-scanner */ 58765);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 45667);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngx-translate/core */ 67690);
/* harmony import */ var _capacitor_camera__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @capacitor/camera */ 12534);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 82454);


var _class;











let ScanPage = (_class = class ScanPage {
  constructor(platform, location, navController, translate, router) {
    var _this = this;
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "platform", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "location", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "navController", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "translate", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "router", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "doorSelection", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "aps", []);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "invitations", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "apSelected", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "backClick", new _angular_core__WEBPACK_IMPORTED_MODULE_7__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "accessPointClick", new _angular_core__WEBPACK_IMPORTED_MODULE_7__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "scanSuccess", new _angular_core__WEBPACK_IMPORTED_MODULE_7__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "scanError", new _angular_core__WEBPACK_IMPORTED_MODULE_7__.EventEmitter());
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "appBaseUrl", 'http://www.identifast.com/');
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "testUrl", 'http://www.identifast.com/qr/11111111-1111-1111-1111-111111111111/865419');
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "userId", void 0);
    (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, "token", void 0);
    this.platform = platform;
    this.location = location;
    this.navController = navController;
    this.translate = translate;
    this.router = router;
    this.platform.ready();
    this.platform.backButton.subscribeWithPriority(11, /*#__PURE__*/(0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.stopScanner();
      _this.navController.back();
      console.log('Back button');
    }));
  }
  ngOnInit() {
    var _this2 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this2.startScanner();
    })();
  }
  getSelectedString() {
    let str = '';
    if (this.apSelected) {
      str = this.apSelected.name;
    } else {
      str = this.translate.instant('scan.noDoor');
    }
    return str;
  }
  checkPermission() {
    var _this3 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if ((0,_ionic_angular__WEBPACK_IMPORTED_MODULE_8__.isPlatform)('capacitor')) {
        const status = yield _capacitor_camera__WEBPACK_IMPORTED_MODULE_6__.Camera.checkPermissions();
        console.log('Status check permissions: ' + status.camera);
        if (status.camera === 'granted') {
          // user granted permission
          return true;
        } else if (status.camera === 'denied' || status.camera === 'prompt' || status.camera === 'prompt-with-rationale') {
          const c = confirm(_this3.translate.instant('scan.askPermission'));
          if (c) {
            const requestStatus = yield _capacitor_camera__WEBPACK_IMPORTED_MODULE_6__.Camera.requestPermissions({
              permissions: ['camera']
            });
            if (requestStatus.camera === 'granted') {
              return true;
            } else if (requestStatus.camera === 'denied') {
              alert(_this3.translate.instant('scan.needPermission'));
              _capacitor_community_barcode_scanner__WEBPACK_IMPORTED_MODULE_5__.BarcodeScanner.openAppSettings();
              return false;
            }
          } else {
            return false;
          }
        }
        return false;
      } else {
        document.body.classList.add('qrscanner-desktop');
        return false;
      }
    })();
  }
  startScanner() {
    var _this4 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const allowed = yield _this4.checkPermission();
      if (allowed) {
        console.log('Opening scanner');
        _capacitor_community_barcode_scanner__WEBPACK_IMPORTED_MODULE_5__.BarcodeScanner.hideBackground();
        document.body.classList.add('qrscanner');
        const result = yield _capacitor_community_barcode_scanner__WEBPACK_IMPORTED_MODULE_5__.BarcodeScanner.startScan();
        if (result.hasContent) {
          const url = result.content;
          // validar la url de identifast
          if (url?.startsWith(_this4.appBaseUrl)) {
            // pasear parametros
            const regex = /\/qr\/([^\/]+)\/([^\/]+)/;
            const matches = url.match(regex);
            if (matches && matches.length === 3) {
              _this4.userId = matches[1];
              _this4.token = matches[2];
              console.log('userId:', _this4.userId);
              console.log('token:', _this4.token);
              _this4.router.navigate(['scan/result'], {
                queryParams: {
                  userId: _this4.userId,
                  tokenCode: _this4.token,
                  accessPointId: _this4.apSelected?.id
                }
              });
            } else {
              _this4.stopScanner().then(() => {
                _this4.startScanner();
              });
              alert('Error URL');
            }
          } else {
            _this4.stopScanner().then(() => {
              _this4.startScanner();
            });
            alert('La URL no es de identifast');
          }
        } else {
          _this4.stopScanner();
          alert('NO DATA FOUND!');
          _this4.scanError.emit(result);
        }
      } else {
        if ((0,_ionic_angular__WEBPACK_IMPORTED_MODULE_8__.isPlatform)('capacitor')) {
          alert(_this4.translate.instant('scan.notGranted'));
          _this4.stopScanner();
          _this4.scanError.emit();
        }
      }
    })();
  }
  stopScanner() {
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        yield _capacitor_community_barcode_scanner__WEBPACK_IMPORTED_MODULE_5__.BarcodeScanner.stopScan();
        _capacitor_community_barcode_scanner__WEBPACK_IMPORTED_MODULE_5__.BarcodeScanner.showBackground();
        document.body.classList.remove('qrscanner');
      } catch (error) {
        if (error.code === 'UNIMPLEMENTED') {
          document.body.classList.remove('qrscanner-desktop');
        }
      }
    })();
  }
  torch() {
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        yield _capacitor_community_barcode_scanner__WEBPACK_IMPORTED_MODULE_5__.BarcodeScanner.toggleTorch();
      } catch (error) {
        if (error.code === 'UNIMPLEMENTED') {
          console.log(error.code);
        }
      }
    })();
  }
  close() {
    this.stopScanner();
    this.backClick.emit();
  }
  openDoorModal() {
    var _this5 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this5.aps.length > 1) {
        yield _this5.stopScanner();
        _this5.doorSelection?.modal?.show();
      }
    })();
  }
  closeDoorModal() {
    var _this6 = this;
    return (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this6.startScanner();
    })();
  }
  ionViewDidLeave() {
    this.stopScanner();
    console.log('leaving scanner view');
  }
}, (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "ctorParameters", () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.Platform
}, {
  type: _angular_common__WEBPACK_IMPORTED_MODULE_10__.Location
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.NavController
}, {
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__.TranslateService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.Router
}]), (0,C_Repos_Identifast_App_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_class, "propDecorators", {
  doorSelection: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild,
    args: [_components_door_selection_door_selection_component__WEBPACK_IMPORTED_MODULE_4__.DoorSelectionComponent]
  }],
  aps: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.Input
  }],
  invitations: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.Input
  }],
  apSelected: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.Input
  }],
  backClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.Output
  }],
  accessPointClick: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.Output
  }],
  scanSuccess: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.Output
  }],
  scanError: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.Output
  }]
}), _class);
ScanPage = (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
  selector: 'app-scan',
  template: _scan_page_html_ngResource__WEBPACK_IMPORTED_MODULE_2__,
  styles: [(_scan_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_3___default())]
})], ScanPage);


/***/ }),

/***/ 7865:
/*!*********************************************!*\
  !*** ./src/app/scan/scan-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ScanPageRoutingModule": () => (/* binding */ ScanPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 82454);
/* harmony import */ var _pages_scan_result_scan_result_business__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pages/scan-result/scan-result.business */ 25002);
/* harmony import */ var _pages_scan_scan_page_business__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pages/scan/scan.page.business */ 47695);





const routes = [{
  path: '',
  component: _pages_scan_scan_page_business__WEBPACK_IMPORTED_MODULE_1__.ScanPageBusiness
}, {
  path: 'result',
  component: _pages_scan_result_scan_result_business__WEBPACK_IMPORTED_MODULE_0__.ScanResultBusiness
}];
let ScanPageRoutingModule = class ScanPageRoutingModule {};
ScanPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
  imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)],
  exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
})], ScanPageRoutingModule);


/***/ }),

/***/ 85809:
/*!*************************************!*\
  !*** ./src/app/scan/scan.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ScanModule": () => (/* binding */ ScanModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 71081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 51197);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ 89650);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/forms */ 70997);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic/angular */ 7533);
/* harmony import */ var _scan_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./scan-routing.module */ 7865);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../shared/shared.module */ 56208);
/* harmony import */ var _pages_scan_scan_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pages/scan/scan.page */ 74842);
/* harmony import */ var _pages_scan_result_scan_result_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/scan-result/scan-result.page */ 88231);
/* harmony import */ var _components_identification_identification_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/identification/identification.component */ 42056);
/* harmony import */ var _pages_scan_result_scan_result_business__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages/scan-result/scan-result.business */ 25002);
/* harmony import */ var _components_tabs_switch_tabs_switch_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/tabs-switch/tabs-switch.component */ 27339);
/* harmony import */ var _components_scan_confirm_scan_confirm_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./components/scan-confirm/scan-confirm.component */ 87541);
/* harmony import */ var _components_manual_authorization_manual_authorization_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./components/manual-authorization/manual-authorization.component */ 62878);
/* harmony import */ var _components_door_selection_door_selection_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/door-selection/door-selection.component */ 71943);
/* harmony import */ var _pages_scan_scan_page_business__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./pages/scan/scan.page.business */ 47695);
















let ScanModule = class ScanModule {};
ScanModule = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.NgModule)({
  declarations: [_pages_scan_scan_page__WEBPACK_IMPORTED_MODULE_2__.ScanPage, _pages_scan_result_scan_result_page__WEBPACK_IMPORTED_MODULE_3__.ScanResultPage, _components_identification_identification_component__WEBPACK_IMPORTED_MODULE_4__.IdentificationComponent, _pages_scan_result_scan_result_business__WEBPACK_IMPORTED_MODULE_5__.ScanResultBusiness, _components_tabs_switch_tabs_switch_component__WEBPACK_IMPORTED_MODULE_6__.TabsSwitchComponent, _components_scan_confirm_scan_confirm_component__WEBPACK_IMPORTED_MODULE_7__.ScanConfirmComponent, _components_manual_authorization_manual_authorization_component__WEBPACK_IMPORTED_MODULE_8__.ManualAuthorizationComponent, _components_door_selection_door_selection_component__WEBPACK_IMPORTED_MODULE_9__.DoorSelectionComponent, _pages_scan_scan_page_business__WEBPACK_IMPORTED_MODULE_10__.ScanPageBusiness],
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_13__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.IonicModule, _scan_routing_module__WEBPACK_IMPORTED_MODULE_0__.ScanPageRoutingModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule],
  exports: [_scan_routing_module__WEBPACK_IMPORTED_MODULE_0__.ScanPageRoutingModule, _components_identification_identification_component__WEBPACK_IMPORTED_MODULE_4__.IdentificationComponent, _pages_scan_scan_page__WEBPACK_IMPORTED_MODULE_2__.ScanPage, _pages_scan_result_scan_result_page__WEBPACK_IMPORTED_MODULE_3__.ScanResultPage, _components_tabs_switch_tabs_switch_component__WEBPACK_IMPORTED_MODULE_6__.TabsSwitchComponent, _components_scan_confirm_scan_confirm_component__WEBPACK_IMPORTED_MODULE_7__.ScanConfirmComponent, _components_manual_authorization_manual_authorization_component__WEBPACK_IMPORTED_MODULE_8__.ManualAuthorizationComponent, _components_door_selection_door_selection_component__WEBPACK_IMPORTED_MODULE_9__.DoorSelectionComponent]
})], ScanModule);


/***/ }),

/***/ 44690:
/*!*********************************************!*\
  !*** ./src/app/shared/models/ScanResult.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ScanResult": () => (/* binding */ ScanResult)
/* harmony export */ });
var ScanResult;
(function (ScanResult) {
  ScanResult["success"] = "Success";
  ScanResult["deny"] = "Denied";
  ScanResult["notAuthorized"] = "NotAuthorized";
})(ScanResult || (ScanResult = {}));

/***/ }),

/***/ 81516:
/*!*****************************************************************************************!*\
  !*** ./src/app/scan/components/door-selection/door-selection.component.scss?ngResource ***!
  \*****************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 40038:
/*!*****************************************************************************************!*\
  !*** ./src/app/scan/components/identification/identification.component.scss?ngResource ***!
  \*****************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 81790:
/*!*****************************************************************************************************!*\
  !*** ./src/app/scan/components/manual-authorization/manual-authorization.component.scss?ngResource ***!
  \*****************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 83331:
/*!*************************************************************************************!*\
  !*** ./src/app/scan/components/scan-confirm/scan-confirm.component.scss?ngResource ***!
  \*************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".form-control {\n  background-color: transparent !important;\n  border-width: 1px;\n  border-radius: 10px;\n}\n\n.form-container {\n  margin-bottom: 10px;\n  padding-bottom: 20px;\n  position: relative;\n}\n\n.form-container label {\n  display: block;\n  margin-bottom: 5px;\n}\n\n.input-style {\n  margin-bottom: 0 !important;\n}", "",{"version":3,"sources":["webpack://./src/app/scan/components/scan-confirm/scan-confirm.component.scss"],"names":[],"mappings":"AAAA;EACE,wCAAA;EACA,iBAAA;EACA,mBAAA;AACF;;AACA;EACE,mBAAA;EACA,oBAAA;EACA,kBAAA;AAEF;;AAAA;EACE,cAAA;EACA,kBAAA;AAGF;;AAAA;EACE,2BAAA;AAGF","sourcesContent":[".form-control {\n  background-color: transparent !important;\n  border-width: 1px;\n  border-radius: 10px;\n}\n.form-container {\n  margin-bottom: 10px;\n  padding-bottom: 20px;\n  position: relative;\n}\n.form-container label {\n  display: block;\n  margin-bottom: 5px;\n}\n\n.input-style {\n  margin-bottom: 0 !important;\n}\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 42855:
/*!***********************************************************************************!*\
  !*** ./src/app/scan/components/tabs-switch/tabs-switch.component.scss?ngResource ***!
  \***********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "", "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 62376:
/*!*************************************************************************!*\
  !*** ./src/app/scan/pages/scan-result/scan-result.page.scss?ngResource ***!
  \*************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".custom-height-separation {\n  height: 12vh !important;\n}", "",{"version":3,"sources":["webpack://./src/app/scan/pages/scan-result/scan-result.page.scss"],"names":[],"mappings":"AAAA;EACE,uBAAA;AACF","sourcesContent":[".custom-height-separation {\n  height: 12vh !important;\n}\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 6300:
/*!***********************************************************!*\
  !*** ./src/app/scan/pages/scan/scan.page.scss?ngResource ***!
  \***********************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ 92487);
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ 31386);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".overlay {\n  position: absolute;\n  height: 50vh;\n  width: 85%;\n  top: 25%;\n  left: 0;\n  right: 0;\n  max-height: 300px;\n  max-width: 300px;\n  margin-right: auto;\n  margin-left: auto;\n  --border-style: 4px solid white;\n  --border-space: 0px;\n}\n\n.overlay-element {\n  position: absolute;\n  width: 3rem;\n  height: 3rem;\n}\n\n.overlay .top-left {\n  border-left: var(--border-style);\n  border-top: var(--border-style);\n  top: var(--border-space);\n  left: var(--border-space);\n}\n\n.overlay .top-right {\n  border-right: var(--border-style);\n  border-top: var(--border-style);\n  top: var(--border-space);\n  right: var(--border-space);\n}\n\n.overlay .bottom-left {\n  border-left: var(--border-style);\n  border-bottom: var(--border-style);\n  bottom: var(--border-space);\n  left: var(--border-space);\n}\n\n.overlay .bottom-right {\n  border-right: var(--border-style);\n  border-bottom: var(--border-style);\n  bottom: var(--border-space);\n  right: var(--border-space);\n}\n\n.overlay-helper {\n  position: relative;\n  width: 100%;\n  height: 100%;\n}", "",{"version":3,"sources":["webpack://./src/app/scan/pages/scan/scan.page.scss"],"names":[],"mappings":"AAAA;EACE,kBAAA;EACA,YAAA;EACA,UAAA;EACA,QAAA;EACA,OAAA;EACA,QAAA;EACA,iBAAA;EACA,gBAAA;EACA,kBAAA;EACA,iBAAA;EACA,+BAAA;EACA,mBAAA;AACF;;AAEA;EACE,kBAAA;EACA,WAAA;EACA,YAAA;AACF;;AAEA;EACE,gCAAA;EACA,+BAAA;EACA,wBAAA;EACA,yBAAA;AACF;;AAEA;EACE,iCAAA;EACA,+BAAA;EACA,wBAAA;EACA,0BAAA;AACF;;AAEA;EACE,gCAAA;EACA,kCAAA;EACA,2BAAA;EACA,yBAAA;AACF;;AAEA;EACE,iCAAA;EACA,kCAAA;EACA,2BAAA;EACA,0BAAA;AACF;;AAEA;EACE,kBAAA;EACA,WAAA;EACA,YAAA;AACF","sourcesContent":[".overlay {\n  position: absolute;\n  height: 50vh;\n  width: 85%;\n  top: 25%;\n  left: 0;\n  right: 0;\n  max-height: 300px;\n  max-width: 300px;\n  margin-right: auto;\n  margin-left: auto;\n  --border-style: 4px solid white;\n  --border-space: 0px;\n}\n\n.overlay-element {\n  position: absolute;\n  width: 3rem;\n  height: 3rem;\n}\n\n.overlay .top-left {\n  border-left: var(--border-style);\n  border-top: var(--border-style);\n  top: var(--border-space);\n  left: var(--border-space);\n}\n\n.overlay .top-right {\n  border-right: var(--border-style);\n  border-top: var(--border-style);\n  top: var(--border-space);\n  right: var(--border-space);\n}\n\n.overlay .bottom-left {\n  border-left: var(--border-style);\n  border-bottom: var(--border-style);\n  bottom: var(--border-space);\n  left: var(--border-space);\n}\n\n.overlay .bottom-right {\n  border-right: var(--border-style);\n  border-bottom: var(--border-style);\n  bottom: var(--border-space);\n  right: var(--border-space);\n}\n\n.overlay-helper {\n  position: relative;\n  width: 100%;\n  height: 100%;\n}\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___.toString();


/***/ }),

/***/ 16363:
/*!*****************************************************************************************!*\
  !*** ./src/app/scan/components/door-selection/door-selection.component.html?ngResource ***!
  \*****************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-modal-menu #modal [height]=\"modalHeight\" *ngIf=\"isLoaded\" (hideClick)=\"hideClick.emit()\" [scrollable]=\"'hidden'\">\n  <ng-template #modalContent>\n    <app-door-select-form\n      [scanPage]=\"true\"\n      [isModal]=\"true\"\n      [isToggle]=\"false\"\n      [accessPoints]=\"accessPointList\"\n      (accessClick)=\"accessClick($event)\"\n      (viewMoreClick)=\"viewMore($event)\"></app-door-select-form>\n  </ng-template>\n</app-modal-menu>\n";

/***/ }),

/***/ 38760:
/*!*****************************************************************************************!*\
  !*** ./src/app/scan/components/identification/identification.component.html?ngResource ***!
  \*****************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"card card-style p-3 pb-0\" [ngClass]=\"getCardBackground()\">\n  <div class=\"pos d-flex justify-content-center\" *ngIf=\"loading\">\n    <ngx-skeleton-loader\n      [theme]=\"{\n        'border-radius': '50%',\n        width: '100px',\n        height: '100px',\n        border: '1px solid white',\n        'vertical-align': 'middle'\n      }\"></ngx-skeleton-loader>\n  </div>\n  <img\n    #image\n    (load)=\"hideLoader()\"\n    [src]=\"hasPicture ? (userImage | secure: 'url' | async) : userImage\"\n    class=\"avatar profile-img mx-auto\"\n    [ngStyle]=\"{ visibility: loading ? 'hidden' : '', position: loading ? 'absolute' : '' }\" />\n  <h4\n    class=\"font-400 font-16 lh-base text-center mt-1\"\n    [class.color-white]=\"!notAuthorized\"\n    *ngFor=\"let s of getSubtitle()\"\n    [innerHTML]=\"s\"></h4>\n  <h1\n    class=\"font-24 font-400 mx-auto w-fit pt-2 mb-0\"\n    [class.color-white]=\"!notAuthorized\"\n    [innerHTML]=\"getResultTitle()\"></h1>\n  <h6\n    *ngIf=\"result.invalidCode && notAuthorized\"\n    class=\"font-400 mx-auto w-fit pt-2 pb-2 text-center\"\n    [innerHTML]=\"'scan.notValidated' | translate\"></h6>\n  <h1\n    class=\"font-13 font-400 mx-auto w-fit\"\n    [class.color-white]=\"!notAuthorized\"\n    *ngIf=\"notAuthorized\"\n    [innerHTML]=\"getNextAccessTitle()\"></h1>\n  <h6\n    class=\"font-400 font-13 lh-base text-center fst-italic\"\n    [innerHTML]=\"getLastReported()\"\n    [class.color-white]=\"!notAuthorized\"></h6>\n</div>\n";

/***/ }),

/***/ 5656:
/*!*****************************************************************************************************!*\
  !*** ./src/app/scan/components/manual-authorization/manual-authorization.component.html?ngResource ***!
  \*****************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-modal-menu id=\"modal\" [height]=\"'h-fit'\">\n  <ng-template #modalContent>\n    <div class=\"mb-3\">\n      <div class=\"form-container mb-0 flex-wrap\">\n        <div class=\"input-style input-style-always-active has-borders no-icon validate-field w-100\">\n          <input type=\"name\" class=\"form-control validate-text\" [(ngModel)]=\"nameValue\" />\n\n          <label class=\"color-theme text-uppercase font-400 font-10\">{{ 'scan.nameInput' | translate }}</label>\n          <em class=\"color-highlight opacity-75 mt-0\">(opcional)</em>\n        </div>\n        <div class=\"input-style input-style-always-active has-borders no-icon validate-field w-100\">\n          <input type=\"name\" class=\"form-control validate-text\" [(ngModel)]=\"docValue\" />\n\n          <label class=\"color-theme text-uppercase font-400 font-10\">{{ 'scan.docInput' | translate }}</label>\n          <em class=\"color-highlight opacity-75 mt-0\">(opcional)</em>\n        </div>\n        <div class=\"input-style input-style-always-active has-borders no-icon validate-field w-100\">\n          <textarea class=\"form-control validate-text\" [(ngModel)]=\"notesValue\" rows=\"5\"></textarea>\n          <label class=\"font-10 font-400 opacity-100 text-uppercase\">\n            {{ 'scan.noteInput' | translate }}\n          </label>\n        </div>\n      </div>\n\n      <app-button\n        [label]=\"'scan.authorize' | translate\"\n        (buttonClick)=\"buttonClick.emit()\"\n        [status]=\"buttonState\"></app-button>\n    </div>\n  </ng-template>\n</app-modal-menu>\n";

/***/ }),

/***/ 92210:
/*!*************************************************************************************!*\
  !*** ./src/app/scan/components/scan-confirm/scan-confirm.component.html?ngResource ***!
  \*************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-modal-menu id=\"modal\" [height]=\"'h-fit'\">\n  <ng-template #modalContent>\n    <h3 class=\"font-400 pb-3\">{{ title }}</h3>\n    <div class=\"mb-3\">\n      <div class=\"form-container mb-0\">\n        <div class=\"input-style input-style-always-active has-borders no-icon w-100\">\n          <textarea\n            class=\"form-control\"\n            [(ngModel)]=\"model\"\n            id=\"input\"\n            (keyup.enter)=\"enterKey.emit(model)\"\n            rows=\"5\"></textarea>\n          <label class=\"font-10 font-400 opacity-100 text-uppercase\">\n            {{ 'scan.noteInput' | translate }}\n          </label>\n        </div>\n      </div>\n\n      <app-button [status]=\"buttonState\" [label]=\"buttonLabel\" (buttonClick)=\"buttonClick.emit(model)\"></app-button>\n    </div>\n  </ng-template>\n</app-modal-menu>\n";

/***/ }),

/***/ 96212:
/*!***********************************************************************************!*\
  !*** ./src/app/scan/components/tabs-switch/tabs-switch.component.html?ngResource ***!
  \***********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"content me-0 ms-0\">\n  <div class=\"tab-controls tabs-small\">\n    <a\n      role=\"button\"\n      class=\"p-1 rounded-xs-left\"\n      (click)=\"selectEntrance()\"\n      [class.no-click]=\"option === 0\"\n      [class.bg-highlight]=\"option === 0\"\n      >Entrada</a\n    >\n    <a\n      role=\"button\"\n      class=\"p-1 rounded-xs-right\"\n      (click)=\"selectDeparture()\"\n      [class.no-click]=\"option === 1\"\n      [class.bg-highlight]=\"option === 1\"\n      >Salida</a\n    >\n  </div>\n</div>\n";

/***/ }),

/***/ 86207:
/*!*************************************************************************!*\
  !*** ./src/app/scan/pages/scan-result/scan-result.page.html?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-page-layout\n  *ngIf=\"result\"\n  [footerSelectedOption]=\"footerOptions.scan\"\n  (back)=\"backClick.emit()\"\n  [title]=\"getTitle()\">\n  <div class=\"position-relative h-100\">\n    <app-identification [result]=\"result\"></app-identification>\n\n    <div class=\"card card-style p-2\" *ngIf=\"authorized\">\n      <app-tabs-switch\n        (entranceClick)=\"tabsClick.emit('entrance')\"\n        (departureClick)=\"tabsClick.emit('departure')\"></app-tabs-switch>\n      <div class=\"form-container mb-0\">\n        <div class=\"input-style input-style-always-active has-borders no-icon w-100\">\n          <textarea\n            [(ngModel)]=\"notesModel\"\n            class=\"form-control\"\n            id=\"input\"\n            (keyup.enter)=\"registerClick.emit(notesModel)\"></textarea>\n          <label class=\"font-10 font-400 opacity-100 text-uppercase\"> {{ 'scan.noteInput' | translate }} </label>\n        </div>\n      </div>\n\n      <app-button [label]=\"'scan.confirm' | translate\" (buttonClick)=\"registerClick.emit(notesModel)\"></app-button>\n    </div>\n\n    <ng-container *ngIf=\"notAuthorized\">\n      <div class=\"px-4 pb-3\">\n        <app-button\n          [reallocate]=\"false\"\n          [label]=\"'common.next' | translate\"\n          (buttonClick)=\"nextClick.emit()\"></app-button>\n      </div>\n    </ng-container>\n\n    <ng-template #accessTemplate let-ap let-isLast=\"isLast\">\n      <app-list-item\n        [id]=\"ap.id\"\n        [isLast]=\"isLast\"\n        [title]=\"getInvTitle(ap.invitation.motive)\"\n        [img]=\"ap.invitation.presentationImg[0]?.url\"\n        [topTexts]=\"getRecurrenceText(ap.invitation)\"\n        [subText]=\"ap.invitation.place\"\n        [subTextIcon]=\"['fas', 'map-marker']\"\n        [rightIcon]=\"undefined\">\n      </app-list-item>\n    </ng-template>\n\n    <app-list-container\n      *ngIf=\"!denied\"\n      [items]=\"result.accesses\"\n      [itemTemplate]=\"accessTemplate\"\n      [viewMore]=\"1\"\n      [viewMoreLabel]=\"'scan.viewAllAccess' | translate\">\n    </app-list-container>\n\n    <div class=\"px-4 pb-2\">\n      <ng-container *ngIf=\"denied\">\n        <app-button\n          [reallocate]=\"false\"\n          [label]=\"'common.next' | translate\"\n          (buttonClick)=\"nextClick.emit()\"></app-button>\n        <div class=\"custom-height-separation\"></div>\n      </ng-container>\n      <app-button\n        [reallocate]=\"false\"\n        *ngIf=\"notAuthorized\"\n        [label]=\"'scan.manualAuthorize' | translate\"\n        (buttonClick)=\"manualAuthorizeClick.emit()\"></app-button>\n    </div>\n    <div class=\"px-4 pb-2\" *ngIf=\"authorized\">\n      <app-button\n        [reallocate]=\"false\"\n        [label]=\"'common.moreActions' | translate\"\n        (buttonClick)=\"denyClick.emit()\"></app-button>\n    </div>\n  </div>\n</app-page-layout>\n";

/***/ }),

/***/ 61087:
/*!***********************************************************!*\
  !*** ./src/app/scan/pages/scan/scan.page.html?ngResource ***!
  \***********************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"overlay\" *ngIf=\"aps.length > 0\">\n  <div class=\"overlay-helper\">\n    <div class=\"overlay-element top-left\"></div>\n    <div class=\"overlay-element top-right\"></div>\n    <div class=\"overlay-element bottom-left\"></div>\n    <div class=\"overlay-element bottom-right\"></div>\n  </div>\n</div>\n<div class=\"scanner-ui\">\n  <div class=\"position-absolute top-20vh w-100\" *ngIf=\"aps.length === 0\">\n    <div class=\"shadow-icon w-75\" style=\"margin: 0 auto\">\n      <app-img-title\n        [faClass]=\"['fas', 'circle-exclamation']\"\n        [faStyleClass]=\"'color-white'\"\n        [title]=\"'scan.noData' | translate\"\n        [titleClass]=\"'font-400 font-24 lh-sm text-center pt-2 color-white'\"\n        [subtitle]=\"'scan.noDataSubtitle' | translate\"\n        [subtitleClass]=\"'font-400 font-16 lh-sm text-center pt-2 color-white'\"></app-img-title>\n    </div>\n  </div>\n  <fa-icon\n    role=\"button\"\n    (click)=\"close()\"\n    [icon]=\"['fas', 'xmark']\"\n    class=\"font-16 color-white scan-close-position shadow-icon\"></fa-icon>\n  <fa-icon\n    *ngIf=\"aps.length > 0\"\n    role=\"button\"\n    (click)=\"helpModal.show();\"\n    [icon]=\"['fas', 'circle-question']\"\n    class=\"font-16 color-white position-absolute bottom-60p left-20 shadow-icon\"></fa-icon>\n\n  <div\n    *ngIf=\"aps.length > 0\"\n    (click)=\"openDoorModal()\"\n    class=\"color-white mx-auto text-center h-fit w-fit position-absolute bottom-0 start-0 end-0 mx-auto mb-scanner-vh shadow-icon\">\n    <fa-icon role=\"button\" [icon]=\"['fas', 'door-closed']\" class=\"font-20 font-400 color-white\"></fa-icon>\n    <span class=\"position-relative d-block\">{{getSelectedString()}}</span>\n  </div>\n\n  <fa-icon\n    *ngIf=\"aps.length > 0\"\n    role=\"button\"\n    (click)=\"torch()\"\n    [icon]=\"['fas', 'bolt-lightning']\"\n    class=\"font-16 color-white position-absolute bottom-60p right-20 shadow-icon\"></fa-icon>\n</div>\n\n<app-door-selection\n  #doorSelect\n  (hideClick)=\"closeDoorModal()\"\n  [accessPointList]=\"aps\"\n  (accessPointSelected)=\"accessPointClick.emit($event)\"></app-door-selection>\n\n<app-modal-menu\n  #helpModal\n  [positioning]=\"'menu-box-detached menu-box-modal'\"\n  [height]=\"'h-fit'\"\n  [fullScreen]=\"false\"\n  [bgColor]=\"'bg-transparent'\">\n  <ng-template #modalContent>\n    <h6 class=\"font-400 font-15 text-center color-white mb-0 shadow-icon\">{{ 'scan.help' | translate }}</h6>\n  </ng-template>\n</app-modal-menu>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_scan_scan_module_ts.js.map